# CS6300 9 - Software Development

| Timestamp | Content |
|-----------|---------|
| 00:00:00,060 --> 00:00:01,970 | Now that we saw how software engineering was born and we |
| 00:00:01,970 --> 00:00:04,580 | saw some of the problems that led to the birth of software |
| 00:00:04,580 --> 00:00:07,020 | engineering. Let's see how we can do better. How can we |
| 00:00:07,020 --> 00:00:10,580 | preform software development in a smarter, in a better way, a more |
| 00:00:10,580 --> 00:00:13,150 | successful way? So what I'm going to show here is the |
| 00:00:13,150 --> 00:00:14,730 | way I see software development. To |
| 00:00:14,730 --> 00:00:17,080 | me software development is fundementally going |
| 00:00:17,080 --> 00:00:21,150 | from an abstract idea in somebody's head, for example, the customer's head, |
| 00:00:21,150 --> 00:00:25,300 | to a concrete system that actually implements that idea and hopefully it |
| 00:00:25,300 --> 00:00:27,640 | does it in the right way. And this is a very |
| 00:00:27,640 --> 00:00:31,290 | complex process. It can be overwhelming. So, unless we are talking about |
| 00:00:31,290 --> 00:00:34,800 | the trivial system, it's very complex for us to keep in mind |
| 00:00:34,800 --> 00:00:37,020 | all the different aspects of the systems, and to do all the |
| 00:00:37,020 --> 00:00:40,270 | different steps required to build this system, automatically. So that's when |
| 00:00:40,270 --> 00:00:43,630 | software processes come to the rescue. So what is a software process? |
| 00:00:43,630 --> 00:00:46,380 | A software process is nothing else but a way of breaking down |
| 00:00:46,380 --> 00:00:50,320 | this otherwise unmanageable task into smaller steps. In smaller steps that we |
| 00:00:50,320 --> 00:00:53,270 | can handle. And that can be tackled individually. So having a |
| 00:00:53,270 --> 00:00:56,580 | software process is of fundamental importance for several reasons. First of |
| 00:00:56,580 --> 00:00:59,530 | all, for non-trivial systems, you can't just do it by getting |
| 00:00:59,530 --> 00:01:01,680 | it, by just sitting down and developing. What you have to |
| 00:01:01,680 --> 00:01:04,629 | do instead is to break down the complexity in a systematic |
| 00:01:04,629 --> 00:01:08,250 | way. So software processes are normally systematic. And you need to |
| 00:01:08,250 --> 00:01:11,370 | break down this complexity, in a more or less formal way. |
| 00:01:11,370 --> 00:01:15,800 | So software processes are also a formal, or semiformal, way of |
| 00:01:15,800 --> 00:01:19,120 | discussing, or describing, how software should be developed. |
| 00:01:19,120 --> 00:01:19,120 | So what are the steps involved in developing software? |