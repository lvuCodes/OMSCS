# CS6300 68 - GIT Recap

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:02,212 | Now that we are done with our demo, I just want |
| 00:00:02,212 --> 00:00:05,910 | to go through a quick GIT recap to remind you of the |
| 00:00:05,910 --> 00:00:08,720 | main commands that we saw, and what they do. And you can |
| 00:00:08,720 --> 00:00:11,290 | also use these as sort of a reference when you work with |
| 00:00:11,290 --> 00:00:13,940 | GIT. And by the way, if you look around and you do |
| 00:00:13,940 --> 00:00:16,960 | a search, you can see that there's tons of examples on the |
| 00:00:16,960 --> 00:00:22,170 | web of GitHub tutorials, videos, examples, manuals. So feel free to |
| 00:00:22,170 --> 00:00:25,910 | explore. And I'm actually going to put some references to tutorials and |
| 00:00:25,910 --> 00:00:25,910 | videos that I found particularly useful in the notes for the class. |