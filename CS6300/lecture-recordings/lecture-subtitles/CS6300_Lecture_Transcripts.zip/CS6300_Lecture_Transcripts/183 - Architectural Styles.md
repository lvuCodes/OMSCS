# CS6300 183 - Architectural Styles

| Timestamp | Content |
|-----------|---------|
| 00:00:00,210 --> 00:00:01,569 | The last topic I want to cover in |
| 00:00:01,569 --> 00:00:04,939 | this lesson is architectural styles. So, let's see |
| 00:00:04,939 --> 00:00:07,400 | what those architectural styles are. There are certain |
| 00:00:07,400 --> 00:00:10,240 | design choices that when applied in a given context |
| 00:00:10,240 --> 00:00:14,420 | regularly result in solutions with superior properties. What |
| 00:00:14,420 --> 00:00:17,290 | this means is that, compared to other possible alternatives, |
| 00:00:17,290 --> 00:00:20,952 | these solutions are more elegant, effective, efficient, dependable, |
| 00:00:20,952 --> 00:00:25,560 | evolve-able, scale-able, and so on. Architectural styles capture exactly |
| 00:00:25,560 --> 00:00:28,490 | these solutions. They capture idioms that we can |
| 00:00:28,490 --> 00:00:30,870 | use when designing a system. For a more formal |
| 00:00:30,870 --> 00:00:34,160 | definition, let's look how Mary Shaw and David Garlan |
| 00:00:34,160 --> 00:00:37,480 | define a architectural style. They say that an architectural |
| 00:00:37,480 --> 00:00:40,000 | style defines a family of systems in terms |
| 00:00:40,000 --> 00:00:43,550 | of a pattern of structural organization; a vocabulary of |
| 00:00:43,550 --> 00:00:47,880 | components and connectors and constraints on how these components |
| 00:00:47,880 --> 00:00:50,620 | and connectors can be combined. So in summary we |
| 00:00:50,620 --> 00:00:53,650 | can say that an architectural style is a named collection |
| 00:00:53,650 --> 00:00:57,680 | of architectural design decisions applicable in a given context. And I |
| 00:00:57,680 --> 00:01:00,100 | want to stress that it is important to study and |
| 00:01:00,100 --> 00:01:04,670 | know these architectural styles for several reasons. Because knowing them allows |
| 00:01:04,670 --> 00:01:07,660 | us to avoid reinventing the wheel. It also allows us |
| 00:01:07,660 --> 00:01:10,330 | to choose the right solution to a known problem and in |
| 00:01:10,330 --> 00:01:12,910 | some cases it even allows us to move on and |
| 00:01:12,910 --> 00:01:16,400 | discover even more advanced styles if we know the basic ones. |
| 00:01:16,400 --> 00:01:19,340 | So we should be familiar with architectural styles, what |
| 00:01:19,340 --> 00:01:22,000 | they are, and in which context they work, and |
| 00:01:22,000 --> 00:01:23,800 | in which context they do not work. So as |
| 00:01:23,800 --> 00:01:23,800 | to be able to apply them in the right situations. |