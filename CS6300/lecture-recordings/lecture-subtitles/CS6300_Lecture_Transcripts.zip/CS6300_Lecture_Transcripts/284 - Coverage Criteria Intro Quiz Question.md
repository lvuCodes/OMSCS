# CS6300 284 - Coverage Criteria Intro Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,620 --> 00:00:03,310 | Now let's see if we are all on the same page |
| 00:00:03,310 --> 00:00:07,180 | on the concept of testing specifications, and we're going to do that through |
| 00:00:07,180 --> 00:00:09,280 | a quiz. What I would like for you to do is to |
| 00:00:09,280 --> 00:00:12,830 | tell me, what are some possible test specifications that will satisfy the |
| 00:00:12,830 --> 00:00:15,380 | requirements that we just saw? And I want you to express this |
| 00:00:15,380 --> 00:00:17,270 | specification in terms of constraints on |
| 00:00:17,270 --> 00:00:19,166 | the inputs. Which means, what constraints |
| 00:00:19,166 --> 00:00:23,130 | should the input satisfy in order for this statement to be executed, |
| 00:00:23,130 --> 00:00:26,210 | and this statement to be executed, and you can write your answer |
| 00:00:26,210 --> 00:00:26,210 | here in these two slots. |