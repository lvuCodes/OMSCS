# CS6300 294 - Subsumption Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,080 --> 00:00:02,220 | So now that we introduced an additional criterion, |
| 00:00:02,220 --> 00:00:04,290 | let's have a quiz to see whether everybody |
| 00:00:04,290 --> 00:00:06,410 | understood the concept of subsumption. We know that |
| 00:00:06,410 --> 00:00:09,490 | branch coverage subsumes statement coverage, but what about condition |
| 00:00:09,490 --> 00:00:12,230 | coverage? Does it subsume branch coverage? Is it |
| 00:00:12,230 --> 00:00:13,720 | the case that all of the test which |
| 00:00:13,720 --> 00:00:16,980 | satisfy condition coverage will also satisfy branch coverage? |
| 00:00:16,980 --> 00:00:16,980 | Think about it, and answer either yes or no. |