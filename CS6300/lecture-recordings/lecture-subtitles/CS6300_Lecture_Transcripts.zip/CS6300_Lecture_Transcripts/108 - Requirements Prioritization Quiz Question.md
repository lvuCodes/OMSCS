# CS6300 108 - Requirements Prioritization Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:03,090 | Now that we talked about requirements prioritization, let's try to see |
| 00:00:03,090 --> 00:00:06,110 | how this might work in practice. Imagine that you have collected the |
| 00:00:06,110 --> 00:00:09,560 | folowing set of five requirements for an ATM system, but only |
| 00:00:09,560 --> 00:00:12,680 | have resources to satisfy two of them. Possibly three. I would like |
| 00:00:12,680 --> 00:00:15,550 | for you to look at this list and suitablely prioritize the |
| 00:00:15,550 --> 00:00:19,220 | requirements by marking them as mandatory, in this case you're going to put |
| 00:00:19,220 --> 00:00:21,840 | an M in the space. Nice to have, in this case you're |
| 00:00:21,840 --> 00:00:25,350 | going to put an N. Or superfluous, in this case you're going to put |
| 00:00:25,350 --> 00:00:28,005 | an S. This is the set of requirements, the first one |
| 00:00:28,005 --> 00:00:30,342 | says that the system shall check the PIN of the ATM |
| 00:00:30,342 --> 00:00:33,863 | card before allowing the customer to perform an operation. The second |
| 00:00:33,863 --> 00:00:37,575 | says that the system shall perform an additional biometric verification of |
| 00:00:37,575 --> 00:00:40,881 | the customer identity for example a check of the customer's finger |
| 00:00:40,881 --> 00:00:44,294 | prints before it allows the customer to perform an operation. Then |
| 00:00:44,294 --> 00:00:47,466 | we have that the system shall allow customers to withdraw cash |
| 00:00:47,466 --> 00:00:50,580 | using an ATM card. The system shall allow customer to deposit |
| 00:00:50,580 --> 00:00:53,350 | money using an ATM card. And the system shall allow |
| 00:00:53,350 --> 00:00:56,330 | customers to change the pin of their ATM card. So again, |
| 00:00:56,330 --> 00:01:00,600 | mark those as mandatory, nice to have, or superfluous considering the |
| 00:01:00,600 --> 00:01:00,600 | fact that you can satisfy only two, possibly three of them. |