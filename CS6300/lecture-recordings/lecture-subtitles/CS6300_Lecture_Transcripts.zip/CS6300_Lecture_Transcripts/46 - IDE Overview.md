# CS6300 46 - IDE Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,130 --> 00:00:05,680 | So, now let's look in a little more detail to what is an IDE. An IDE is a |
| 00:00:05,680 --> 00:00:09,790 | software application that supports software developers in many of |
| 00:00:09,790 --> 00:00:13,840 | their everyday tasks. It has many useful features. Most IDEs |
| 00:00:13,840 --> 00:00:16,790 | provide views that can be used to navigate, project |
| 00:00:16,790 --> 00:00:20,140 | resources from different perspectives. For example, you might want to |
| 00:00:20,140 --> 00:00:22,390 | look at your code differently when you're writing code, |
| 00:00:22,390 --> 00:00:25,950 | and when you're debugging. They also normally provide an intelligent |
| 00:00:25,950 --> 00:00:29,380 | source code editor. For example, an editor that will allow you |
| 00:00:29,380 --> 00:00:32,110 | to browse the documentation when you're writing a code that |
| 00:00:32,110 --> 00:00:35,780 | uses a specific method, or that will give you autocompletion when |
| 00:00:35,780 --> 00:00:37,990 | you start writing the name of an object and you want to |
| 00:00:37,990 --> 00:00:40,820 | get the methods for that object. And all of these things |
| 00:00:40,820 --> 00:00:43,420 | can be very useful while you're developing and can save you a |
| 00:00:43,420 --> 00:00:47,750 | lot of time. Modern IDE's will also normally give you support for |
| 00:00:47,750 --> 00:00:49,540 | version control systems that then you |
| 00:00:49,540 --> 00:00:52,490 | can use for softer configuration management. |
| 00:00:52,490 --> 00:00:55,720 | And we're going to discuss in detail version control systems in |
| 00:00:55,720 --> 00:00:58,380 | the next tools of the trade lesson, and we're also |
| 00:00:58,380 --> 00:01:01,135 | going to see how it can be integrated within an IDE. |
| 00:01:01,135 --> 00:01:04,730 | IDEs also give you builders so they give you build automation |
| 00:01:04,730 --> 00:01:08,070 | tools, they give you runtime support. So that you can |
| 00:01:08,070 --> 00:01:10,960 | run your projects from within the IDE and, for example, |
| 00:01:10,960 --> 00:01:14,550 | observe some aspects of the execution. In addition to giving |
| 00:01:14,550 --> 00:01:17,562 | you support for the runtime, they give you support for testing. |
| 00:01:17,562 --> 00:01:21,267 | Many IDEs allow you to run tests from within |
| 00:01:21,267 --> 00:01:23,520 | the IDE and to check the results of the tests |
| 00:01:23,520 --> 00:01:26,300 | from within the IDE. Not only that. Normally, after you |
| 00:01:26,300 --> 00:01:28,210 | run your tests, if there are some test cases that |
| 00:01:28,210 --> 00:01:31,500 | fail, you can also use your IDEs to do debugging. |
| 00:01:31,500 --> 00:01:35,620 | Many IDEs include graphical debuggers. Debuggers will allow you to |
| 00:01:35,620 --> 00:01:39,400 | navigate through the code, set which points, stop and restart |
| 00:01:39,400 --> 00:01:43,160 | the execution. Inspect variables, and do all of the activities |
| 00:01:43,160 --> 00:01:46,320 | that help debugging. And, to help you be more efficient |
| 00:01:46,320 --> 00:01:49,440 | and more effective when you do debugging. And into addition to |
| 00:01:49,440 --> 00:01:52,760 | all these features that are listed here IDEs can normally provide |
| 00:01:52,760 --> 00:01:52,760 | you even more features through a mechanishm that is called plugins. |