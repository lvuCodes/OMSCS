# CS6300 296 - Branch and Condition Coverage

| Timestamp | Content |
|-----------|---------|
| 00:00:00,052 --> 00:00:03,407 | Let's go back to our test criteria subsumption representation, where |
| 00:00:03,407 --> 00:00:06,770 | we already had branch coverage and statement coverage. In this case, |
| 00:00:06,770 --> 00:00:09,350 | if we want to add condition coverage to this page, we |
| 00:00:09,350 --> 00:00:12,050 | have to put it here on this side, with no relationship |
| 00:00:12,050 --> 00:00:15,830 | of subsumption with either branch coverage or statement coverage, which |
| 00:00:15,830 --> 00:00:19,270 | means that the criteria are not comparable. So now let's consider |
| 00:00:19,270 --> 00:00:22,108 | again our last example, and let's use a different test |
| 00:00:22,108 --> 00:00:25,060 | with this time. We still have two tests, but the first |
| 00:00:25,060 --> 00:00:27,575 | one has x is equal to 0 and y is equal to minus |
| 00:00:27,575 --> 00:00:30,370 | 5. And the second one, x is equal to 5 and y is |
| 00:00:30,370 --> 00:00:33,350 | equal to 5 as well. Let's see what happens in terms of condition |
| 00:00:33,350 --> 00:00:36,740 | coverage, when we run these tests. If we look at the first condition, x |
| 00:00:36,740 --> 00:00:39,820 | is equal to 0. It is both true, for the first test case, |
| 00:00:39,820 --> 00:00:43,240 | and false for the second one. As for the second condition, y greater |
| 00:00:43,240 --> 00:00:45,800 | than 0, it is false for the first test case and true for |
| 00:00:45,800 --> 00:00:47,770 | the second one. Therefore we've achieved a |
| 00:00:47,770 --> 00:00:50,400 | 100% condition coverage with these two tests. |
| 00:00:50,400 --> 00:00:54,020 | But what about branch coverage? If we consider the whole predicate, |
| 00:00:54,020 --> 00:00:56,620 | instead of just the individual conditions, let's see what happens for the |
| 00:00:56,620 --> 00:00:59,090 | two test cases. If we look at the first one, because |
| 00:00:59,090 --> 00:01:02,200 | x is equal to 0, the overall predicate is true. As for |
| 00:01:02,200 --> 00:01:05,750 | the second one, because the second condition is true, the overall |
| 00:01:05,750 --> 00:01:09,110 | predicate is true. In other words, despite the fact that we're exercising |
| 00:01:09,110 --> 00:01:12,520 | all the possible values for the two conditions, the overall predicate is |
| 00:01:12,520 --> 00:01:16,540 | always true. And therefore, we're covering only one of the two branches. |
| 00:01:16,540 --> 00:01:19,591 | So our coverage will be 50%. This is the reason |
| 00:01:19,591 --> 00:01:22,231 | why normally the two criteria that we just saw, decision |
| 00:01:22,231 --> 00:01:26,205 | coverage, and condition coverage are considered together. And the resulting |
| 00:01:26,205 --> 00:01:30,320 | criterion is called branch and condition coverage, or also decision |
| 00:01:30,320 --> 00:01:33,030 | and condition coverage. At this point the test requirements and |
| 00:01:33,030 --> 00:01:35,590 | the coverage measure should be pretty straight forward, because they're |
| 00:01:35,590 --> 00:01:38,120 | just considering the two criteria together. As far as the |
| 00:01:38,120 --> 00:01:39,960 | requirements are concerned, they include |
| 00:01:39,960 --> 00:01:41,880 | all the branches and individual conditions |
| 00:01:41,880 --> 00:01:44,580 | in the program. Where as the coverage measure is computed |
| 00:01:44,580 --> 00:01:44,580 | considering both coverage measures, both branch coverage and condition coverage. |