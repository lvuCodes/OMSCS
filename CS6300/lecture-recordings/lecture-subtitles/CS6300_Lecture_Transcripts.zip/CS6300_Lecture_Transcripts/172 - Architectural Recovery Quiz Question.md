# CS6300 172 - Architectural Recovery Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:03,070 | Now that we discussed some important concepts about |
| 00:00:03,070 --> 00:00:05,060 | software architectures, I would like for you to |
| 00:00:05,060 --> 00:00:07,290 | tell me which of the following sentences is |
| 00:00:07,290 --> 00:00:11,420 | true. Prescriptive architecture and descriptive architecture are typically the |
| 00:00:11,420 --> 00:00:15,970 | same. Architectural drift results in unnecessarily complex architectures. |
| 00:00:15,970 --> 00:00:20,320 | Architectural erosion is less problematic than architectural drift. And |
| 00:00:20,320 --> 00:00:22,660 | the best way to improve a degraded architecture, |
| 00:00:22,660 --> 00:00:25,250 | is to keep fixing the code until the system |
| 00:00:25,250 --> 00:00:25,250 | starts looking and behaving as expected. Which of these sentences is true? |