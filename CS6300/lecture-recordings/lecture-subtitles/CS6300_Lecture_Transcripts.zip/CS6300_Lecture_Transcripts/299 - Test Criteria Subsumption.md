# CS6300 299 - Test Criteria Subsumption

| Timestamp | Content |
|-----------|---------|
| 00:00:00,280 --> 00:00:03,400 | So we can now update our test criteria subsumption. We start |
| 00:00:03,400 --> 00:00:06,700 | from this situation in which there are no relationship between condition |
| 00:00:06,700 --> 00:00:09,650 | coverage, branch coverage and statement coverage. And when we add branch |
| 00:00:09,650 --> 00:00:12,160 | and condition coverage, we can mark the fact that branch and |
| 00:00:12,160 --> 00:00:14,470 | condition coverage subsumes branch coverage |
| 00:00:14,470 --> 00:00:16,370 | and also subsumes condition coverage, for |
| 00:00:16,370 --> 00:00:19,660 | the same reason. Therefore, this is a stronger criterion than both |
| 00:00:19,660 --> 00:00:23,100 | branch coverage and condition coverage, and of course indirectly also soft |
| 00:00:23,100 --> 00:00:25,330 | statement coverage. So once more, to make sure we are all |
| 00:00:25,330 --> 00:00:29,255 | on the same page, if I develop a test rate that satisfies branch and condition |
| 00:00:29,255 --> 00:00:31,380 | coverage, the same test will satisfy also |
| 00:00:31,380 --> 00:00:31,380 | branch coverage, statement coverage and condition coverage, necessarily. |