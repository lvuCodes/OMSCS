# CS6300 14 - Preliminary Questions Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,180 --> 00:00:03,450 | Studies has shown that, on average, developers produce between |
| 00:00:03,450 --> 00:00:07,030 | 50 and 100 lines of code a day. And that |
| 00:00:07,030 --> 00:00:09,530 | might not seem much. Why, why only 50 to |
| 00:00:09,530 --> 00:00:11,580 | 100 lines of code in a whole day? And the |
| 00:00:11,580 --> 00:00:14,350 | answer is because coding is not everything. When you |
| 00:00:14,350 --> 00:00:17,020 | develop a system writing code is not the only thing |
| 00:00:17,020 --> 00:00:18,890 | you have to do. It's not the only activity that |
| 00:00:18,890 --> 00:00:18,890 | you have to perform. And that's a very important point. |