# CS6300 42 - Classic Mistakes Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,060 --> 00:00:01,650 | To conclude this lesson, I'm going to have a |
| 00:00:01,650 --> 00:00:03,650 | simple quiz and what I'm going to ask you |
| 00:00:03,650 --> 00:00:07,950 | is, which kind of mistake adding people to a late project is? And you can pick |
| 00:00:07,950 --> 00:00:10,540 | between a people mistake, a product mistake, a |
| 00:00:10,540 --> 00:00:12,830 | technology mistake, or maybe this is not a |
| 00:00:12,830 --> 00:00:12,830 | mistake at all, it is actually okay to add people to a project that is late. |