# CS6300 205 - Factory Method Pattern

| Timestamp | Content |
|-----------|---------|
| 00:00:00,012 --> 00:00:02,350 | Let's now look at the first design pattern that we |
| 00:00:02,350 --> 00:00:05,700 | will discuss, the factory method pattern. And I'm going to start |
| 00:00:05,700 --> 00:00:09,220 | by discussing the intent of the pattern and its applicability. |
| 00:00:09,220 --> 00:00:12,210 | As far as the intent is concerned, the factory method pattern |
| 00:00:12,210 --> 00:00:16,690 | allows for creating objects without specifying their class, by invoking |
| 00:00:16,690 --> 00:00:19,370 | what we call a factory method. And what that is, is |
| 00:00:19,370 --> 00:00:22,680 | a method whose main goal is to create class instances. |
| 00:00:22,680 --> 00:00:25,510 | So when is this pattern useful? So when is it applicable? |
| 00:00:25,510 --> 00:00:28,080 | For example, it is applicable in cases in which a class |
| 00:00:28,080 --> 00:00:31,890 | cannot anticipate the type of object it must create. That is, |
| 00:00:31,890 --> 00:00:34,800 | the type of an object is not known at compile time, |
| 00:00:34,800 --> 00:00:37,800 | is not known until the code runs. A typical example of |
| 00:00:37,800 --> 00:00:40,500 | this, are frameworks. So if you ever used a framework, you |
| 00:00:40,500 --> 00:00:44,280 | will know that, normally, frameworks only know about interfaces and abstract |
| 00:00:44,280 --> 00:00:47,450 | classes. So the exact type of the objects of these classes |
| 00:00:47,450 --> 00:00:50,840 | is only known at runtime. The second case in which the factory |
| 00:00:50,840 --> 00:00:53,835 | method pattern is applicable, is when a class wants its |
| 00:00:53,835 --> 00:00:57,160 | subclasses to specify the type of objects it creates. And we'll |
| 00:00:57,160 --> 00:00:59,920 | see an example of this in a minute. Finally, factory |
| 00:00:59,920 --> 00:01:03,580 | method patterns are applicable when a class needs control over the |
| 00:01:03,580 --> 00:01:06,760 | creation of its objects. And in this case, one possible |
| 00:01:06,760 --> 00:01:09,380 | example is when there is a limit on the number of |
| 00:01:09,380 --> 00:01:12,930 | objects that can be created. Special example, it's a singleton. If |
| 00:01:12,930 --> 00:01:15,840 | you're familiar with a singleton, a singleton is a class for |
| 00:01:15,840 --> 00:01:18,930 | which only one instance can be created. The factory method pattern |
| 00:01:18,930 --> 00:01:21,760 | is perfect in these cases, because it allows to control how many |
| 00:01:21,760 --> 00:01:24,640 | objects get created. So in this case, it would allow the creation |
| 00:01:24,640 --> 00:01:27,290 | only of a single object. And from the second time that it |
| 00:01:27,290 --> 00:01:30,040 | is invoked, it will just return the object that was previously |
| 00:01:30,040 --> 00:01:33,700 | created. Now let's go ahead and see how this pattern actually works, |
| 00:01:33,700 --> 00:01:37,100 | and let's do that by discussing the structure and the participants for |
| 00:01:37,100 --> 00:01:41,330 | the pattern. The structure that is represented here, using the UML notation, |
| 00:01:41,330 --> 00:01:45,530 | includes three classes, the Creator, the ConcreteCreator, |
| 00:01:45,530 --> 00:01:48,000 | and the Product. The Creator provides the |
| 00:01:48,000 --> 00:01:50,710 | interface for the factory method. So this |
| 00:01:50,710 --> 00:01:53,200 | here, is the interface for the factory method |
| 00:01:53,200 --> 00:01:55,950 | that, when invoked, returns an object of |
| 00:01:55,950 --> 00:01:59,440 | type Product. The ConcreteCreator provides the actual |
| 00:01:59,440 --> 00:02:02,350 | method for creating the Product. So this |
| 00:02:02,350 --> 00:02:06,170 | method is a concrete implementation of this interface. |
| 00:02:06,170 --> 00:02:10,630 | Finally, the Product is the object created by the factory method. So |
| 00:02:10,630 --> 00:02:12,350 | summarizing, we have the interface for |
| 00:02:12,350 --> 00:02:14,300 | the factory method, the actual implementation of |
| 00:02:14,300 --> 00:02:17,540 | the summary method, and the object that is created by the factory method, |
| 00:02:17,540 --> 00:02:17,540 | when it is invoked. So let's look at an example of this pattern. |