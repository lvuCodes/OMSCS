# CS6300 233 - Phases and Iterations

| Timestamp | Content |
|-----------|---------|
| 00:00:00,170 --> 00:00:02,210 | So now I would like to wrap up this lesson |
| 00:00:02,210 --> 00:00:05,720 | by going back to our discussion of rational unified process |
| 00:00:05,720 --> 00:00:08,630 | phases and iterations. So to do that I'm going to bring |
| 00:00:08,630 --> 00:00:12,480 | back the presentation that I used before, the summary representation |
| 00:00:12,480 --> 00:00:16,840 | about phases and traditional software engineering activities. And I want to |
| 00:00:16,840 --> 00:00:19,720 | use this representation to stress and discuss a couple of |
| 00:00:19,720 --> 00:00:22,140 | things. Mainly I want to recap it because I think |
| 00:00:22,140 --> 00:00:25,480 | it is very important. What is the relation between the rational |
| 00:00:25,480 --> 00:00:29,270 | unified process, and the traditional software engineering phases, and software |
| 00:00:29,270 --> 00:00:31,540 | engineering activities? And I like to do it now that |
| 00:00:31,540 --> 00:00:33,648 | we have discussed the phases in a little more detail. |
| 00:00:33,648 --> 00:00:35,920 | So I want to make sure that it is clear by now |
| 00:00:35,920 --> 00:00:39,660 | how and when the traditional software engineering activities, the ones |
| 00:00:39,660 --> 00:00:42,620 | listed here, take place in the context of the RUP |
| 00:00:42,620 --> 00:00:45,850 | phases, the four listed up here. For instance, it should |
| 00:00:45,850 --> 00:00:50,410 | be clear why implementation takes place mainly in the construction phase. |
| 00:00:50,410 --> 00:00:54,140 | Why requirements engineering is prominent in the elaboration phase |
| 00:00:54,140 --> 00:00:58,290 | and why deployment activities occur mostly in the transition phase, |
| 00:00:58,290 --> 00:01:00,120 | and so on. So it should be clear now |
| 00:01:00,120 --> 00:01:03,930 | why the activities are so distributed in the four phases. |
| 00:01:03,930 --> 00:01:06,130 | It should also be clear that although there is |
| 00:01:06,130 --> 00:01:09,350 | normally one main phase for each activity, the activities really |
| 00:01:09,350 --> 00:01:12,550 | span multiple phases. Which is actually one of the interesting |
| 00:01:12,550 --> 00:01:15,580 | aspect of RUP. So the fact that you're not really |
| 00:01:15,580 --> 00:01:19,700 | done with an activity even in later phases. Why? Well, because that allows |
| 00:01:19,700 --> 00:01:22,070 | you, in subsequent iterations, to address |
| 00:01:22,070 --> 00:01:22,070 | problems that came up in previous iterations. |