# CS6300 287 - Coverage Criteria Intro Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:02,360 | In this case like in many other cases, there's not just a |
| 00:00:02,360 --> 00:00:05,550 | single right answer because you can build many test cases that will |
| 00:00:05,550 --> 00:00:09,730 | satisfy this test specification. So for example, we could pick value 3 |
| 00:00:09,730 --> 00:00:13,640 | for a and value 9 for b. Those satisfy the specification because a |
| 00:00:13,640 --> 00:00:16,400 | plus b is equal to 12 and therefore is greater than 0, |
| 00:00:16,400 --> 00:00:19,470 | and therefore this is a test case that implements this test specification. |
| 00:00:19,470 --> 00:00:21,960 | And in terms of results, what we expect to see is in |
| 00:00:21,960 --> 00:00:25,200 | the case of a result greater than 0, the caller should be red, |
| 00:00:25,200 --> 00:00:28,109 | and the upper value should be 12. And obviously for this test |
| 00:00:28,109 --> 00:00:30,971 | specification, we just need to pick two inputs such that the sum |
| 00:00:30,971 --> 00:00:33,674 | of the two inputs is less than 0. So for example, we |
| 00:00:33,674 --> 00:00:37,125 | could pick minus 5 and minus 8. The output color in this |
| 00:00:37,125 --> 00:00:40,230 | case is going to be blue, and the output value is going to be |
| 00:00:40,230 --> 00:00:43,780 | minus 13. So, what we just saw is basically how we can |
| 00:00:43,780 --> 00:00:47,060 | go from a piece of code to a set of requirements, which |
| 00:00:47,060 --> 00:00:50,260 | are the interesting aspects of the code that we want to exercise. How we |
| 00:00:50,260 --> 00:00:52,800 | can satisfy the requirements by finding |
| 00:00:52,800 --> 00:00:54,700 | the right test specifications, and then how |
| 00:00:54,700 --> 00:00:58,450 | we can initiate the test specifications into actual test cases. And this is |
| 00:00:58,450 --> 00:01:01,010 | what we will do in general when doing white books testing. And we'll |
| 00:01:01,010 --> 00:01:02,520 | do things likely different way, depending on |
| 00:01:02,520 --> 00:01:02,520 | the specific criteria that we are considering. |