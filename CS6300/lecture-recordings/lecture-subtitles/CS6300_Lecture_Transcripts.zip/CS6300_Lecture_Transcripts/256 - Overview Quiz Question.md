# CS6300 256 - Overview Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,740 --> 00:00:02,780 | So, now I want to do a little quiz about |
| 00:00:02,780 --> 00:00:05,530 | identifying testable features. Let's consider |
| 00:00:05,530 --> 00:00:07,700 | this simple problem called printSum. |
| 00:00:07,700 --> 00:00:09,680 | We won't see the implementation because we are doing black-box |
| 00:00:09,680 --> 00:00:12,780 | testing. And all we need to know is that printSum takes |
| 00:00:12,780 --> 00:00:15,550 | two integers, a and b, and prints the sum of |
| 00:00:15,550 --> 00:00:17,540 | these two numbers. So what I want to ask, is |
| 00:00:17,540 --> 00:00:20,700 | how many independently testable features do we have here? Do |
| 00:00:20,700 --> 00:00:20,700 | we have one, two, three features? Or more than three features? |