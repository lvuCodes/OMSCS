# CS6300 291 - Control Flow Graphs

| Timestamp | Content |
|-----------|---------|
| 00:00:00,320 --> 00:00:03,450 | Let's look at the code for PrintSum in a slightly different way |
| 00:00:03,450 --> 00:00:06,140 | by making something explicit. If we go through the code, we can |
| 00:00:06,140 --> 00:00:08,578 | see that the, the code does something in that case, if the |
| 00:00:08,578 --> 00:00:11,720 | result greater then zero, does something else if the result is not |
| 00:00:11,720 --> 00:00:14,890 | greater than zero but is less than zero, and otherwise in the |
| 00:00:14,890 --> 00:00:17,800 | case in which neither of these two conditions is true. Nothing really |
| 00:00:17,800 --> 00:00:19,090 | happens. So we're going to make that |
| 00:00:19,090 --> 00:00:21,290 | explicit, we're going to say here, otherwise |
| 00:00:21,290 --> 00:00:25,430 | do nothing, which is exactly our problem, the code does nothing, in this |
| 00:00:25,430 --> 00:00:28,380 | case where it should do something. So now, let's look again in |
| 00:00:28,380 --> 00:00:31,470 | our test cases, let's consider the first one, and I'm going to go a |
| 00:00:31,470 --> 00:00:34,410 | little faster in this case, because we already saw what happens If |
| 00:00:34,410 --> 00:00:37,890 | we execute the first test case, we get to this point, we execute |
| 00:00:37,890 --> 00:00:40,710 | this statement, and then we just jump to the end, as we |
| 00:00:40,710 --> 00:00:44,020 | saw. Now we, if we execute the second test case, we do the |
| 00:00:44,020 --> 00:00:46,740 | same, we get to the else statement, the condition for the if is |
| 00:00:46,740 --> 00:00:50,770 | true, and therefore we execute this statement. And we never reached this point |
| 00:00:50,770 --> 00:00:53,320 | for either of the test cases. So how can we express |
| 00:00:53,320 --> 00:00:56,470 | this? In order to do that, I'm going to introduce a very useful |
| 00:00:56,470 --> 00:01:00,450 | concept. The concept of control flow graphs. The control flow graphs |
| 00:01:00,450 --> 00:01:03,310 | is just a representation for the code that is very convenient when |
| 00:01:03,310 --> 00:01:06,030 | we run our reason about the code and its structure. And |
| 00:01:06,030 --> 00:01:09,910 | it's a fairly simple one that represents statement with notes and the |
| 00:01:09,910 --> 00:01:12,900 | flow of control within the code with edges. So here's an |
| 00:01:12,900 --> 00:01:16,180 | example of control flow graph for this code. There is the entry |
| 00:01:16,180 --> 00:01:19,790 | point of the code right here, then our statement in which we |
| 00:01:19,790 --> 00:01:23,320 | assign the result of A plus B to variable result. Our if |
| 00:01:23,320 --> 00:01:25,720 | statement and as you can see the if statement it's got two |
| 00:01:25,720 --> 00:01:28,930 | branches coming out of it, because based on the outcome of this |
| 00:01:28,930 --> 00:01:32,376 | predicate we will go one way or the other. In fact normally |
| 00:01:32,376 --> 00:01:36,000 | what we do, we will label this edges accordingly. So for example, |
| 00:01:36,000 --> 00:01:38,580 | here we will say that this is the label to be executed |
| 00:01:38,580 --> 00:01:41,470 | when the predicate is true. And this is the label that is executed |
| 00:01:41,470 --> 00:01:44,120 | when the predicate is false. Now, at this point, similar |
| 00:01:44,120 --> 00:01:47,080 | thing, statement five which corresponds with this one, we have another |
| 00:01:47,080 --> 00:01:49,650 | if statement and if that statement is true, then we get |
| 00:01:49,650 --> 00:01:51,830 | to this point and if it's false, we get to this |
| 00:01:51,830 --> 00:01:54,370 | point. So as you can see, this graph represents my |
| 00:01:54,370 --> 00:01:57,040 | code, in a much more intuitive way, because I can see |
| 00:01:57,040 --> 00:02:00,650 | right away where the control flows, while I execute the code. |
| 00:02:00,650 --> 00:02:01,730 | So we're going to use this |
| 00:02:01,730 --> 00:02:01,730 | representation to introduce further coverage criteria. |