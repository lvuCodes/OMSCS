# CS6300 28 - Spiral Process

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:02,600 | The next model that we will discuss is the spiral |
| 00:00:02,600 --> 00:00:05,630 | model, which was first described by Barry Boehm, which is |
| 00:00:05,630 --> 00:00:08,010 | the professor that we interviewed at the beginning of this |
| 00:00:08,010 --> 00:00:12,240 | lesson. In his paper from 1986 that was entitled A Spiral |
| 00:00:12,240 --> 00:00:15,730 | Model of Software Development and Enhancement. And one of the |
| 00:00:15,730 --> 00:00:18,520 | main characteristics of that paper is that it was describing the |
| 00:00:18,520 --> 00:00:21,670 | spiral model using a diagram, which is the one that |
| 00:00:21,670 --> 00:00:25,130 | I'm showing you here, and this diagram has become very very |
| 00:00:25,130 --> 00:00:27,950 | popular, and you probably saw it either in this |
| 00:00:27,950 --> 00:00:30,400 | form or one of the many variations of the |
| 00:00:30,400 --> 00:00:32,680 | diagram. So I'm not going to discuss all of |
| 00:00:32,680 --> 00:00:34,770 | the details of the spiral model, but I just want to |
| 00:00:34,770 --> 00:00:37,510 | give you an idea of its main characteristics. The |
| 00:00:37,510 --> 00:00:41,580 | spiral model is an incremental risk-oriented lifecycle model that has |
| 00:00:41,580 --> 00:00:46,330 | four main phases listed here: determine objectives, identify and |
| 00:00:46,330 --> 00:00:51,180 | resolve risks, development and tests, and plan the next iteration. |
| 00:00:51,180 --> 00:00:53,690 | A software project will go through these four phases in |
| 00:00:53,690 --> 00:00:57,020 | an iterative way. In the first phase, the requirements will |
| 00:00:57,020 --> 00:00:59,470 | be gathered. In the second phase, the risks and the |
| 00:00:59,470 --> 00:01:04,010 | alternate solutions will be identified, and a prototype will be produced. |
| 00:01:04,010 --> 00:01:06,190 | Software and tests for the software are produced in the |
| 00:01:06,190 --> 00:01:09,210 | development and test phase, which is the third step of the |
| 00:01:09,210 --> 00:01:12,830 | process. Finally, in the fourth phase, the output of the |
| 00:01:12,830 --> 00:01:16,880 | project, so far, is evaluated, and the next iteration is planned. |
| 00:01:16,880 --> 00:01:19,960 | So basically, what the spiral process prescribes is a |
| 00:01:19,960 --> 00:01:23,262 | way of developing software by going through these phases in |
| 00:01:23,262 --> 00:01:26,020 | an iterative way, in which we learn more and more |
| 00:01:26,020 --> 00:01:29,420 | of the software, we identify more and more, and account |
| 00:01:29,420 --> 00:01:32,250 | for, more and more risks and we go more |
| 00:01:32,250 --> 00:01:36,000 | and more towards our final solution, our final release. There |
| 00:01:36,000 --> 00:01:38,930 | are several advantages of using a spiral model. The first |
| 00:01:38,930 --> 00:01:41,930 | one is that the extensive risk analysis does reduce the |
| 00:01:41,930 --> 00:01:44,140 | chances of the project to fail. So there is a |
| 00:01:44,140 --> 00:01:48,300 | risk reduction advantage. The second advantage is that functionality can be |
| 00:01:48,300 --> 00:01:51,190 | added at a later phase because of the iterative nature of |
| 00:01:51,190 --> 00:01:55,175 | the process. And finally, software is produced early in the software |
| 00:01:55,175 --> 00:01:58,260 | lifecycle. So, at any iteration, we have something to show |
| 00:01:58,260 --> 00:02:01,300 | for our development. We don't wait until the end before producing |
| 00:02:01,300 --> 00:02:03,790 | something. And then of course there's also the advantage that we |
| 00:02:03,790 --> 00:02:07,190 | can get early feedback from the customer about what we produced. |
| 00:02:07,190 --> 00:02:09,000 | The main disadvantages on the other hand of |
| 00:02:09,000 --> 00:02:11,870 | the spiral model, are that the risk analysis requires |
| 00:02:11,870 --> 00:02:16,560 | a highly specific expertise. And unfortunately, the whole success |
| 00:02:16,560 --> 00:02:19,260 | of the process is highly dependent on risk analysis. |
| 00:02:19,260 --> 00:02:21,580 | So risk analysis has to be done right. |
| 00:02:21,580 --> 00:02:24,510 | And finally the spiral model is way more complex |
| 00:02:24,510 --> 00:02:27,180 | than other models, like for example, the water fall |
| 00:02:27,180 --> 00:02:27,180 | model. And therefore it can be costly to implement. |