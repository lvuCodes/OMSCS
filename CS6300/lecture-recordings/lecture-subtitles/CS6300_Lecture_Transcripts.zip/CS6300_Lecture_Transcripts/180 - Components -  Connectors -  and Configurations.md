# CS6300 180 - Components -  Connectors -  and Configurations

| Timestamp | Content |
|-----------|---------|
| 00:00:00,250 --> 00:00:02,350 | And let's start with software components. A |
| 00:00:02,350 --> 00:00:06,700 | software component is an architectural entity that encapsulates |
| 00:00:06,700 --> 00:00:09,940 | a subset of the system's functionality and or |
| 00:00:09,940 --> 00:00:13,180 | the system's data. So basically components typically provide |
| 00:00:13,180 --> 00:00:16,100 | application specific services. In addition to that, a |
| 00:00:16,100 --> 00:00:19,650 | software component also restricts access to that subset |
| 00:00:19,650 --> 00:00:23,570 | via an explicitly defined interface. And, in addition, |
| 00:00:23,570 --> 00:00:25,610 | which I'm not showing here, a component |
| 00:00:25,610 --> 00:00:28,010 | can also have explicitly defined dependencies |
| 00:00:28,010 --> 00:00:30,990 | on its required execution environment. In complex |
| 00:00:30,990 --> 00:00:33,680 | systems, interactions might become more important and |
| 00:00:33,680 --> 00:00:36,220 | challenging than functionality. And this is why |
| 00:00:36,220 --> 00:00:40,000 | connectors are very important architectural elements. A |
| 00:00:40,000 --> 00:00:42,935 | software connector is an architectural building block |
| 00:00:42,935 --> 00:00:46,990 | tasked with effecting and regulating interactions among |
| 00:00:46,990 --> 00:00:50,980 | components. So basically, connectors typically provide application |
| 00:00:50,980 --> 00:00:54,610 | independent interaction facilities. And it's worth noting here |
| 00:00:54,610 --> 00:00:57,530 | that in many software systems, connectors might simply be |
| 00:00:57,530 --> 00:01:01,140 | procedure calls or shared data accesses. So all constants |
| 00:01:01,140 --> 00:01:03,589 | that we're familiar with. But consider that much more |
| 00:01:03,589 --> 00:01:06,690 | sophisticated and complex connectors are also possible. And |
| 00:01:06,690 --> 00:01:10,310 | components and connectors are composed in a specific way |
| 00:01:10,310 --> 00:01:13,510 | in a given system architecture to accomplish that system's |
| 00:01:13,510 --> 00:01:17,400 | objective And this is expressed through an architectural configuration. |
| 00:01:17,400 --> 00:01:21,070 | More precisely, an architectural configuration, or topology, is a |
| 00:01:21,070 --> 00:01:25,630 | set of specific associations between the components and connectors |
| 00:01:25,630 --> 00:01:28,380 | of a software system's architecture. So now, let's look |
| 00:01:28,380 --> 00:01:28,380 | at an example that brings all of this together. |