# CS6300 234 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,700 --> 00:00:03,682 | Hello, and welcome back. In the previous |
| 00:00:03,682 --> 00:00:07,160 | mini course we covered software design, discussed the |
| 00:00:07,160 --> 00:00:10,020 | UML and the unified software process, and worked |
| 00:00:10,020 --> 00:00:12,160 | on a complex project in which we developed |
| 00:00:12,160 --> 00:00:16,020 | a distributed software system. In this mini course, |
| 00:00:16,020 --> 00:00:17,900 | which is the last one for this class, |
| 00:00:17,900 --> 00:00:21,080 | we will cover my very favorite topic, software |
| 00:00:21,080 --> 00:00:25,860 | testing or more generally, software verification and validation. |
| 00:00:25,860 --> 00:00:28,850 | So why do I love software testing? Well, |
| 00:00:28,850 --> 00:00:32,430 | I love it because it is extremely important. It |
| 00:00:32,430 --> 00:00:38,330 | is very challenging and it is fun but only if you do it in the right way. |
| 00:00:38,330 --> 00:00:40,900 | In the upcoming lessons we will discuss why |
| 00:00:40,900 --> 00:00:44,710 | software verification is important, why software testing, which is |
| 00:00:44,710 --> 00:00:47,730 | a specific type of verification, is important, and |
| 00:00:47,730 --> 00:00:51,910 | what are the main techniques for performing software testing. |
| 00:00:51,910 --> 00:00:54,866 | We will also discuss test-driven development and agile methods, |
| 00:00:54,866 --> 00:00:57,780 | in which we'll lose some of the rigidity of |
| 00:00:57,780 --> 00:01:01,340 | the earlier processes and turn things around by writing |
| 00:01:01,340 --> 00:01:04,260 | tests before we write the code and then writing |
| 00:01:04,260 --> 00:01:08,280 | code that makes the test pass. Finally, we will |
| 00:01:08,280 --> 00:01:10,750 | perform a project, in which you get to apply |
| 00:01:10,750 --> 00:01:14,010 | most of the principles and practices of agile development |
| 00:01:14,010 --> 00:01:14,010 | in a realistic scenario. So let's jump right in. |