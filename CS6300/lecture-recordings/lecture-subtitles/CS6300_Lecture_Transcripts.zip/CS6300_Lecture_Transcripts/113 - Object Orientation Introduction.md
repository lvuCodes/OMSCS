# CS6300 113 - Object Orientation Introduction

| Timestamp | Content |
|-----------|---------|
| 00:00:00,390 --> 00:00:03,750 | Let's start with a quick introduction to object orientation and |
| 00:00:03,750 --> 00:00:07,920 | the fundamental concepts behind it. And let's start by discussing what |
| 00:00:07,920 --> 00:00:11,100 | exactly is object orientation? If you're younger than me, it |
| 00:00:11,100 --> 00:00:13,700 | could be that the first programming language you learned was already |
| 00:00:13,700 --> 00:00:17,030 | an object-oriented language. But things were not always like this. |
| 00:00:17,030 --> 00:00:20,660 | Before object orientation became prevalent, people were not used to thinking |
| 00:00:20,660 --> 00:00:23,447 | in terms of objects. So what happened afterwards? And what does |
| 00:00:23,447 --> 00:00:25,727 | it mean to think in terms of objects and to follow |
| 00:00:25,727 --> 00:00:28,583 | an object-oriented approach? First of all, it |
| 00:00:28,583 --> 00:00:32,203 | means to give precedence of data over function. |
| 00:00:32,203 --> 00:00:35,377 | Did items rather than functionality become the center |
| 00:00:35,377 --> 00:00:39,020 | of development activities. This also allows for enforcing |
| 00:00:39,020 --> 00:00:42,200 | the very important concept of information hiding, |
| 00:00:42,200 --> 00:00:45,460 | which is the encapsulation and segregation of data |
| 00:00:45,460 --> 00:00:49,710 | behind well-defined and ideally stable interfaces. In order |
| 00:00:49,710 --> 00:00:51,490 | to be able to hide the design and |
| 00:00:51,490 --> 00:00:54,130 | also implementation decisions. And note that the terms |
| 00:00:54,130 --> 00:00:58,580 | encapsulation and information hiding are often used interchangeably, although |
| 00:00:58,580 --> 00:01:01,270 | some people prefer to think of information hiding |
| 00:01:01,270 --> 00:01:04,709 | as being the principle and encapsulation being the technique |
| 00:01:04,709 --> 00:01:07,990 | to achieve information hiding. The key concept though, |
| 00:01:07,990 --> 00:01:10,110 | no matter which term you use, is really to |
| 00:01:10,110 --> 00:01:13,460 | gather, to seclude this data behind sort of |
| 00:01:13,460 --> 00:01:16,610 | a wall and give access to the data only |
| 00:01:16,610 --> 00:01:20,270 | through interfaces that you, the developer define. And why is |
| 00:01:20,270 --> 00:01:22,800 | that important? Oh, for many reasons, and one of the main |
| 00:01:22,800 --> 00:01:26,690 | ones is that it makes code more maintainable. Because the |
| 00:01:26,690 --> 00:01:28,860 | rest of the code, the rest of the system doesn't have |
| 00:01:28,860 --> 00:01:32,370 | to be concerned on how the implementation details or the |
| 00:01:32,370 --> 00:01:37,220 | design are defined. And therefore, any change that happens behind this |
| 00:01:37,220 --> 00:01:39,580 | wall doesn't concern the rest of the system. And, doesn't |
| 00:01:39,580 --> 00:01:41,820 | affect the rest of the system, as long as you keep |
| 00:01:41,820 --> 00:01:45,730 | your interfaces consistent. Another advantage of focusing on |
| 00:01:45,730 --> 00:01:49,230 | objects and encapsulating the information into cohesive entities is |
| 00:01:49,230 --> 00:01:52,130 | that it allows the reuse of object definitions |
| 00:01:52,130 --> 00:01:55,000 | by incremental refinement. Which is what we normally call |
| 00:01:55,000 --> 00:01:58,830 | inheritance. And inheritance is definitely a fundamental concept |
| 00:01:58,830 --> 00:02:01,560 | in object orientation. For example, we can define a |
| 00:02:01,560 --> 00:02:04,030 | car as a refinement of the vehicle. That there's |
| 00:02:04,030 --> 00:02:06,850 | some additional characteristics with respect to a generic vehicle. |
| 00:02:06,850 --> 00:02:11,220 | And then we can use the car wherever a vehicle can be used, which is what we |
| 00:02:11,220 --> 00:02:14,200 | call polymorphism. And we'll continue this discussion for a |
| 00:02:14,200 --> 00:02:16,440 | very long time. Because there's so many things that |
| 00:02:16,440 --> 00:02:18,860 | could be discussed when we talk about object orientation, |
| 00:02:18,860 --> 00:02:21,890 | its characteristics and its advantages. But in the interest |
| 00:02:21,890 --> 00:02:24,000 | of time, let's for now just stop here. And |
| 00:02:24,000 --> 00:02:24,000 | start talking about two key concepts in object orientation. |