# CS6300 311 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,270 --> 00:00:02,880 | In previous lessons, we covered testing principles and |
| 00:00:02,880 --> 00:00:06,610 | techniques. In this lesson, we will discuss a |
| 00:00:06,610 --> 00:00:09,550 | type of software process that is heavily based |
| 00:00:09,550 --> 00:00:12,812 | on the use of testing. The agile development |
| 00:00:12,812 --> 00:00:17,310 | process. Also called test-driven development. To do that, |
| 00:00:17,310 --> 00:00:19,290 | we will revisit some of the assumptions that |
| 00:00:19,290 --> 00:00:21,490 | led to the definition of the more traditional |
| 00:00:21,490 --> 00:00:25,440 | software processes. The ones that we discussed so far. |
| 00:00:25,440 --> 00:00:27,690 | We will see how, when some of these assumptions are |
| 00:00:27,690 --> 00:00:30,210 | no longer valid, we can change the way in which we |
| 00:00:30,210 --> 00:00:32,560 | look at software processes. And we can change the way |
| 00:00:32,560 --> 00:00:36,120 | in which we look at software development in general. We will |
| 00:00:36,120 --> 00:00:40,250 | discuss how this changing perspective, let's us rethink software processes |
| 00:00:40,250 --> 00:00:43,520 | and make them more agile and better suited for context in |
| 00:00:43,520 --> 00:00:46,120 | which changes are the norm and we need to adapt |
| 00:00:46,120 --> 00:00:50,535 | fast. In particular, we will discuss two processes that apply the |
| 00:00:50,535 --> 00:00:53,570 | principles of agile software development and that are commonly |
| 00:00:53,570 --> 00:00:59,170 | used in industry. Extreme programming, also called XP, and Scrum. |
| 00:00:59,170 --> 00:00:59,170 | [BLANK_AUDIO] |