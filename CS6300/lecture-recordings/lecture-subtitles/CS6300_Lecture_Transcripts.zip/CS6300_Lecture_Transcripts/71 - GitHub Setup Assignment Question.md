# CS6300 71 - GitHub Setup Assignment Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:03,095 | This is ultimately pretty simple. All you need to do is visit |
| 00:00:03,095 --> 00:00:08,720 | github.com/join and set up a free GitHub account. If you already have a GitHub, |
| 00:00:08,720 --> 00:00:11,870 | account you can sign in using your existing account. If you want to |
| 00:00:11,870 --> 00:00:11,870 | use a separate identity for the class, feel free to set up a second one. |