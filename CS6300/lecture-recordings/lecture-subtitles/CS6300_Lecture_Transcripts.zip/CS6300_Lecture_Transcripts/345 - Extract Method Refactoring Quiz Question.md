# CS6300 345 - Extract Method Refactoring Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:02,580 | After the demo I would like to have a little quiz |
| 00:00:02,580 --> 00:00:05,430 | about the extract method refactoring. And I would like to ask you |
| 00:00:05,430 --> 00:00:08,910 | when is it appropriate to apply the extract method refactoring. Here I |
| 00:00:08,910 --> 00:00:11,890 | have a set of possible scenarios. First one is when there is |
| 00:00:11,890 --> 00:00:14,730 | duplicated code in two or more methods. When a class is too |
| 00:00:14,730 --> 00:00:17,730 | large. When the names of two classes are too similar. Or when |
| 00:00:17,730 --> 00:00:20,840 | a method is highly coupled with a class other than the one |
| 00:00:20,840 --> 00:00:20,840 | where it is defined. So as usual, please mark all that apply. |