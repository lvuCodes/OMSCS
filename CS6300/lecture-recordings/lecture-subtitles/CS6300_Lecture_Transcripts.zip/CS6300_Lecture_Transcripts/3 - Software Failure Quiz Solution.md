# CS6300 3 - Software Failure Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,600 | As you probably guessed, these are not fireworks for the 4th of |
| 00:00:02,600 --> 00:00:06,670 | July but, rather, the explosion of the Ariane 5, which happened 30 seconds |
| 00:00:06,670 --> 00:00:09,250 | or so after takeoff due to a software error. And this is |
| 00:00:09,250 --> 00:00:12,020 | just an example of what can go wrong when we don't build software |
| 00:00:12,020 --> 00:00:15,600 | and we don't test and verify and perform quality assurance of software |
| 00:00:15,600 --> 00:00:18,540 | in the right way, and quite an expensive one. In fact, to develop |
| 00:00:18,540 --> 00:00:21,250 | and to build the Ariane 5 it took 10 years. The cost |
| 00:00:21,250 --> 00:00:25,240 | was around $7 billion and there were $500 million of cargo on board. |
| 00:00:25,240 --> 00:00:27,280 | Luckily, at least there were no humans on the |
| 00:00:27,280 --> 00:00:29,400 | rocket. And you can find more details in case |
| 00:00:29,400 --> 00:00:31,610 | you're interested about the Ariane 5 accident in the |
| 00:00:31,610 --> 00:00:31,610 | lesson notes. I put a couple of links there. |