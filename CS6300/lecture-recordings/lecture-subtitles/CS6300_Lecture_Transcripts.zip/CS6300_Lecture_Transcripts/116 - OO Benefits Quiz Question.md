# CS6300 116 - OO Benefits Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:02,600 | Now let's make sure that we understand the benefits of |
| 00:00:02,600 --> 00:00:06,270 | object orientation through a quiz. Imagine that acme corporation decided |
| 00:00:06,270 --> 00:00:09,180 | to use an objetory entered approach in its software development |
| 00:00:09,180 --> 00:00:12,230 | process. If this is the case what benefits can they expect |
| 00:00:12,230 --> 00:00:14,640 | to receive from this decision. And here I'm listing some |
| 00:00:14,640 --> 00:00:18,120 | possible benefits. Increased reuse because of the modular cooling style. |
| 00:00:18,120 --> 00:00:21,450 | Increased maintainability because the system design can accommodate changes more |
| 00:00:21,450 --> 00:00:25,530 | easily. Increased speed because object oriented systems tend to run faster. |
| 00:00:25,530 --> 00:00:27,770 | And increased understandability because the |
| 00:00:27,770 --> 00:00:30,680 | design models real world entities. So, |
| 00:00:30,680 --> 00:00:30,680 | I would like, as usual, for you to mark all that apply. |