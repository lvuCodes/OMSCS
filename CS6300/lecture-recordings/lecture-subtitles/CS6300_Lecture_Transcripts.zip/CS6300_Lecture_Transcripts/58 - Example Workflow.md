# CS6300 58 - Example Workflow

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:02,830 | Before looking at additional actions, though, I would like to |
| 00:00:02,830 --> 00:00:06,770 | see what is the basic workflow in a version control system |
| 00:00:06,770 --> 00:00:09,370 | using the three actions that we just saw. And to |
| 00:00:09,370 --> 00:00:11,760 | do that I'm going to use two of our friends, Brad |
| 00:00:11,760 --> 00:00:14,590 | and Janet. So we have Janet here, Brad, and a |
| 00:00:14,590 --> 00:00:18,440 | VCS that they are using. Now imagine that Janet creates a |
| 00:00:18,440 --> 00:00:23,020 | file called foo.txt and puts some information in the file. |
| 00:00:23,020 --> 00:00:25,250 | At that point she might want to add the file to |
| 00:00:25,250 --> 00:00:28,340 | the repository and to commit it so that her changes |
| 00:00:28,340 --> 00:00:31,210 | and the file get to the central repository. And when she |
| 00:00:31,210 --> 00:00:33,900 | adds and commit, that's exactly what will happen, in foo |
| 00:00:33,900 --> 00:00:36,870 | will be come available here, and will be accessible to the |
| 00:00:36,870 --> 00:00:40,330 | other users. In this case it'll be accessible to Brad. |
| 00:00:40,330 --> 00:00:44,190 | If Brett were to run an update command, what will happen |
| 00:00:44,190 --> 00:00:47,800 | is that the file foo.txt will be copied on the local |
| 00:00:47,800 --> 00:00:50,460 | work space of Brad and Brad will be able to access |
| 00:00:50,460 --> 00:00:52,980 | the file. At this point Brad might want to modify |
| 00:00:52,980 --> 00:00:57,110 | the file, for example add something to this existing file. |
| 00:00:57,110 --> 00:00:59,410 | After doing that, he also may want to share the |
| 00:00:59,410 --> 00:01:02,900 | updated file with Janet. To do that, he will commit the |
| 00:01:02,900 --> 00:01:06,070 | file and the result will be exactly the same of |
| 00:01:06,070 --> 00:01:09,470 | when Janet committed her file. That the updated file will |
| 00:01:09,470 --> 00:01:11,890 | be sent to the repository and the repository will store |
| 00:01:11,890 --> 00:01:15,570 | that information and make it available for other users. So now, |
| 00:01:15,570 --> 00:01:18,290 | if Janet performs an update, she will get the |
| 00:01:18,290 --> 00:01:21,860 | new version of foo.txt with the additional information that was |
| 00:01:21,860 --> 00:01:24,950 | added by Brad. And we will see all of this |
| 00:01:24,950 --> 00:01:24,950 | in action in our next demo in a few minutes. |