# CS6300 237 - Failure -  Fault -  and Error Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:02,900 | So now I have a few questions for you. And so we use, as |
| 00:00:02,900 --> 00:00:07,350 | usual, our developer Janet to introduce a quiz. And the first question I want to |
| 00:00:07,350 --> 00:00:11,710 | ask you is the following. A call to double passing three as a parameter returns |
| 00:00:11,710 --> 00:00:11,710 | the value nine. What is this? Is that a failure, a fault, or an error? |