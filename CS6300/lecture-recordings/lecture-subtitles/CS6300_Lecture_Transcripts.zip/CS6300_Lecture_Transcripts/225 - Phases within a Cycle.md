# CS6300 225 - Phases within a Cycle

| Timestamp | Content |
|-----------|---------|
| 00:00:00,240 --> 00:00:02,505 | Now let's go back to the phases within a cycle. |
| 00:00:02,505 --> 00:00:04,930 | because I want to show you how they relate to traditional |
| 00:00:04,930 --> 00:00:08,196 | activities of software development. Because this is the first time that |
| 00:00:08,196 --> 00:00:12,066 | we talk about inception, elaboration, construction and transition. So we will |
| 00:00:12,066 --> 00:00:14,859 | know what they mean, in terms of the traditional software |
| 00:00:14,859 --> 00:00:18,380 | development. So I'm going to first discuss these relations and then |
| 00:00:18,380 --> 00:00:22,198 | I'm going to talk about each individual phase in further detail. |
| 00:00:22,198 --> 00:00:25,570 | So I'm going to start by representing the four RUP phases here |
| 00:00:25,570 --> 00:00:29,810 | with possible internal iterations. I1, E1 and E2, C1, |
| 00:00:29,810 --> 00:00:32,490 | C2, and so on. And just as a reference, this |
| 00:00:32,490 --> 00:00:34,670 | is the way in which time will progress. So we |
| 00:00:34,670 --> 00:00:37,890 | will start with inception and we will finish with transition. |
| 00:00:37,890 --> 00:00:39,710 | So what I'm want to do now is to show the |
| 00:00:39,710 --> 00:00:43,930 | actual, traditional, software development activities here on the left. And |
| 00:00:43,930 --> 00:00:46,970 | I also want to show you, using this diagram, how these |
| 00:00:46,970 --> 00:00:51,610 | activities are actually performed in each of the RUP phases. |
| 00:00:51,610 --> 00:00:54,540 | So, let's see what this representation means. Basically, what |
| 00:00:54,540 --> 00:00:58,410 | I'm showing here, is that requirements engineering actually starts in |
| 00:00:58,410 --> 00:01:00,480 | the inception phase. So, you can see the height |
| 00:01:00,480 --> 00:01:03,090 | of this bar as the amount of effort devoted to |
| 00:01:03,090 --> 00:01:05,890 | this activity in this specific phase. So you can |
| 00:01:05,890 --> 00:01:09,950 | see that requirements engineering starts in inception phase, is mostly |
| 00:01:09,950 --> 00:01:13,210 | performed in the elaboration phase, and then it continues, |
| 00:01:13,210 --> 00:01:16,820 | although to a lesser extent, throughout all phases up until |
| 00:01:16,820 --> 00:01:18,570 | the end of the transition. But the bulk is really |
| 00:01:18,570 --> 00:01:22,940 | performed here in the elaboration phase. Similarly, if we consider analysis |
| 00:01:22,940 --> 00:01:25,450 | and design, we can see that analysis and design are |
| 00:01:25,450 --> 00:01:29,510 | mainly performed in the elaboration phase. But a considerable amount of |
| 00:01:29,510 --> 00:01:31,900 | it also continues in the construction phase, and then it |
| 00:01:31,900 --> 00:01:34,514 | kind of phases out. So there's very little of that done |
| 00:01:34,514 --> 00:01:37,300 | in the transition phase. Looking now at implementation, you can see |
| 00:01:37,300 --> 00:01:41,190 | that the implementation happens mostly in the construction phase, which is, |
| 00:01:41,190 --> 00:01:45,460 | unsurprisingly, the phase that is mostly concerned with actual code development, |
| 00:01:45,460 --> 00:01:47,620 | as we will see in a minute. Testing, on the other |
| 00:01:47,620 --> 00:01:50,990 | hand, is performed throughout most phases, with, peaks in some specific |
| 00:01:50,990 --> 00:01:54,260 | point, for example, at the end of some iterations, like here |
| 00:01:54,260 --> 00:01:57,880 | and here. To conclude, we have the business modeling activity that |
| 00:01:57,880 --> 00:02:00,160 | happens mainly in the inception and a little bit in the |
| 00:02:00,160 --> 00:02:04,100 | elaboration phase and the deployment activity which happens a little bit |
| 00:02:04,100 --> 00:02:06,420 | throughout, but the bulk of it is really in the transition |
| 00:02:06,420 --> 00:02:08,699 | phase, which is actually the phase that has to do |
| 00:02:08,699 --> 00:02:12,070 | with deployment and then maintenance. So I hope this kind |
| 00:02:12,070 --> 00:02:14,970 | of high level view gives you a better understanding of |
| 00:02:14,970 --> 00:02:17,940 | what is the mapping between these new phases and, the |
| 00:02:17,940 --> 00:02:21,760 | typical software development activities that we are more familiar with. |
| 00:02:21,760 --> 00:02:24,360 | So to further this understanding, later in the lesson, I'm |
| 00:02:24,360 --> 00:02:28,220 | also going to talk about these specific phases individually. First, however, |
| 00:02:28,220 --> 00:02:31,610 | I want to spend a little more time discussing what happens |
| 00:02:31,610 --> 00:02:35,200 | inside each one of these iterations, just to make sure |
| 00:02:35,200 --> 00:02:35,200 | that we are all understand what an iteration is exactly. |