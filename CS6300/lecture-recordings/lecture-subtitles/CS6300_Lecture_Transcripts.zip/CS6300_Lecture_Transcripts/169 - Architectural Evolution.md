# CS6300 169 - Architectural Evolution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:02,810 | To do that let's look at how architectural evolution |
| 00:00:02,810 --> 00:00:06,880 | occurs in practice. Ideally when a system evolves, its prescriptive |
| 00:00:06,880 --> 00:00:09,340 | architecture should be modified first. Just like when you |
| 00:00:09,340 --> 00:00:12,170 | modify a building. You change the blueprint and then you |
| 00:00:12,170 --> 00:00:13,940 | change the actual building. You don't go the other |
| 00:00:13,940 --> 00:00:17,820 | way around. In software, unfortunately this rarely ever happens in |
| 00:00:17,820 --> 00:00:21,706 | practice. In practice the system, and therefore it's descriptive |
| 00:00:21,706 --> 00:00:25,150 | architecture are often directly modified. Like in this case that |
| 00:00:25,150 --> 00:00:27,870 | I'm showing here. So what happens is that the architecture |
| 00:00:27,870 --> 00:00:32,259 | as conceived does not change. Whereas the architecture as implemented, does |
| 00:00:32,259 --> 00:00:35,600 | change. And therefore these two things start diverging. And this really |
| 00:00:35,600 --> 00:00:38,720 | happens for a number of reasons. So I'm just going to list |
| 00:00:38,720 --> 00:00:41,740 | a few of those reasons here. In some cases it |
| 00:00:41,740 --> 00:00:45,620 | just happens for plain sloppiness. I need to make this modification |
| 00:00:45,620 --> 00:00:47,290 | and I don't really want to go back and look at |
| 00:00:47,290 --> 00:00:50,610 | the prescriptive architecture modified. I'm just going to make the change, and |
| 00:00:50,610 --> 00:00:53,800 | maybe I'll fix the description later. And then you never really get |
| 00:00:53,800 --> 00:00:56,950 | to it. In other cases you do this because of the perception |
| 00:00:56,950 --> 00:01:00,290 | of short deadlines. If you have to do something by this afternoon, |
| 00:01:00,290 --> 00:01:01,300 | you're not going through a four |
| 00:01:01,300 --> 00:01:03,410 | month software architecture review, you normally just |
| 00:01:03,410 --> 00:01:06,460 | get to it, and do it. In some cases a prescriptive architecture |
| 00:01:06,460 --> 00:01:09,510 | is not even present, so there's a lack of documentation. So in these |
| 00:01:09,510 --> 00:01:12,450 | cases, clearly, you cannot go and modify something that does not even |
| 00:01:12,450 --> 00:01:15,880 | exist, and so you jump directly to the code and start modifying that. |
| 00:01:15,880 --> 00:01:18,280 | And as I said there's many, many more |
| 00:01:18,280 --> 00:01:21,080 | other reasons why that happen. But important point here is |
| 00:01:21,080 --> 00:01:23,770 | that it does happen and it does happen often |
| 00:01:23,770 --> 00:01:23,770 | and the result is that prescriptive and descriptive architectures diverge. |