# CS6300 236 - Failure -  Fault -  and Error

| Timestamp | Content |
|-----------|---------|
| 00:00:00,390 --> 00:00:03,460 | The first term I want to define, is failure. |
| 00:00:03,460 --> 00:00:09,080 | A failure is an observable incorrect behavior of the software. |
| 00:00:09,080 --> 00:00:10,910 | It is conceptually related to the behavior of the |
| 00:00:10,910 --> 00:00:13,910 | program, rather than its code. The second term I want |
| 00:00:13,910 --> 00:00:17,600 | to introduce is fault, which is also called bug. |
| 00:00:17,600 --> 00:00:20,540 | And the fault or bug, is an incorrect piece of |
| 00:00:20,540 --> 00:00:22,780 | code. In other words, a fault is related to |
| 00:00:22,780 --> 00:00:25,900 | the code. And is a necessary, but not sufficient condition |
| 00:00:25,900 --> 00:00:28,160 | for the occurrence of a failure. The final |
| 00:00:28,160 --> 00:00:30,880 | term I want to introduce is, error. Where an |
| 00:00:30,880 --> 00:00:33,630 | error is the cause of a fault. It is |
| 00:00:33,630 --> 00:00:36,990 | usually a human error, which can be conceptual. A |
| 00:00:36,990 --> 00:00:39,620 | typo or something along those lines. And know that |
| 00:00:39,620 --> 00:00:43,422 | this terminology, failure, fault and error, is the official |
| 00:00:43,422 --> 00:00:46,945 | [UNKNOWN] terminology. So you cannot go wrong if you |
| 00:00:46,945 --> 00:00:51,282 | use it. Now, let me illustrate the difference between |
| 00:00:51,282 --> 00:00:57,153 | failure, fault and error. Using a small example. What I'm showing here is |
| 00:00:57,153 --> 00:01:00,876 | a small function that, as you can see from its name, takes an |
| 00:01:00,876 --> 00:01:04,920 | integer parameter i. And is supposed to double the value of i, and |
| 00:01:04,920 --> 00:01:04,920 | return it. As we can clearly see, this is not what the function does. |