# CS6300 15 - Software Phases

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:03,730 | In fact, software processes are normally characterized by several phases, what |
| 00:00:03,730 --> 00:00:07,240 | we call the software phases, and only one of these phases is |
| 00:00:07,240 --> 00:00:09,970 | mainly focused on coding. The other phases are meant to support |
| 00:00:09,970 --> 00:00:13,440 | other parts of software development. The first of these phases is called |
| 00:00:13,440 --> 00:00:16,110 | requirements engineering and that's the phase in which we talk to |
| 00:00:16,110 --> 00:00:19,640 | the customer, to the stakeholders, whoever we are building the software for. |
| 00:00:19,640 --> 00:00:22,120 | And we try to understand what kind of system we need |
| 00:00:22,120 --> 00:00:25,650 | to build. Then we use this information to define our design and |
| 00:00:25,650 --> 00:00:28,840 | the design is the high-level structure, that then can become more |
| 00:00:28,840 --> 00:00:31,800 | and more detailed, of our software system. Once we've defined our |
| 00:00:31,800 --> 00:00:34,180 | design we can actually move to the next phase, which is |
| 00:00:34,180 --> 00:00:37,480 | the implementation, in which we write code that implements the design which |
| 00:00:37,480 --> 00:00:40,630 | we just defined. After implementing the code, we need to verify |
| 00:00:40,630 --> 00:00:43,510 | and validate the code. We need to make sure that the code |
| 00:00:43,510 --> 00:00:46,930 | behaves as intended. And finally, we need to maintain the code. |
| 00:00:46,930 --> 00:00:48,992 | And maintenance involves several activities like, |
| 00:00:48,992 --> 00:00:50,980 | for example, adding new functionality or |
| 00:00:50,980 --> 00:00:54,568 | eliminating bugs from the code or responding to problems that |
| 00:00:54,568 --> 00:00:57,420 | were reported from the field after we released the software. |
| 00:00:57,420 --> 00:00:59,020 | We will look at all of these activities and of |
| 00:00:59,020 --> 00:01:01,670 | the software development process in detail, in the rest of the |
| 00:01:01,670 --> 00:01:03,610 | class. And for each activity, we will look at the |
| 00:01:03,610 --> 00:01:06,460 | fundamental principles and how it is done currently. And in |
| 00:01:06,460 --> 00:01:08,780 | some cases, we will also look at some advance ways |
| 00:01:08,780 --> 00:01:08,780 | to do it. For example, more research approaches for that activity. |