# CS6300 168 - Prescriptive vs Descriptive Architecture

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:02,200 | We can look at the software architecture from two |
| 00:00:02,200 --> 00:00:07,120 | main standpoints. There are prescriptive and descriptive software architectures. |
| 00:00:07,120 --> 00:00:09,900 | So what does that mean? A prescriptive architecture captures |
| 00:00:09,900 --> 00:00:12,620 | the design decisions that are made prior to the |
| 00:00:12,620 --> 00:00:15,398 | system's construction. This is what we normally call the |
| 00:00:15,398 --> 00:00:18,280 | as-conceived software architecture. Conversely, |
| 00:00:18,280 --> 00:00:20,550 | a descriptive architecture describes how |
| 00:00:20,550 --> 00:00:23,010 | the system has actually been built. So it's based |
| 00:00:23,010 --> 00:00:25,860 | on observing the system as it is and extracting |
| 00:00:25,860 --> 00:00:28,200 | the architecture from the observation. This is what we call |
| 00:00:28,200 --> 00:00:31,890 | the as-implemented software architecture. And one key point here is |
| 00:00:31,890 --> 00:00:35,780 | that often, these two architectures, the prescriptive and the descriptive |
| 00:00:35,780 --> 00:00:35,780 | architectures end up being different. So let's see why that happens. |