# CS6300 66 - GIT Demo_ Git + Eclipse

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,580 | Now that we saw some of the git basic |
| 00:00:02,580 --> 00:00:05,689 | functionalities in practice, let's go a step further. If |
| 00:00:05,689 --> 00:00:08,420 | you remember I mentioned before that many of these |
| 00:00:08,420 --> 00:00:12,250 | version control systems are actually integrated into IDE's. So |
| 00:00:12,250 --> 00:00:14,540 | what were going to look at next is what happens |
| 00:00:14,540 --> 00:00:17,500 | if we put together git and eclipse. And the |
| 00:00:17,500 --> 00:00:20,960 | result is egit, or EGit is a plug in |
| 00:00:20,960 --> 00:00:25,520 | for the eclipse IDE that adds git functionality to eclipse. |
| 00:00:25,520 --> 00:00:27,880 | So let's see how that works in practice. So |
| 00:00:27,880 --> 00:00:31,400 | support for git is available in many IDE's including |
| 00:00:31,400 --> 00:00:33,920 | Eclipse. And if you want to get github |
| 00:00:33,920 --> 00:00:38,620 | for Eclipse, you should go to eclipse.github.com and you can |
| 00:00:38,620 --> 00:00:41,445 | download the plugin. So this bring us to the |
| 00:00:41,445 --> 00:00:44,530 | plugin page and you can use the provided URL |
| 00:00:44,530 --> 00:00:47,060 | and directions to install the plugin. In this case |
| 00:00:47,060 --> 00:00:49,945 | we're going to copy this address. So we're going to |
| 00:00:49,945 --> 00:00:54,110 | Eclipse, Help, Install new software. We can click on Add |
| 00:00:54,110 --> 00:00:56,810 | to add a new site from which to get software. We |
| 00:00:56,810 --> 00:00:59,110 | paste the location that we just copied here. And we |
| 00:00:59,110 --> 00:01:02,842 | can give it a descriptive name. In this case I'll just |
| 00:01:02,842 --> 00:01:06,645 | call it Eclipse Git plugin. Then when I click okay, |
| 00:01:06,645 --> 00:01:09,720 | Eclipse will go, and look for plugins. And as you can |
| 00:01:09,720 --> 00:01:12,510 | see, there are two options. We can select both of them, |
| 00:01:12,510 --> 00:01:15,180 | and click on next. You can see that the Eclipse identified |
| 00:01:15,180 --> 00:01:18,330 | a few dependencies. You can click next and accept them. You can |
| 00:01:18,330 --> 00:01:21,540 | accept the terms and conditions for the plug in, and then just |
| 00:01:21,540 --> 00:01:25,730 | finish. And at this point, Eclipse will install the plugin, which might |
| 00:01:25,730 --> 00:01:28,610 | take a little bit of time. So we're just going to speed it up. |
| 00:01:28,610 --> 00:01:31,110 | And when Eclipse is done, you will get this prompt that will |
| 00:01:31,110 --> 00:01:33,670 | tell you that you need to restart Eclipse for the plugin to |
| 00:01:33,670 --> 00:01:36,990 | be actually installed. And at this point, you want to click yes. And |
| 00:01:36,990 --> 00:01:40,550 | when Eclipse restarts. You'll have your plugin. We're going to go to the git |
| 00:01:40,550 --> 00:01:44,030 | repository perspective that we can select here. And when we click |
| 00:01:44,030 --> 00:01:47,160 | OK, you can see that our display will change. And since |
| 00:01:47,160 --> 00:01:49,360 | we don't have any repository yet, we are provided with the |
| 00:01:49,360 --> 00:01:53,620 | possibility of adding an existing local git repository, cloning a git repository |
| 00:01:53,620 --> 00:01:56,330 | or creating a new local git repository. We're going to add an |
| 00:01:56,330 --> 00:01:59,800 | existing local repository. This is the one that we created earlier, |
| 00:01:59,800 --> 00:02:02,170 | so we'll select it and click finish, and you can see |
| 00:02:02,170 --> 00:02:05,660 | that my project is now added to this set of git repositories. |
| 00:02:05,660 --> 00:02:09,240 | Now let's check out the project from the repository by selecting import |
| 00:02:09,240 --> 00:02:12,530 | project. And here you can import something as an existing project, you |
| 00:02:12,530 --> 00:02:15,300 | can use a new project wizard, and in this case I chose |
| 00:02:15,300 --> 00:02:18,680 | the option of importing as a general project. Then I click Next and |
| 00:02:18,680 --> 00:02:20,870 | as you can see, I have the project name up there and |
| 00:02:20,870 --> 00:02:24,630 | I can click Finish. So now, if I go to the resource perspective |
| 00:02:24,630 --> 00:02:27,740 | by clicking here, I can see that the project has been added |
| 00:02:27,740 --> 00:02:30,760 | to my set of projects. And I can see all the files within |
| 00:02:30,760 --> 00:02:33,440 | the project, particularly, if I click on the README, you can see |
| 00:02:33,440 --> 00:02:36,190 | that we have the Readme file that we created before. Same thing for |
| 00:02:36,190 --> 00:02:38,930 | the test file. One thing I can do at this point, it |
| 00:02:38,930 --> 00:02:41,070 | to execute different git commands, perform |
| 00:02:41,070 --> 00:02:43,430 | different git operations by using the team |
| 00:02:43,430 --> 00:02:47,010 | submenu in the contactual menu. And here there are several things |
| 00:02:47,010 --> 00:02:50,650 | I can do including some advanced commands. And just to give it a |
| 00:02:50,650 --> 00:02:53,200 | shot, I am going to try to click show local history, and this |
| 00:02:53,200 --> 00:02:56,180 | shows the history of the file. For example it shows the author and |
| 00:02:56,180 --> 00:02:59,200 | it shows when he was created, when he was authored. let's make |
| 00:02:59,200 --> 00:03:02,810 | some changes to this file by adding some new content. Okay. I saved |
| 00:03:02,810 --> 00:03:05,160 | the file and now I can see that error that indicates that my |
| 00:03:05,160 --> 00:03:08,620 | file was locally changed. So now if I go to the team menu, |
| 00:03:08,620 --> 00:03:11,380 | you can see that I have the option to add to the index, |
| 00:03:11,380 --> 00:03:14,686 | to stage the file. And now I got this new label that star |
| 00:03:14,686 --> 00:03:17,980 | that shows the files added to the index. And now at this point, |
| 00:03:17,980 --> 00:03:21,270 | I can go to the team menu again and I can actually commit |
| 00:03:21,270 --> 00:03:25,480 | the file by selecting the corresponding entry. This allows me to enter |
| 00:03:25,480 --> 00:03:28,390 | the commit message, exactly in the same way which I could do |
| 00:03:28,390 --> 00:03:31,250 | that from the command line with the textual editor. And after I |
| 00:03:31,250 --> 00:03:34,050 | put the comment there, I can actually commit. And now if we |
| 00:03:34,050 --> 00:03:36,320 | look at the history view, we can see here that we have |
| 00:03:36,320 --> 00:03:38,960 | a new version for the file that we just modified. And we |
| 00:03:38,960 --> 00:03:42,250 | can also see the commit comment. And, at this point, if we |
| 00:03:42,250 --> 00:03:46,450 | had remote repository we could push our changes to that remote repository |
| 00:03:46,450 --> 00:03:49,330 | as well. Again, using the team submenu and |
| 00:03:49,330 --> 00:03:52,170 | the contextual menu. And, speaking of remote repositories, what we |
| 00:03:52,170 --> 00:03:55,230 | are going to see next is how to use GitHub |
| 00:03:55,230 --> 00:03:55,230 | repositories which are remote repositories that are hosted on GitHub. |