# CS6300 211 - Choosing a Pattern Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:02,780 | Now that we've discussed how to choose a pattern. Imagine that |
| 00:00:02,780 --> 00:00:05,210 | you have to write a class that can have only one |
| 00:00:05,210 --> 00:00:08,090 | instance. So to satisfy this requirement, I would like for you |
| 00:00:08,090 --> 00:00:10,720 | to pick one of the design patterns that we discussed in |
| 00:00:10,720 --> 00:00:14,580 | this lesson, and write the code here that satisfies that requirement. |
| 00:00:14,580 --> 00:00:16,270 | And when you write the code, please make sure that your |
| 00:00:16,270 --> 00:00:21,140 | class has only one method, without counting possible constructors, and that |
| 00:00:21,140 --> 00:00:21,140 | the class is called Singleton. And write your class right here. |