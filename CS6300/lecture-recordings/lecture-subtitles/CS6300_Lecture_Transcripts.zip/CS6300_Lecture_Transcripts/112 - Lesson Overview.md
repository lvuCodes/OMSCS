# CS6300 112 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,460 --> 00:00:03,770 | Hi. In the last lesson we discussed |
| 00:00:03,770 --> 00:00:08,370 | requirements engineering. This lesson is about object orientation |
| 00:00:08,370 --> 00:00:11,958 | and other related concepts. The lesson is split |
| 00:00:11,958 --> 00:00:14,720 | in two main parts. In the first part, |
| 00:00:14,720 --> 00:00:16,870 | we will provide a quick introduction to |
| 00:00:16,870 --> 00:00:20,890 | object orientation and object oriented analysis and design. |
| 00:00:20,890 --> 00:00:22,750 | In the second part, we will cover the |
| 00:00:22,750 --> 00:00:25,710 | essential of UML, which is the notation that |
| 00:00:25,710 --> 00:00:25,710 | we will use in the rest of the course and also in our projects. |