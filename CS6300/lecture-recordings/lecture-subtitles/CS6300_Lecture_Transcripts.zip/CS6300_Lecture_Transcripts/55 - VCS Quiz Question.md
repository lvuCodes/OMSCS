# CS6300 55 - VCS Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,430 | Now before we continue, and we look at more details |
| 00:00:02,430 --> 00:00:04,400 | of version control systems, I want to ask you a |
| 00:00:04,400 --> 00:00:07,230 | quick question about VCS. I want to know whether you |
| 00:00:07,230 --> 00:00:10,190 | have used a version control system before, and if so, |
| 00:00:10,190 --> 00:00:12,090 | which one or which ones. I'm going to list in |
| 00:00:12,090 --> 00:00:15,260 | here some of the most commonly used version control systems, |
| 00:00:15,260 --> 00:00:18,840 | like CVS, Subversion, GIT, and I'm also allowing you to |
| 00:00:18,840 --> 00:00:18,840 | specify other VCS in case you have used different ones. |