# CS6300 105 - Modeling Requirements

| Timestamp | Content |
|-----------|---------|
| 00:00:00,220 --> 00:00:03,550 | Once we collected the required knowledge on the requirements for |
| 00:00:03,550 --> 00:00:06,120 | the system that we're developing, we need to model it in |
| 00:00:06,120 --> 00:00:08,430 | a structured and clear way, so that it can be |
| 00:00:08,430 --> 00:00:12,100 | analyzed and refined. And there are really tons of ways to |
| 00:00:12,100 --> 00:00:15,840 | do that, depending on your focus and objectives. More specifically, |
| 00:00:15,840 --> 00:00:18,940 | when modeling requirements you need to decide what you want to |
| 00:00:18,940 --> 00:00:21,710 | model and how you want to model it. So let's look |
| 00:00:21,710 --> 00:00:25,390 | at these two aspects independently. What you decide to model depends |
| 00:00:25,390 --> 00:00:28,270 | on where your emphasis is. That is on which |
| 00:00:28,270 --> 00:00:31,390 | aspects of the requirements you want to focus. For |
| 00:00:31,390 --> 00:00:34,880 | example if your emphasis is on the characteristics of |
| 00:00:34,880 --> 00:00:37,970 | the enterprise of the company that you are analyzing you |
| 00:00:37,970 --> 00:00:40,240 | may want to model goals and objectives of the |
| 00:00:40,240 --> 00:00:44,380 | company, or its organizational structure, its task and dependencies |
| 00:00:44,380 --> 00:00:47,040 | and so on. Conversely, if your focus is on |
| 00:00:47,040 --> 00:00:50,500 | information and behaviors, you might want to concentrate on aspects |
| 00:00:50,500 --> 00:00:53,800 | such as the structure of information, various behavioral views |
| 00:00:53,800 --> 00:00:55,480 | some of which we will see in the next |
| 00:00:55,480 --> 00:00:59,650 | lesson, or maybe time or sequencing requirements. Finally, if |
| 00:00:59,650 --> 00:01:02,750 | you're mostly interested in the quality aspects of your |
| 00:01:02,750 --> 00:01:06,790 | system, you will focus on the various non-functional properties |
| 00:01:06,790 --> 00:01:09,070 | of the software that are relevant in the context |
| 00:01:09,070 --> 00:01:13,570 | considered. For example reliability, robustness, security, and so on. |
| 00:01:13,570 --> 00:01:15,550 | You will just pick the ones that are relevant for |
| 00:01:15,550 --> 00:01:18,540 | your context. And as we said, there's a second dimension. |
| 00:01:18,540 --> 00:01:21,050 | After you have decided what to model in your system, |
| 00:01:21,050 --> 00:01:23,480 | you have to decide how you want to model it. |
| 00:01:23,480 --> 00:01:25,860 | So I want to show here some options for modeling |
| 00:01:25,860 --> 00:01:30,380 | enterprises, information, and quality aspects. And as you can see |
| 00:01:30,380 --> 00:01:34,100 | here for each type of information there are many possible |
| 00:01:34,100 --> 00:01:36,840 | models that we can use to represent it. And all |
| 00:01:36,840 --> 00:01:38,750 | these models have advantages and |
| 00:01:38,750 --> 00:01:41,400 | disadvantages, different levels of formality and |
| 00:01:41,400 --> 00:01:44,000 | different focus. Something else that I want to point out |
| 00:01:44,000 --> 00:01:47,145 | about these models is the fact that these models are often |
| 00:01:47,145 --> 00:01:50,980 | orthogonal to one another, especially if we consider models in different |
| 00:01:50,980 --> 00:01:54,620 | categories. So what that means is that they're complimentary rather than |
| 00:01:54,620 --> 00:01:58,310 | mutually exclusive. Different models can be used to provide views |
| 00:01:58,310 --> 00:02:01,290 | of the requirements from different perspectives, and we will not see |
| 00:02:01,290 --> 00:02:03,700 | most of these models in this course, but I wanted to |
| 00:02:03,700 --> 00:02:06,550 | list them anyways to give you an idea of how many |
| 00:02:06,550 --> 00:02:09,490 | there are and how vast is this area. As far |
| 00:02:09,490 --> 00:02:11,540 | as we are concerned in the course and for the |
| 00:02:11,540 --> 00:02:14,660 | projects we will express requirements using one of two main |
| 00:02:14,660 --> 00:02:19,010 | ways. Using natural language, that is informal specifications and using |
| 00:02:19,010 --> 00:02:22,600 | UML diagrams, which is graphical models. And we will introduce |
| 00:02:22,600 --> 00:02:25,840 | UML and the most important diagrams in the next lesson. |
| 00:02:25,840 --> 00:02:27,330 | And the only other type of models that I want |
| 00:02:27,330 --> 00:02:31,610 | to mentions explicitly are goal models because they're extremely popular. |
| 00:02:31,610 --> 00:02:34,930 | So the main idea with goal models is it start with the main goal of |
| 00:02:34,930 --> 00:02:36,990 | the system and then keep refining it |
| 00:02:36,990 --> 00:02:39,654 | by decomposing it in sub-goals. So it's kind |
| 00:02:39,654 --> 00:02:41,610 | of a very natural way of progressing. |
| 00:02:41,610 --> 00:02:44,210 | And you continue this refinement until you get |
| 00:02:44,210 --> 00:02:47,150 | to goals that can be operationalized, and represent |
| 00:02:47,150 --> 00:02:47,150 | the basic units of functionality of the system. |