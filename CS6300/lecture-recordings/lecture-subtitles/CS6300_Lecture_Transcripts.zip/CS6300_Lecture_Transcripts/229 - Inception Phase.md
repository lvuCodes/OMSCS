# CS6300 229 - Inception Phase

| Timestamp | Content |
|-----------|---------|
| 00:00:00,175 --> 00:00:03,510 | Let's talk a little bit more about phases. The rational unified |
| 00:00:03,510 --> 00:00:07,050 | process phases are fundamental aspects of this process and which just touched |
| 00:00:07,050 --> 00:00:09,200 | on them so we just give a quick overview. And I want to |
| 00:00:09,200 --> 00:00:12,010 | look at these phases in a little more detail. So, what I'm |
| 00:00:12,010 --> 00:00:14,960 | going to do is, for each phase, I'm going to discuss what it is, |
| 00:00:14,960 --> 00:00:18,310 | what it produces and how is the result of the phase suppose |
| 00:00:18,310 --> 00:00:21,910 | to be,. Assessed, and what are the consequences of this assessment. So |
| 00:00:21,910 --> 00:00:25,350 | let's start with the first phase, the inception phase. The first phase |
| 00:00:25,350 --> 00:00:27,920 | goes from the idea of the product to the |
| 00:00:27,920 --> 00:00:30,990 | vision of the end product. What this involves is basically |
| 00:00:30,990 --> 00:00:34,230 | to delimiting the project scope. And making the business case |
| 00:00:34,230 --> 00:00:37,040 | for the product presented. Why is it worth doing? What |
| 00:00:37,040 --> 00:00:39,870 | are the success criteria? What are the main risks? What |
| 00:00:39,870 --> 00:00:43,690 | resources will be needed? And so on, specifically these phases |
| 00:00:43,690 --> 00:00:47,310 | answer three main questions. The first one is, what are |
| 00:00:47,310 --> 00:00:51,330 | the major users or actors, to use the UML terminology. |
| 00:00:51,330 --> 00:00:53,450 | And what will the system do for them? To |
| 00:00:53,450 --> 00:00:56,780 | answer this, these phases produce a simplified use-case model where |
| 00:00:56,780 --> 00:01:00,480 | only a few use-cases are represented and described. So this |
| 00:01:00,480 --> 00:01:03,390 | is a sort of initial use-case model. The second question |
| 00:01:03,390 --> 00:01:05,610 | is about the architecture, what could be an architecture |
| 00:01:05,610 --> 00:01:08,370 | for the system? So in this phase we will normally |
| 00:01:08,370 --> 00:01:12,420 | also develop a tentative architecture. So an initial architecture that |
| 00:01:12,420 --> 00:01:16,540 | describes the most crucial subsystems. Finally this phase also answers |
| 00:01:16,540 --> 00:01:18,890 | the question, what is the plan and how much |
| 00:01:18,890 --> 00:01:21,620 | will it cost? To answer this question. This phase will |
| 00:01:21,620 --> 00:01:24,930 | identify the main risks for the project and also produce |
| 00:01:24,930 --> 00:01:28,600 | a rough plan with estimates for resources, initial planning for |
| 00:01:28,600 --> 00:01:32,820 | the phases and dates and milestones. Specifically, the inception phase |
| 00:01:32,820 --> 00:01:36,370 | generates several deliverables. It is very important that you pay |
| 00:01:36,370 --> 00:01:39,600 | attention so that you understand what this deliberate approach are. |
| 00:01:39,600 --> 00:01:42,320 | Starting from the first one, which is the vision document. |
| 00:01:42,320 --> 00:01:44,800 | And this is a document that provides a general |
| 00:01:44,800 --> 00:01:48,420 | vision of the core projects requirements, key features and main |
| 00:01:48,420 --> 00:01:51,890 | constraints. Together with this, the inception phase also produces an |
| 00:01:51,890 --> 00:01:54,900 | initial use case model, as I just mentioned. So this |
| 00:01:54,900 --> 00:01:57,720 | is a use case model that includes an initial set |
| 00:01:57,720 --> 00:02:00,670 | of use cases, and then will be later refined. Two |
| 00:02:00,670 --> 00:02:04,300 | additional variables are the initial project glossary, which describes the |
| 00:02:04,300 --> 00:02:07,330 | main terms, using the project and their meaning, and the |
| 00:02:07,330 --> 00:02:10,229 | initial business case which includes business context. And |
| 00:02:10,229 --> 00:02:13,470 | success criteria. Yet another deliverable for the inception phase |
| 00:02:13,470 --> 00:02:15,770 | is the initial project plan, which shows the |
| 00:02:15,770 --> 00:02:20,650 | phases, iterations, roles of the participants, schedule and initial |
| 00:02:20,650 --> 00:02:23,610 | estimates. In addition, the inception phase also produces |
| 00:02:23,610 --> 00:02:26,810 | a risk assessment document, which describes the main risks |
| 00:02:26,810 --> 00:02:29,970 | and counters measures for this risk. Finally, and this |
| 00:02:29,970 --> 00:02:32,430 | is an optional deliverable, in the sense that it, |
| 00:02:32,430 --> 00:02:34,990 | it might or might not be produced, depending on the specific |
| 00:02:34,990 --> 00:02:37,870 | project. As part of the inception phase we might also generate |
| 00:02:37,870 --> 00:02:41,780 | 1 or more prototypes. For example, we might develop prototypes to |
| 00:02:41,780 --> 00:02:45,590 | address some specific risks that we have identified or to show some |
| 00:02:45,590 --> 00:02:48,380 | specific aspect of the system of which we are unsure to |
| 00:02:48,380 --> 00:02:51,910 | the stakeholders. So basically all the typical users of prototypes that |
| 00:02:51,910 --> 00:02:54,600 | we discussed before. So when we're done with the inception phase |
| 00:02:54,600 --> 00:02:58,300 | we hit the first milestone for the cycle we are currently performing. |
| 00:02:58,300 --> 00:03:00,600 | And so there are some evaluation criteria that will tell |
| 00:03:00,600 --> 00:03:03,640 | us whether we can consider the inception phase concluded or not. |
| 00:03:03,640 --> 00:03:06,840 | And the first of this criteria is stakeholder concurrence, which |
| 00:03:06,840 --> 00:03:10,510 | means that all the stakeholders must agree on the scope, definition, |
| 00:03:10,510 --> 00:03:13,510 | and cost schedule estimates for the projects. The second criteria |
| 00:03:13,510 --> 00:03:17,040 | needs requirements understanding, out of the initial primary use cases that |
| 00:03:17,040 --> 00:03:20,380 | we have identified so far, the right one for our system. |
| 00:03:20,380 --> 00:03:23,760 | And other criteria is the credibility of the cost schedule estimates, |
| 00:03:23,760 --> 00:03:28,280 | the priorities, defined the risks identifies and the countermeasures for |
| 00:03:28,280 --> 00:03:31,590 | those risks, and the development process that we're following. Finally, in |
| 00:03:31,590 --> 00:03:34,000 | the case we produce prototypes as part of the inceptional |
| 00:03:34,000 --> 00:03:37,520 | phase, this will also be evaluated and assessed to judge the |
| 00:03:37,520 --> 00:03:39,960 | overall outcome of the phase. So what happens if the |
| 00:03:39,960 --> 00:03:43,170 | project fails to pass this milestone? So if the outcome of |
| 00:03:43,170 --> 00:03:46,020 | the inception phase is considered to be inadequate with respect |
| 00:03:46,020 --> 00:03:48,642 | to one or more of these criteria. Well at this point, |
| 00:03:48,642 --> 00:03:51,240 | since we're kind of an initial phase of the cycle |
| 00:03:51,240 --> 00:03:54,370 | the project may be cancelled or considerably re-thought. So to |
| 00:03:54,370 --> 00:03:57,610 | summarize all of these in one sentence the Inception Phase |
| 00:03:57,610 --> 00:04:00,320 | is the phase in which we produce. Then you shall vision, |
| 00:04:00,320 --> 00:04:04,750 | used case model, project plan, risk assessment and possibly, prototypes |
| 00:04:04,750 --> 00:04:07,290 | for the project. And we have to make sure, that |
| 00:04:07,290 --> 00:04:10,680 | all of this deliverables satisfy a set of criteria, so |
| 00:04:10,680 --> 00:04:13,770 | that we can continue on the project. And otherwise, we'll either |
| 00:04:13,770 --> 00:04:13,770 | cancel the project or rethink its scope, or other aspects of it. |