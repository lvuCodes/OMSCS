# CS6300 227 - Iterative Approach Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,182 --> 00:00:02,850 | So now, since we're talking about the incremental and iterative |
| 00:00:02,850 --> 00:00:05,950 | nature of the Rational Unified Process, let's have a quiz on |
| 00:00:05,950 --> 00:00:09,460 | the benefits of iterative approaches. So I'd like for you to tell |
| 00:00:09,460 --> 00:00:12,710 | me what are these benefits. Is one benefit the fact that |
| 00:00:12,710 --> 00:00:16,129 | iterative approaches keep developers busy or maybe that they give developers |
| 00:00:16,129 --> 00:00:19,480 | early feedback, that they allow for doing the same thing over |
| 00:00:19,480 --> 00:00:22,930 | and over in an iterative way. Maybe they also minimize the |
| 00:00:22,930 --> 00:00:25,210 | risk of developing the wrong system. Can they be used to |
| 00:00:25,210 --> 00:00:27,170 | improve planning, or is it the benefit |
| 00:00:27,170 --> 00:00:30,160 | that they accommodate evolving requirements. Also, in this |
| 00:00:30,160 --> 00:00:30,160 | case, I would like for you to check all the answers that you think are correct. |