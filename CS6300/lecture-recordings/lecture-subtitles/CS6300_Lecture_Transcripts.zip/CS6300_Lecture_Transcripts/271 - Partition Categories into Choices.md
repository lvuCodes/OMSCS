# CS6300 271 - Partition Categories into Choices

| Timestamp | Content |
|-----------|---------|
| 00:00:00,230 --> 00:00:03,250 | Now we move to the next step, which involves partitioning the |
| 00:00:03,250 --> 00:00:07,680 | categories that we just identified into choices. And these choices are the |
| 00:00:07,680 --> 00:00:11,930 | interesting cases for each category. So the interesting subdomains for each one |
| 00:00:11,930 --> 00:00:14,810 | of these categories. So once more, let's look at that using our |
| 00:00:14,810 --> 00:00:18,110 | example, the split program. So let's start by considering length. What are |
| 00:00:18,110 --> 00:00:20,710 | the interesting cases when we think about the length of a string? |
| 00:00:20,710 --> 00:00:23,220 | Some of those we already saw, one interesting case is the case |
| 00:00:23,220 --> 00:00:26,190 | of the length of size zero, so a string with no characters. |
| 00:00:26,190 --> 00:00:29,030 | Another interesting case is the one in which the length of the |
| 00:00:29,030 --> 00:00:31,780 | string is size minus one, so the string is just one character |
| 00:00:31,780 --> 00:00:34,610 | short of the size at which it will be cut by the |
| 00:00:34,610 --> 00:00:38,160 | split program. And we can continue along these lines, so we will select |
| 00:00:38,160 --> 00:00:42,950 | size, size plus one, size twice the value of size minus one, |
| 00:00:42,950 --> 00:00:45,560 | and so on and so forth. But even without listing all of |
| 00:00:45,560 --> 00:00:47,500 | those, I'm sure you get the idea of what it means to |
| 00:00:47,500 --> 00:00:49,780 | identify this interesting cases. Let's see |
| 00:00:49,780 --> 00:00:51,702 | the movements that are considering the content. |
| 00:00:51,702 --> 00:00:53,990 | So without the interesting cases when we think about the content |
| 00:00:53,990 --> 00:00:56,520 | of the string. So possible interesting case is the string that |
| 00:00:56,520 --> 00:01:00,660 | contains only spaces. Why? Well maybe because a split is written |
| 00:01:00,660 --> 00:01:04,290 | spaces in a special way. Similarly a string that contains special |
| 00:01:04,290 --> 00:01:06,780 | characters, like non printable characters, |
| 00:01:06,780 --> 00:01:09,020 | like tabulation characters, new line might |
| 00:01:09,020 --> 00:01:12,240 | also be an interesting case, something that we want to test. Also |
| 00:01:12,240 --> 00:01:14,280 | in this case we could continue and go on and on. |
| 00:01:14,280 --> 00:01:17,250 | So basically here you just want to put all the interesting cases |
| 00:01:17,250 --> 00:01:20,010 | that you can think of when you consider the content |
| 00:01:20,010 --> 00:01:22,440 | of a string. Now let's move to the value as the |
| 00:01:22,440 --> 00:01:25,740 | next category. So the value of the input size. And |
| 00:01:25,740 --> 00:01:29,280 | here we might want to consider a size zero, special case, a |
| 00:01:29,280 --> 00:01:33,640 | normal situation, like size greater than zero, another special case, |
| 00:01:33,640 --> 00:01:36,420 | size less than zero or maxint. And these are, if you |
| 00:01:36,420 --> 00:01:39,420 | remember, I accepted the cases that we consider when we look |
| 00:01:39,420 --> 00:01:42,350 | at this example, before. And also here we can continue and |
| 00:01:42,350 --> 00:01:43,970 | go on and on. So, at the end of the |
| 00:01:43,970 --> 00:01:46,860 | step, what we have is a set of interesting cases |
| 00:01:46,860 --> 00:01:49,220 | for each one of the categories, and now we can |
| 00:01:49,220 --> 00:01:49,220 | start to think about how we want to combine them. |