# CS6300 281 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:02,570 | In the previous lesson we discussed black box |
| 00:00:02,570 --> 00:00:05,120 | testing, which is the testing performed based on a |
| 00:00:05,120 --> 00:00:08,760 | description of the software, but without considering any of |
| 00:00:08,760 --> 00:00:12,440 | software's internal details. In this lesson, we will discuss |
| 00:00:12,440 --> 00:00:15,490 | the counterpart of black box testing, which is called |
| 00:00:15,490 --> 00:00:20,590 | unsurprisingly white box testing or structural testing. And just |
| 00:00:20,590 --> 00:00:22,780 | like we did for black box testing, we will |
| 00:00:22,780 --> 00:00:25,740 | cover the main characteristics of white box testing and |
| 00:00:25,740 --> 00:00:30,620 | this casts the most commonly used white box testing techniques. We |
| 00:00:30,620 --> 00:00:33,650 | will conclude the lesson with the discussion of the main strengths and |
| 00:00:33,650 --> 00:00:37,540 | limitations of white box testing. So that you will know, when to |
| 00:00:37,540 --> 00:00:37,540 | use it? How to use it? And what to expect from it? |