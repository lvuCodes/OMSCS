# CS6300 230 - Elaboration Phase

| Timestamp | Content |
|-----------|---------|
| 00:00:00,350 --> 00:00:02,400 | Now that we've discussed the inception phase, let's move |
| 00:00:02,400 --> 00:00:04,180 | on to the second phase of RUP, which is |
| 00:00:04,180 --> 00:00:07,280 | the elaboration phase. And there are four main goals |
| 00:00:07,280 --> 00:00:10,900 | and activities for the elaboration phase. Analyzing the problem domain |
| 00:00:10,900 --> 00:00:13,690 | to get a better understanding of the domain. Establishing |
| 00:00:13,690 --> 00:00:17,840 | a solid architectural foundation for the project. Eliminating the highest |
| 00:00:17,840 --> 00:00:21,454 | risk elements which basically means addressing the most critical |
| 00:00:21,454 --> 00:00:25,590 | use cases. And finally, refine the plan of activities and estimates |
| 00:00:25,590 --> 00:00:28,250 | of resources to complete the project. The outcome |
| 00:00:28,250 --> 00:00:31,310 | of the elaboration phase reflects these activities and also |
| 00:00:31,310 --> 00:00:34,440 | in this case produces several artifacts. The first one |
| 00:00:34,440 --> 00:00:38,700 | is an almost complete use case model with all use cases |
| 00:00:38,700 --> 00:00:42,560 | and actors identified and most use case descriptions developed. |
| 00:00:42,560 --> 00:00:44,070 | As part of this phase we also identify a |
| 00:00:44,070 --> 00:00:47,550 | set of what we called supplementary requirements. So these |
| 00:00:47,550 --> 00:00:50,685 | are basically all the requirements that are not associated |
| 00:00:50,685 --> 00:00:53,483 | with a use case. And these sets includes in particular all |
| 00:00:53,483 --> 00:00:56,110 | non-functional requirements such as security, |
| 00:00:56,110 --> 00:00:58,630 | reliability, maintainability and so on. So |
| 00:00:58,630 --> 00:01:00,770 | all the ones that are relevant for the system that |
| 00:01:00,770 --> 00:01:02,280 | you're developing. We mentioned before |
| 00:01:02,280 --> 00:01:04,410 | that the software architecture is developed |
| 00:01:04,410 --> 00:01:07,220 | in an incremental way, so it's not created at once. |
| 00:01:07,220 --> 00:01:09,650 | And this is exactly what happens in the elaboration phase, that |
| 00:01:09,650 --> 00:01:12,990 | we take the initial architecture that was defined in the inception |
| 00:01:12,990 --> 00:01:16,280 | phase and we refine it until we get to a software |
| 00:01:16,280 --> 00:01:19,400 | architecture which is complete. And that is part of the |
| 00:01:19,400 --> 00:01:22,410 | deliverables for this phase. And the list continues, so let |
| 00:01:22,410 --> 00:01:25,020 | me make some room. In addition to producing a complete |
| 00:01:25,020 --> 00:01:28,270 | architecture for our system, in the elaboration phase we also |
| 00:01:28,270 --> 00:01:32,130 | define the lower-level design for the system. And, therefore, as |
| 00:01:32,130 --> 00:01:35,560 | part of this phase, we produce as deliverables a design |
| 00:01:35,560 --> 00:01:38,000 | model, and together with that, a complete set of test |
| 00:01:38,000 --> 00:01:41,770 | cases, and an executable prototype. We also produce a revised |
| 00:01:41,770 --> 00:01:44,390 | project plan. Now that we have more information about the |
| 00:01:44,390 --> 00:01:47,120 | project we can refine the various estimates and the various |
| 00:01:47,120 --> 00:01:50,020 | pieces of information in the project plan. And also an |
| 00:01:50,020 --> 00:01:54,160 | updated risk assessment document. Finally, in this phase we also generate |
| 00:01:54,160 --> 00:01:57,680 | a preliminary user manual that describes to the users how |
| 00:01:57,680 --> 00:02:00,350 | the system can be used and should be used. So now |
| 00:02:00,350 --> 00:02:03,630 | let's see what are the evaluation criteria for the elaboration |
| 00:02:03,630 --> 00:02:06,880 | phase which is our second milestone. So I'm just going to list |
| 00:02:06,880 --> 00:02:09,400 | them here. The first one is whether the vision |
| 00:02:09,400 --> 00:02:12,620 | and the architecture are stable or they're still changing so |
| 00:02:12,620 --> 00:02:15,680 | did we converge into a final complete vision for the |
| 00:02:15,680 --> 00:02:18,620 | system? Does the prototype show that the major risks that |
| 00:02:18,620 --> 00:02:22,090 | we have identified have been resolved or at least addressed |
| 00:02:22,090 --> 00:02:25,390 | in this phase? Is the project plan sufficiently detailed and |
| 00:02:25,390 --> 00:02:29,030 | accurate? Do all stakeholders agree that the vision can be |
| 00:02:29,030 --> 00:02:32,320 | achieved with the current plan? Is the actual resource expenditure |
| 00:02:32,320 --> 00:02:35,840 | versus the planned expenditure acceptable? So now we study consumer |
| 00:02:35,840 --> 00:02:39,120 | resources and therefore we can check whether our estimates were |
| 00:02:39,120 --> 00:02:41,964 | correct. And also in this case the project might be |
| 00:02:41,964 --> 00:02:41,964 | cancelled or considerably reshaped if it fails to pass this milestone. |