# CS6300 200 - Debriefing

| Timestamp | Content |
|-----------|---------|
| 00:00:00,210 --> 00:00:02,200 | >> So Spencer, now that we went through |
| 00:00:02,200 --> 00:00:05,340 | this process and, I'd just like to hear |
| 00:00:05,340 --> 00:00:07,090 | whether you enjoyed it, whether you think it |
| 00:00:07,090 --> 00:00:09,640 | was useful. What are your thoughts? |
| 00:00:09,640 --> 00:00:11,661 | >> Well, ti was very interesting. I not only |
| 00:00:11,661 --> 00:00:16,541 | learned something about computers and about how you design information systems |
| 00:00:16,541 --> 00:00:19,713 | in UML, but I, it was interesting. I also learned something |
| 00:00:19,713 --> 00:00:25,290 | interesting about the library. And things that, that I knew but |
| 00:00:25,290 --> 00:00:27,920 | I never really, explicitly written down. |
| 00:00:27,920 --> 00:00:28,099 | >> Uh-huh. |
| 00:00:28,099 --> 00:00:32,280 | >> Came up during the course of doing this. And I think I now |
| 00:00:32,280 --> 00:00:35,800 | much better understand what this information system that you're |
| 00:00:35,800 --> 00:00:38,590 | going to build for us, is really all about. |
| 00:00:38,590 --> 00:00:40,480 | >> Okay, well, I mean, I'm very happy that you say |
| 00:00:40,480 --> 00:00:43,040 | that, because I really believe that, you know, doing this kind |
| 00:00:43,040 --> 00:00:46,870 | of analysis and design exercises really helps you figuring out whether |
| 00:00:46,870 --> 00:00:50,480 | there's any issues with the requirements. So for example, you can find |
| 00:00:50,480 --> 00:00:53,580 | out whether there's any missing information, or maybe conflicting |
| 00:00:53,580 --> 00:00:56,820 | information. And I think that's exactly what happened today. |
| 00:00:56,820 --> 00:01:01,120 | So I'm very glad to hear that it worked for you. That you enjoyed it. I hope you |
| 00:01:01,120 --> 00:01:03,690 | enjoyed it as well. And I strongly encourage you |
| 00:01:03,690 --> 00:01:06,000 | to do this kind of exercises for different kinds |
| 00:01:06,000 --> 00:01:08,630 | of systems. So as you can become more familiar |
| 00:01:08,630 --> 00:01:12,410 | with analysis and design techniques. So, any final thoughts? |
| 00:01:12,410 --> 00:01:15,440 | >> I look forward to receiving your delivered software. |
| 00:01:15,440 --> 00:01:15,440 | >> All right. Will do. |