# CS6300 214 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,770 --> 00:00:02,830 | In the previous lessons of this mini-course, |
| 00:00:02,830 --> 00:00:06,620 | we discussed high level design, or architecture, |
| 00:00:06,620 --> 00:00:12,380 | low level design, and design patterns. Now, we're going to see how we can put |
| 00:00:12,380 --> 00:00:15,380 | this and also others software engineering activities |
| 00:00:15,380 --> 00:00:18,436 | together in the context of a UML-based |
| 00:00:18,436 --> 00:00:21,820 | process model, the unified software process, or |
| 00:00:21,820 --> 00:00:25,580 | USP. We will discuss how USP was defined, |
| 00:00:25,580 --> 00:00:25,580 | its main characteristics, its phases, and how we can apply it in practice. |