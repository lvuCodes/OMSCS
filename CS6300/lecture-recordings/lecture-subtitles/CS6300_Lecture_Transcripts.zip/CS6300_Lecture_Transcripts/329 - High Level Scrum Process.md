# CS6300 329 - High Level Scrum Process

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,200 | So I want to conclude this lesson by providing a high |
| 00:00:02,200 --> 00:00:05,790 | level view of this scrum process. The process is represented here, |
| 00:00:05,790 --> 00:00:07,939 | and as you can see it has several components. We're going to |
| 00:00:07,939 --> 00:00:09,860 | go through all of them one at a time. We're going to |
| 00:00:09,860 --> 00:00:13,110 | start with a product backlog. Product backlog is the single source |
| 00:00:13,110 --> 00:00:17,420 | of requirements, for the process. They're order by value raised priority |
| 00:00:17,420 --> 00:00:21,110 | necessity, so that all of this characteristics can be taken into |
| 00:00:21,110 --> 00:00:25,920 | account when selecting which backlog items to consider for the next iteration. |
| 00:00:25,920 --> 00:00:28,710 | It's a living list in the sense that backlog items |
| 00:00:28,710 --> 00:00:31,020 | can be added or removed. And it's not really defined |
| 00:00:31,020 --> 00:00:33,200 | as we just said, by the product owner. In the |
| 00:00:33,200 --> 00:00:36,260 | sprint planning, what happens is that the next increment or |
| 00:00:36,260 --> 00:00:40,180 | the next sprint is defined. So basically, the backlog items |
| 00:00:40,180 --> 00:00:43,348 | of interest are selected based on the characteristics we just |
| 00:00:43,348 --> 00:00:46,890 | mentioned: value, [UNKNOWN], priority, and necessity. And the items are |
| 00:00:46,890 --> 00:00:50,950 | converted into tasks and estimated. So the result is this sprint |
| 00:00:50,950 --> 00:00:54,240 | backlog, which is the set of backlog items that will |
| 00:00:54,240 --> 00:00:57,650 | be completed during the next sprint. The sprint is an actual |
| 00:00:57,650 --> 00:01:01,040 | iteration of this scrum process. It's got a main part |
| 00:01:01,040 --> 00:01:04,730 | that lasts two to four weeks, and within this main part, |
| 00:01:04,730 --> 00:01:08,150 | there are many daily scrums that last 24 hours. So |
| 00:01:08,150 --> 00:01:11,260 | let's see how this work. A daily scrum is typically characterized |
| 00:01:11,260 --> 00:01:13,960 | by a 50-minute meeting at the beginning of the day |
| 00:01:13,960 --> 00:01:16,220 | for the team to sync, and what happens during the meeting |
| 00:01:16,220 --> 00:01:19,010 | is that there is a discussion of the accomplishments since |
| 00:01:19,010 --> 00:01:21,210 | the last meeting. A to do list for the next |
| 00:01:21,210 --> 00:01:24,210 | meeting is produced, and there is also an obstacle analysis. |
| 00:01:24,210 --> 00:01:27,690 | So if some problem appear, they're discussing the daily scrum, and |
| 00:01:27,690 --> 00:01:30,905 | possible solutions are proposed. At the end of the two |
| 00:01:30,905 --> 00:01:34,840 | four-week cycle, there is a sprint review and retrospective. The sprint |
| 00:01:34,840 --> 00:01:37,440 | review normally consists of a four hour meeting. In the |
| 00:01:37,440 --> 00:01:41,270 | meeting, the product owner assesses the accomplishment for the specific sprint, |
| 00:01:41,270 --> 00:01:44,020 | and the team discusses issues that were encountered and solved. |
| 00:01:44,020 --> 00:01:46,530 | There is typically a demo of the deliverable for that |
| 00:01:46,530 --> 00:01:48,810 | sprint. And at that point, the product owner will also |
| 00:01:48,810 --> 00:01:52,610 | discuss the backlogs. And together with the team they will decide |
| 00:01:52,610 --> 00:01:56,230 | what to do next. In the retrospective conversely what happens |
| 00:01:56,230 --> 00:01:59,140 | is there is more focus on the process. So the |
| 00:01:59,140 --> 00:02:02,010 | goal of that part of the meeting is discussing possible |
| 00:02:02,010 --> 00:02:04,850 | process improvements. To identify them |
| 00:02:04,850 --> 00:02:07,140 | and if promising improvements are identified |
| 00:02:07,140 --> 00:02:10,810 | try to plan how to implement those improvements and use them |
| 00:02:10,810 --> 00:02:13,790 | in the next iterations. And something else that might happen at |
| 00:02:13,790 --> 00:02:16,720 | the end of a sprint is that if the product increment |
| 00:02:16,720 --> 00:02:19,210 | is good enough as it reach the state in which it |
| 00:02:19,210 --> 00:02:22,660 | can be actually shipped that will result in a release that |
| 00:02:22,660 --> 00:02:25,730 | is not just internal. To show the product owner the progress |
| 00:02:25,730 --> 00:02:28,510 | that can also be deployed and actually used in production. So |
| 00:02:28,510 --> 00:02:32,650 | one final consideration is that as you can see, XP and scrum |
| 00:02:32,650 --> 00:02:35,340 | are fairly similar, and that's because they're both agile development |
| 00:02:35,340 --> 00:02:37,930 | processes. So the main thing to keep in mind is that |
| 00:02:37,930 --> 00:02:40,620 | they both implement and enforce |
| 00:02:40,620 --> 00:02:44,380 | those ideas, values, practices, and characteristics |
| 00:02:44,380 --> 00:02:44,380 | that we saw when we discussed agile development process in general. |