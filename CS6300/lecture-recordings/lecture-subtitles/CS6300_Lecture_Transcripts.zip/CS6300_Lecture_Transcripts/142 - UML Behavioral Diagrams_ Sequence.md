# CS6300 142 - UML Behavioral Diagrams_ Sequence

| Timestamp                     | Content                                                                    |
| ----------------------------- | -------------------------------------------------------------------------- |
| 00:00:00,080 --> 00:00:02,400 | Now that we have seen use cases, the next behavioral                       |
| 00:00:02,400 --> 00:00:05,540 | diagram I want to discuss is the sequence diagram. So                      |
| 00:00:05,540 --> 00:00:08,070 | **what is a sequence diagram? It is an interaction diagram**               |
| 00:00:08,070 --> 00:00:12,710 | **that emphasizes how objects communicate and the time ordering of**       |
| 00:00:12,710 --> 00:00:15,940 | **the messages between objects.** To illustrate sequence diagrams in a     |
| 00:00:15,940 --> 00:00:18,600 | practical way, and hopefully in a clear way, I will                        |
| 00:00:18,600 --> 00:00:21,960 | introduce them by creating an actual sequence diagram using an             |
| 00:00:21,960 --> 00:00:25,160 | example taken from our course management system. So let's see what         |
| 00:00:25,160 --> 00:00:28,050 | are the steps needed to build such a sequence diagram. The first           |
| 00:00:28,050 --> 00:00:30,900 | **thing we want to do is place the objects that participate in**           |
| 00:00:30,900 --> 00:00:34,460 | **the interaction at the top of the diagram along the x-axis, and**        |
| 00:00:34,460 --> 00:00:36,410 | **you also want to place them in a specific way. You want**                |
| 00:00:36,410 --> 00:00:39,770 | **to place objects that initiate the interaction at the left, and place**  |
| 00:00:39,770 --> 00:00:42,260 | **increasingly more subordinate objects to the**                           |
| 00:00:42,260 --> 00:00:44,430 | **right**. So basically, this should reflect                               |
| 00:00:44,430 --> 00:00:47,660 | the way the events will flow for the majority of the interactions          |
| 00:00:47,660 --> 00:00:50,202 | in the system. Next thing you want to do is to add                         |
| 00:00:50,202 --> 00:00:53,910 | what is called the **object lifeline. It's a vertical line that**          |
| 00:00:53,910 --> 00:00:57,300 | **shows the existence of objects over a period of time. And**              |
| 00:00:57,300 --> 00:01:00,660 | **it's normally represented with a dashed line, except for the outermost** |
| 00:01:00,660 --> 00:01:03,190 | **object for which it is a solid line. Now that you**                      |
| 00:01:03,190 --> 00:01:06,450 | have your object lifeline you can start placing messages that these        |
| 00:01:06,450 --> 00:01:09,285 | objects send and receive. You want to put them along the                   |
| 00:01:09,285 --> 00:01:12,860 | **y-axis in order of increasing time, from top to bottom. And**            |
| 00:01:12,860 --> 00:01:15,550 | you can also put a number on the message to further                        |
| 00:01:15,550 --> 00:01:18,230 | clarify the sequence. So in this case what we're showing                   |
| 00:01:18,230 --> 00:01:21,550 | is that the student will send the fill in info                             |
| 00:01:21,550 --> 00:01:24,330 | message to the registration form. And this is the first                    |
| 00:01:24,330 --> 00:01:27,960 | message in the sequence diagram, the first interaction. Then the student   |
| 00:01:27,960 --> 00:01:30,900 | might submit the form and this is also a message                           |
| 00:01:30,900 --> 00:01:33,370 | that goes to the registration form. At this point, when                    |
| 00:01:33,370 --> 00:01:36,440 | the submission takes place, the registration form will send the            |
| 00:01:36,440 --> 00:01:39,990 | message, so it will invoke some functionality in the registration manager. |
| 00:01:39,990 --> 00:01:43,560 | Specifically you will invoke the add course functionality                  |
| 00:01:43,560 --> 00:01:46,400 | and pass Joe, the name of the student and                                  |
| 00:01:46,400 --> 00:01:49,410 | Math 101 which is the specific course for which                            |
| 00:01:49,410 --> 00:01:53,180 | Joe is registering. Then the registration manager will ask                 |
| 00:01:53,180 --> 00:01:56,780 | the Math 101 course whether it accepts registrations,                      |
| 00:01:56,780 --> 00:01:59,780 | and the interaction will continue. So that Math 101                        |
| 00:01:59,780 --> 00:02:02,820 | will actually check for a specific offering, if everything                 |
| 00:02:02,820 --> 00:02:05,070 | goes fine, you will receive an ack, you'll send                            |
| 00:02:05,070 --> 00:02:07,180 | back the act to the registration manager and so                            |
| 00:02:07,180 --> 00:02:10,650 | on. Until at the end, Joe will be registered for                           |
| 00:02:10,650 --> 00:02:13,390 | Math 101. As you can see, it is very                                       |
| 00:02:13,390 --> 00:02:17,600 | easy to see how the interaction occurs between these different             |
| 00:02:17,600 --> 00:02:21,010 | objects at run time, dynamically. So what the behavior                     |
| 00:02:21,010 --> 00:02:24,070 | of the system is for this specific scenario. So the                        |
| 00:02:24,070 --> 00:02:26,780 | last notational element that I want to add to this                         |
| 00:02:26,780 --> 00:02:30,350 | **diagram is the focus of control. Which is this tall**                    |
| 00:02:30,350 --> 00:02:32,880 | **thin rectangle, that shows the period of time**                          |
| 00:02:32,880 --> 00:02:35,190 | **that an object is performing an action, either**                         |
| 00:02:35,190 --> 00:02:37,270 | **directly or indirectly. So if we look at**                               |
| 00:02:37,270 --> 00:02:39,240 | the registration form, this is telling us that                             |
| 00:02:39,240 --> 00:02:41,670 | the registration form is active for this amount                            |
| 00:02:41,670 --> 00:02:43,170 | of time. And the same thing we can                                         |
| 00:02:43,170 --> 00:02:45,520 | do for the registration manager, the Math 101                              |
| 00:02:45,520 --> 00:02:45,520 | course offering, and the Math 101 specific section.                        |
![[lvu 2026-02-15 at 09.53PM 1.png]]