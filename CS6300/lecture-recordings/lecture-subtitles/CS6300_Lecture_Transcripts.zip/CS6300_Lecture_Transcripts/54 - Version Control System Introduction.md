# CS6300 54 - Version Control System Introduction

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:02,080 | So first of all, what is a version |
| 00:00:02,080 --> 00:00:05,550 | control system? A version control system or VCS, |
| 00:00:05,550 --> 00:00:07,670 | is a system that allows you to manage |
| 00:00:07,670 --> 00:00:11,180 | multiple revisions of the same unit of information. For |
| 00:00:11,180 --> 00:00:14,330 | example of documents, of source files or any |
| 00:00:14,330 --> 00:00:17,380 | other item of that sort. And as the graphical |
| 00:00:17,380 --> 00:00:21,240 | depiction shows, a VCS allows a multiple actors. |
| 00:00:21,240 --> 00:00:25,020 | Here we have four, to cooperate and share files. |
| 00:00:25,020 --> 00:00:26,980 | Now, let's drill into this concept in a little |
| 00:00:26,980 --> 00:00:29,720 | more detail. And let's do that by discussing why |
| 00:00:29,720 --> 00:00:32,870 | is VCS useful, especially in the context of software |
| 00:00:32,870 --> 00:00:35,790 | engineering and of software development. So first of all, |
| 00:00:35,790 --> 00:00:39,570 | using a version control system enforces discipline, because it |
| 00:00:39,570 --> 00:00:43,030 | manages the process by which the control of items |
| 00:00:43,030 --> 00:00:46,720 | passes from one person to another. Another important aspect |
| 00:00:46,720 --> 00:00:51,170 | of VCS is that it allows you for archiving versions. |
| 00:00:51,170 --> 00:00:54,330 | So you can store subsequent versions of source controlled |
| 00:00:54,330 --> 00:00:57,450 | items into a VCS. And not only you can |
| 00:00:57,450 --> 00:01:00,450 | store versions, you can also maintain a lot of |
| 00:01:00,450 --> 00:01:03,480 | interesting and important historical information |
| 00:01:03,480 --> 00:01:05,810 | about these versions. For example, |
| 00:01:05,810 --> 00:01:08,070 | a VCL will store information such as, who is |
| 00:01:08,070 --> 00:01:11,270 | the author for this specific version stored in the system. |
| 00:01:11,270 --> 00:01:13,820 | Or, for another example, on what day and what |
| 00:01:13,820 --> 00:01:16,260 | time that version was stored. And a lot of other |
| 00:01:16,260 --> 00:01:19,240 | interesting information about the specific version of the |
| 00:01:19,240 --> 00:01:21,600 | item. Information that you can then retrieve and for |
| 00:01:21,600 --> 00:01:25,040 | example, use to compare versions. Obviously, the fact of |
| 00:01:25,040 --> 00:01:27,970 | having a central repository in which all these items |
| 00:01:27,970 --> 00:01:31,350 | are stored enables collaboration, so people can more easily |
| 00:01:31,350 --> 00:01:35,510 | share data, share files, share documents through the use |
| 00:01:35,510 --> 00:01:37,950 | of VCS. And I'm sure that you all had |
| 00:01:37,950 --> 00:01:41,320 | the experience of deleting a file by mistake or |
| 00:01:41,320 --> 00:01:43,860 | modifying a file in the wrong way, or in the |
| 00:01:43,860 --> 00:01:47,830 | most common case of changing something in your code for instance. |
| 00:01:47,830 --> 00:01:50,490 | And breaking something and not being able to go back |
| 00:01:50,490 --> 00:01:53,630 | to a version that was working. Not remembering, for example, what |
| 00:01:53,630 --> 00:01:56,130 | is that you changed that broke the code. In all |
| 00:01:56,130 --> 00:01:59,850 | these cases a version control system can be extremely useful because |
| 00:01:59,850 --> 00:02:03,330 | it will allow you to recover from this accidental deletions |
| 00:02:03,330 --> 00:02:06,690 | or edits. And for example, to go back of yesterdays version |
| 00:02:06,690 --> 00:02:09,949 | that was working perfectly, and also to compare, for example, yesterdays |
| 00:02:09,949 --> 00:02:12,920 | version with today version and see what is that you changed. |
| 00:02:12,920 --> 00:02:16,000 | Finally, a version control system will normally also allow you to |
| 00:02:16,000 --> 00:02:20,460 | conserve and save disk space on both the source control client |
| 00:02:20,460 --> 00:02:23,880 | and on the server. Why? Well, for instance because it's centralizing |
| 00:02:23,880 --> 00:02:26,570 | the management of the version. So instead of having many copies |
| 00:02:26,570 --> 00:02:29,480 | spread around, you'll have only one central point where these copies |
| 00:02:29,480 --> 00:02:32,240 | are stored or a few points where these copies are stored. |
| 00:02:32,240 --> 00:02:34,330 | In addition, version control system often |
| 00:02:34,330 --> 00:02:37,470 | uses efficient algorithms to store these changes. |
| 00:02:37,470 --> 00:02:37,470 | And therefore, you can keep many versions without taking up too much space. |