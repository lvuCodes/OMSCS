# CS6300 61 - Introduction to GIT

| Timestamp | Content |
|-----------|---------|
| 00:00:00,240 --> 00:00:04,160 | One good representative of distributed version control systems, is |
| 00:00:04,160 --> 00:00:08,320 | GIT. A distributed version control system that was initially designed |
| 00:00:08,320 --> 00:00:11,297 | and developed by Linus Torvalds. I'm pretty sure you |
| 00:00:11,297 --> 00:00:14,140 | know who Linus Torvalds is. He's basically this guy who |
| 00:00:14,140 --> 00:00:17,070 | started and created the Linux operating system. And Linus |
| 00:00:17,070 --> 00:00:20,140 | was unhappy with the existing version control systems, and wanted |
| 00:00:20,140 --> 00:00:22,610 | a different one. He wanted to use it for maintaining |
| 00:00:22,610 --> 00:00:25,330 | the Linux kernel. In particular, he wanted one with some |
| 00:00:25,330 --> 00:00:28,550 | key characteristics. For example, the fact that it was distributed. He |
| 00:00:28,550 --> 00:00:30,470 | wanted it to be fast. He wanted it to have a |
| 00:00:30,470 --> 00:00:33,660 | simple design. And he wanted to have a strong support for |
| 00:00:33,660 --> 00:00:37,370 | parallel branches, because many people were contributing to the kernel at the |
| 00:00:37,370 --> 00:00:41,620 | same time. And therefore there many different branches of development. And |
| 00:00:41,620 --> 00:00:45,120 | finally, he wanted for the virtual control system to be able to |
| 00:00:45,120 --> 00:00:48,070 | handle large projects. As the Linux kernel is, and to do |
| 00:00:48,070 --> 00:00:50,480 | it in an efficient way. So if you want to get an idea |
| 00:00:50,480 --> 00:00:54,210 | of how popular GIT is today, there was a survey performed across the |
| 00:00:54,210 --> 00:00:58,330 | Eclipse IDE users, and it showed that in 2013 GIT was used by |
| 00:00:58,330 --> 00:01:02,950 | about 30% of the developers. So the, it had a 30% adoption rate. |
| 00:01:02,950 --> 00:01:02,950 | So we will use a GIT as a version control system for the class. |