# CS6300 314 - Extreme Programming (XP)

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,490 | So now let's talk about a specific agile method, which |
| 00:00:02,490 --> 00:00:05,850 | is also one of the first ones, extreme programming, also called |
| 00:00:05,850 --> 00:00:08,430 | XP. And to introduce XP, I'm going to start with |
| 00:00:08,430 --> 00:00:12,520 | a quote. The quote says XP is a lightweight methodology for |
| 00:00:12,520 --> 00:00:16,180 | small to medium sized teams developing software in the face |
| 00:00:16,180 --> 00:00:19,770 | of vague or rapidly-changing requirements. And this is a quote from |
| 00:00:19,770 --> 00:00:23,010 | Kent Beck the American Software Engineer that created extreme programming. |
| 00:00:23,010 --> 00:00:25,630 | And by the way Beck was one of the original 17 |
| 00:00:25,630 --> 00:00:29,570 | developers who signed the manifesto in 2001. And as you can see |
| 00:00:29,570 --> 00:00:31,940 | we are still talking about the methodology. So we are not just |
| 00:00:31,940 --> 00:00:35,760 | talking about going out and just start writing software. There are principles. |
| 00:00:35,760 --> 00:00:38,130 | And there are practices that we need to follow, but we're going |
| 00:00:38,130 --> 00:00:40,330 | to do it in a much more agile, and a much more |
| 00:00:40,330 --> 00:00:43,720 | flexible ways than we did for our software processes. And also note |
| 00:00:43,720 --> 00:00:45,340 | that the vague and rapidly changing |
| 00:00:45,340 --> 00:00:47,190 | requirements are explicitly mentioned, because this |
| 00:00:47,190 --> 00:00:51,130 | is really one of the important parts about all of this agile methodologies. |
| 00:00:51,130 --> 00:00:54,780 | so what is XP? XP is a. Lightweight. Humanistic. |
| 00:00:54,780 --> 00:00:58,250 | Discipline. Of software development. It is lightweight because it doesn't |
| 00:00:58,250 --> 00:01:02,190 | overburden the developers with an invasive process. So process |
| 00:01:02,190 --> 00:01:04,510 | is kept to a minimum. It's humanistic because as we |
| 00:01:04,510 --> 00:01:07,760 | said, it's centered on people. People, developers, customers, are |
| 00:01:07,760 --> 00:01:10,520 | at the center of the process. It's a discipline, as |
| 00:01:10,520 --> 00:01:12,870 | we said, it includes practices that we to Follow. |
| 00:01:12,870 --> 00:01:16,470 | And finally, is of course about software development. Software development |
| 00:01:16,470 --> 00:01:19,530 | is a key point of the whole method. In XP, developing |
| 00:01:19,530 --> 00:01:22,910 | is like driving, imagine having a road, a wind road, we need |
| 00:01:22,910 --> 00:01:25,110 | to able to drive our car down the road, take the |
| 00:01:25,110 --> 00:01:29,640 | abrupt turns, react promptly to changes, for example obstacles on the road. |
| 00:01:29,640 --> 00:01:32,610 | So, in a nutshell, change is the only constant. Eyes always |
| 00:01:32,610 --> 00:01:34,980 | have to be on the road and it's about steering and not |
| 00:01:34,980 --> 00:01:38,110 | pointing, and XP is trying to do the same thing, while creating |
| 00:01:38,110 --> 00:01:42,190 | softer systems. In XP we need to adopt a mentality of sufficiency, |
| 00:01:42,190 --> 00:01:44,820 | what does that mean? How would you program if you had all |
| 00:01:44,820 --> 00:01:48,010 | the time in the world? No time constraints at all, you will probably |
| 00:01:48,010 --> 00:01:51,090 | write tests instead of skipping them, because there's no more resources. You |
| 00:01:51,090 --> 00:01:53,200 | will probably restructure your code often, |
| 00:01:53,200 --> 00:01:55,210 | because you see opportunities to improve it, |
| 00:01:55,210 --> 00:01:57,300 | and you will take them. And you will probably talk to fellow |
| 00:01:57,300 --> 00:02:00,910 | programmers and with the customer, interact with them, and this is actually the |
| 00:02:00,910 --> 00:02:04,700 | kind of mentality that XP is trying to promote and agile processes |
| 00:02:04,700 --> 00:02:07,760 | in general. And we will see that the following some of the practices |
| 00:02:07,760 --> 00:02:11,250 | that XP is advocating, you can actually achieve these goals and you can |
| 00:02:11,250 --> 00:02:12,840 | actually behave in this way. And the |
| 00:02:12,840 --> 00:02:12,840 | development process is going to benefit overall. |