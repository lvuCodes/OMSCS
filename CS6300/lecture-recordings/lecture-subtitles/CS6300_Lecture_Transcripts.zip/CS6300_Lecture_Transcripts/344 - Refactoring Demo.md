# CS6300 344 - Refactoring Demo

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:03,110 | So now we saw, this set of re-factoring's. They're nice, but |
| 00:00:03,110 --> 00:00:06,260 | how can we actually perform re-factoring's? In some cases you'll have to |
| 00:00:06,260 --> 00:00:08,430 | do it by hand. And you'll do it in that case in |
| 00:00:08,430 --> 00:00:10,880 | small steps, so that you can check at every step that you |
| 00:00:10,880 --> 00:00:14,180 | didn't introduce any area. But there's also many cases in which at |
| 00:00:14,180 --> 00:00:17,640 | least for the more standard re-factoring's, you can just apply, you can |
| 00:00:17,640 --> 00:00:21,530 | just use a tool that actually supports re-factoring. I'm going to show |
| 00:00:21,530 --> 00:00:26,120 | you how that works, into a specific ID, Eclipse through a demo. |
| 00:00:26,120 --> 00:00:28,425 | To show you how Eclipse, can help in performing |
| 00:00:28,425 --> 00:00:31,880 | re-factoring, in an automated way, I just opened the Eclipse |
| 00:00:31,880 --> 00:00:35,050 | editor and I maximized it. So that we can look |
| 00:00:35,050 --> 00:00:36,810 | at the code more clearly. And as you can see |
| 00:00:36,810 --> 00:00:39,551 | here, I have this class. It's called Re-factorable, it's a |
| 00:00:39,551 --> 00:00:43,550 | pretty indicative name. And what we're going to do, we're going to |
| 00:00:43,550 --> 00:00:47,840 | try to apply the extract method re-factoring to this class. |
| 00:00:47,840 --> 00:00:51,060 | And in particular, to parts of this print owing method. |
| 00:00:51,060 --> 00:00:54,090 | So this is a matter than will print owing's, |
| 00:00:54,090 --> 00:00:56,160 | as the name says. And it will do several things |
| 00:00:56,160 --> 00:00:59,180 | such as, for example, printing a banner first, then |
| 00:00:59,180 --> 00:01:03,650 | calculating the outstanding debts, and then printing some details. So |
| 00:01:03,650 --> 00:01:06,980 | the starting point for an extract method re-fractoring, is |
| 00:01:06,980 --> 00:01:10,650 | the identification of some cohesive code fragment. And here, for |
| 00:01:10,650 --> 00:01:12,970 | instance, we can see that, if we can see there, |
| 00:01:12,970 --> 00:01:16,350 | these three print statements. They are basically printing some banner, |
| 00:01:16,350 --> 00:01:18,530 | for the method. And I also put a comment here |
| 00:01:18,530 --> 00:01:21,160 | just to make that even more explicit. So this is a |
| 00:01:21,160 --> 00:01:23,970 | perfect case in which we might want to just extract |
| 00:01:23,970 --> 00:01:27,220 | this part, create an independent method, so that we can make |
| 00:01:27,220 --> 00:01:31,410 | the code more readable and maintainable. So I select, the |
| 00:01:31,410 --> 00:01:33,320 | part of the code, that I want to put in my |
| 00:01:33,320 --> 00:01:37,080 | method. I invoke the contextual menu, and as you can see |
| 00:01:37,080 --> 00:01:41,287 | there is a re-factor entry here. Here are some re-factoring's [UNKNOWN], |
| 00:01:41,287 --> 00:01:45,039 | re-factoring's that I can apply, and I'm going to select extract |
| 00:01:45,039 --> 00:01:48,120 | method. When I do that, Eclipse is going to ask me to |
| 00:01:48,120 --> 00:01:51,610 | specify a method name. I'll just call this one print |
| 00:01:51,610 --> 00:01:54,260 | banner. And as you can see, as soon as I do |
| 00:01:54,260 --> 00:01:57,310 | that, Eclipse will show me the preview, for the method |
| 00:01:57,310 --> 00:02:01,010 | that will be generated. I'm going to leave the access modifier. To |
| 00:02:01,010 --> 00:02:03,290 | public and I'm not going to change anything else. So, |
| 00:02:03,290 --> 00:02:07,760 | now when I click Ok. As you can see Eclipse modified |
| 00:02:07,760 --> 00:02:10,669 | my code so that now I have the Print Banner method |
| 00:02:10,669 --> 00:02:14,050 | down here that does exactly what that piece of code was doing |
| 00:02:14,050 --> 00:02:16,090 | before. And I just have an invocation of the Print Banner |
| 00:02:16,090 --> 00:02:19,440 | method, up here, where the code was before. And of course, this |
| 00:02:19,440 --> 00:02:21,830 | is something that we could have done by hand. It's pretty |
| 00:02:21,830 --> 00:02:25,480 | easy to do, but it's even easier, to do it using Eclipse's |
| 00:02:25,480 --> 00:02:29,040 | capabilities. And this will become even more apparent, when we consider slightly |
| 00:02:29,040 --> 00:02:32,866 | more complex case. So here, if we look at this piece of |
| 00:02:32,866 --> 00:02:35,234 | code for instance, we can that see this code |
| 00:02:35,234 --> 00:02:38,264 | prints some details, about the always. And the reason |
| 00:02:38,264 --> 00:02:41,351 | why this case is likely more complicated, is because |
| 00:02:41,351 --> 00:02:45,210 | this code needs to know about the value of outstanding. |
| 00:02:45,210 --> 00:02:49,130 | And whereas that underscore name, is a member of |
| 00:02:49,130 --> 00:02:51,150 | the class, and therefore will be available to the |
| 00:02:51,150 --> 00:02:55,110 | method. Outstanding is a locker variable, so a method |
| 00:02:55,110 --> 00:02:58,310 | different from print, oh it wouldn't know anything about outstanding. |
| 00:02:58,310 --> 00:03:00,070 | So let's see what happens when we try to apply |
| 00:03:00,070 --> 00:03:03,460 | a re-factoring for this code. So we go again here |
| 00:03:03,460 --> 00:03:06,410 | to the re-factor menu, we select extract method, we will |
| 00:03:06,410 --> 00:03:10,080 | pick a name again. So let's call it [SOUND] print details, |
| 00:03:10,080 --> 00:03:12,660 | since this is what the code does. And as you |
| 00:03:12,660 --> 00:03:17,270 | can see here, Eclipse was able to figure out, that outstanding |
| 00:03:17,270 --> 00:03:20,290 | has to be a parameter, of this method. So if |
| 00:03:20,290 --> 00:03:23,340 | you look at the signature here, this will be very clear. |
| 00:03:23,340 --> 00:03:26,270 | So outstanding has to be passed to the matter because |
| 00:03:26,270 --> 00:03:29,230 | it's a locker variable of the print owing method. so |
| 00:03:29,230 --> 00:03:32,600 | it will not be visible to the other methods otherwise. |
| 00:03:32,600 --> 00:03:34,990 | So since eclipse figured it out, all I have to do, |
| 00:03:34,990 --> 00:03:37,630 | is to press Ok. And at this point what I |
| 00:03:37,630 --> 00:03:41,280 | will have here is my new method, for in details |
| 00:03:41,280 --> 00:03:45,140 | that takes outstanding as a parameter. And does exactly what |
| 00:03:45,140 --> 00:03:48,880 | the code was doing before. And here, where the code was, |
| 00:03:48,880 --> 00:03:51,630 | I will have my print details invocation, with outstanding |
| 00:03:51,630 --> 00:03:54,930 | as a parameter. So now, let's continue to extract methods. |
| 00:03:54,930 --> 00:03:58,470 | And let's look at a even more complex case. which |
| 00:03:58,470 --> 00:04:01,550 | is, the one involving this piece of code. So this |
| 00:04:01,550 --> 00:04:03,900 | piece of code, as you can see, will calculate |
| 00:04:03,900 --> 00:04:07,820 | the value of the outstanding debt. Will calculate the owing's, |
| 00:04:07,820 --> 00:04:09,600 | and the way in which it does that, is by |
| 00:04:09,600 --> 00:04:14,080 | considering all the orders, that are part of this enumeration. |
| 00:04:14,080 --> 00:04:16,519 | That is the declared here, and it will |
| 00:04:16,519 --> 00:04:20,769 | compute for each one, of these orders, the amount, |
| 00:04:20,769 --> 00:04:23,520 | and then added to outstanding. So what is the |
| 00:04:23,520 --> 00:04:26,160 | additional complication here? Well, the additional complication here is |
| 00:04:26,160 --> 00:04:29,520 | that this code needs to know, not only |
| 00:04:29,520 --> 00:04:33,220 | about outstanding. It also needs to know, about this |
| 00:04:33,220 --> 00:04:36,160 | enumeration, because this one is also a local variable. |
| 00:04:36,160 --> 00:04:39,140 | And in addition to that, this code also has |
| 00:04:39,140 --> 00:04:43,280 | some side effects. So outstanding, is modified as a |
| 00:04:43,280 --> 00:04:46,600 | consequence of the execution of this code. So how can |
| 00:04:46,600 --> 00:04:49,120 | we do that in the extracted method? Well let's |
| 00:04:49,120 --> 00:04:51,000 | see what the clips will do and what the clips |
| 00:04:51,000 --> 00:04:53,950 | will suggest. It will try to again re-factor this |
| 00:04:53,950 --> 00:04:58,030 | code and extract the method. In this case as you |
| 00:04:58,030 --> 00:05:01,160 | can see. The clips does two things. First of all, |
| 00:05:01,160 --> 00:05:04,180 | it figures out as before, that there are some parameters, |
| 00:05:04,180 --> 00:05:07,650 | that are needed for this method to operate correctly. The |
| 00:05:07,650 --> 00:05:11,600 | enumeration e, as we said, and the outstanding variable. In |
| 00:05:11,600 --> 00:05:14,880 | addition, if you look at the method signature Eclipse will |
| 00:05:14,880 --> 00:05:17,490 | also figure out that this method has to return, a |
| 00:05:17,490 --> 00:05:21,530 | double value. So what does this value correspond to? This |
| 00:05:21,530 --> 00:05:24,700 | value corresponds to a new value of outstanding. So if |
| 00:05:24,700 --> 00:05:27,490 | we, give a name to this method, so we just |
| 00:05:27,490 --> 00:05:29,620 | use the name, [SOUND] that I put in the comment |
| 00:05:29,620 --> 00:05:33,510 | over there. We click Ok, and this will create |
| 00:05:33,510 --> 00:05:36,560 | a method by extracting the code. And here, where the |
| 00:05:36,560 --> 00:05:39,100 | method used to be, we will have that the |
| 00:05:39,100 --> 00:05:43,169 | value of outstanding is updated. Based on the return value |
| 00:05:43,169 --> 00:05:46,260 | of calculate outstanding. So in the end if we |
| 00:05:46,260 --> 00:05:48,730 | look at this code, you can see that if we |
| 00:05:48,730 --> 00:05:51,980 | just focus, on this code it's very easy to |
| 00:05:51,980 --> 00:05:55,150 | understand what it does. It prints the banner, it calculates |
| 00:05:55,150 --> 00:05:59,180 | an outstanding value, and then it prints some details. And |
| 00:05:59,180 --> 00:06:01,520 | in case we don't care, as I said before, about the |
| 00:06:01,520 --> 00:06:04,840 | details of what these methods do, we're done. And if we |
| 00:06:04,840 --> 00:06:07,740 | care about the details we can look at each matter individually. |
| 00:06:07,740 --> 00:06:10,580 | And get exactly the same information that we got before, |
| 00:06:10,580 --> 00:06:13,650 | in a sort of a separation of concerns kind of way, |
| 00:06:13,650 --> 00:06:16,420 | by focusing on one problem at a time. So now let |
| 00:06:16,420 --> 00:06:19,345 | me do one last thing. So let me modify the code, |
| 00:06:19,345 --> 00:06:23,170 | slightly. So i'm going to go back, to the version of |
| 00:06:23,170 --> 00:06:25,610 | the code before re-factoring. So this is what we had. |
| 00:06:25,610 --> 00:06:32,480 | And I'm going to add, an additional variable here, [SOUND] called count, |
| 00:06:32,480 --> 00:06:38,870 | which I initialize to zero. Here I'm going to increase, [SOUND] |
| 00:06:38,870 --> 00:06:41,360 | the value of count at every iteration. And |
| 00:06:41,360 --> 00:06:44,570 | finally, here I'm going to print out the value |
| 00:06:44,570 --> 00:06:50,130 | of count. Okay, now that I have this code up. So let's imagine that I |
| 00:06:50,130 --> 00:06:55,665 | want to, again as I did before, extract this matter. So, I'm going to |
| 00:06:55,665 --> 00:06:58,430 | give you a second. Have a look at this and see, if you see |
| 00:06:58,430 --> 00:07:07,350 | any problem with that. Feel free to stop the video, if you need more time. |
| 00:07:07,350 --> 00:07:11,440 | So the problem here is that I have two side effects. |
| 00:07:11,440 --> 00:07:14,820 | Both outstanding and count are modified. And therefore it's not really |
| 00:07:14,820 --> 00:07:19,600 | possible to extract this method, and preserve the semantics of this |
| 00:07:19,600 --> 00:07:26,130 | code. Let's see if Eclipse will be able to figure that out. |
| 00:07:26,130 --> 00:07:28,950 | And it does. If we try to extract the matter here, |
| 00:07:28,950 --> 00:07:32,250 | you'll tell us that's an ambiguous return value. The selected block |
| 00:07:32,250 --> 00:07:35,800 | contains more than one assignment to look at variables. And the |
| 00:07:35,800 --> 00:07:40,170 | affected variables are outstanding, just a Double and Count which is |
| 00:07:40,170 --> 00:07:44,780 | an integer. So it will refuse to extract the method. So |
| 00:07:44,780 --> 00:07:46,470 | at this point if we wanted to do that we have |
| 00:07:46,470 --> 00:07:48,650 | we'll have to do the re-factoring a different way, but I |
| 00:07:48,650 --> 00:07:51,110 | don't really want to get there. I want to conclude here, |
| 00:07:51,110 --> 00:07:53,440 | and I hope this this little demo helped you |
| 00:07:53,440 --> 00:07:55,310 | realize how useful it can be to use an |
| 00:07:55,310 --> 00:07:58,270 | id that supports re-factoring that can automate this important |
| 00:07:58,270 --> 00:08:00,160 | task. And I also encourage you to try to play |
| 00:08:00,160 --> 00:08:03,170 | with this, and try to use different re-factoring's, on |
| 00:08:03,170 --> 00:08:05,480 | your code. So as to get familiar with the kind |
| 00:08:05,480 --> 00:08:08,060 | of re-factoring's that are supported by the ID. And |
| 00:08:08,060 --> 00:08:08,060 | also with the re-factoring's themselves and how should be used. |