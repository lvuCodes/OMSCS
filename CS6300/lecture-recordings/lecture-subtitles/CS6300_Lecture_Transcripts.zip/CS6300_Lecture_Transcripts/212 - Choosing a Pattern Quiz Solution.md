# CS6300 212 - Choosing a Pattern Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,220 --> 00:00:01,750 | As we discussed in the class the right thing to |
| 00:00:01,750 --> 00:00:05,050 | do here was to use the factory pattern. So here is |
| 00:00:05,050 --> 00:00:07,910 | a possible code to solve the problem. Of course that there |
| 00:00:07,910 --> 00:00:11,220 | are different possible solutions. So what we did for this code |
| 00:00:11,220 --> 00:00:16,210 | was to first create a private, static, Singleton object called |
| 00:00:16,210 --> 00:00:19,340 | instance, which is the one that will keep track of the |
| 00:00:19,340 --> 00:00:22,250 | only instance that can be created on the class. Then we |
| 00:00:22,250 --> 00:00:25,750 | define the default constructor, the constructor that doesn't take any parameter |
| 00:00:25,750 --> 00:00:29,900 | as private. In this way other classes cannot create instances |
| 00:00:29,900 --> 00:00:33,310 | of Singleton without calling our factory method, and finally we |
| 00:00:33,310 --> 00:00:35,650 | create the factory method. And the factory method is very |
| 00:00:35,650 --> 00:00:38,600 | simple. The method will first check whether an instance of |
| 00:00:38,600 --> 00:00:40,970 | the class was already created. If it was created, it |
| 00:00:40,970 --> 00:00:44,010 | would just return that instance. Otherwise, it will create a |
| 00:00:44,010 --> 00:00:47,550 | new instance and assign it to that instance member variable |
| 00:00:47,550 --> 00:00:50,960 | and then return the newly created instance. So with this code |
| 00:00:50,960 --> 00:00:53,540 | you're guaranteed that other classes cannot bypass the factory |
| 00:00:53,540 --> 00:00:56,530 | method, because the default constructor is private. And the that |
| 00:00:56,530 --> 00:00:59,600 | the factory method will create one and only one instance |
| 00:00:59,600 --> 00:00:59,600 | of the class, which is exactly what our requirements were. |