# CS6300 82 - Software Intensive Systems

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:03,100 | In our initial definition of requirements engineering, we talked about |
| 00:00:03,100 --> 00:00:06,130 | software systems. But what do we really mean when we |
| 00:00:06,130 --> 00:00:09,980 | use the term software? Software is an abstract description of |
| 00:00:09,980 --> 00:00:13,920 | a set of computations that becomes concrete, and therefore useful, only |
| 00:00:13,920 --> 00:00:16,600 | when we run the software on some hardware, and that, |
| 00:00:16,600 --> 00:00:19,310 | in the context of some human activity that it can |
| 00:00:19,310 --> 00:00:22,530 | support. So what does that mean exactly? What that means |
| 00:00:22,530 --> 00:00:25,235 | is that when we say software, what we really mean is |
| 00:00:25,235 --> 00:00:28,790 | a software intensive system. That is, the combination |
| 00:00:28,790 --> 00:00:31,930 | of 3 things, the software, the hardware on which |
| 00:00:31,930 --> 00:00:34,610 | the software runs, and the context in which the |
| 00:00:34,610 --> 00:00:37,470 | software is used. Just to illustrate, let me show |
| 00:00:37,470 --> 00:00:40,010 | you this through a picture. What I'm showing here |
| 00:00:40,010 --> 00:00:42,830 | is a customer, a user, that is using, is |
| 00:00:42,830 --> 00:00:47,000 | accessing, an ATM machine. And this action involves several |
| 00:00:47,000 --> 00:00:50,650 | things. There is the software that drives the logic |
| 00:00:50,650 --> 00:00:53,410 | of the ATM machine. There is the hardware on |
| 00:00:53,410 --> 00:00:57,280 | which the software runs. And there is the context |
| 00:00:57,280 --> 00:00:59,850 | In which the software is used. And in this |
| 00:00:59,850 --> 00:01:02,660 | case, the context is the bank. And only by |
| 00:01:02,660 --> 00:01:06,105 | considering these 3 things together can we really understand |
| 00:01:06,105 --> 00:01:09,510 | the functionality that is represented here. So the bottom |
| 00:01:09,510 --> 00:01:12,690 | line here is that we usually take hardware and |
| 00:01:12,690 --> 00:01:15,750 | context for granted in this equation. But they actually |
| 00:01:15,750 --> 00:01:18,210 | need to be explicitly considered when building a |
| 00:01:18,210 --> 00:01:20,770 | system. Otherwise, we might forget this is all |
| 00:01:20,770 --> 00:01:23,850 | the functionality, and ultimately of the requirements. And |
| 00:01:23,850 --> 00:01:23,850 | we might end up with the wrong system. |