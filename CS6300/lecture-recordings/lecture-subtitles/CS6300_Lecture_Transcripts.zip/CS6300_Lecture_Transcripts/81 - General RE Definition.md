# CS6300 81 - General RE Definition

| Timestamp | Content |
|-----------|---------|
| 00:00:00,360 --> 00:00:03,900 | Basically, and roughly speaking, requirements engineering, which is |
| 00:00:03,900 --> 00:00:06,630 | also called in short, RE, is the process |
| 00:00:06,630 --> 00:00:10,520 | of establishing the services that the customer requires |
| 00:00:10,520 --> 00:00:13,530 | from the software system. In addition to that, requirements |
| 00:00:13,530 --> 00:00:16,360 | engineering also has to do with the constraints |
| 00:00:16,360 --> 00:00:19,900 | under which the system operates and is developed. Requirements |
| 00:00:19,900 --> 00:00:22,770 | engineering is a very important activity for several |
| 00:00:22,770 --> 00:00:25,450 | reasons. In particular, as we also saw in earlier |
| 00:00:25,450 --> 00:00:29,860 | lessons, many errors are made in requirement specifications. So many |
| 00:00:29,860 --> 00:00:33,100 | errors are made because we don't do requirements engineering in |
| 00:00:33,100 --> 00:00:35,670 | the right way. And many of these errors are not |
| 00:00:35,670 --> 00:00:38,340 | being detected early. But they could be if we were |
| 00:00:38,340 --> 00:00:41,350 | to do RE in the right way. And, unfortunately, not |
| 00:00:41,350 --> 00:00:45,510 | detecting these errors can dramatically increase software costs. So that's |
| 00:00:45,510 --> 00:00:48,250 | the reason why requirements engineering is important, and why it |
| 00:00:48,250 --> 00:00:50,730 | is important to do it in the right way. The final |
| 00:00:50,730 --> 00:00:53,660 | result of the requirements engineering process is a software |
| 00:00:53,660 --> 00:00:58,230 | requirements specification that we also called SRS. We will discuss |
| 00:00:58,230 --> 00:01:01,060 | SRS later in more details and also when we talk |
| 00:01:01,060 --> 00:01:03,740 | about the projects for the course. For now, it is |
| 00:01:03,740 --> 00:01:07,040 | enough to say that the software requirements specification and |
| 00:01:07,040 --> 00:01:10,280 | the requirements engineering, in general, should focus on what the |
| 00:01:10,280 --> 00:01:13,290 | proposed system is intended to do, and not on the |
| 00:01:13,290 --> 00:01:16,280 | how it will do it. In fact, how the system |
| 00:01:16,280 --> 00:01:18,450 | will do what it is required to do is something that we |
| 00:01:18,450 --> 00:01:18,450 | will discuss when we talk about design of a system in later phases. |