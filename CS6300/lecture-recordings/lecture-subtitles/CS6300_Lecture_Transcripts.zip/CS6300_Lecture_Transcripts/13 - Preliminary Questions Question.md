# CS6300 13 - Preliminary Questions Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:03,200 | So now I want to ask you one additional question, which is how many lines |
| 00:00:03,200 --> 00:00:05,030 | of code a day do you think professional |
| 00:00:05,030 --> 00:00:07,370 | software engineers produce? Do you think they produce |
| 00:00:07,370 --> 00:00:12,160 | 25 lines of code? Between 25 and 50? Between 50 and 100? Between 100 and 1000? |
| 00:00:12,160 --> 00:00:13,720 | Or more than 1000 a day? And remember |
| 00:00:13,720 --> 00:00:13,720 | that here we're talking about professional software engineers. |