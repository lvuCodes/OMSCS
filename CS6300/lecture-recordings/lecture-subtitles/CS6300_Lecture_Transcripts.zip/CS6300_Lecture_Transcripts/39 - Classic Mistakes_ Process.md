# CS6300 39 - Classic Mistakes_ Process

| Timestamp | Content |
|-----------|---------|
| 00:00:00,080 --> 00:00:03,770 | Another type of classic mistakes are process-related mistakes. And also |
| 00:00:03,770 --> 00:00:05,850 | in this case, these kind of mistakes can be due |
| 00:00:05,850 --> 00:00:08,970 | to many reasons. And they are of many types. One |
| 00:00:08,970 --> 00:00:12,310 | typical example are scheduling issues, which are due to the fact |
| 00:00:12,310 --> 00:00:15,180 | of being unable to come up with a realistic schedule. |
| 00:00:15,180 --> 00:00:17,750 | So to have an overly optimistic schedule. And this can be |
| 00:00:17,750 --> 00:00:21,230 | because we underestimate the effort involved in different parts of |
| 00:00:21,230 --> 00:00:25,010 | the project. Because we overestimate the ability of the people involved. |
| 00:00:25,010 --> 00:00:27,600 | Because we overestimate the importance, for example, of the use |
| 00:00:27,600 --> 00:00:29,640 | of tools. But no matter what the reason is, the |
| 00:00:29,640 --> 00:00:32,840 | result is typically that the projects end up being late, |
| 00:00:32,840 --> 00:00:35,580 | which is a very common situation. So this is somehow |
| 00:00:35,580 --> 00:00:39,020 | related to planning. And in general, planning is a fundamental |
| 00:00:39,020 --> 00:00:42,720 | factor in software processes and in software development. Mistakes in |
| 00:00:42,720 --> 00:00:46,120 | planning, such as insufficient planning or abandoning planning due to |
| 00:00:46,120 --> 00:00:50,190 | pressure, usually lead inexorably to failure. And speaking of failures, |
| 00:00:50,190 --> 00:00:53,040 | often there are unforeseen failures. Such as |
| 00:00:53,040 --> 00:00:55,410 | failures on the constructor's end, for example, |
| 00:00:55,410 --> 00:00:56,920 | that might lead to low quality or |
| 00:00:56,920 --> 00:00:56,920 | late deliverables, which ultimately affects the downstream activities. |