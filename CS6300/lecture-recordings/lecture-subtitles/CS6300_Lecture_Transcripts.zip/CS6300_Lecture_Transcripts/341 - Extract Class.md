# CS6300 341 - Extract Class

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,890 | We are now going to talk about the extract class refactoring. When a |
| 00:00:02,890 --> 00:00:06,040 | softer system evolves, we might end up with classes that really do the |
| 00:00:06,040 --> 00:00:09,210 | work of more than one class because we keep adding functionality to |
| 00:00:09,210 --> 00:00:11,010 | the class. Therefore also they're too |
| 00:00:11,010 --> 00:00:13,160 | big, too complicated. In particular, we might |
| 00:00:13,160 --> 00:00:15,250 | end up with a class that is doing the work of two |
| 00:00:15,250 --> 00:00:18,890 | classes. Typical examples are classes with many methods and quite a lot of |
| 00:00:18,890 --> 00:00:22,520 | data, quite a lot of fields. In this case, it's normally good idea |
| 00:00:22,520 --> 00:00:25,120 | to split the class into two, so what you will do, you will |
| 00:00:25,120 --> 00:00:28,700 | create a new class and move there the relevant fields and methods from |
| 00:00:28,700 --> 00:00:31,700 | the original class. So as to have two classes, each one implementing a |
| 00:00:31,700 --> 00:00:34,900 | piece of the functionality. Let's look at an example. In this case we're |
| 00:00:34,900 --> 00:00:38,850 | going to use a UML like representation for the class. We have this class Person |
| 00:00:38,850 --> 00:00:41,769 | that ends up representing also a phone number. And imagine that we add |
| 00:00:41,769 --> 00:00:44,500 | up these pieces, you know, a little bit at the time so we end |
| 00:00:44,500 --> 00:00:47,430 | up with something that really is doing the job of the person and |
| 00:00:47,430 --> 00:00:50,490 | of the phone number. So what we can do, we can actually do exactly |
| 00:00:50,490 --> 00:00:52,650 | what we described here. We split this class |
| 00:00:52,650 --> 00:00:55,470 | into a Person class, and the Phone Number class. |
| 00:00:55,470 --> 00:00:57,440 | And then we establish a use relation, so we |
| 00:00:57,440 --> 00:00:59,470 | have a reference of the phone number class into |
| 00:00:59,470 --> 00:01:01,960 | this class. And by separating the telephone number behavior |
| 00:01:01,960 --> 00:01:04,680 | into its own class, I once more improved the |
| 00:01:04,680 --> 00:01:06,980 | structure of the code, because now I have classes |
| 00:01:06,980 --> 00:01:06,980 | that are more cohesive, and do exactly one thing. |