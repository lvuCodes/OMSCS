# CS6300 59 - Donts in VCS

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,020 | Before getting to the demo, I want to say a few |
| 00:00:02,020 --> 00:00:06,550 | more things. In particular, I discuss the main don'ts in VCS. So, |
| 00:00:06,550 --> 00:00:09,110 | what are some things that you don't want to do, and |
| 00:00:09,110 --> 00:00:12,687 | you should not do, when you're using a version control system? And |
| 00:00:12,687 --> 00:00:15,382 | I'm going to mention two, in particular, because these are two |
| 00:00:15,382 --> 00:00:18,028 | that I witnessed several times when I was teaching this class and |
| 00:00:18,028 --> 00:00:21,820 | also when collaborating with other people. So, there are two kinds |
| 00:00:21,820 --> 00:00:25,460 | of resources that you don't want to add to a VCS normally. |
| 00:00:25,460 --> 00:00:29,070 | One is derived files. For example an executable that is |
| 00:00:29,070 --> 00:00:31,930 | derived by compiling a set of source files, where the |
| 00:00:31,930 --> 00:00:34,480 | source files all already in the repository. At that point, |
| 00:00:34,480 --> 00:00:37,680 | there is no reason to also add the executable file in |
| 00:00:37,680 --> 00:00:41,150 | the repository. So in general, any executable file should not |
| 00:00:41,150 --> 00:00:44,570 | be added to repository. The second class of files that I |
| 00:00:44,570 --> 00:00:47,760 | want to mention is these bulky binary files. If you |
| 00:00:47,760 --> 00:00:50,600 | have one such file, it is normally not a good idea |
| 00:00:50,600 --> 00:00:53,430 | to store them under a version control system, to store them |
| 00:00:53,430 --> 00:00:56,670 | in the repository. There might be exceptions to these rules, but in |
| 00:00:56,670 --> 00:00:59,070 | general, these are the kind of files that you want to |
| 00:00:59,070 --> 00:01:02,540 | keep local, and you don't want to put in the VCS repository. |
| 00:01:02,540 --> 00:01:06,500 | Another typical mistake, and that happens all the time, especially to |
| 00:01:06,500 --> 00:01:10,650 | novice users of VCS. Is that you get your file from VCS |
| 00:01:10,650 --> 00:01:13,120 | and so you get your local copy of the file that |
| 00:01:13,120 --> 00:01:16,270 | was in the VCS, and you want to make some changes, and |
| 00:01:16,270 --> 00:01:20,090 | before making the changes you decided, no, no let me actually save |
| 00:01:20,090 --> 00:01:22,410 | a local copy of the file, and I'm going to work on |
| 00:01:22,410 --> 00:01:24,950 | that one. Or let me save it before I modify it, or |
| 00:01:24,950 --> 00:01:28,350 | let take a snap shot of a whole tree of files. Just because |
| 00:01:28,350 --> 00:01:30,830 | I don't really trust the fact that VCS is going to be |
| 00:01:30,830 --> 00:01:33,170 | able to help and is going to be able to recover from possible |
| 00:01:33,170 --> 00:01:36,980 | mistakes. Never ever do that. I have seen that done many times, |
| 00:01:36,980 --> 00:01:41,570 | and it always leads to disasters. First of all it is useless, and |
| 00:01:41,570 --> 00:01:44,000 | second it's risky. Because then what happens is that at |
| 00:01:44,000 --> 00:01:46,610 | the time in which you have to turn in your assignment, |
| 00:01:46,610 --> 00:01:48,330 | in the case you are doing an assignment, but even in |
| 00:01:48,330 --> 00:01:50,740 | more serious situation, when you have to turn in your code, |
| 00:01:50,740 --> 00:01:54,620 | for example to your colleagues. You always end up being confused |
| 00:01:54,620 --> 00:01:59,010 | about which is the version that you're really using. So absolutely |
| 00:01:59,010 --> 00:02:03,262 | no local copies. No local redundancy when you're using a version |
| 00:02:03,262 --> 00:02:06,798 | control system. Trust the version control system, and trust the version |
| 00:02:06,798 --> 00:02:09,280 | control system to be able to manage your versions. You |
| 00:02:09,280 --> 00:02:13,350 | can always save it, commit it, retrieve previous versions, and you'll |
| 00:02:13,350 --> 00:02:15,530 | be able to do everything that you can do by copying |
| 00:02:15,530 --> 00:02:15,530 | the file yourself, and even more. So again, try the VCS. |