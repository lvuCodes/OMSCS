# CS6300 48 - Eclipse Demo_ Create Java Project

| Timestamp | Content |
|-----------|---------|
| 00:00:00,070 --> 00:00:02,550 | In the rest of this lesson we're going to look at eclipse and |
| 00:00:02,550 --> 00:00:05,290 | try to get more familiar with eclipse in a hands on manner |
| 00:00:05,290 --> 00:00:07,550 | through a demo. In the demo we will cover some of the |
| 00:00:07,550 --> 00:00:11,040 | basic aspects of eclipse like how to run eclipse, how to select |
| 00:00:11,040 --> 00:00:14,400 | their workspace, how to create a project, how to create the class |
| 00:00:14,400 --> 00:00:18,240 | within the project and so on. I'll also cover some more advanced |
| 00:00:18,240 --> 00:00:21,610 | aspects, like how to create builders, run your project within Eclipse, and |
| 00:00:21,610 --> 00:00:25,800 | how to use their Eclipse debugger. So let's get to the demo. |
| 00:00:25,800 --> 00:00:28,220 | So let's start Eclipse. Eclipse is going to ask me |
| 00:00:28,220 --> 00:00:31,600 | for the location of my workspace and in this |
| 00:00:31,600 --> 00:00:34,530 | case, I selected a suitable directory and you can |
| 00:00:34,530 --> 00:00:38,480 | also use that checkbox on the left to avoid Eclipse |
| 00:00:38,480 --> 00:00:40,640 | for asking you again about where to put the |
| 00:00:40,640 --> 00:00:43,860 | workspace. And the workspace is basically the place the |
| 00:00:43,860 --> 00:00:48,310 | directory. Where, Eclipse will place all of your projects. |
| 00:00:48,310 --> 00:00:50,830 | So, now when you start Eclipse, if it's the first |
| 00:00:50,830 --> 00:00:53,480 | time you might get this Welcome screen. It's not going to happen |
| 00:00:53,480 --> 00:00:57,500 | again on subsequent executions, but I just wanted to make sure |
| 00:00:57,500 --> 00:01:00,210 | that I covered all the bases. And so, whatcha want to |
| 00:01:00,210 --> 00:01:03,360 | do here is to basically go to the java perspective |
| 00:01:03,360 --> 00:01:06,760 | which you can do by clicking over there or you can |
| 00:01:06,760 --> 00:01:09,240 | also use the menus. So in this case we will have |
| 00:01:09,240 --> 00:01:12,810 | to go to Window, open Perspective, and if the Perspective is |
| 00:01:12,810 --> 00:01:15,660 | not here, you'll have to click on Other. And at this point, |
| 00:01:15,660 --> 00:01:18,030 | that you can click on Java Perspective, then you |
| 00:01:18,030 --> 00:01:21,680 | click okay. And the perspective is basically, the visual work |
| 00:01:21,680 --> 00:01:24,810 | space where you will be operating. So, after we selected |
| 00:01:24,810 --> 00:01:29,350 | perspective, we can actually close the welcome screen. And here, |
| 00:01:29,350 --> 00:01:32,000 | you see that you have this different areas and on |
| 00:01:32,000 --> 00:01:34,930 | the left You have the package explorer. This is the |
| 00:01:34,930 --> 00:01:37,650 | area where your packages will be, you've got a task list, |
| 00:01:37,650 --> 00:01:41,280 | and an outline on the right which we'll cover later. |
| 00:01:41,280 --> 00:01:44,870 | And then you have underneath, the bottom, a problems, java |
| 00:01:44,870 --> 00:01:48,330 | doc and declaration views and we will see some of |
| 00:01:48,330 --> 00:01:51,320 | these views in actions later. And here in the center |
| 00:01:51,320 --> 00:01:54,290 | you have the area. Which is called a code editor, |
| 00:01:54,290 --> 00:01:58,360 | which is where you'll be writing, editing, and modifying, basically, |
| 00:01:58,360 --> 00:02:00,440 | your code. This is where most of the action takes |
| 00:02:00,440 --> 00:02:03,140 | place. So let's start by creating a Java project. And |
| 00:02:03,140 --> 00:02:06,950 | to do that we can use either the context menu, or |
| 00:02:06,950 --> 00:02:09,560 | you can just use the menu, select new Java project. |
| 00:02:09,560 --> 00:02:12,390 | You'll be greeted by this, wizard, and. And at this |
| 00:02:12,390 --> 00:02:15,500 | point in the wizard, you can select the name of |
| 00:02:15,500 --> 00:02:19,100 | your project. I'm just going to call it a very simple way |
| 00:02:19,100 --> 00:02:21,990 | my project. And I going to use the default location for |
| 00:02:21,990 --> 00:02:24,070 | the project, as you can see it will be placed |
| 00:02:24,070 --> 00:02:27,440 | in the work space that I selected before. I'm going to |
| 00:02:27,440 --> 00:02:32,080 | also use the default. Java Runtime Environment, which is Java 1.7 |
| 00:02:32,080 --> 00:02:36,250 | in this case. I'm going to keep the selected default layout |
| 00:02:36,250 --> 00:02:39,120 | and the, then I'm going to go to the next step. Here, |
| 00:02:39,120 --> 00:02:42,380 | we're first presented with the location of the source code for |
| 00:02:42,380 --> 00:02:46,840 | our project. The default is a directory SRC in my project |
| 00:02:46,840 --> 00:02:49,320 | and for the output file, the directory bin. So repeat, we're now |
| 00:02:49,320 --> 00:02:52,410 | going to change that. Here in case you need other projects to |
| 00:02:52,410 --> 00:02:55,240 | build your own, then you can specify them here. Here we |
| 00:02:55,240 --> 00:02:57,570 | are building a simple project, so there's no need for that. |
| 00:02:57,570 --> 00:03:00,890 | And here we can specify which libraries our project requires. As |
| 00:03:00,890 --> 00:03:03,880 | you can see, the Java library's already specified. And you can |
| 00:03:03,880 --> 00:03:07,840 | also add other jars, which can even be External jars. And |
| 00:03:07,840 --> 00:03:11,840 | finally this is the tab that allows you to specify which |
| 00:03:11,840 --> 00:03:14,300 | part of you project. So how your project will be exported, |
| 00:03:14,300 --> 00:03:16,760 | so let's not worry about that for now. let's click finish. |
| 00:03:16,760 --> 00:03:19,300 | And as you can see here on the package explorer, my |
| 00:03:19,300 --> 00:03:22,920 | project appeared. So now we can open the project by clicking |
| 00:03:22,920 --> 00:03:24,920 | on the triangle right next to it, and as you can |
| 00:03:24,920 --> 00:03:28,250 | see there is the SRC directory, where my source code will go, |
| 00:03:28,250 --> 00:03:31,760 | and there's also an indication that we're using the JRE, so that's |
| 00:03:31,760 --> 00:03:35,800 | the Java system directory within our project. And this is just for people |
| 00:03:35,800 --> 00:03:38,860 | who are interested in what happens you know, under the hood. So |
| 00:03:38,860 --> 00:03:41,840 | if you don't care about that, you can just skip this part. So |
| 00:03:41,840 --> 00:03:45,200 | basically here I'm showing you how we can go to the directory |
| 00:03:45,200 --> 00:03:49,250 | where the project was created. We can see the bin and src directories. |
| 00:03:49,250 --> 00:03:52,020 | And there's also some other files here that you can |
| 00:03:52,020 --> 00:03:54,780 | see these 'dot' files that you will not normally, see. And |
| 00:03:54,780 --> 00:03:57,870 | those are kind of bookkeeping files. So these are files that |
| 00:03:57,870 --> 00:04:02,280 | contain information about your project and that are created automatically by |
| 00:04:02,280 --> 00:04:05,860 | Eclipse. And, for example, will have various indication about the |
| 00:04:05,860 --> 00:04:09,580 | configuration of the project, some settings and the class path for |
| 00:04:09,580 --> 00:04:11,880 | the project. And, as I said, you don't have to worry |
| 00:04:11,880 --> 00:04:14,490 | about this if you just want to go Eclipse as you're never |
| 00:04:14,490 --> 00:04:14,490 | going to mess with the command line. |