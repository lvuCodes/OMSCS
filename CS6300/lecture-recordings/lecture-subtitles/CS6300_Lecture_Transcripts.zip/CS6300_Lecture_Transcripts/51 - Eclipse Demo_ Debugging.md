# CS6300 51 - Eclipse Demo_ Debugging

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:03,090 | Now let's look at how we can do debugging within |
| 00:00:03,090 --> 00:00:06,240 | Eclipse. I created a new file called AddNumbers which I'm |
| 00:00:06,240 --> 00:00:10,770 | showing here. It takes two numbers, parses them into integers, |
| 00:00:10,770 --> 00:00:14,870 | adds them and prints the sum, supposedly, of the two numbers. |
| 00:00:14,870 --> 00:00:17,450 | Now we look at the run configuration for this program, |
| 00:00:17,450 --> 00:00:19,670 | and here you can see that we're passing two arguments, |
| 00:00:19,670 --> 00:00:22,060 | two and five, to the program. So now let's run |
| 00:00:22,060 --> 00:00:25,468 | our program and see what happens. And the result says that |
| 00:00:25,468 --> 00:00:28,150 | 2 plus 5 is equal to 10, which is not |
| 00:00:28,150 --> 00:00:31,030 | exactly correct. So we need to debug our program. We |
| 00:00:31,030 --> 00:00:33,310 | need to figure out what's wrong with the program, why |
| 00:00:33,310 --> 00:00:37,140 | the wrong result was, produced. So we're going to add a break |
| 00:00:37,140 --> 00:00:40,260 | point here by double-clicking here on the side of the |
| 00:00:40,260 --> 00:00:42,940 | code. And the break point is basically a place where I'm |
| 00:00:42,940 --> 00:00:46,240 | telling my debugger to stop during the execution because I |
| 00:00:46,240 --> 00:00:50,750 | want to inspect the state of the program. So to start |
| 00:00:50,750 --> 00:00:54,690 | debugging, we select Debug as Java Application from the Context |
| 00:00:54,690 --> 00:00:58,170 | menu, similar to what we were doing for running the program. |
| 00:00:58,170 --> 00:01:00,190 | And as you can see, this asks us whether we want |
| 00:01:00,190 --> 00:01:03,720 | to pass to the debug perspective, which is a, a perspective |
| 00:01:03,720 --> 00:01:07,110 | specifically designed for debugging. We say yes. And as you |
| 00:01:07,110 --> 00:01:10,750 | see here, it shows us, it's like a different, set of |
| 00:01:10,750 --> 00:01:13,310 | views, so we can see the code down here with an |
| 00:01:13,310 --> 00:01:16,100 | indication of where the execution is. And of course the execution |
| 00:01:16,100 --> 00:01:18,610 | stopped at the break point, which is exactly where |
| 00:01:18,610 --> 00:01:21,850 | we told the debugger to stop. So let's look at |
| 00:01:21,850 --> 00:01:24,400 | some of the other views in this perspective. The view |
| 00:01:24,400 --> 00:01:27,370 | here on the right-hand side, for example, shows the variables |
| 00:01:27,370 --> 00:01:30,720 | in scope and the break points that are currently active |
| 00:01:30,720 --> 00:01:33,240 | for the debugging session. This is where the editor is |
| 00:01:33,240 --> 00:01:36,710 | at. The outline of the program and the console at |
| 00:01:36,710 --> 00:01:41,520 | the bottom. So now let's execute one line by clicking |
| 00:01:41,520 --> 00:01:45,400 | on the Step Over button here at the top, and this will |
| 00:01:45,400 --> 00:01:49,150 | execute the line that is currently highlighted and therefore it will move to |
| 00:01:49,150 --> 00:01:51,500 | the next line. And as you can see, one nice feature is that |
| 00:01:51,500 --> 00:01:54,760 | if I move the mouse over a variable, I can see the value |
| 00:01:54,760 --> 00:01:57,710 | of the variable. And the same thing I can do if I look |
| 00:01:57,710 --> 00:02:00,690 | at the variables windows here on the right. If I click it, it |
| 00:02:00,690 --> 00:02:03,960 | will tell me what is the value of the variable, and in case |
| 00:02:03,960 --> 00:02:07,410 | of more complex variables you can even expand it and get more details. |
| 00:02:07,410 --> 00:02:10,870 | So now let's step over another line by clicking again this button, |
| 00:02:10,870 --> 00:02:13,180 | and as you can see now we get to the line that |
| 00:02:13,180 --> 00:02:16,410 | is actually performing the sum, supposedly, so now let's do the same |
| 00:02:16,410 --> 00:02:19,100 | thing that we did before, and let's mouse over b, and we can |
| 00:02:19,100 --> 00:02:22,150 | see that the value of b is five, as expected. So now |
| 00:02:22,150 --> 00:02:27,080 | let's step over this line as well, and execute the actual sum. And |
| 00:02:27,080 --> 00:02:29,730 | doing the mouseover thing, we can see that the value of sum |
| 00:02:29,730 --> 00:02:33,000 | is ten, which is not right, of course. In fact, if we check |
| 00:02:33,000 --> 00:02:35,590 | a gain we can see that value of A is two. The |
| 00:02:35,590 --> 00:02:39,130 | value of B is five and therefore it's clear that there's something |
| 00:02:39,130 --> 00:02:41,780 | wrong going on here, and at this point we can notice that |
| 00:02:41,780 --> 00:02:44,030 | here we are doing multiplication instead |
| 00:02:44,030 --> 00:02:46,010 | of addition. And therefore that's what the |
| 00:02:46,010 --> 00:02:49,260 | error is. And this is clearly a very simple case. Right? A |
| 00:02:49,260 --> 00:02:51,440 | case in which probably you just needed to look at the code and |
| 00:02:51,440 --> 00:02:54,150 | you didn't need the debugger. But you probably got the idea right? |
| 00:02:54,150 --> 00:02:58,055 | So this can be extremely useful when you're debugging, when you're studying more |
| 00:02:58,055 --> 00:03:01,533 | complex programs. If you want to stop the debugger because you're |
| 00:03:01,533 --> 00:03:04,557 | done with your debugging session as in this case, you can |
| 00:03:04,557 --> 00:03:07,518 | either click here on the Terminate button or you can also |
| 00:03:07,518 --> 00:03:11,109 | just simply tell the debugger to continue the execution, to resume |
| 00:03:11,109 --> 00:03:15,140 | the execution until the program terminates naturally. So, in this case, |
| 00:03:15,140 --> 00:03:17,520 | we're going to click here just to show what happens. And what |
| 00:03:17,520 --> 00:03:20,230 | happens is that, you know, the execution will just continue until |
| 00:03:20,230 --> 00:03:23,690 | the program exits. So now let's say that we want to fix |
| 00:03:23,690 --> 00:03:27,740 | this problem that we just discovered. So we replace the multiplication |
| 00:03:27,740 --> 00:03:30,600 | with an addition, we save the program, and we execute the |
| 00:03:30,600 --> 00:03:33,860 | program again by clicking on this button. And at this point, |
| 00:03:33,860 --> 00:03:33,860 | unsurprisingly, we get the right result as shown in the console. |