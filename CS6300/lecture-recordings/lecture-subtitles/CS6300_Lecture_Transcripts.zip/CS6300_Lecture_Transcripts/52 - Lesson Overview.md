# CS6300 52 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,440 --> 00:00:06,190 | Hi and welcome to the second lesson on tools of the trade. In the |
| 00:00:06,190 --> 00:00:09,710 | previous lesson we talked about IDEs. Integrated |
| 00:00:09,710 --> 00:00:13,300 | Development Environments and in particular we discussed |
| 00:00:13,300 --> 00:00:16,460 | the eclipse ID. Today we're going to |
| 00:00:16,460 --> 00:00:19,780 | talk about another fundamental type of tools |
| 00:00:19,780 --> 00:00:22,840 | in the software engineering arena. Version control |
| 00:00:22,840 --> 00:00:26,140 | systems. And these are also called, revision |
| 00:00:26,140 --> 00:00:30,620 | or source control systems. In particular, we will focus on a |
| 00:00:30,620 --> 00:00:36,320 | specific version control system called git. And as we did for eclipse, |
| 00:00:36,320 --> 00:00:40,510 | we will first present git from a conceptual standpoint. And then |
| 00:00:40,510 --> 00:00:40,510 | we will do a demo. To get some hands-on experience with GIT. |