# CS6300 125 - Class Diagram_ Attributes

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:02,435 | Now that we identify the classes in my system, |
| 00:00:02,435 --> 00:00:04,930 | let's see how we can identify the attributes for |
| 00:00:04,930 --> 00:00:08,680 | these classes. First of all let's recall what attributes |
| 00:00:08,680 --> 00:00:12,355 | are. Attributes represent the structure of a class the individual |
| 00:00:12,355 --> 00:00:15,530 | data items that compose the state of the class. |
| 00:00:15,530 --> 00:00:18,530 | So how do we identify these attributes? Attributes may be |
| 00:00:18,530 --> 00:00:21,070 | found in one of three ways. By examining class |
| 00:00:21,070 --> 00:00:25,330 | definitions, by studying the requirements, and by applying domain knowledge. |
| 00:00:25,330 --> 00:00:28,400 | And notice that I want to stress, that this is always |
| 00:00:28,400 --> 00:00:31,800 | a very important aspect. No matter what kind of system you're |
| 00:00:31,800 --> 00:00:35,670 | developing. Domain knowledge tends to be fairly important to identify things |
| 00:00:35,670 --> 00:00:38,200 | Which might not be provided in the descriptions of the system |
| 00:00:38,200 --> 00:00:41,070 | that tend to be incomplete. And that you can derive by |
| 00:00:41,070 --> 00:00:44,390 | the fact that you are familiar with the domain. So always |
| 00:00:44,390 --> 00:00:47,340 | keep in mind the domain knowledge is important for analysis, for |
| 00:00:47,340 --> 00:00:50,430 | design, for requirements gathering and so on. So now let's go |
| 00:00:50,430 --> 00:00:53,530 | back to our description of the system. As I said, |
| 00:00:53,530 --> 00:00:55,450 | I will bring you back for each step of our |
| 00:00:55,450 --> 00:00:58,200 | analysis. And in this case, we're going to focus on |
| 00:00:58,200 --> 00:01:01,550 | course offering. And we can say that the course offering, according |
| 00:01:01,550 --> 00:01:04,610 | to the description, has a number, a location, and a |
| 00:01:04,610 --> 00:01:08,140 | time. So this is a pretty clear indication that these are |
| 00:01:08,140 --> 00:01:11,650 | important aspects of the course offering. So they probably should |
| 00:01:11,650 --> 00:01:15,600 | become attributes of the course offering class. So now if we |
| 00:01:15,600 --> 00:01:19,400 | report here that sentence, and once more, we underline |
| 00:01:19,400 --> 00:01:22,330 | the information that we underlined in the description. We can |
| 00:01:22,330 --> 00:01:25,540 | clearly see how this can be mapped into the definition |
| 00:01:25,540 --> 00:01:28,730 | of the class. So our class course offering after this |
| 00:01:28,730 --> 00:01:32,900 | step the analysis will have 3 attributes: number, location, and |
| 00:01:32,900 --> 00:01:35,270 | time. And as you can see here, I'm not specifying |
| 00:01:35,270 --> 00:01:37,540 | the type or any other additional information. So in this |
| 00:01:37,540 --> 00:01:40,640 | first step I'm just interested in having a first draft. |
| 00:01:40,640 --> 00:01:42,170 | of the class diagram, that I can then |
| 00:01:42,170 --> 00:01:42,170 | refine in the next iterations of my analysis. |