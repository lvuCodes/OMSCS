# CS6300 334 - Reasons to Refactor

| Timestamp | Content |
|-----------|---------|
| 00:00:00,230 --> 00:00:02,000 | We saw at the beginning of the lesson, what are the |
| 00:00:02,000 --> 00:00:05,490 | goals of refactoring? Or what are the reasons ,why we need to |
| 00:00:05,490 --> 00:00:09,130 | refactor in the first place? The first reason is that requirements |
| 00:00:09,130 --> 00:00:12,370 | change, and when the requirements change, we often need to change our |
| 00:00:12,370 --> 00:00:16,356 | design accordingly. In other cases if any of the requirements unchange, |
| 00:00:16,356 --> 00:00:19,690 | we might need to improve our design. And this happens for many |
| 00:00:19,690 --> 00:00:22,300 | reasons. For example, we need to add a new feature, we |
| 00:00:22,300 --> 00:00:25,330 | want to make the code more maintainable, and also in general programmers |
| 00:00:25,330 --> 00:00:28,110 | don't come up with the best design the first time. So they might |
| 00:00:28,110 --> 00:00:31,130 | need to adapt it after the fact. And the final reason I want to |
| 00:00:31,130 --> 00:00:33,040 | mention is sloppiness, and to some |
| 00:00:33,040 --> 00:00:35,700 | extent laziness, of programmers. And a typical |
| 00:00:35,700 --> 00:00:38,520 | example of this is something that we all have done, which is copy |
| 00:00:38,520 --> 00:00:41,890 | and paste programming. So instead of rewriting a new piece of code, because |
| 00:00:41,890 --> 00:00:44,620 | we know that there is some code in some other parts for the |
| 00:00:44,620 --> 00:00:47,900 | program that does a similar thing, we'll just copy the code over. And |
| 00:00:47,900 --> 00:00:51,080 | before we know, we end up with tons of copies of the same functionality. |
| 00:00:51,080 --> 00:00:54,150 | And when that happens, a good way of consolidating that code and |
| 00:00:54,150 --> 00:00:57,580 | extracting that functionality is to use refactoring, for example, by creating a |
| 00:00:57,580 --> 00:01:01,080 | method or a class that provides the functionality. And we'll see specific |
| 00:01:01,080 --> 00:01:03,830 | examples of that. A question I would like to ask at this |
| 00:01:03,830 --> 00:01:07,330 | point of the class is whether you have used refactoring before? So |
| 00:01:07,330 --> 00:01:09,690 | I want you to take a second and think about it. And |
| 00:01:09,690 --> 00:01:12,590 | no matter what you're history is, if you ever coded I bet |
| 00:01:12,590 --> 00:01:16,180 | you any money that the answer is yes, you have done refactoring. |
| 00:01:16,180 --> 00:01:17,300 | What do I mean? I'm going to give you an |
| 00:01:17,300 --> 00:01:19,610 | example. I'm sure you renamed the class or a |
| 00:01:19,610 --> 00:01:22,190 | method or change the name of some variables in |
| 00:01:22,190 --> 00:01:25,490 | the code before. That's refactoring. Even something as simple as |
| 00:01:25,490 --> 00:01:28,030 | renaming a class is refactoring, because, for example, it |
| 00:01:28,030 --> 00:01:30,230 | might help you making your code more understandable. And of |
| 00:01:30,230 --> 00:01:32,520 | course I'll admit that in this case, this is |
| 00:01:32,520 --> 00:01:32,520 | a trivial refactoring, and there are much more interesting ones. |