# CS6300 196 - Adding Relationships

| Timestamp | Content |
|-----------|---------|
| 00:00:00,420 --> 00:00:02,740 | OK I like the way this class diagram is |
| 00:00:02,740 --> 00:00:05,850 | coming along. So at this point I think we |
| 00:00:05,850 --> 00:00:08,300 | have all the classes that we need. For each |
| 00:00:08,300 --> 00:00:12,250 | class we specified the attributes or the characteristics of the |
| 00:00:12,250 --> 00:00:15,150 | class. And we also specified the operations so we |
| 00:00:15,150 --> 00:00:18,710 | know what the class can do And, I like to |
| 00:00:18,710 --> 00:00:22,110 | kind of move forward on this, but I first |
| 00:00:22,110 --> 00:00:25,690 | want to see that you're fine with the class structure. |
| 00:00:25,690 --> 00:00:27,500 | So that's the way the class structure is going |
| 00:00:27,500 --> 00:00:29,880 | to be in terms of attributes and operations. So anything |
| 00:00:29,880 --> 00:00:34,910 | that bothers you? Well, one thing I didn't understand |
| 00:00:34,910 --> 00:00:38,090 | is how come you put check out over where |
| 00:00:38,090 --> 00:00:40,350 | the patron when it's really the item being checked |
| 00:00:40,350 --> 00:00:46,280 | out? Right. Okay. So that actually is you know, is a perfect |
| 00:00:46,280 --> 00:00:48,030 | segway for the next thing that really wanted |
| 00:00:48,030 --> 00:00:50,780 | to model. Because what you're talking about is basically a |
| 00:00:50,780 --> 00:00:54,100 | relationship between two classes which is something we haven't touched on |
| 00:00:54,100 --> 00:00:57,582 | yet. So we haven't, haven't looked at individual classes. But now, it |
| 00:00:57,582 --> 00:01:00,720 | is typical, now we are looking more at requirements, we're starting to |
| 00:01:00,720 --> 00:01:04,800 | find more things about our system, and what you're pointed out right |
| 00:01:04,800 --> 00:01:08,370 | now is the fact that patron and item are somehow related. So |
| 00:01:08,370 --> 00:01:11,020 | this checkout operation is not really something that belongs only on in |
| 00:01:11,020 --> 00:01:13,660 | the patron, because it needs to know about the item. And it |
| 00:01:13,660 --> 00:01:15,790 | doesn't belong only on the item because it needs to know about |
| 00:01:15,790 --> 00:01:19,640 | the patron. So, it's something that associates the patron and |
| 00:01:19,640 --> 00:01:22,600 | the item. Okay. And that's exactly the way we call |
| 00:01:22,600 --> 00:01:24,630 | in the UML which is the notation that we're using |
| 00:01:24,630 --> 00:01:29,060 | here this kind of relationship. So, we're going to represent that |
| 00:01:29,060 --> 00:01:32,820 | by drawing a line between these two classes that tells |
| 00:01:32,820 --> 00:01:35,220 | us there is an association. And we're also going to |
| 00:01:35,220 --> 00:01:37,890 | give a name to this. Since this refers to the |
| 00:01:37,890 --> 00:01:40,280 | fact of checking out items. We're just going to call |
| 00:01:40,280 --> 00:01:43,794 | it, checkout. Gotcha. And notice that this basically you |
| 00:01:43,794 --> 00:01:48,500 | know,eventually will end up kind of replacing this attribute. Because |
| 00:01:48,500 --> 00:01:51,780 | the existence of this association will tell us that |
| 00:01:51,780 --> 00:01:53,932 | this is checked out. We're, we're not going to, you know, |
| 00:01:53,932 --> 00:01:55,428 | do it right now, but in the final cleanup |
| 00:01:55,428 --> 00:01:58,750 | or the diagram, this name will disappear. Okay. Okay. |
| 00:01:58,750 --> 00:02:02,190 | And so since we started talking about relationships and |
| 00:02:02,190 --> 00:02:05,280 | associations, is there any other kind of relationship that you |
| 00:02:05,280 --> 00:02:08,805 | see here? Well, what you just did with checked |
| 00:02:08,805 --> 00:02:12,009 | out is, it seems similar to the whole issue |
| 00:02:12,009 --> 00:02:16,090 | of requests. It is, it is. So a request |
| 00:02:16,090 --> 00:02:19,580 | is something else that happens in both, you know, in |
| 00:02:19,580 --> 00:02:22,090 | the patron and in the item, it involves both. |
| 00:02:22,090 --> 00:02:24,070 | And in fact in a request, I would definitely |
| 00:02:24,070 --> 00:02:26,950 | represent this as an additional association. So I will |
| 00:02:26,950 --> 00:02:30,730 | just draw an another line between these two that represent |
| 00:02:30,730 --> 00:02:33,804 | that specific kind of relationship and I will call it |
| 00:02:33,804 --> 00:02:37,330 | request. So that indicates that this association refers to a |
| 00:02:37,330 --> 00:02:41,660 | request that also connects the patron with an item. Okay. |
| 00:02:41,660 --> 00:02:45,710 | And, let's see. Any, anything else that jumps at you? |
| 00:02:45,710 --> 00:02:47,590 | Yeah, well, how about all these ones down at the |
| 00:02:47,590 --> 00:02:50,080 | bottom? I mean book and item's got to be |
| 00:02:50,080 --> 00:02:52,920 | related, right? A book is a kind of item, And |
| 00:02:52,920 --> 00:02:55,860 | audiovisual... are there associations between them? Can you repeat |
| 00:02:55,860 --> 00:02:58,790 | that, you said that the book, yeah? Is |
| 00:02:58,790 --> 00:03:02,550 | a kind of item. Perfect, that's exactly what we're |
| 00:03:02,550 --> 00:03:04,700 | modeling next, which is, this, what we call the |
| 00:03:04,700 --> 00:03:07,900 | is-a relationship. So you said, a book is an item? |
| 00:03:07,900 --> 00:03:13,346 | A book is an item. And, we can model that in the diagram. So, we do that |
| 00:03:13,346 --> 00:03:17,409 | using another kind of relationship between the classes. So |
| 00:03:17,409 --> 00:03:21,210 | we're going to represent that as a specialization we call it. |
| 00:03:21,210 --> 00:03:24,890 | And, a specialization is indicated in this way. Okay? |
| 00:03:24,890 --> 00:03:27,410 | With this arrow at the end, so a solid |
| 00:03:27,410 --> 00:03:30,800 | with this kind of arrow at the end. And |
| 00:03:30,800 --> 00:03:34,160 | we can do the same for book, magazine, reference book |
| 00:03:34,160 --> 00:03:36,200 | and audiovisual material. So we're all going to connect, |
| 00:03:36,200 --> 00:03:37,950 | we're going to connect all of them, to the |
| 00:03:37,950 --> 00:03:43,190 | item, using the same kind of connection. And now |
| 00:03:43,190 --> 00:03:47,200 | that we have connected all these four, with item |
| 00:03:47,200 --> 00:03:50,620 | and indicated them in subclasses. That's something else that we can |
| 00:03:50,620 --> 00:03:54,370 | do. So we can make this kind of cleaner. And I'll |
| 00:03:54,370 --> 00:03:56,360 | tell you what I mean by that. So now we have |
| 00:03:56,360 --> 00:04:00,190 | this loanable attribute that refers to item, but it seems to |
| 00:04:00,190 --> 00:04:03,100 | me from what you were saying before, that loanable is not |
| 00:04:03,100 --> 00:04:05,490 | really an attribute of an item. Right? It's more of a |
| 00:04:05,490 --> 00:04:09,240 | characteristic of the type of item. Right. Is that right? Right. |
| 00:04:09,240 --> 00:04:13,120 | Books, and audio/visual are loanable but the others aren't. |
| 00:04:13,120 --> 00:04:16,450 | Okay, and so representing it here, it's okay to, |
| 00:04:16,450 --> 00:04:20,579 | it will work. But it's not really right so from |
| 00:04:20,579 --> 00:04:23,590 | the style standpoint it doesn't really you know, |
| 00:04:23,590 --> 00:04:26,100 | it's not the best way of modeling this. What we're going to |
| 00:04:26,100 --> 00:04:30,130 | do instead, we're going to use this specialization relationship to make |
| 00:04:30,130 --> 00:04:33,000 | that more explicit. To make it cleaner. Okay, so what |
| 00:04:33,000 --> 00:04:35,300 | I'm doing here is I'm going to take this hierarchy |
| 00:04:35,300 --> 00:04:38,130 | of classes, this is just on two levels now, and I'm |
| 00:04:38,130 --> 00:04:40,380 | going to kind of make it a little richer. |
| 00:04:40,380 --> 00:04:43,470 | So I'm going to add an intermediate set of |
| 00:04:43,470 --> 00:04:45,756 | classes. And in particular I'm going to have these two |
| 00:04:45,756 --> 00:04:48,306 | classes that I'm going to call non loanable item and loanable |
| 00:04:48,306 --> 00:04:51,790 | item. So, they're both items but they tell me |
| 00:04:51,790 --> 00:04:55,490 | clearly that some items are loanable and some items |
| 00:04:55,490 --> 00:04:59,392 | are not. Okay. Okay. And then I'm simply going to |
| 00:04:59,392 --> 00:05:03,192 | put book and audio video material as subclasses of loanable |
| 00:05:03,192 --> 00:05:07,980 | item and reference book and magazine as subclasses of non-loanable |
| 00:05:07,980 --> 00:05:10,510 | item. So, if we look at this diagram now it's |
| 00:05:10,510 --> 00:05:13,650 | pretty clear what is loanable and what is not. And |
| 00:05:13,650 --> 00:05:16,070 | it's actually is a very clean, much cleaner |
| 00:05:16,070 --> 00:05:18,980 | design. And, and I see you've, gotten rid of |
| 00:05:18,980 --> 00:05:21,560 | the loanable attribute, too. I did. Because at |
| 00:05:21,560 --> 00:05:24,130 | this point this is already represented by the fact of |
| 00:05:24,130 --> 00:05:28,570 | having these two classes. And actually, something else that I did |
| 00:05:28,570 --> 00:05:31,820 | is that I moved all these attributes, value, |
| 00:05:31,820 --> 00:05:34,220 | due date, renewed and checked out, that makes |
| 00:05:34,220 --> 00:05:37,452 | sense only for loanable item. From item to |
| 00:05:37,452 --> 00:05:40,450 | loanable item. So at this point, this really |
| 00:05:40,450 --> 00:05:42,600 | is telling me that, you know, these |
| 00:05:42,600 --> 00:05:46,410 | characteristics are just meaningful for the loanable item, |
| 00:05:46,410 --> 00:05:53,800 | and not for the other ones. Well, speaking of that, the way that you got the |
| 00:05:53,800 --> 00:05:57,270 | lines going in the diagram here is you still have |
| 00:05:57,270 --> 00:05:59,920 | request and checked out going to item, even though you |
| 00:05:59,920 --> 00:06:02,610 | can't request non loanable Items. You can't check out non |
| 00:06:02,610 --> 00:06:05,630 | loanable Items. Oh, you were right actually. You got me on |
| 00:06:05,630 --> 00:06:10,940 | that one. You're exactly right. So this associations are between |
| 00:06:10,940 --> 00:06:13,440 | the two wrong classes. So, I guess, at this point, |
| 00:06:13,440 --> 00:06:16,450 | you can probably go and fix the diagram yourself. Well, |
| 00:06:16,450 --> 00:06:19,120 | can we just make the lines go from patron to loanable |
| 00:06:19,120 --> 00:06:21,640 | item instead of to item? That's exactly the way in which we |
| 00:06:21,640 --> 00:06:25,550 | are going to fix it. So, we're going to move these two associations down |
| 00:06:25,550 --> 00:06:29,190 | here. And at this point, this will represent the right relationships in |
| 00:06:29,190 --> 00:06:29,190 | the, in the diagram, and in the system. Makes sense to me. |