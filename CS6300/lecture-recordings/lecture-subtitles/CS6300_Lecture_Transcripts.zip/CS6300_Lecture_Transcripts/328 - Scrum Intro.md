# CS6300 328 - Scrum Intro

| Timestamp | Content |
|-----------|---------|
| 00:00:00,220 --> 00:00:02,830 | Before concluding this class on java development, I want to |
| 00:00:02,830 --> 00:00:06,330 | talk about another process that is very popular these days, and |
| 00:00:06,330 --> 00:00:09,990 | it's used in many companies, which is called Scrum. Which similar |
| 00:00:09,990 --> 00:00:13,370 | to XP is another agile development process, and I'm going to |
| 00:00:13,370 --> 00:00:16,400 | start by discussing what the Scrum actors are. There's three |
| 00:00:16,400 --> 00:00:19,490 | main kinds of actors. The first one is the product owner, |
| 00:00:19,490 --> 00:00:22,590 | which means the customer. The product owner is mainly responsible for |
| 00:00:22,590 --> 00:00:25,460 | the product back log, where the product back log is basically |
| 00:00:25,460 --> 00:00:27,660 | the list of things that have to be done, the |
| 00:00:27,660 --> 00:00:30,670 | back log in fact for the project. And that is |
| 00:00:30,670 --> 00:00:33,640 | analogous to the user stories to be realized in XP, |
| 00:00:33,640 --> 00:00:36,190 | that we just saw. So what the product owner does is |
| 00:00:36,190 --> 00:00:39,310 | to clearly express these back log items, and to also |
| 00:00:39,310 --> 00:00:42,680 | order them by value, so they can be prioritized. The second |
| 00:00:42,680 --> 00:00:45,680 | actor is the team. The team is responsible for delivering |
| 00:00:45,680 --> 00:00:48,012 | shippable increments to estimate the |
| 00:00:48,012 --> 00:00:50,600 | back log items. It's normally self-organized, |
| 00:00:50,600 --> 00:00:53,055 | consists of four to nine people, and it's what you |
| 00:00:53,055 --> 00:00:56,180 | would consider normally as the main development team in a |
| 00:00:56,180 --> 00:00:59,080 | project. And finally we have the Scrum master. The Scrum |
| 00:00:59,080 --> 00:01:02,860 | master is the person who's responsible for the overall Scrum process, |
| 00:01:02,860 --> 00:01:05,980 | so he or she has to remove obstacles, facilitate events, |
| 00:01:05,980 --> 00:01:08,668 | helps communications, and so on. So you you can see |
| 00:01:08,668 --> 00:01:11,013 | the Scrum master as sort of a manager or the |
| 00:01:11,013 --> 00:01:11,013 | person who's got oversight, or the supervisor of the Scrum process. |