# CS6300 177 - Architectural Design Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:02,330 | At this point, we have seen some examples of |
| 00:00:02,330 --> 00:00:05,070 | things that might go wrong with the software architecture. So |
| 00:00:05,070 --> 00:00:07,220 | I'd like to ask you also to recap some of |
| 00:00:07,220 --> 00:00:10,800 | the concepts that we've touched upon. What are ideal characteristics |
| 00:00:10,800 --> 00:00:13,526 | of an architectural design? And I'm showing you three possibilities |
| 00:00:13,526 --> 00:00:16,970 | here: scalability, low cohesion, and low coupling. And some of |
| 00:00:16,970 --> 00:00:20,260 | these concepts we did not explicitly define, but we talked |
| 00:00:20,260 --> 00:00:20,260 | about it when discussing the examples that we just saw. |