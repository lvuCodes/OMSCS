# CS6300 226 - Iterations

| Timestamp | Content |
|-----------|---------|
| 00:00:00,420 --> 00:00:03,520 | So what happens, exactly, within an iteration? In |
| 00:00:03,520 --> 00:00:07,680 | almost every iteration, developers perform the following activities. |
| 00:00:07,680 --> 00:00:10,830 | So they identify which pieces of functionality this |
| 00:00:10,830 --> 00:00:14,450 | iteration will develop, will implement. After doing that, they |
| 00:00:14,450 --> 00:00:17,240 | will create a design, for the considered use |
| 00:00:17,240 --> 00:00:19,640 | cases, and they will do that guided by the |
| 00:00:19,640 --> 00:00:22,334 | chosen architecture. So the set of use cases |
| 00:00:22,334 --> 00:00:25,666 | plus the architectural guidelines will result in a design |
| 00:00:25,666 --> 00:00:29,035 | for the selected use cases. Once the design is defined, |
| 00:00:29,035 --> 00:00:32,060 | then the developers will implement the design, which will result |
| 00:00:32,060 --> 00:00:35,430 | in a set of software components. They will then verify |
| 00:00:35,430 --> 00:00:38,992 | the components against the use cases to make sure that the |
| 00:00:38,992 --> 00:00:41,740 | components satisfy the use cases, they suitably realize the use |
| 00:00:41,740 --> 00:00:43,995 | cases. And they will do that through testing or some |
| 00:00:43,995 --> 00:00:47,730 | other verification and validation activity. Finally, after verifying that the |
| 00:00:47,730 --> 00:00:51,320 | code actually implements the use cases, they will release a product, |
| 00:00:51,320 --> 00:00:53,840 | which also represent the end of the iteration. And notice that |
| 00:00:53,840 --> 00:00:56,370 | what I put here is an icon for the world, |
| 00:00:56,370 --> 00:00:59,330 | in double quotes. Because in many cases the release will be |
| 00:00:59,330 --> 00:01:02,050 | just an internal release or maybe a release that will just |
| 00:01:02,050 --> 00:01:04,813 | go to some of the stakeholders so that they can provide |
| 00:01:04,813 --> 00:01:07,040 | feedback on that. Okay. So it doesn't have to be an |
| 00:01:07,040 --> 00:01:09,080 | external release. It doesn't have to be a release to the |
| 00:01:09,080 --> 00:01:09,080 | world. But it is, nevertheless, a release of a software product. . |