# CS6300 338 - Consolidate Conditional Expression Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,070 --> 00:00:00,860 | We're now going to talk about |
| 00:00:00,860 --> 00:00:03,390 | the consolidate conditional expression refactoring. |
| 00:00:03,390 --> 00:00:05,730 | A common situation in code is that you have a set |
| 00:00:05,730 --> 00:00:08,530 | of conditionals with the same result. What that means that |
| 00:00:08,530 --> 00:00:12,090 | sometimes the code contains a series of conditional checks in which |
| 00:00:12,090 --> 00:00:14,760 | each check is different, yet the resulting action is the |
| 00:00:14,760 --> 00:00:18,440 | same. In these cases, the code could be improved by combining |
| 00:00:18,440 --> 00:00:22,100 | the conditionals using, for example, and, and or, as connectors. So |
| 00:00:22,100 --> 00:00:25,390 | as to have a single conditional check, with a single result. |
| 00:00:25,390 --> 00:00:28,500 | At that point you can also extract those conditional into a |
| 00:00:28,500 --> 00:00:32,310 | method. And replace the conditional with a call, to debt matter consolidating |
| 00:00:32,310 --> 00:00:35,110 | the conditional code in this way can make the checks clearer |
| 00:00:35,110 --> 00:00:38,170 | by showing that you're really making a single check rather than multiple |
| 00:00:38,170 --> 00:00:41,150 | checks, and extracted that condition and having that matter instead of |
| 00:00:41,150 --> 00:00:44,550 | a condition can clarify your code by explaining why you're doing a |
| 00:00:44,550 --> 00:00:47,350 | given check, rather than how you're doing it. You can see an |
| 00:00:47,350 --> 00:00:52,020 | example of that situation in this code, which is the disabilityAmount method. |
| 00:00:52,020 --> 00:00:54,580 | As the name of the method says, the purpose of this code |
| 00:00:54,580 --> 00:00:58,300 | is to compute the disability amount for a given, for example, employee. |
| 00:00:58,300 --> 00:01:01,250 | And there is a set of initial checks in the methods whose |
| 00:01:01,250 --> 00:01:05,090 | goal is to decide whether there's this disabilityAmount should be instead zero. |
| 00:01:05,090 --> 00:01:07,750 | And as you can see, there's multiple conditions. For example, there's a |
| 00:01:07,750 --> 00:01:10,630 | check about the seniority level, and about the number of months that |
| 00:01:10,630 --> 00:01:14,350 | the employee's been disabled. So far, whether the employee is part time |
| 00:01:14,350 --> 00:01:17,060 | and the outcome of all these check is always the same. If they're |
| 00:01:17,060 --> 00:01:19,740 | true, if the check is satisfied then there is no disability |
| 00:01:19,740 --> 00:01:22,564 | amount. So the disabilityAmount is zero. So what I will do |
| 00:01:22,564 --> 00:01:25,986 | if I apply the consolidate conditional expression to this matter, is |
| 00:01:25,986 --> 00:01:29,690 | that I will take these three conditionals. I will put them together |
| 00:01:29,690 --> 00:01:32,772 | by saying basically that if seniority is less than 2 or |
| 00:01:32,772 --> 00:01:36,524 | monthsDisabled is greater than 12 or isPartTime is true then the |
| 00:01:36,524 --> 00:01:40,170 | return should be zero. And once I have this combined conditional, |
| 00:01:40,170 --> 00:01:40,170 | as I see here, I will just extract that into a method. |