# CS6300 187 - P2P Architectures

| Timestamp | Content |
|-----------|---------|
| 00:00:00,170 --> 00:00:02,110 | We're not going to be able to study indepth |
| 00:00:02,110 --> 00:00:05,590 | any of the architectural styles that we just discussed. However, I |
| 00:00:05,590 --> 00:00:08,790 | want to at least discuss two representative examples of P2P |
| 00:00:08,790 --> 00:00:12,100 | architectures. Because, these are systems that you probably used, or at |
| 00:00:12,100 --> 00:00:14,090 | least, you used one of them. And, they will allow |
| 00:00:14,090 --> 00:00:17,590 | me to highlight some interesting points. So, as we just mentioned, |
| 00:00:17,590 --> 00:00:22,450 | P2P systems are decentralized resource sharing and discovery systems. And the |
| 00:00:22,450 --> 00:00:25,370 | two systems that I want to discuss, and that are representative |
| 00:00:25,370 --> 00:00:29,630 | of this kind of architectures, are Napster and Skype. And you may or |
| 00:00:29,630 --> 00:00:29,630 | may not be familiar with Napster, but I'm pretty sure that you know Skype. |