# CS6300 119 - OO Analysis Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:02,540 | So let's look at the object-oriented analysis in a |
| 00:00:02,540 --> 00:00:05,540 | little more detail. As I said earlier, traditional analysis |
| 00:00:05,540 --> 00:00:08,890 | and design techniques were functionally oriented. What that means |
| 00:00:08,890 --> 00:00:11,980 | is that they concentrated on the functions to be performed, |
| 00:00:11,980 --> 00:00:14,510 | whereas the data upon which the functions operated were |
| 00:00:14,510 --> 00:00:18,900 | secondary to the functions themselves. Conversely, object oriented analysis, is |
| 00:00:18,900 --> 00:00:22,100 | primarily concerned that with a data objects, so we |
| 00:00:22,100 --> 00:00:25,500 | went from a functional oriented view to a data oriented |
| 00:00:25,500 --> 00:00:28,070 | view, what that means is that during the analysis phase, |
| 00:00:28,070 --> 00:00:30,770 | we define a system first in terms of the data |
| 00:00:30,770 --> 00:00:34,380 | types and their relationships, and the functions or methods are |
| 00:00:34,380 --> 00:00:38,130 | defined only later and associated with specific objects which are sets |
| 00:00:38,130 --> 00:00:40,380 | of data. So let's see how we can perform object |
| 00:00:40,380 --> 00:00:44,040 | orientated analysis in practice, so the basic idea is to be |
| 00:00:44,040 --> 00:00:47,060 | focused on the objects of the real world. So to |
| 00:00:47,060 --> 00:00:51,310 | go from a real world objects to a set of requirements. |
| 00:00:51,310 --> 00:00:55,340 | And we can describe this as a four-step process. The first |
| 00:00:55,340 --> 00:00:57,790 | step is to obtain or prepare a textual description of the |
| 00:00:57,790 --> 00:01:00,400 | problem to be solved. So obviously, we need to start from |
| 00:01:00,400 --> 00:01:03,300 | some description of the system that we need to build. And |
| 00:01:03,300 --> 00:01:06,120 | this is a very practical oriented approach, so that the next |
| 00:01:06,120 --> 00:01:08,390 | thing we do is that we take the description and we |
| 00:01:08,390 --> 00:01:12,670 | underline nouns. In this description. And the nouns that we underline |
| 00:01:12,670 --> 00:01:16,710 | will become classes in my analysis. We then look at adjectives in |
| 00:01:16,710 --> 00:01:19,530 | the document. We underline those, and we use that |
| 00:01:19,530 --> 00:01:23,130 | information to identify the attributes of the classes that we've |
| 00:01:23,130 --> 00:01:26,370 | previously identified. At this point we focus on active |
| 00:01:26,370 --> 00:01:29,610 | verbs in the description, and the analysis of the active |
| 00:01:29,610 --> 00:01:32,710 | verbs will give us the operations that we'll need |
| 00:01:32,710 --> 00:01:36,830 | to define for our classes. So, again, underline nouns, and |
| 00:01:36,830 --> 00:01:38,950 | those will become the classes in my system. Then, |
| 00:01:38,950 --> 00:01:42,150 | objectives. And, those will be the attributes of the classes. |
| 00:01:42,150 --> 00:01:46,650 | And, finally, active verbs that will become the operations of my classes. And |
| 00:01:46,650 --> 00:01:48,840 | of course, this is a high level view to take this with a |
| 00:01:48,840 --> 00:01:51,790 | grain of salt. But we will see that it's a very good pragmatic |
| 00:01:51,790 --> 00:01:54,760 | approach to identifying requirements, starting from a |
| 00:01:54,760 --> 00:01:54,760 | description of the system to be built. |