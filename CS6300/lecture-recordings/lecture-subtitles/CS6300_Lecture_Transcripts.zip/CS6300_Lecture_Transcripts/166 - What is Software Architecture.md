# CS6300 166 - What is Software Architecture

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,460 | After this interesting conversation with Neno, let me start |
| 00:00:02,460 --> 00:00:06,060 | the lesson by defining what a software architecture is. |
| 00:00:06,060 --> 00:00:07,600 | And to do that, I'm going to use two |
| 00:00:07,600 --> 00:00:11,030 | seminal definitions. The first one is from Dewayne Perry |
| 00:00:11,030 --> 00:00:13,990 | and Alex Wolf. And they define a software architecture |
| 00:00:13,990 --> 00:00:17,940 | as elements, form and rationale. In this definition, the |
| 00:00:17,940 --> 00:00:21,300 | elements are the what, which means the processes, data, |
| 00:00:21,300 --> 00:00:25,430 | and connectors that compose a software architecture. The form |
| 00:00:25,430 --> 00:00:27,780 | is the how, the set of properties of |
| 00:00:27,780 --> 00:00:32,030 | in relationships among these elements. And, finally, the rationale |
| 00:00:32,030 --> 00:00:35,390 | is the why, the justification for the elements and |
| 00:00:35,390 --> 00:00:38,440 | their relationships. The second definition I want to use |
| 00:00:38,440 --> 00:00:40,710 | is from Mary Shaw and David Garland. And |
| 00:00:40,710 --> 00:00:43,480 | they defined a software architecture as a level of |
| 00:00:43,480 --> 00:00:47,300 | design that involves four main things, a description of |
| 00:00:47,300 --> 00:00:50,860 | elements from which these systems are built, the interactions |
| 00:00:50,860 --> 00:00:54,800 | among those elements, the patterns that guide their composition, and |
| 00:00:54,800 --> 00:00:58,320 | finally, the constraints on these patterns. As you can see, these |
| 00:00:58,320 --> 00:01:01,420 | definitions are fairly similar and there are many more alternative |
| 00:01:01,420 --> 00:01:04,870 | definitions of software architecture. In fact, if we try to search |
| 00:01:04,870 --> 00:01:08,540 | the term software architecture, we get over two million entries. |
| 00:01:08,540 --> 00:01:10,670 | And if we look at the images in the results of |
| 00:01:10,670 --> 00:01:13,110 | the search this is what we get. And I like this |
| 00:01:13,110 --> 00:01:16,120 | sort of graphical depiction because it gives you a clear idea |
| 00:01:16,120 --> 00:01:19,300 | the software architecture are prevalent concept, given the number of |
| 00:01:19,300 --> 00:01:22,600 | results. But they also show you clearly, that software architecture are |
| 00:01:22,600 --> 00:01:25,550 | complex entities, if you look at some of these pictures. |
| 00:01:25,550 --> 00:01:28,930 | And ultimately, they show that software architecture are presented in all |
| 00:01:28,930 --> 00:01:31,700 | kinds of ways including in 3D, if you look at this |
| 00:01:31,700 --> 00:01:34,970 | picture. We cannot clearly cover all of these definitions in one |
| 00:01:34,970 --> 00:01:37,340 | lesson. So what I will do instead, is to introduce |
| 00:01:37,340 --> 00:01:37,340 | a very general definition that encompasses most of the existing ones. |