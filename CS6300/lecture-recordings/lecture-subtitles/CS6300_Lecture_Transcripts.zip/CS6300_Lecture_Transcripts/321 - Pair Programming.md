# CS6300 321 - Pair Programming

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,530 | The next practice I want to discuss is a very important one |
| 00:00:02,530 --> 00:00:05,750 | in XP, and also one of the scandal, controversial, and it's |
| 00:00:05,750 --> 00:00:08,390 | the practice of pair programming. What does it mean? It means |
| 00:00:08,390 --> 00:00:11,790 | that all production code is written with two people looking at one |
| 00:00:11,790 --> 00:00:15,170 | machine. And not that they're, they're working with one keyboard and |
| 00:00:15,170 --> 00:00:18,450 | one mouse or they're not just interfering and writing on each other's |
| 00:00:18,450 --> 00:00:20,920 | code. And the way in which that happens is by playing |
| 00:00:20,920 --> 00:00:25,180 | different roles at different times. So the two developers alternate between the |
| 00:00:25,180 --> 00:00:29,080 | role of programming and strategizing, where strategizing means, for example, |
| 00:00:29,080 --> 00:00:31,660 | looking at the code that has been written and thinking whether |
| 00:00:31,660 --> 00:00:34,420 | that would work. Or what other tests that are not there |
| 00:00:34,420 --> 00:00:37,050 | might not work, given the way the code is being written. |
| 00:00:37,050 --> 00:00:39,300 | Or maybe looking at the code from a, you know, slightly |
| 00:00:39,300 --> 00:00:42,380 | detached perspective and trying to figure out whether the code can |
| 00:00:42,380 --> 00:00:46,900 | be made simpler, more maintainable, more efficient. And interestingly, there are |
| 00:00:46,900 --> 00:00:48,440 | measurements, there are studies that |
| 00:00:48,440 --> 00:00:50,340 | suggest that development productivity with pair |
| 00:00:50,340 --> 00:00:52,550 | programming is similar to that of two people |
| 00:00:52,550 --> 00:00:55,080 | working independently. And that answers one of the |
| 00:00:55,080 --> 00:00:57,740 | main objections against pair programming, which is why |
| 00:00:57,740 --> 00:00:59,840 | should I put two developers together, which is |
| 00:00:59,840 --> 00:01:01,860 | going to cut their productivity in half. It is |
| 00:01:01,860 --> 00:01:04,390 | not. Studies shows that that does not happen. |
| 00:01:04,390 --> 00:01:06,380 | And that the resulting code can actually benefit |
| 00:01:06,380 --> 00:01:06,380 | from the fact that two developers are working together. |