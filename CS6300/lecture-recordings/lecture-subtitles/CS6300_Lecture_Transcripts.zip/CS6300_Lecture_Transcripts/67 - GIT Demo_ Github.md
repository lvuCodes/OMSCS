# CS6300 67 - GIT Demo_ Github

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:02,820 | In the interview that we did at the beginning of the class, |
| 00:00:02,820 --> 00:00:08,430 | we talked with John about GitHub, where GitHub is a Git hosting website, and |
| 00:00:08,430 --> 00:00:11,390 | John told you all about it. For this class, we will be |
| 00:00:11,390 --> 00:00:16,350 | using GitHub as our Git hosting. Let's see how GitHub works in practice and |
| 00:00:16,350 --> 00:00:19,450 | let's see some of the common features offered by GitHub. |
| 00:00:19,450 --> 00:00:24,010 | This is what we'll do in the third part of this Git demo. What I'm showing here |
| 00:00:24,010 --> 00:00:28,550 | is the GitHub website and as I said, GitHub is a Git hosting website and |
| 00:00:28,550 --> 00:00:32,950 | you can create an account on GitHub by simply signing up on the website. And |
| 00:00:32,950 --> 00:00:36,100 | because we already have an account that we're simply going to sign in |
| 00:00:36,100 --> 00:00:40,570 | to see what kind of functionality GitHub offers. And we're going to specify our |
| 00:00:40,570 --> 00:00:44,190 | username and password. And as you can see on the GitHub website, |
| 00:00:44,190 --> 00:00:47,695 | you can use this menu up on the right to create a new repository or |
| 00:00:47,695 --> 00:00:51,500 | change the account settings. Let's click on our user profile. And |
| 00:00:51,500 --> 00:00:54,270 | here we can see some statistics for our user. For |
| 00:00:54,270 --> 00:00:59,190 | example, we can see statistic about our contributions and our repositories. So |
| 00:00:59,190 --> 00:01:02,560 | now if we go to the Repositories view, we can create a new repository. |
| 00:01:02,560 --> 00:01:07,117 | We give it a name. Let's call it myrepo. We can provide the description for |
| 00:01:07,117 --> 00:01:11,680 | the repository. If we want, we can initialize the repository by adding a README |
| 00:01:11,680 --> 00:01:15,860 | file. And even though we are not doing it right now, if you can see up here, |
| 00:01:15,860 --> 00:01:19,820 | you can also add a license here on the right and it allows you |
| 00:01:19,820 --> 00:01:24,831 | to choose from a set of predefined licenses. And you can also a .gitignore file, |
| 00:01:24,831 --> 00:01:28,410 | which, in case you don't know what that is, it's a very convenient file that |
| 00:01:28,410 --> 00:01:32,740 | will automatically exclude from the repositories file that should not be added. |
| 00:01:32,740 --> 00:01:35,690 | So if you remember in the lesson we said there are things that you should not |
| 00:01:35,690 --> 00:01:39,263 | add to the repositories. For example, derived files. So |
| 00:01:39,263 --> 00:01:42,360 | here, using this menu, you can pick the type of project that you have. |
| 00:01:42,360 --> 00:01:47,740 | For example, Java project or PHP project or many other kinds of projects. And |
| 00:01:47,740 --> 00:01:50,510 | the GitHub will automatically add that file for you. |
| 00:01:50,510 --> 00:01:53,680 | But let's skip that for now and simply create our repository. And |
| 00:01:53,680 --> 00:01:58,000 | that creates a repository that contains the README file because that's what we |
| 00:01:58,000 --> 00:02:02,580 | decided to do. And it also allows you to edit the README file by clicking on it. |
| 00:02:02,580 --> 00:02:05,560 | It will bring up an editor and here you can write, you know, |
| 00:02:05,560 --> 00:02:08,949 | for example, initial readme for your project. Then you can add your |
| 00:02:08,949 --> 00:02:13,070 | commit message up there and then you can commit the changes to your README file. |
| 00:02:13,070 --> 00:02:18,212 | The site also provides many other features, like, for example, creating issues, |
| 00:02:18,212 --> 00:02:22,030 | pull requests, adding and editing a wiki, and also, you know, |
| 00:02:22,030 --> 00:02:25,740 | defining other characteristics and settings for the repository. Now, if we go to |
| 00:02:25,740 --> 00:02:30,500 | the repository, you can see that we also get the HTTPS link for the repository. |
| 00:02:30,500 --> 00:02:35,870 | So this is the URL that you can use to clone your repository. If you remember, |
| 00:02:35,870 --> 00:02:39,250 | with a git clone command, that's the URL that you can specify. So |
| 00:02:39,250 --> 00:02:43,480 | let's try to do that and clone that repository. So we're going to copy this URL. |
| 00:02:43,480 --> 00:02:48,300 | To do that, we're going to execute git clone and specify the URL that we |
| 00:02:48,300 --> 00:02:52,310 | just copied. And you can see that the project was created, was cloned locally. |
| 00:02:52,310 --> 00:02:55,760 | And if we go under myrepo, which is the name of the repository, you can see that |
| 00:02:55,760 --> 00:02:59,570 | the README file that we created on GitHub is here. So if we create a new file, |
| 00:02:59,570 --> 00:03:03,340 | which we're going to call again, newFile just to be clear. And then we |
| 00:03:03,340 --> 00:03:07,920 | can add it, commit it, specifying as usual a commit message. So at this point, |
| 00:03:07,920 --> 00:03:11,940 | we can push our locked out changes to the remote GitHub repository. And |
| 00:03:11,940 --> 00:03:14,340 | because the GitHub repository is password protected, |
| 00:03:14,340 --> 00:03:17,660 | we have to specify our login and password. And of course, if you |
| 00:03:17,660 --> 00:03:21,770 | pass the wrong password, GitHub is not going to let you in. So let's try again. |
| 00:03:21,770 --> 00:03:25,110 | Let's try to get the password right this time. I'm going to specify again, |
| 00:03:25,110 --> 00:03:31,130 | my login and my password. At this point, the push is successful and |
| 00:03:31,130 --> 00:03:35,220 | my changes are actually pushed to the master, which is the GitHub repository. |
| 00:03:35,220 --> 00:03:39,020 | To double check that, let's go back to the GitHub repository and as you can see, |
| 00:03:39,020 --> 00:03:42,470 | that the file that we added, newFile, is there as expected. And of course, |
| 00:03:42,470 --> 00:03:45,880 | there's many more things that you can do on the GitHub website, so |
| 00:03:45,880 --> 00:03:48,410 | I strongly encourage you to go and try out things. But |
| 00:03:48,410 --> 00:03:51,980 | the key message here is that the GitHub is a Git hosting website where you |
| 00:03:51,980 --> 00:03:51,980 | can get an account and create your remote repositories. |