# CS6300 201 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,230 --> 00:00:04,560 | In the last lesson, we talked about design, and we saw how difficult it can |
| 00:00:04,560 --> 00:00:10,010 | be to come up with a good and effective design for a given software system. To |
| 00:00:10,010 --> 00:00:12,620 | help address these difficulties, we will discuss |
| 00:00:12,620 --> 00:00:16,560 | design patterns, which can support design activities by |
| 00:00:16,560 --> 00:00:20,710 | providing general, reusable solutions to commonly occurring design |
| 00:00:20,710 --> 00:00:25,410 | problems. Similar to architectural styles, design patterns can |
| 00:00:25,410 --> 00:00:30,400 | help developers build better designed systems by reusing design solutions that |
| 00:00:30,400 --> 00:00:30,400 | worked well in the past and by building on those solutions. |