# CS6300 143 - UML Behavioral Diagrams_ State Transition Diagram

| Timestamp                     | Content                                                                          |
| ----------------------------- | -------------------------------------------------------------------------------- |
| 00:00:00,100 --> 00:00:02,430 | The very last diagram that I want to discuss is                                  |
| 00:00:02,430 --> 00:00:05,900 | **the state transition diagram. The state transition diagram is defined for**    |
| 00:00:05,900 --> 00:00:09,270 | **each relevant class in the system and basically shows the**                    |
| 00:00:09,270 --> 00:00:12,880 | **possible live history of a given class or object. So what**                    |
| 00:00:12,880 --> 00:00:15,090 | does it mean to describe the life history? It means                              |
| 00:00:15,090 --> 00:00:18,630 | **that it describes the possible states of the class as defined**                |
| 00:00:18,630 --> 00:00:21,910 | **by the values of the class attributes. And it also describes**                 |
| 00:00:21,910 --> 00:00:25,710 | **the events that cause a transition from one state to another.**                |
| 00:00:25,710 --> 00:00:28,800 | **Finally, it describes the actions that result from a state**                   |
| 00:00:28,800 --> 00:00:31,050 | **change. So if you put all of this together you**                               |
| 00:00:31,050 --> 00:00:33,760 | **can see how this can represent the whole history of**                          |
| 00:00:33,760 --> 00:00:36,860 | **the class, from its creation to its destruction. So let me**                   |
| 00:00:36,860 --> 00:00:40,610 | discuss the transition diagram in more detail, and also provide                  |
| 00:00:40,610 --> 00:00:43,550 | information about the notation used to represent them. We have                   |
| 00:00:43,550 --> 00:00:46,770 | **states, that are represented by ovals with a name. And**                       |
| 00:00:46,770 --> 00:00:51,820 | **we have transitions marked by the event that triggers the transition.**        |
| 00:00:51,820 --> 00:00:55,500 | **What transitions indicate is the passage from one state to**                   |
| 00:00:55,500 --> 00:00:59,430 | **another state as the consequence of some external stimuli. Notice**            |
| 00:00:59,430 --> 00:01:01,930 | that not all events will cause a state transition. So                            |
| 00:01:01,930 --> 00:01:04,930 | for example, some events might be consumed within a single state.                |
| 00:01:04,930 --> 00:01:06,500 | And we'll get to that in a second. But in                                        |
| 00:01:06,500 --> 00:01:10,200 | most cases, an event will trigger some state transition. Events                  |
| 00:01:10,200 --> 00:01:13,480 | **may also produce actions and they may also have attributes**                   |
| 00:01:13,480 --> 00:01:17,100 | **which are analogous to parameters in a method call. And Boolean**              |
| 00:01:17,100 --> 00:01:20,830 | **conditions that guard the state transition that is prevented**                 |
| 00:01:20,830 --> 00:01:22,860 | **from happening in the case the conditions are not**                            |
| 00:01:22,860 --> 00:01:26,630 | **satisfied. States may also be associated with activities and**                 |
| 00:01:26,630 --> 00:01:31,450 | **actions. Specifically, activities are operations performed by an object**      |
| 00:01:31,450 --> 00:01:33,410 | **when it is in a given state and that**                                         |
| 00:01:33,410 --> 00:01:36,690 | **takes time to complete. Actions, conversely, just like the**                   |
| 00:01:36,690 --> 00:01:40,270 | **actions corresponding to an event are instantaneous operations that**          |
| 00:01:40,270 --> 00:01:42,420 | **are performed by an object. And can be triggered**                             |
| 00:01:42,420 --> 00:01:46,050 | **on entry. So, when the object reaches a given state,**                         |
| 00:01:46,050 --> 00:01:48,970 | **when the object exits that state, and also when a**                            |
| 00:01:48,970 --> 00:01:53,240 | **specific event occurs. And in this case, this notation is**                    |
| 00:01:53,240 --> 00:01:55,930 | **basically a shortcut for any event that will cause a**                         |
| 00:01:55,930 --> 00:01:58,840 | **state transition that will bring the object back into the**                    |
| 00:01:58,840 --> 00:02:01,696 | **same state.** Since we have several actions and activities, it                 |
| 00:02:01,696 --> 00:02:04,480 | is probably worthwhile clarifyinig the ordering of such actions and              |
| 00:02:04,480 --> 00:02:07,559 | activities. So the way in which these actions and activities                     |
| 00:02:07,559 --> 00:02:10,079 | occur is, first of all, we have the actions on the                               |
| 00:02:10,079 --> 00:02:13,737 | **incoming transition, so this is performed first.** Then if there is an         |
| 00:02:13,737 --> 00:02:17,321 | entry action that is the next action that would be performed, then               |
| 00:02:17,321 --> 00:02:17,321 | we have **activity and event actions as appropriate. And finally exit actions.** |