# CS6300 350 - Bad Smells

| Timestamp | Content |
|-----------|---------|
| 00:00:00,070 --> 00:00:03,450 | The concept of bad smells. What are bad smells? Well, we |
| 00:00:03,450 --> 00:00:06,700 | mentioned earlier that refactoring is typically applied when there is something |
| 00:00:06,700 --> 00:00:09,130 | that does not look right, does not feel right in the |
| 00:00:09,130 --> 00:00:12,260 | code. And that's exactly what bad smells are. Bad smells, or |
| 00:00:12,260 --> 00:00:15,320 | code smells if you wish, are symptoms in the code of |
| 00:00:15,320 --> 00:00:18,868 | a program that might indicate deeper problems. So there might be |
| 00:00:18,868 --> 00:00:21,775 | parts of my system, classes in my systems, that just don't |
| 00:00:21,775 --> 00:00:25,309 | smell right, and it feels like there's, there might be something wrong |
| 00:00:25,309 --> 00:00:29,010 | with them. And if you are an experienced developer just like Brad, |
| 00:00:29,010 --> 00:00:31,320 | you'll be able to figure out there is something wrong with the |
| 00:00:31,320 --> 00:00:33,950 | classes. You'll be able to smell that there's something wrong and you'll |
| 00:00:33,950 --> 00:00:36,880 | do something about it. And I want to mention one more, just to make |
| 00:00:36,880 --> 00:00:39,270 | sure that we're all on the same page here. That these bad |
| 00:00:39,270 --> 00:00:43,070 | smells are usually not bugs and don't prevent the program from functioning. They |
| 00:00:43,070 --> 00:00:46,190 | however indicate weaknesses in the design of the system that might cause |
| 00:00:46,190 --> 00:00:48,480 | problems during maintenance. In other words, |
| 00:00:48,480 --> 00:00:50,440 | they might make the code less maintainable, |
| 00:00:50,440 --> 00:00:53,650 | harder to understand, and so on. Just like refactorings, |
| 00:00:53,650 --> 00:00:56,610 | there's also many possible different bad smells. So what |
| 00:00:56,610 --> 00:00:59,160 | I'm providing here is just a possible list of |
| 00:00:59,160 --> 00:01:02,190 | some very common bad smells. And you can find plenty |
| 00:01:02,190 --> 00:01:04,349 | of information on this online. So what I want |
| 00:01:04,349 --> 00:01:06,910 | to do next is just to cover before finishing the |
| 00:01:06,910 --> 00:01:08,700 | lesson a few of those to show you some |
| 00:01:08,700 --> 00:01:08,700 | examples of smells and what you can do about them. |