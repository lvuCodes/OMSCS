# CS6300 135 - UML Structural Diagrams_ Deployment

| Timestamp                     | Content                                                                                       |
| ----------------------------- | --------------------------------------------------------------------------------------------- |
| 00:00:00,100 --> 00:00:02,980 | The last UML structural diagram I want to discuss                                             |
| 00:00:02,980 --> 00:00:06,750 | is the **deployment diagram**. The deployment diagram provides a **static**                   |
| 00:00:06,750 --> 00:00:10,220 | **deployment view of a system, and unlike previous diagram,**                                 |
| 00:00:10,220 --> 00:00:13,980 | **it is about the physical allocation of components to computational**                        |
| 00:00:13,980 --> 00:00:16,950 | **units**. Think, for example, of a client-server system in                                   |
| 00:00:16,950 --> 00:00:19,130 | which you'll have to define which components will go on                                       |
| 00:00:19,130 --> 00:00:20,880 | the server and which component will go on the                                                 |
| 00:00:20,880 --> 00:00:25,200 | client. For deployment diagram, the nodes correspond to computation unit;                     |
| 00:00:25,200 --> 00:00:29,090 | for example, a specific device. And the edges indicate communication                          |
| 00:00:29,090 --> 00:00:32,880 | between these units. Also in this case, I'm going to illustrate deployment                    |
| 00:00:32,880 --> 00:00:36,720 | diagrams using an example for our course management system. And                               |
| 00:00:36,720 --> 00:00:39,820 | also in this case, I'm going to use a slightly more complex![[lvu 2026-02-15 at 03.47PM.png]] |
| 00:00:39,820 --> 00:00:41,910 | diagram than usual. But I don't want you to look                                              |
| 00:00:41,910 --> 00:00:45,170 | at all the individual details. Instead, I would like to focus                                 |
| 00:00:45,170 --> 00:00:47,530 | on a few main aspects. So, if you look at                                                     |
| 00:00:47,530 --> 00:00:50,700 | this diagram, there are three things that you should clearly see.                             |
| 00:00:50,700 --> 00:00:53,555 | First, you should see how the system involves four                                            |
| 00:00:53,555 --> 00:00:56,590 | nodes, a web server, an application server, a DB                                              |
| 00:00:56,590 --> 00:00:59,740 | server, and a mainframe. Second, you should see which                                         |
| 00:00:59,740 --> 00:01:03,500 | components are deployed on which nodes. For example, the student                              |
| 00:01:03,500 --> 00:01:07,400 | component is deployed on the application server. And finally,                                 |
| 00:01:07,400 --> 00:01:09,570 | you should see how the nodes communicate with one                                             |
| 00:01:09,570 --> 00:01:11,880 | another. For example, you can see that the application                                        |
| 00:01:11,880 --> 00:01:11,880 | server and the university database communicate using a JDBC protocol.                         |