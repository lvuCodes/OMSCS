# CS6300 98 - User and System Requirements

| Timestamp | Content |
|-----------|---------|
| 00:00:00,180 --> 00:00:03,170 | Another important distinction, when talking about requirements, is that |
| 00:00:03,170 --> 00:00:07,220 | between user and system requirements. So, let's start with defining |
| 00:00:07,220 --> 00:00:10,540 | user requirements. Those are requirements that are written for the |
| 00:00:10,540 --> 00:00:13,400 | customers and they're often in natural language and they don't |
| 00:00:13,400 --> 00:00:16,190 | contain technical details. And the reason for that is |
| 00:00:16,190 --> 00:00:19,740 | that their purpose is to allow customers, stakeholders, to check |
| 00:00:19,740 --> 00:00:22,210 | that the system will do what they intended. So it's |
| 00:00:22,210 --> 00:00:25,470 | a way for the analyst, the developers, to communicate with |
| 00:00:25,470 --> 00:00:28,460 | the customers, with the stakeholders. System requirements, on the |
| 00:00:28,460 --> 00:00:32,560 | other hand, are written for developers. Contain detailed functional and |
| 00:00:32,560 --> 00:00:35,330 | non functional requirements. Which we just discussed, and which |
| 00:00:35,330 --> 00:00:39,860 | are clearly and more rigourously specified than the user requirements. |
| 00:00:39,860 --> 00:00:42,130 | And the reason for this difference is that the |
| 00:00:42,130 --> 00:00:45,410 | purpose of the system requirements is to tell developers what |
| 00:00:45,410 --> 00:00:47,870 | to build. They must contain enough details so the |
| 00:00:47,870 --> 00:00:50,480 | developers can take them and use them to design and |
| 00:00:50,480 --> 00:00:52,530 | then develop a system. Just to give you a concrete |
| 00:00:52,530 --> 00:00:55,750 | example, here I'm showing you a user requirement that just says |
| 00:00:55,750 --> 00:00:59,510 | that the software must provide a means of representing and accessing |
| 00:00:59,510 --> 00:01:03,940 | external files created by other tools, and the corresponding system requirement. |
| 00:01:03,940 --> 00:01:05,700 | And as you can see, even if we don't read the |
| 00:01:05,700 --> 00:01:09,380 | whole requirements. The former is an informal and high level description |
| 00:01:09,380 --> 00:01:12,210 | of a piece of functionality, whereas the latter describes the same |
| 00:01:12,210 --> 00:01:15,940 | functionality but in a much more extensive and rigorous way. As |
| 00:01:15,940 --> 00:01:18,760 | I said, this is something that the developers can use to |
| 00:01:18,760 --> 00:01:21,820 | design and then build a system whereas this is something that |
| 00:01:21,820 --> 00:01:25,590 | can be used to communicate. With the stakeholders, with a non-technical |
| 00:01:25,590 --> 00:01:25,590 | audience. And we need to define both because they serve different purposes. |