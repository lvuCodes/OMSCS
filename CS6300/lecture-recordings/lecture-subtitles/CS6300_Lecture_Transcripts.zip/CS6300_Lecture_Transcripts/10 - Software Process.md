# CS6300 10 - Software Process

| Timestamp | Content |
|-----------|---------|
| 00:00:00,200 --> 00:00:02,580 | One thing you need to know right away about software processes |
| 00:00:02,580 --> 00:00:05,750 | is that there's not just one single process, but there are multiple, |
| 00:00:05,750 --> 00:00:08,840 | possible processes, depending on your context, depending on the kind of |
| 00:00:08,840 --> 00:00:11,535 | applications that you are developing. In this course, we are going to try |
| 00:00:11,535 --> 00:00:14,760 | to cover the spectrum of the possible processes, as much as |
| 00:00:14,760 --> 00:00:18,900 | possible, by focusing on four main software processes. The first one is |
| 00:00:18,900 --> 00:00:22,480 | what we call normally the waterfall process. And, we call it waterfall |
| 00:00:22,480 --> 00:00:25,490 | because in the process we go from one phase to the other |
| 00:00:25,490 --> 00:00:28,300 | in the same way in which water follows the flow |
| 00:00:28,300 --> 00:00:30,910 | in a waterfall. The second process that we consider is what |
| 00:00:30,910 --> 00:00:34,580 | we call evolutionary prototyping, and in this case, instead of |
| 00:00:34,580 --> 00:00:37,790 | following this set of rigid steps, all we're trying to do |
| 00:00:37,790 --> 00:00:40,930 | is to start with an initial prototype and evolve it |
| 00:00:40,930 --> 00:00:43,670 | based on the feedback from the customer. We will then move |
| 00:00:43,670 --> 00:00:47,150 | towards a slightly more formal process, which is the rational unified |
| 00:00:47,150 --> 00:00:50,590 | process or the unified software process. And this is a kind |
| 00:00:50,590 --> 00:00:53,040 | of project heavily based on the use of UML, so we |
| 00:00:53,040 --> 00:00:56,263 | will also cover UML when discussing this kind of project. Finally, |
| 00:00:56,263 --> 00:00:58,680 | the fourth kind of process we will consider is the family |
| 00:00:58,680 --> 00:01:01,670 | of agile software processes. And these are processes in which we |
| 00:01:01,670 --> 00:01:04,280 | sacrifice the discipline a little bi,t in order to be more |
| 00:01:04,280 --> 00:01:07,380 | flexible and be more able to account for changes and in |
| 00:01:07,380 --> 00:01:10,760 | particular for changes in requirements. We are going to cover each |
| 00:01:10,760 --> 00:01:10,760 | one of these four processes extensively in the rest of the class. |