# CS6300 38 - Classic Mistakes_ People

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:02,000 | Now we get to the final part of the lesson. |
| 00:00:02,000 --> 00:00:04,810 | And in this part I want to talk about well known, |
| 00:00:04,810 --> 00:00:09,230 | ineffective development practices. These practices, when followed, tend to lead |
| 00:00:09,230 --> 00:00:13,245 | to predictably bad results. So let's look at some examples of |
| 00:00:13,245 --> 00:00:17,130 | these classic mistakes. And we're going to start with mistakes |
| 00:00:17,130 --> 00:00:20,660 | involving people. And notice that there is a long list. So |
| 00:00:20,660 --> 00:00:23,100 | I'm going to discuss just a few of those mistakes. |
| 00:00:23,100 --> 00:00:25,215 | And I'm going to point you to more information on this |
| 00:00:25,215 --> 00:00:27,550 | topic in the class notes. And some of these mistakes are |
| 00:00:27,550 --> 00:00:30,020 | actually kind of entertaining. So I'll recommend that you look at |
| 00:00:30,020 --> 00:00:33,210 | the class notes and go in more depth in this list. |
| 00:00:33,210 --> 00:00:35,550 | So the first people mistake I want to mention is the |
| 00:00:35,550 --> 00:00:38,945 | one that I define, heroics. And this refers to too much |
| 00:00:38,945 --> 00:00:43,480 | emphasis on can do attitudes, so this idea that one person |
| 00:00:43,480 --> 00:00:46,330 | by himself or by herself can do everything and can make |
| 00:00:46,330 --> 00:00:50,422 | the difference in the whole project. And unfortunately, this encourages extreme |
| 00:00:50,422 --> 00:00:53,950 | risk taking and discourages cooperation, which is plain bad for |
| 00:00:53,950 --> 00:00:56,610 | the project. For example, it might force people not to |
| 00:00:56,610 --> 00:00:59,600 | report schedule slips. It might force people to take on |
| 00:00:59,600 --> 00:01:02,210 | on too much responsibility. And normally, and I saw it |
| 00:01:02,210 --> 00:01:05,600 | happen many times, the final result is a failure. So |
| 00:01:05,600 --> 00:01:08,410 | what you want when you're developing a larger project, is |
| 00:01:08,410 --> 00:01:11,710 | actually to apply soft engineering principles. Have teams, have team |
| 00:01:11,710 --> 00:01:15,580 | work, and have cooperation among the different team members, without pointing |
| 00:01:15,580 --> 00:01:18,830 | too much on single individuals. Another classic mistake |
| 00:01:18,830 --> 00:01:22,140 | is to not create the right working environment. We |
| 00:01:22,140 --> 00:01:24,900 | all like to work in nice environments. And there |
| 00:01:24,900 --> 00:01:27,790 | is strong evidence that the working environments can play |
| 00:01:27,790 --> 00:01:30,670 | a big role in productivity. There is evidence |
| 00:01:30,670 --> 00:01:34,280 | that productivity increases when the workplace is nice, quiet, |
| 00:01:34,280 --> 00:01:37,950 | warm, and welcoming. Finally, some of the most important |
| 00:01:37,950 --> 00:01:41,480 | people relating mistakes are due to poor people management. |
| 00:01:41,480 --> 00:01:44,540 | For example, lack of leaderships, or leadership that is |
| 00:01:44,540 --> 00:01:47,920 | exercised using the wrong means in the wrong way, which |
| 00:01:47,920 --> 00:01:50,280 | can lead to very unhappy personnel and therefore, low |
| 00:01:50,280 --> 00:01:54,190 | productivity, or even people leaving teams. Another classic example of |
| 00:01:54,190 --> 00:01:57,370 | poor management is adding people to a project that |
| 00:01:57,370 --> 00:02:01,600 | is behind schedule, which never works. Why it doesn't work? |
| 00:02:01,600 --> 00:02:03,440 | Because these new people need to be brought up to |
| 00:02:03,440 --> 00:02:06,520 | speed, and that causes further delays rather than improving the |
| 00:02:06,520 --> 00:02:06,520 | situation with the project schedule. |