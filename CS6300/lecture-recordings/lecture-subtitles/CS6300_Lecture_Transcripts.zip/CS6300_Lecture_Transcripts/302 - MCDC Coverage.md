# CS6300 302 - MCDC Coverage

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:03,880 | And this criterion is called Modified Condition/Decision Coverage, |
| 00:00:03,880 --> 00:00:07,750 | also called MC/DC. This criterion is very important because |
| 00:00:07,750 --> 00:00:10,330 | it is often required for safety critical applications. |
| 00:00:10,330 --> 00:00:13,920 | For example, the FAA, the Federal Aviation Administration, requires |
| 00:00:13,920 --> 00:00:15,980 | for all the software that runs on commercial |
| 00:00:15,980 --> 00:00:19,420 | airplanes to be tested according to the Modified Condition/Decision |
| 00:00:19,420 --> 00:00:22,015 | Coverage. So what is the key idea behind the |
| 00:00:22,015 --> 00:00:25,270 | MC/DC criterion? It is to test only the important |
| 00:00:25,270 --> 00:00:28,710 | combinations of conditions instead of all of them, and limit |
| 00:00:28,710 --> 00:00:32,189 | the testing cost by excluding the other combinations. And the way |
| 00:00:32,189 --> 00:00:34,950 | in which it works is by extending branch and decision |
| 00:00:34,950 --> 00:00:38,860 | coverage with the requirement that each condition should affect the decision |
| 00:00:38,860 --> 00:00:41,940 | outcome independently. So let's see what this means with an |
| 00:00:41,940 --> 00:00:45,030 | example that will also show you how you can reduce the |
| 00:00:45,030 --> 00:00:46,940 | number of combinations in this way. I am going to |
| 00:00:46,940 --> 00:00:50,460 | show you an example of how MC/DC works using this predicate |
| 00:00:50,460 --> 00:00:53,870 | which consists of three conditions. a, b, and c, which are all |
| 00:00:53,870 --> 00:00:57,070 | in and, so the overall predicate is a and b and c. |
| 00:00:57,070 --> 00:00:58,980 | The first thing I'm going to do is to show you how |
| 00:00:58,980 --> 00:01:03,370 | many test cases we will need to satisfy the multiple condition coverage |
| 00:01:03,370 --> 00:01:06,440 | for this simple predicate. Which means, how many test cases we will |
| 00:01:06,440 --> 00:01:09,780 | need to test all the possible combinations of true and false values |
| 00:01:09,780 --> 00:01:12,740 | for these conditions. So I'm going to populate this table. And as you |
| 00:01:12,740 --> 00:01:15,870 | can see, at the end we have eight test cases. Each test case |
| 00:01:15,870 --> 00:01:18,650 | tests a different combination of values for a, b, and c. |
| 00:01:18,650 --> 00:01:21,200 | I'm also showing, for each test case, the outcome of the overall |
| 00:01:21,200 --> 00:01:23,930 | predicate. So, for example, if we look at the first one, the |
| 00:01:23,930 --> 00:01:27,200 | first test case, will be such that a is true, b is |
| 00:01:27,200 --> 00:01:30,210 | true, and c is true. And therefore, the overall outcome of |
| 00:01:30,210 --> 00:01:34,360 | the predicate is true. Now let's consider the first condition, a. As |
| 00:01:34,360 --> 00:01:36,300 | I said a minute ago, what we want to test are the |
| 00:01:36,300 --> 00:01:39,160 | important combination. Which are the comibatinos |
| 00:01:39,160 --> 00:01:41,930 | in which a single condition independently |
| 00:01:41,930 --> 00:01:45,610 | effects the outcome of the overall predicate. So if we consider a |
| 00:01:45,610 --> 00:01:48,490 | and we look at this possible set of this cases. Let's try to |
| 00:01:48,490 --> 00:01:51,850 | find two test cases such that the only difference between the two |
| 00:01:51,850 --> 00:01:54,960 | test cases is the value of a, and the overall outcome of the |
| 00:01:54,960 --> 00:01:57,790 | predicate is different. If we look at the table, we can see |
| 00:01:57,790 --> 00:02:00,920 | that this is true for test cases one and five. If we look |
| 00:02:00,920 --> 00:02:04,030 | at these two cases, we can see that the overall of the predicate |
| 00:02:04,030 --> 00:02:07,420 | in the two cases is true and false, and that the only difference |
| 00:02:07,420 --> 00:02:10,720 | between the value of the conditions in the value of a. So |
| 00:02:10,720 --> 00:02:13,990 | these test cases satisfy exactly what we wanted. There are two test |
| 00:02:13,990 --> 00:02:18,270 | cases in which the value of a independently decides the overall value |
| 00:02:18,270 --> 00:02:21,380 | of the predicate. What we do, therefore, is to add these first |
| 00:02:21,380 --> 00:02:24,740 | two test cases to our set of tests down here. Now let's |
| 00:02:24,740 --> 00:02:27,520 | focus on b and let's try to find two test cases such |
| 00:02:27,520 --> 00:02:30,280 | that the value of b is the only value that changes between |
| 00:02:30,280 --> 00:02:32,450 | the two test cases, but the overall value of the predicate is |
| 00:02:32,450 --> 00:02:34,980 | different, the same thing we did for a. And in this case, |
| 00:02:34,980 --> 00:02:37,610 | we can see that if we select test case number one, and test |
| 00:02:37,610 --> 00:02:40,420 | case number three, we have exactly that situation. b is true in the |
| 00:02:40,420 --> 00:02:44,250 | first case, false in the second one, a and c don't change, but |
| 00:02:44,250 --> 00:02:46,830 | the overall value of the predicate changes. And now you can notice |
| 00:02:46,830 --> 00:02:50,720 | something else. That even though we selected two test cases, tested two values, |
| 00:02:50,720 --> 00:02:53,950 | one we already had. So, we only need three test cases overall to |
| 00:02:53,950 --> 00:02:57,730 | test a and b according to MC/DC. Now, let's look at our last |
| 00:02:57,730 --> 00:03:00,510 | condition, c. At this point, we know the game, so we |
| 00:03:00,510 --> 00:03:02,780 | just have to look for two test cases that satisfy our |
| 00:03:02,780 --> 00:03:06,380 | requirements. And in this case, one and two are suitable candidates. |
| 00:03:06,380 --> 00:03:08,820 | And once more, because we already have one, we just have to |
| 00:03:08,820 --> 00:03:11,070 | add two to our list. So as you can see from |
| 00:03:11,070 --> 00:03:14,730 | this example, we went from having eight test cases needed to cover |
| 00:03:14,730 --> 00:03:18,600 | all the possible combinations of conditions to only four test cases |
| 00:03:18,600 --> 00:03:22,880 | to satisfy the MC/DC criteria. So let's see where MC/DC stands in |
| 00:03:22,880 --> 00:03:25,510 | our substantion hierarchy. This is what we had so far |
| 00:03:25,510 --> 00:03:28,430 | in the hierarchy and this is where the MC/DC criterion will |
| 00:03:28,430 --> 00:03:31,930 | stand. MC/DC criterion is stronger than branch and condition coverage. |
| 00:03:31,930 --> 00:03:35,210 | Why? Because it requires every single condition to be true and |
| 00:03:35,210 --> 00:03:38,400 | false. And therefore, this section was a condition coverage criteria. |
| 00:03:38,400 --> 00:03:41,610 | And it also requires every predicate to be true and false |
| 00:03:41,610 --> 00:03:44,425 | and therefore, this section is branch coverage. And in addition, |
| 00:03:44,425 --> 00:03:47,790 | it's got the additional requirements that the true and false values, |
| 00:03:47,790 --> 00:03:50,330 | all the conditions have to also decide the overall |
| 00:03:50,330 --> 00:03:53,190 | value of the predicate. So it's stronger. Which is more |
| 00:03:53,190 --> 00:03:56,130 | thorough than branch and condition coverage and, as usual, |
| 00:03:56,130 --> 00:03:56,130 | also stronger than branch coverage, statement coverage, and condition coverage. |