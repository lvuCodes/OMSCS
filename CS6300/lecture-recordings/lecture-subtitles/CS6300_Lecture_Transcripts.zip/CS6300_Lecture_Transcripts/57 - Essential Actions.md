# CS6300 57 - Essential Actions

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,220 | What I want to do next, is to look at how |
| 00:00:02,220 --> 00:00:05,780 | version control systems actually work. We saw what they are. We |
| 00:00:05,780 --> 00:00:08,130 | saw why they are useful. But how do they actually work? |
| 00:00:08,130 --> 00:00:11,460 | And we're going to do that by starting from some essential |
| 00:00:11,460 --> 00:00:15,400 | actions that version control systems perform. The first one is the |
| 00:00:15,400 --> 00:00:18,920 | addition of files. So, when you use a version control system, |
| 00:00:18,920 --> 00:00:22,280 | you can add a file to the repository. And at that |
| 00:00:22,280 --> 00:00:25,400 | point the file will be accessible to other people who have access |
| 00:00:25,400 --> 00:00:28,640 | to the repository. And now the fundamental action is commit. |
| 00:00:28,640 --> 00:00:31,230 | When you change a file, a file that is already in |
| 00:00:31,230 --> 00:00:33,610 | the repository, when you make some local changes to a |
| 00:00:33,610 --> 00:00:36,430 | file that is already in the repository, you want then to |
| 00:00:36,430 --> 00:00:39,460 | commit your changes to the central repository, so they can |
| 00:00:39,460 --> 00:00:43,990 | become visible to all of the other users on the repository. Finally, |
| 00:00:43,990 --> 00:00:47,770 | another fundamental action is the action of updating a file. If |
| 00:00:47,770 --> 00:00:50,650 | we have a repository and someone else can modify the files |
| 00:00:50,650 --> 00:00:52,800 | in the repository, I want to be able to get |
| 00:00:52,800 --> 00:00:55,550 | the changes that other people made to the files in the |
| 00:00:55,550 --> 00:00:58,980 | repository. And these are just three of the basic actions, but |
| 00:00:58,980 --> 00:00:58,980 | there are many, many more. And we'll see several of those. |