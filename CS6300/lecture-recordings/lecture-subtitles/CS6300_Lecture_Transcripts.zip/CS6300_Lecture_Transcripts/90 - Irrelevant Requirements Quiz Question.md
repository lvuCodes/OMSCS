# CS6300 90 - Irrelevant Requirements Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,400 | In the previous quiz, we saw that some of the requirements |
| 00:00:02,400 --> 00:00:04,920 | that they put in the list were not pertinent. They were |
| 00:00:04,920 --> 00:00:08,590 | irrelevant. So let me ask you. Why can irrelevant requirements be |
| 00:00:08,590 --> 00:00:12,170 | harmful? Why is that a problem to have irrelevant requirements? So |
| 00:00:12,170 --> 00:00:15,060 | here, I'm giving you four possible answers. And I'd like for |
| 00:00:15,060 --> 00:00:18,150 | you to mark all that apply. Can irrelevant requirements be harmful |
| 00:00:18,150 --> 00:00:21,210 | because they may lead to missing functionality in the final product. |
| 00:00:21,210 --> 00:00:23,390 | Because they can introduce inconsistency. Because |
| 00:00:23,390 --> 00:00:25,410 | they can waste the project resources. |
| 00:00:25,410 --> 00:00:28,170 | Or because they may introduce bugs in the software system. And |
| 00:00:28,170 --> 00:00:28,170 | as I said, more than one can be a valid reason. |