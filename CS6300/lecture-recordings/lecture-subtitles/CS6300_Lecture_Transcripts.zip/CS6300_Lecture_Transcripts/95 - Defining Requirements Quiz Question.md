# CS6300 95 - Defining Requirements Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,180 --> 00:00:01,780 | Since we just discussed application |
| 00:00:01,780 --> 00:00:04,770 | domain, machine domain, and the specificiation, |
| 00:00:04,770 --> 00:00:07,760 | let's make sure that these concepts are well understood. To do that, |
| 00:00:07,760 --> 00:00:09,740 | I'm going to use a quiz, and I would like for you |
| 00:00:09,740 --> 00:00:12,590 | to refer to the figure that we just discussed that I'm also |
| 00:00:12,590 --> 00:00:16,050 | reproducing here on a small scale on the right. And then |
| 00:00:16,050 --> 00:00:19,080 | referring to the figure, you should indicate for each of the items |
| 00:00:19,080 --> 00:00:22,140 | that I'm going to show you here shortly. Whether they belong to |
| 00:00:22,140 --> 00:00:25,360 | the machine domain. In this case, we're going to put a one next |
| 00:00:25,360 --> 00:00:28,150 | to the icon. The application domain, in this case you should |
| 00:00:28,150 --> 00:00:31,410 | put two. Or their intersection, and in this case you should |
| 00:00:31,410 --> 00:00:34,100 | put three. So this is the lists of items. So let |
| 00:00:34,100 --> 00:00:37,750 | me read it. An algorithm sorts a list of books in alphabetical |
| 00:00:37,750 --> 00:00:41,070 | order by the first author's name. A notification of the arrival |
| 00:00:41,070 --> 00:00:44,380 | of a message appears on a smart watch. An employee wants to |
| 00:00:44,380 --> 00:00:47,150 | organize a meeting with a set of colleagues. And finally, a |
| 00:00:47,150 --> 00:00:50,690 | user clicks a link on a web page. So again, put 1, |
| 00:00:50,690 --> 00:00:55,740 | 2, or 3 here in these lots, depending on whether you think that these items |
| 00:00:55,740 --> 00:00:57,840 | belong to the machine domain, the application |
| 00:00:57,840 --> 00:00:57,840 | domain, or their intersection. So, their specification, here. |