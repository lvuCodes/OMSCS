# CS6300 22 - Verification & Validation

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:03,550 | After we have built our system, verification and validation |
| 00:00:03,550 --> 00:00:05,970 | is that phase of software development that aims to |
| 00:00:05,970 --> 00:00:09,000 | check that the software system meets its specification and |
| 00:00:09,000 --> 00:00:12,800 | fulfills its intended purpose. More precisely, we can look |
| 00:00:12,800 --> 00:00:16,250 | at verification and validation independently. And validation is the |
| 00:00:16,250 --> 00:00:19,100 | activity that answers the question did we build the |
| 00:00:19,100 --> 00:00:21,420 | right system. Did we build the system that the |
| 00:00:21,420 --> 00:00:26,030 | customer wants? That will make the customer happy. Whereas verification |
| 00:00:26,030 --> 00:00:28,730 | answers a different question which is did we build the system |
| 00:00:28,730 --> 00:00:31,410 | right. So given a description of the system that is the one |
| 00:00:31,410 --> 00:00:34,280 | that we derived from the customer through the collection of requirements |
| 00:00:34,280 --> 00:00:37,130 | and then design and so on, did we build a system that |
| 00:00:37,130 --> 00:00:41,150 | actually implements the specification that we defined? And when we look |
| 00:00:41,150 --> 00:00:44,600 | at verification there's many, many ways of doing verification and in fact |
| 00:00:44,600 --> 00:00:48,430 | in the mini course number four we will cover verification extensively. The |
| 00:00:48,430 --> 00:00:51,100 | only thing I want to mention here is the fact that verification |
| 00:00:51,100 --> 00:00:54,110 | can be performed at different levels. In particular, it can be |
| 00:00:54,110 --> 00:00:57,810 | performed at the unit level in which we test that the individual |
| 00:00:57,810 --> 00:01:01,520 | units work as a expected. Can be performed in the integration level |
| 00:01:01,520 --> 00:01:05,525 | in which what we test is the interaction between the different units. |
| 00:01:05,525 --> 00:01:07,630 | So we want to make sure that the different modules talk |
| 00:01:07,630 --> 00:01:10,720 | to each other in the right way. And finally, there is system |
| 00:01:10,720 --> 00:01:13,440 | testing in which we test the system as a whole and we |
| 00:01:13,440 --> 00:01:16,170 | want to make sure that all the system, all the different pieces |
| 00:01:16,170 --> 00:01:18,010 | of the system work together in the right |
| 00:01:18,010 --> 00:01:20,160 | way. And this is also the level at which |
| 00:01:20,160 --> 00:01:22,360 | then we will apply validation and some other |
| 00:01:22,360 --> 00:01:25,770 | testing techniques like stress testing or robustness testing and |
| 00:01:25,770 --> 00:01:29,890 | so on. And as I said I'm not going to say anything more on this topic because |
| 00:01:29,890 --> 00:01:32,760 | we will cover verification, and validation, and testing in |
| 00:01:32,760 --> 00:01:32,760 | particular in great details in mini course number four. |