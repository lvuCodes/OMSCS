# CS6300 178 - Architectural Design Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:02,540 | So, let's look at these three characteristics one by |
| 00:00:02,540 --> 00:00:06,660 | one. Scalability for software architecture is its ability to handle |
| 00:00:06,660 --> 00:00:09,320 | the growth of the software system. For example, for a |
| 00:00:09,320 --> 00:00:12,610 | web based system, scalability could be the ability to handle |
| 00:00:12,610 --> 00:00:15,620 | a larger workload by adding new servers to the system. |
| 00:00:15,620 --> 00:00:19,508 | Scalability is therefore an important characteristic of a software architecture, |
| 00:00:19,508 --> 00:00:21,938 | especially for the kinds of systems that can grow over |
| 00:00:21,938 --> 00:00:24,990 | time. So, we're going to mark it as an ideal characteristic. |
| 00:00:24,990 --> 00:00:27,901 | Cohesion is a measure of how strongly related are |
| 00:00:27,901 --> 00:00:30,920 | the elements of a module. Clearly, we should shoot |
| 00:00:30,920 --> 00:00:33,760 | for high and not low cohesion when developing a |
| 00:00:33,760 --> 00:00:37,100 | system. We want to develop modules whose elements cooperate to |
| 00:00:37,100 --> 00:00:40,480 | provide the specific piece of functionality rather than modules |
| 00:00:40,480 --> 00:00:43,410 | consisting of a bunch of elements that provide different |
| 00:00:43,410 --> 00:00:47,040 | unrelated pieces of functionality. Therefor, low cohesion is definitely |
| 00:00:47,040 --> 00:00:49,980 | not something that we want. We want high cohesion instead. |
| 00:00:49,980 --> 00:00:53,040 | As for coupling, coupling is a concept related to cohesion |
| 00:00:53,040 --> 00:00:55,070 | and is also a measure. In this case though, it |
| 00:00:55,070 --> 00:00:58,130 | is a measure of how strongly related are the different |
| 00:00:58,130 --> 00:01:01,830 | modules in a system. Low coupling, which is often correlated with |
| 00:01:01,830 --> 00:01:05,570 | high cohesion, is an important and ideal characteristic of a |
| 00:01:05,570 --> 00:01:08,660 | software architecture as it indicates that the different modules in |
| 00:01:08,660 --> 00:01:12,220 | the system are independent from one another. Each module provides |
| 00:01:12,220 --> 00:01:15,300 | a specific piece of functionality and it can provide it without |
| 00:01:15,300 --> 00:01:17,530 | relying too much on other modules. |
| 00:01:17,530 --> 00:01:19,960 | Basically, systems characterized by low coupling |
| 00:01:19,960 --> 00:01:19,960 | and high cohesion, are systems that are easier to understand, and to maintain. |