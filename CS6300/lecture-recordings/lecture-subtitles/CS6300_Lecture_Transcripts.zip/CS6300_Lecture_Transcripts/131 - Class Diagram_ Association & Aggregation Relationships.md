# CS6300 131 - Class Diagram_ Association & Aggregation Relationships

| Timestamp                     | Content                                                                                              |
| ----------------------------- | ---------------------------------------------------------------------------------------------------- |
| 00:00:00,080 --> 00:00:02,469 | The next example of relationship we're going to look at is                                           |
| 00:00:02,469 --> 00:00:06,740 | the association relationship. This is a relationship in which objects of                             |
| 00:00:06,740 --> 00:00:09,570 | one class are **connected to objects of another.** And it's                                          |
| 00:00:09,570 --> 00:00:12,480 | called an **has a** relationship. So it means that **objects of**                                    |
| 00:00:12,480 --> 00:00:15,930 | **one class have objects of another class.** So let's see                                            |
| 00:00:15,930 --> 00:00:18,750 | what that means. Let's do it by considering two classes in                                           |
| 00:00:18,750 --> 00:00:22,370 | our example system. The student class and the course offering class.                                 |
| 00:00:22,370 --> 00:00:25,300 | In this case, there is an association between the student and                                        |
| 00:00:25,300 --> 00:00:28,010 | the course offering, because the student is registering for the                                      |
| 00:00:28,010 --> 00:00:31,750 | course offering. So, in a sense, the **course offering has students**.                               |
| 00:00:31,750 --> 00:00:35,360 | **Contains** students, to indicate this fact we add a solid                                          |
| 00:00:35,360 --> 00:00:38,750 | line between the student class and the course offering. And the                                      |
| 00:00:38,750 --> 00:00:40,540 | fact that having a solid line doesn't really tell us                                                 |
| 00:00:40,540 --> 00:00:44,780 | much about the nature of the relationship, so to clarify such                                        |
| 00:00:44,780 --> 00:00:47,550 | nature we can use what we call **adornments** that we                                                |
| 00:00:47,550 --> 00:00:51,010 | can apply to associations we can add to associations to clarify                                      |
| 00:00:51,010 --> 00:00:53,850 | their meaning. In particular we can add a label to                                                   |
| 00:00:53,850 --> 00:00:57,550 | an association and the **label describes the nature of the relationship.**                           |
| 00:00:57,550 --> 00:01:00,440 | In this case, for example, it clarifies that the student                                             |
| 00:01:00,440 --> 00:01:03,970 | registers for CourseOffering. We can also add a **triangle** to                                      |
| 00:01:03,970 --> 00:01:07,050 | further clarify the **direction** of the relationship. So in this                                    |
| 00:01:07,050 --> 00:01:10,240 | case, the triangle will indicate that it's the student That registers                                |
| 00:01:10,240 --> 00:01:13,120 | for the course offering, and not the other way around. Another                                       |
| 00:01:13,120 --> 00:01:16,650 | important adornment or limitation that we can put on an association,                                 |
| 00:01:16,650 --> 00:01:20,800 | is multiplicity. **Multiplicity defines the number of instances of one**                             |
| 00:01:20,800 --> 00:01:23,540 | **class that are related to one instance of the other**                                              |
| 00:01:23,540 --> 00:01:26,900 | **class**. We can define multiplicity at **either end** of the                                       |
| 00:01:26,900 --> 00:01:29,620 | relationship. In this case, for instance, we can say that                                            |
| 00:01:29,620 --> 00:01:31,890 | if we look at the student, the student can register                                                  |
| 00:01:31,890 --> 00:01:35,410 | for two or more course offerings. Whereas, if we look                                                |
| 00:01:35,410 --> 00:01:37,560 | at the course offering, we can say that each course                                                  |
| 00:01:37,560 --> 00:01:42,260 | offering can have or can enroll between 1 and 50 students.                                           |
| 00:01:42,260 --> 00:01:45,120 | So as you can see by adding a label, a direction,                                                    |
| 00:01:45,120 --> 00:01:49,590 | and multiplicity, we make it much clearer what the relationship is                                   |
| 00:01:49,590 --> 00:01:52,170 | and what it means and what are its characteristics. As we![[lvu 2026-02-15 at 03.26PM.png]]          |
| 00:01:52,170 --> 00:01:55,130 | saw when we introduced relationships, there is a different kind of                                   |
| 00:01:55,130 --> 00:01:58,860 | association, kind of a specialized one, which we call aggregation. So                                |
| 00:01:58,860 --> 00:02:01,130 | here we're going to look at an example of an aggregation. So                                         |
| 00:02:01,130 --> 00:02:03,490 | first of all what is an aggregation? An aggregation is a                                             |
| 00:02:03,490 --> 00:02:07,580 | **relationship between 2 classes in which 1 represents a larger class**                              |
| 00:02:07,580 --> 00:02:10,610 | **like a whole which consists of smaller classes which are**                                         |
| 00:02:10,610 --> 00:02:13,430 | **the parts of this whole.** So let's look at an example                                             |
| 00:02:13,430 --> 00:02:16,960 | in the context of our system. Let's consider a Course                                                |
| 00:02:16,960 --> 00:02:19,160 | and the CourseOffering. And in this case, we can see                                                 |
| 00:02:19,160 --> 00:02:23,000 | that the Course consists of multiple CourseOfferings. So in                                          |
| 00:02:23,000 --> 00:02:26,520 | a sense, a course is a whole and the course offerings                                                |
| 00:02:26,520 --> 00:02:29,430 | are the parts of this whole. So this a perfect case                                                  |
| 00:02:29,430 --> 00:02:32,620 | in which we will use an aggregation to express this relationship.                                    |
| 00:02:32,620 --> 00:02:37,630 | So we will add a solid line with a diamond on the side of the whole class                            |
| 00:02:37,630 --> 00:02:42,380 | to indicate that the course consists of multiple course offerings.![[lvu 2026-02-15 at 03.29PM.png]] |
| 00:02:42,380 --> 00:02:44,670 | And as we did for associations even though we                                                        |
| 00:02:44,670 --> 00:02:46,010 | are not going to do it for this specific                                                             |
| 00:02:46,010 --> 00:02:49,540 | example, we could also in this case add multiplicity                                                 |
| 00:02:49,540 --> 00:02:52,830 | information on the aggregation to indicate how many classes                                          |
| 00:02:52,830 --> 00:02:52,830 | of the two types are involved in the relationships.                                                  |
