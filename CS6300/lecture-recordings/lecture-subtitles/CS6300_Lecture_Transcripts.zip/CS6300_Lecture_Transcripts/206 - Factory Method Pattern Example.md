# CS6300 206 - Factory Method Pattern Example

| Timestamp | Content |
|-----------|---------|
| 00:00:00,220 --> 00:00:03,260 | The example I'm going to use consists of a class called |
| 00:00:03,260 --> 00:00:07,380 | ImageReaderFactory which provides the factory method which is this one; |
| 00:00:07,380 --> 00:00:10,250 | createImageReader. As you can see the method takes an InputStream |
| 00:00:10,250 --> 00:00:13,570 | as input and returns an object of type ImageReader, and it's |
| 00:00:13,570 --> 00:00:15,645 | static so that we can invoke it even if we |
| 00:00:15,645 --> 00:00:18,390 | don't have an instance of the ImageReaderFactory. So what does the |
| 00:00:18,390 --> 00:00:22,275 | method do? Well the method first invokes, getImageType, passing the |
| 00:00:22,275 --> 00:00:25,780 | InputStream as a parameter and this method figures out the type |
| 00:00:25,780 --> 00:00:28,820 | of the image that is stored in this Inputstream and it's |
| 00:00:28,820 --> 00:00:32,740 | an integer. Then, based on the value of this integer, the |
| 00:00:32,740 --> 00:00:35,352 | method does one of several things. If the image type is |
| 00:00:35,352 --> 00:00:38,970 | a GIF, it will invoke the constructor for GifReader passing the |
| 00:00:38,970 --> 00:00:41,610 | stream as a parameter. And what will happen is that the |
| 00:00:41,610 --> 00:00:44,450 | GIF reader will read a GIF from the stream, create a |
| 00:00:44,450 --> 00:00:47,887 | corresponding object and return it. So in this case, the ImageReader |
| 00:00:47,887 --> 00:00:51,460 | object return will be the object representing a GIF as appropriate. |
| 00:00:51,460 --> 00:00:54,610 | Similarly, if the image type is JPEG, then the method will |
| 00:00:54,610 --> 00:00:58,579 | invoke the constructor for JPEG Reader and in this case, this constructor |
| 00:00:58,579 --> 00:01:01,981 | will read from the stream a JPEG, create a corresponding object |
| 00:01:01,981 --> 00:01:05,640 | and return it. And so on for different types of images. So |
| 00:01:05,640 --> 00:01:07,880 | why is this a situation in which it is appropriate to |
| 00:01:07,880 --> 00:01:11,100 | use the factory method pattern? One, because it corresponds exactly to the |
| 00:01:11,100 --> 00:01:14,250 | cases that we saw before, of applicability. This is a case |
| 00:01:14,250 --> 00:01:16,560 | in which we don't know the type of the object that we |
| 00:01:16,560 --> 00:01:20,080 | need to create until we run the code, because it depends |
| 00:01:20,080 --> 00:01:22,530 | on the value of the InputStream. It depends on the content |
| 00:01:22,530 --> 00:01:25,590 | of the InputStream. So, until we read the InputStream, we cannot |
| 00:01:25,590 --> 00:01:28,380 | figure out whether we need to create a GIF, a JPEG or |
| 00:01:28,380 --> 00:01:30,780 | some other type of image. So in this case, we want to |
| 00:01:30,780 --> 00:01:33,630 | do, we want to simply delegate to this classes the creation of |
| 00:01:33,630 --> 00:01:35,610 | the object, once we know what type of object needs to |
| 00:01:35,610 --> 00:01:35,610 | be created. So perfect example of application of a factory method pattern. |