# CS6300 285 - Coverage Criteria Intro Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,080 --> 00:00:02,560 | To satisfy our first requirements, we need to find an |
| 00:00:02,560 --> 00:00:06,300 | input that causes the execution of this statement. Because this statement |
| 00:00:06,300 --> 00:00:09,080 | is executed only when result is greater than zero, our |
| 00:00:09,080 --> 00:00:12,815 | test requirement is that a plus b must be greater than |
| 00:00:12,815 --> 00:00:16,219 | 0. When this is satisfied, this statement is executed therefore |
| 00:00:16,219 --> 00:00:19,960 | any test case that implements this specification will cause the execution |
| 00:00:19,960 --> 00:00:22,770 | of this statement. Similarly if we want to cover this statement |
| 00:00:22,770 --> 00:00:25,220 | which is our second requirement we need to have a result |
| 00:00:25,220 --> 00:00:27,370 | that is less than 0. Again, the result is equal |
| 00:00:27,370 --> 00:00:29,490 | to a plus b, so all we need to do |
| 00:00:29,490 --> 00:00:32,450 | is find the test case such that a plus b |
| 00:00:32,450 --> 00:00:32,450 | is less than 0. So this is pretty straight forward. |