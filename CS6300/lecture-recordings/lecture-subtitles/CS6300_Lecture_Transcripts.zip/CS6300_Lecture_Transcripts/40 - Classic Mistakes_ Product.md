# CS6300 40 - Classic Mistakes_ Product

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:01,970 | The third category of mistakes that I want to |
| 00:00:01,970 --> 00:00:04,970 | mention is product-related mistakes. A |
| 00:00:04,970 --> 00:00:07,360 | typical example of product-related mistake |
| 00:00:07,360 --> 00:00:11,010 | is gold plating of requirements. And what that means is |
| 00:00:11,010 --> 00:00:13,710 | basically is that it's very common for projects to have |
| 00:00:13,710 --> 00:00:17,230 | more requirements than they actually need. For example, marketing might |
| 00:00:17,230 --> 00:00:19,090 | want to add more features than the ones that are |
| 00:00:19,090 --> 00:00:21,460 | actually needed by the users. And of course having more |
| 00:00:21,460 --> 00:00:25,720 | requirements lengthens the project's schedule in a totally unnecessary way. |
| 00:00:25,720 --> 00:00:29,250 | Feature creep is another common mistake and consists in |
| 00:00:29,250 --> 00:00:32,140 | adding more and more features to a product that were |
| 00:00:32,140 --> 00:00:34,650 | not initially planned and are not really needed in most |
| 00:00:34,650 --> 00:00:38,360 | cases. And here there is evidence that the average project |
| 00:00:38,360 --> 00:00:41,180 | experiences about a 25% growth in the number of |
| 00:00:41,180 --> 00:00:44,330 | features over its lifetime which can clearly highly effect The |
| 00:00:44,330 --> 00:00:47,580 | project schedule. Finally, if you're working on a project that |
| 00:00:47,580 --> 00:00:50,760 | strains the limits of computer science. For example, because you |
| 00:00:50,760 --> 00:00:53,350 | need to develop new algorithms for the project, or you have |
| 00:00:53,350 --> 00:00:56,670 | to use new techniques. Then that project might be more research than |
| 00:00:56,670 --> 00:00:58,450 | actual development. And therefore, it |
| 00:00:58,450 --> 00:01:00,600 | should be managed accordingly. For example, |
| 00:01:00,600 --> 00:01:00,600 | by taking into account that you will have a highly unpredictable schedule. |