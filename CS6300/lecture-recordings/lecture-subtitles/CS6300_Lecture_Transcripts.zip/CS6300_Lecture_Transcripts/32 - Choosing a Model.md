# CS6300 32 - Choosing a Model

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,860 | We just saw several software process models, and there |
| 00:00:02,860 --> 00:00:06,330 | are many, many more. And because these process models define |
| 00:00:06,330 --> 00:00:09,330 | the master plan for our project, the specific process |
| 00:00:09,330 --> 00:00:12,220 | model that we choose has as much influence over a |
| 00:00:12,220 --> 00:00:15,700 | project's success as any other major planning decision that |
| 00:00:15,700 --> 00:00:18,610 | we make. Therefore, it is very important that we pick |
| 00:00:18,610 --> 00:00:22,100 | the appropriate model for our development process. Picking an appropriate |
| 00:00:22,100 --> 00:00:25,100 | model can ensure the success of a project. On the |
| 00:00:25,100 --> 00:00:27,830 | contrary, if we choose the wrong model, that can be a |
| 00:00:27,830 --> 00:00:31,010 | constant source of problems and ultimately, it can make the project |
| 00:00:31,010 --> 00:00:33,830 | fail. So how can we choose the right model for a |
| 00:00:33,830 --> 00:00:36,310 | project? To be able to do so, we have to take into |
| 00:00:36,310 --> 00:00:40,490 | consideration many factors. In particular, we need to be aware of |
| 00:00:40,490 --> 00:00:44,390 | what level of understanding we have of the requirements. Do we understand |
| 00:00:44,390 --> 00:00:46,720 | all the requirements? Are we going to be able to collect all |
| 00:00:46,720 --> 00:00:50,430 | the requirements in advance, or collecting requirements is going to be hard and |
| 00:00:50,430 --> 00:00:53,460 | therefore, we might want to follow a process that is more flexible |
| 00:00:53,460 --> 00:00:57,470 | with that respect. Another important point is the expected lifetime of the |
| 00:00:57,470 --> 00:01:00,300 | project. Is this a quick project that we are putting together for |
| 00:01:00,300 --> 00:01:03,100 | a specific purpose or something that's going to last for for a number |
| 00:01:03,100 --> 00:01:05,910 | of years and that we're going to maintain over all those years? |
| 00:01:05,910 --> 00:01:08,380 | That's going to make a difference in the way we decide to develop |
| 00:01:08,380 --> 00:01:12,190 | that project. Also, what is the level of risk involved? Do we |
| 00:01:12,190 --> 00:01:15,530 | know the domain very well? Do we know exactly the technologies involved? |
| 00:01:15,530 --> 00:01:19,100 | Well, if so, we might go with a more traditional process. Otherwise, |
| 00:01:19,100 --> 00:01:21,902 | we might want to be more agile, more flexible. It is also |
| 00:01:21,902 --> 00:01:24,900 | very important to know the schedule constraints. How much time, how many |
| 00:01:24,900 --> 00:01:28,640 | resources do we have for this project? What is the expected interaction |
| 00:01:28,640 --> 00:01:31,870 | with the management and the customer? In particular for this ladder, there |
| 00:01:31,870 --> 00:01:34,840 | are many processes that rely on the fact that there can be |
| 00:01:34,840 --> 00:01:38,310 | a continuous interaction with the customer. If that interaction is not there, |
| 00:01:38,310 --> 00:01:41,230 | there's no way we are going to be able to use these processes. |
| 00:01:41,230 --> 00:01:44,580 | Conversely, there are processes that don't require the presence of the customer |
| 00:01:44,580 --> 00:01:47,868 | at all, except for the initial phase and maybe some checking points and |
| 00:01:47,868 --> 00:01:51,020 | so if the customer is very inaccessible, we might want to follow |
| 00:01:51,020 --> 00:01:53,740 | one of those processes, instead of one of the more demanding ones in |
| 00:01:53,740 --> 00:01:57,340 | terms of customer's time. Finally, it is important to take into account |
| 00:01:57,340 --> 00:02:00,450 | the level of the expertise of the people involved. Do we have people |
| 00:02:00,450 --> 00:02:02,730 | that know the technologies that we're using? Do we know people that |
| 00:02:02,730 --> 00:02:04,590 | know a specific kind of process? |
| 00:02:04,590 --> 00:02:06,930 | Some processes require some specific expertise and |
| 00:02:06,930 --> 00:02:09,320 | we're not going to be able to follow that process if we don't |
| 00:02:09,320 --> 00:02:12,410 | have the right expertise. So we need to take into account all of |
| 00:02:12,410 --> 00:02:15,570 | these aspects, and sometimes more, in order to be able to make |
| 00:02:15,570 --> 00:02:15,570 | the right decision and pick the right software process model for our project. |