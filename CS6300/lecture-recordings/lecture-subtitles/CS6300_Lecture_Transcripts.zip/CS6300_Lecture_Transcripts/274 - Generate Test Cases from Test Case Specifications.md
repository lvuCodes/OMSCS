# CS6300 274 - Generate Test Cases from Test Case Specifications

| Timestamp | Content |
|-----------|---------|
| 00:00:00,135 --> 00:00:01,935 | So we get to the last step of the technique in |
| 00:00:01,935 --> 00:00:05,142 | which once we have generated test case specifications. We create test |
| 00:00:05,142 --> 00:00:09,180 | cases starting from this specifications. This step mainly consists in a |
| 00:00:09,180 --> 00:00:12,840 | simple instantiation of frames and it's final result is a set of |
| 00:00:12,840 --> 00:00:16,840 | concrete tests. For our example, test frame number 36 that we |
| 00:00:16,840 --> 00:00:19,270 | just saw, this will be the resulting test case, which has |
| 00:00:19,270 --> 00:00:21,490 | the same ID, so that we can track it and will |
| 00:00:21,490 --> 00:00:25,520 | specify to concrete values, not just the specification for the input elements. |
| 00:00:25,520 --> 00:00:29,130 | So string STR will have this value. And the integer size |
| 00:00:29,130 --> 00:00:31,720 | will have this value. And these two values satisfy what this |
| 00:00:31,720 --> 00:00:35,260 | test case specification was. Which was, having a string contain special |
| 00:00:35,260 --> 00:00:38,760 | characters. Here, we have two special characters, like the new line |
| 00:00:38,760 --> 00:00:41,900 | and the tab. And, we have a size which is greater |
| 00:00:41,900 --> 00:00:44,430 | than zero, in particular, okay? And this is a test case |
| 00:00:44,430 --> 00:00:46,880 | that we can actually run on our code. That we can |
| 00:00:46,880 --> 00:00:50,730 | run on the split program. So, to summarize, we perform six steps |
| 00:00:50,730 --> 00:00:54,400 | in which we went from a high level description of what the program does, to a |
| 00:00:54,400 --> 00:00:56,070 | set of concrete test cases. And this is |
| 00:00:56,070 --> 00:00:57,880 | one of those test cases. So what, what we're |
| 00:00:57,880 --> 00:01:00,210 | going to do next, we're going to do a mini-demo, |
| 00:01:00,210 --> 00:01:02,260 | in which we do this for real. We take |
| 00:01:02,260 --> 00:01:05,440 | the program, we identify categories, choices, constraints, and |
| 00:01:05,440 --> 00:01:05,440 | we actually generate test frames and then test cases. |