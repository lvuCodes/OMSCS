# CS6300 239 - Failure -  Fault -  and Error Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,310 --> 00:00:02,690 | So now, let me ask you a second question. We just saw that we |
| 00:00:02,690 --> 00:00:04,640 | can, reveal a failure in the program |
| 00:00:04,640 --> 00:00:06,640 | by calling double with parameter three. Where |
| 00:00:06,640 --> 00:00:09,750 | is the fault that causes such failure in the program? So I want you |
| 00:00:09,750 --> 00:00:09,750 | to write the number of the line of code that, that contains the fault. |