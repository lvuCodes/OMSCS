# CS6300 327 - Testing Strategy Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:02,600 | The first statement is false. It is not true |
| 00:00:02,600 --> 00:00:04,840 | that because of pair programming, we need twice as many |
| 00:00:04,840 --> 00:00:08,039 | developers. In fact that there is some evidence that even |
| 00:00:08,039 --> 00:00:11,700 | though in pair programming we have two developers working together, |
| 00:00:11,700 --> 00:00:15,175 | that the overall efficiency of the programmers is not really |
| 00:00:15,175 --> 00:00:19,080 | affected by use of this practice. In XP, code is |
| 00:00:19,080 --> 00:00:23,280 | rarely changed after being written. This is also definitely false. |
| 00:00:23,280 --> 00:00:25,233 | In fact in XP there is a lot of emphasis |
| 00:00:25,233 --> 00:00:27,879 | on change on the fact that the code can be changed, |
| 00:00:27,879 --> 00:00:30,462 | it can be resigned, because of the fact when we do |
| 00:00:30,462 --> 00:00:32,793 | that, we have a set of these cases that we can |
| 00:00:32,793 --> 00:00:35,439 | use to check right away that the code still works as |
| 00:00:35,439 --> 00:00:39,850 | expected. So again in XP, it's all about steering rather than |
| 00:00:39,850 --> 00:00:43,430 | just driving down one fixed direction. And therefore, the code can |
| 00:00:43,430 --> 00:00:46,580 | be changed. So this statement is false. It is definitely true |
| 00:00:46,580 --> 00:00:50,950 | that XP follows the test driven development paradigm. In XP we first |
| 00:00:50,950 --> 00:00:53,320 | write tests, and then we write the code, which is |
| 00:00:53,320 --> 00:00:55,980 | exactly what TDD is about. It is not true that |
| 00:00:55,980 --> 00:00:58,740 | the customer does not need to provide requirements in XP. |
| 00:00:58,740 --> 00:01:02,020 | The customer does provide requirements in the form of user |
| 00:01:02,020 --> 00:01:04,879 | stories, and the user stories are the starting point of |
| 00:01:04,879 --> 00:01:09,370 | the development process. Finally, XP is definitely an iterative software |
| 00:01:09,370 --> 00:01:12,500 | development process. In fact, we saw that XP is based |
| 00:01:12,500 --> 00:01:16,100 | on subsequent iterations of the same cycle, in which we |
| 00:01:16,100 --> 00:01:18,110 | select from a set of story cards, or user |
| 00:01:18,110 --> 00:01:21,270 | stories, the stories that we want to implement in the |
| 00:01:21,270 --> 00:01:24,250 | next iteration. Based on that we develop task cards, |
| 00:01:24,250 --> 00:01:26,060 | and then we use the task cards to write this |
| 00:01:26,060 --> 00:01:28,400 | case and then to write code. And we continue |
| 00:01:28,400 --> 00:01:31,140 | this cycle in an iterative way until we are done |
| 00:01:31,140 --> 00:01:33,030 | with all the story cards, and all the user |
| 00:01:33,030 --> 00:01:33,030 | stories, so definitely XP is an iterative software development process. |