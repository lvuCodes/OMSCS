# CS6300 100 - Requirements Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:03,710 | So, the first requirement clearly refers to some specific functionality of |
| 00:00:03,710 --> 00:00:07,230 | the Bowling Alley system, because it talks about what the system has |
| 00:00:07,230 --> 00:00:10,420 | to do from a functional standpoint. So, it's definitely not a non-functional |
| 00:00:10,420 --> 00:00:13,400 | requirement. On the other hand, the fact that the Word Count system |
| 00:00:13,400 --> 00:00:16,320 | should be able to process large files, is telling us something not |
| 00:00:16,320 --> 00:00:19,580 | about the functionality of the system, but rather about its qualities. The |
| 00:00:19,580 --> 00:00:21,600 | fact that it has to be scalable, that it has to be |
| 00:00:21,600 --> 00:00:25,190 | efficient and so we can consider this to be a non-functional requirement. |
| 00:00:25,190 --> 00:00:27,010 | Similarly, the fact that the Login program for a |
| 00:00:27,010 --> 00:00:29,390 | website should be secure is definitely telling us something |
| 00:00:29,390 --> 00:00:31,800 | about the quality of the system that has little |
| 00:00:31,800 --> 00:00:34,026 | to do with its functionality. And so this is |
| 00:00:34,026 --> 00:00:36,680 | also a non-functional requirement. Finally, the fact that the |
| 00:00:36,680 --> 00:00:38,980 | Vending Machine program should take coins as an input |
| 00:00:38,980 --> 00:00:41,010 | from the user is telling us something about the |
| 00:00:41,010 --> 00:00:41,010 | functionality of the program and therefore, is a functional requirement. |