# CS6300 305 - Review Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,180 --> 00:00:04,040 | And the answer in this case is clearly yes. In fact, any input will really |
| 00:00:04,040 --> 00:00:04,040 | achieve path coverage for this code because there is only one path in the code. |