# CS6300 33 - Choosing a Model Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:02,080 | Now before we move to the last part of the lesson, let's |
| 00:00:02,080 --> 00:00:04,939 | have a quick quiz on software process models to make sure that |
| 00:00:04,939 --> 00:00:06,640 | we are all on the same page. So I am going to |
| 00:00:06,640 --> 00:00:10,320 | ask you two questions. The first question is which of the following models |
| 00:00:10,320 --> 00:00:14,330 | is most suitable to develop a software control system? And when you |
| 00:00:14,330 --> 00:00:17,700 | think about the software control system, you can think about for example |
| 00:00:17,700 --> 00:00:21,150 | the control system for the software in an airplane. Would you rather |
| 00:00:21,150 --> 00:00:22,860 | use a pure waterfall model? Test |
| 00:00:22,860 --> 00:00:22,860 | driven development? Or an evolutionary prototyping approach? |