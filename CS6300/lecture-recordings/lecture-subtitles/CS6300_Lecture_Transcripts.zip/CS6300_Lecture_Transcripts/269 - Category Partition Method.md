# CS6300 269 - Category Partition Method

| Timestamp | Content |
|-----------|---------|
| 00:00:00,200 --> 00:00:03,690 | What we will discuss next is a specific black-box testing |
| 00:00:03,690 --> 00:00:07,240 | approach. So a specific instance of the general approach that |
| 00:00:07,240 --> 00:00:10,814 | we just saw. And this approach is the category-partition method, |
| 00:00:10,814 --> 00:00:13,418 | and was defined by Ostrand & Balcer in 1988 in |
| 00:00:13,418 --> 00:00:16,760 | an article to the peer [UNKNOWN] communication of the ACM. |
| 00:00:16,760 --> 00:00:19,490 | So this is a method for going from a specification, |
| 00:00:19,490 --> 00:00:21,370 | a description of the system, to a set of test |
| 00:00:21,370 --> 00:00:26,170 | cases like any other black-box testing approach by following six steps. |
| 00:00:26,170 --> 00:00:28,370 | So let's look at what these steps are. The first |
| 00:00:28,370 --> 00:00:31,850 | step is to identify independently testable features and this is |
| 00:00:31,850 --> 00:00:33,870 | a step that we are familiar with because its exactly |
| 00:00:33,870 --> 00:00:36,950 | the same step that we performed in the generic black box |
| 00:00:36,950 --> 00:00:39,480 | testing approach that we just discussed. The second step is |
| 00:00:39,480 --> 00:00:42,250 | to identify categories. Then the next step is to partition |
| 00:00:42,250 --> 00:00:45,070 | categories into choices. Identify constraints |
| 00:00:45,070 --> 00:00:47,530 | among choices. Produce and evaluate |
| 00:00:47,530 --> 00:00:51,330 | test case specifications. And finally, the sixth step is to generate |
| 00:00:51,330 --> 00:00:54,100 | test cases from test case specifications. So two of |
| 00:00:54,100 --> 00:00:56,970 | the key elements in these six steps are the two |
| 00:00:56,970 --> 00:00:59,430 | that give the name to the technique so the identification |
| 00:00:59,430 --> 00:01:02,240 | of the categories and the partition of these categories into |
| 00:01:02,240 --> 00:01:04,810 | choices. What we're going to do next is to go |
| 00:01:04,810 --> 00:01:07,670 | and look at each one of the steps independently, except |
| 00:01:07,670 --> 00:01:10,285 | for the first one. Because we're already familiar with that |
| 00:01:10,285 --> 00:01:10,285 | step, and this method doesn't really add much to it. |