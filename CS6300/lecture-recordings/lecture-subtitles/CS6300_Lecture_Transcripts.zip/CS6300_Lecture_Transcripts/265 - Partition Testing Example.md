# CS6300 265 - Partition Testing Example

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:02,969 | So let's look at how this will work with an example. |
| 00:00:02,969 --> 00:00:06,210 | I'm going to use this simple program that takes two inputs. The |
| 00:00:06,210 --> 00:00:08,790 | first input is a string, str, and the second one is |
| 00:00:08,790 --> 00:00:11,575 | an integer, size. And the problem is called split. And as |
| 00:00:11,575 --> 00:00:14,363 | the name says what it does is to take this string, |
| 00:00:14,363 --> 00:00:17,491 | str, and split it into sub string, into chunks of size |
| 00:00:17,491 --> 00:00:21,550 | characters each. So how do we identify some possible partitions for |
| 00:00:21,550 --> 00:00:25,620 | this program? If we consider the input size, we can identify |
| 00:00:25,620 --> 00:00:29,630 | three neutral partitions which are size less than 0. For example, |
| 00:00:29,630 --> 00:00:32,259 | we want to test how the program behaves. But if we pass an |
| 00:00:32,259 --> 00:00:36,100 | incorrect size, size equal to 0, which is also a partition. In |
| 00:00:36,100 --> 00:00:39,390 | this case, a partition with a single element. And the third case |
| 00:00:39,390 --> 00:00:42,540 | is size greater than 0, which I will consider to be |
| 00:00:42,540 --> 00:00:44,960 | kind of the standard case. And actually let me do a, you |
| 00:00:44,960 --> 00:00:48,220 | know, slight aggression so when I was talking about designer bias. So |
| 00:00:48,220 --> 00:00:50,630 | this is a case in which designer bias might not make you |
| 00:00:50,630 --> 00:00:53,050 | think of using size less than 0 because you read the |
| 00:00:53,050 --> 00:00:56,210 | spec. And you sort of assume that the size will be positive. |
| 00:00:56,210 --> 00:00:58,556 | Whereas the right thing to do when we test is to consider |
| 00:00:58,556 --> 00:01:01,700 | the complete domain rather than just parts of it. So now let's |
| 00:01:01,700 --> 00:01:04,760 | look at string, str, and let's see what kind of sub |
| 00:01:04,760 --> 00:01:06,538 | domains we could identify for this |
| 00:01:06,538 --> 00:01:08,670 | parameter. And notice another important aspect |
| 00:01:08,670 --> 00:01:12,290 | here is that we treat each different part of the input independently, |
| 00:01:12,290 --> 00:01:15,760 | which also helps breaking down the problem. One interesting sub domain is |
| 00:01:15,760 --> 00:01:18,980 | the domain that includes all the strings whose length is less than |
| 00:01:18,980 --> 00:01:22,310 | size. So all the strings that will not be displayed. Another subdomain |
| 00:01:22,310 --> 00:01:25,000 | is all the strings with length which is between the value of |
| 00:01:25,000 --> 00:01:28,350 | size and twice the value of size. A third subdomain is the one |
| 00:01:28,350 --> 00:01:31,820 | including all the strings whose length is greater than twice the value |
| 00:01:31,820 --> 00:01:35,140 | of size. And we can continue and identify more and more subdomain. |
| 00:01:35,140 --> 00:01:38,350 | The key thing here is that we have to do that based |
| 00:01:38,350 --> 00:01:41,180 | on the domain. So we need to adapt what we just did here |
| 00:01:41,180 --> 00:01:44,620 | based on, on the specific domain involved and on the type |
| 00:01:44,620 --> 00:01:47,190 | of data in this domain. So at this point we said that |
| 00:01:47,190 --> 00:01:49,630 | there were two steps. One was to identify the subdomains and |
| 00:01:49,630 --> 00:01:52,990 | the second one was to pick values in this subdomain. The values |
| 00:01:52,990 --> 00:01:55,320 | that we'll actually use for the testing. In this case, we |
| 00:01:55,320 --> 00:01:58,218 | do not want to just pick any value. Rather we want to |
| 00:01:58,218 --> 00:01:59,871 | pick values that are particularly |
| 00:01:59,871 --> 00:02:02,710 | interesting, particularly representative. So what does |
| 00:02:02,710 --> 00:02:02,710 | that mean? Well, we're going to do that based on an intuitive idea. |