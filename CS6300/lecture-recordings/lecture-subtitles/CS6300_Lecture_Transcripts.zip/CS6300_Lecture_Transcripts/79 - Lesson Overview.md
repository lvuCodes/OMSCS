# CS6300 79 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,340 --> 00:00:05,670 | Hello and welcome to the second part of our software engineering course. In the |
| 00:00:05,670 --> 00:00:09,030 | previous mini-course, we discussed some basic principles |
| 00:00:09,030 --> 00:00:12,430 | behind software engineering. We provided an overview of |
| 00:00:12,430 --> 00:00:15,790 | several software process models and we introduced |
| 00:00:15,790 --> 00:00:18,530 | some important tools that can help developers |
| 00:00:18,530 --> 00:00:21,363 | increase their productivity. In this mini-course, we |
| 00:00:21,363 --> 00:00:25,740 | will focus on requirement and prototyping. More precisely, |
| 00:00:25,740 --> 00:00:28,840 | we will discuss in depth requirements |
| 00:00:28,840 --> 00:00:32,400 | engineering activities. We will also discuss |
| 00:00:32,400 --> 00:00:34,950 | techniques to perform a system analysis |
| 00:00:34,950 --> 00:00:38,720 | and design in an object-oriented fashion. So, |
| 00:00:38,720 --> 00:00:42,250 | let's start the first lesson of this mini-course, which is about the use |
| 00:00:42,250 --> 00:00:45,230 | of engineering techniques to understand and |
| 00:00:45,230 --> 00:00:45,230 | specify the purpose of a software system. |