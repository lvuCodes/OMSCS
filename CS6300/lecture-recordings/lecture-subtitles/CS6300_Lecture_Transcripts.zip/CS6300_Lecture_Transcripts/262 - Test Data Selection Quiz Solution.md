# CS6300 262 - Test Data Selection Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,025 --> 00:00:02,900 | Okay, so now we're going to answer the question. So if we want |
| 00:00:02,900 --> 00:00:06,520 | to consider all these inputs, and run them all on the software, |
| 00:00:06,520 --> 00:00:09,490 | let's see how it will work. Let's assume that these are, 32 |
| 00:00:09,490 --> 00:00:12,280 | bit integers. So at this point what we will have is, a |
| 00:00:12,280 --> 00:00:15,130 | number of combination, which is 2 to the 32, times 2 to |
| 00:00:15,130 --> 00:00:18,390 | the 32. They're two integers. This is equal to 2 to the |
| 00:00:18,390 --> 00:00:21,910 | 64, which in turn, is more or less equal, to 10 to |
| 00:00:21,910 --> 00:00:25,110 | the 19. So 10 to the 19 is the number of tests that |
| 00:00:25,110 --> 00:00:27,960 | we need to run to cover the whole domain. Now let's assume |
| 00:00:27,960 --> 00:00:31,400 | that we can run one test per nanosecond. So what that means |
| 00:00:31,400 --> 00:00:34,290 | is that we can run 10 to the 9 tests per second, |
| 00:00:34,290 --> 00:00:37,240 | and that's a lot. If we do the math, that results in 10 |
| 00:00:37,240 --> 00:00:40,750 | to the 10 seconds over all, because we have 10 to the |
| 00:00:40,750 --> 00:00:43,760 | 19 tests, we could run 10 to the 9 tests per second |
| 00:00:43,760 --> 00:00:46,630 | so, we do the math, and we can run all these tests |
| 00:00:46,630 --> 00:00:50,340 | in 10 to the 10 seconds. And what that corresponds to, it's about |
| 00:00:50,340 --> 00:00:54,470 | 600 years, so a lot of time. So even for such |
| 00:00:54,470 --> 00:00:57,710 | a simple problem, a problem that takes two integers and adds them, |
| 00:00:57,710 --> 00:01:00,990 | it will take more than 500 years to test it exhaustively. So |
| 00:01:00,990 --> 00:01:00,990 | the bottom line here is that we just can't do exhaustive testing. |