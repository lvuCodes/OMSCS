# CS6300 109 - Requirements Prioritization Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,130 --> 00:00:02,640 | Looking at the requirements, and knowing that we have only two |
| 00:00:02,640 --> 00:00:05,630 | that we can satisfy for sure, it makes sense to first mark |
| 00:00:05,630 --> 00:00:09,080 | as mandatory the ability to withdraw cash, which is the most typical |
| 00:00:09,080 --> 00:00:12,650 | use of an ATM machine. We are therefore going to mark this requirement |
| 00:00:12,650 --> 00:00:15,260 | with an M, for mandatory. It also makes sense to mark as |
| 00:00:15,260 --> 00:00:18,390 | mandatory the fact that the ATM system checks the PIN of the |
| 00:00:18,390 --> 00:00:21,480 | card being used by the customer, as that's the typical level of |
| 00:00:21,480 --> 00:00:23,680 | security that the customer would expect, |
| 00:00:23,680 --> 00:00:25,760 | therefore we're going to mark as mandatory |
| 00:00:25,760 --> 00:00:28,320 | also the first requirement here. And of course we |
| 00:00:28,320 --> 00:00:31,930 | could also perform biometric verification, but based on our knowledge |
| 00:00:31,930 --> 00:00:33,640 | of the domain, it seems like that should be |
| 00:00:33,640 --> 00:00:37,410 | an additional verification, rather than the main and only verification |
| 00:00:37,410 --> 00:00:40,170 | for the system. We will therefore mark it superfluous. |
| 00:00:40,170 --> 00:00:42,720 | That is something that we can postpone until a later |
| 00:00:42,720 --> 00:00:45,100 | release, the second requirement. Finally, |
| 00:00:45,100 --> 00:00:46,740 | another typical operation that customers |
| 00:00:46,740 --> 00:00:51,070 | perform at ATM machines is depositing. Whereas changing an ATM |
| 00:00:51,070 --> 00:00:53,850 | card's PIN is not such a common operation. We'll therefore mark |
| 00:00:53,850 --> 00:00:57,710 | it nice to have this fourth requirement and as superfluous, the |
| 00:00:57,710 --> 00:01:00,420 | last one. So at the end, what we have is that |
| 00:01:00,420 --> 00:01:03,540 | we have two mandatory requirements which are the two that we can |
| 00:01:03,540 --> 00:01:06,280 | satisfy for sure. One, nice to have the requirement, which is |
| 00:01:06,280 --> 00:01:09,960 | the possible third requirement which we might have time to satisfy. And |
| 00:01:09,960 --> 00:01:12,980 | the other two that are marked as superfluous, as something that |
| 00:01:12,980 --> 00:01:16,100 | we might do later, for example in a subsequent release. And of |
| 00:01:16,100 --> 00:01:19,060 | course there is something subjective in these answers. But |
| 00:01:19,060 --> 00:01:22,020 | again, based on our knowledge on our understanding of |
| 00:01:22,020 --> 00:01:23,910 | the domain, these are the one that makes more |
| 00:01:23,910 --> 00:01:23,910 | sense for an ATM system as we know it. |