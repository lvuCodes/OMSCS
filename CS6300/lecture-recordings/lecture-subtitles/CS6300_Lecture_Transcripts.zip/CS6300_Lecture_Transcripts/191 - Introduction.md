# CS6300 191 - Introduction

| Timestamp | Content |
|-----------|---------|
| 00:00:00,430 --> 00:00:05,994 | Hello and welcome to a tale of analysis and design, featuring |
| 00:00:05,994 --> 00:00:10,809 | Spencer Rugaber, as the librarian, and Alex Orso, |
| 00:00:10,809 --> 00:00:15,779 | as the software engineer. [SOUND] |
| 00:00:15,779 --> 00:00:21,520 | >> Hi! I'm here waiting for Spencer, my librarian friend. He needs some |
| 00:00:21,520 --> 00:00:25,470 | help developing an information system for a library. So I asked him to write |
| 00:00:25,470 --> 00:00:29,669 | down the requirements for the libra... Oh, [SOUND] that must be him. |
| 00:00:29,669 --> 00:00:30,850 | >> Hello Alex. |
| 00:00:30,850 --> 00:00:32,470 | >> Hey Spencer. How's it going? |
| 00:00:32,470 --> 00:00:34,690 | >> Good. Did you get those requirements I emailed you? |
| 00:00:34,690 --> 00:00:36,890 | >> Oh, you emailed them. Now let me check. |
| 00:00:36,890 --> 00:00:38,780 | And, by the way, get some coffee for you here. |
| 00:00:38,780 --> 00:00:41,840 | >> Thank you very much. |
| 00:00:41,840 --> 00:00:46,790 | >> Oh yeah. They're right here. Let me see. Oh, good. Oh, yeah, |
| 00:00:46,790 --> 00:00:50,580 | good. We have, what we need. So the, the way I like to do |
| 00:00:50,580 --> 00:00:52,500 | this is. I like to start by |
| 00:00:52,500 --> 00:00:55,430 | looking at the requirements and identifying the nouns |
| 00:00:55,430 --> 00:00:57,530 | in the requirements, because those tell us |
| 00:00:57,530 --> 00:01:00,080 | the kind of the relevant elements in the, |
| 00:01:00,080 --> 00:01:03,360 | in the requirements. So if you don't mind we can start looking at those and |
| 00:01:03,360 --> 00:01:07,070 | you can tell me you know, whether the ones that I am identifying make sense or not. |
| 00:01:07,070 --> 00:01:07,920 | >> Sounds good. |
| 00:01:07,920 --> 00:01:07,920 | >> All right. |