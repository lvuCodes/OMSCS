# CS6300 84 - Identifying Purpose

| Timestamp | Content |
|-----------|---------|
| 00:00:00,050 --> 00:00:03,480 | And identifying the purpose of a softer system means |
| 00:00:03,480 --> 00:00:06,980 | defining the requirements for the system. And if you have |
| 00:00:06,980 --> 00:00:09,540 | ever done anything like that, for example, we did |
| 00:00:09,540 --> 00:00:12,060 | it for the first project in the previous mini course, |
| 00:00:12,060 --> 00:00:14,720 | you will know that it is an extremely hard |
| 00:00:14,720 --> 00:00:17,760 | task. Identifying the purpose of the software and defining its |
| 00:00:17,760 --> 00:00:21,600 | requirements is very, very hard. Why is it so hard? |
| 00:00:21,600 --> 00:00:25,560 | First of all, the purpose of most systems is inherently, |
| 00:00:25,560 --> 00:00:27,920 | extremely complex, so this has to do with the |
| 00:00:27,920 --> 00:00:31,330 | sheer complexity of the purpose of the requirements. Just think |
| 00:00:31,330 --> 00:00:34,810 | of how complex is the functionality provided by most systems. |
| 00:00:34,810 --> 00:00:38,790 | Second, it is hard, very hard to extract from humans |
| 00:00:38,790 --> 00:00:41,780 | this purpose and make it explicit. So, paraphrasing a |
| 00:00:41,780 --> 00:00:45,130 | famous quote from the late Steve Jobs, often people don't |
| 00:00:45,130 --> 00:00:47,475 | know what they want until you show it to them. |
| 00:00:47,475 --> 00:00:50,490 | It's hard to figure out what people really want. Third, |
| 00:00:50,490 --> 00:00:54,260 | requirements often change over time. Customers change their |
| 00:00:54,260 --> 00:00:57,490 | mind. Designing and building a system raises new requirements. |
| 00:00:57,490 --> 00:01:00,270 | So for many reasons requirements tend not to |
| 00:01:00,270 --> 00:01:02,760 | be stable, tend to evolve. And that, of course, |
| 00:01:02,760 --> 00:01:05,440 | makes it harder to collect them. Finally, for |
| 00:01:05,440 --> 00:01:09,600 | any realistic system, there are many stakeholders and they |
| 00:01:09,600 --> 00:01:12,990 | often have conflicting goals and requirements. And it |
| 00:01:12,990 --> 00:01:15,900 | can be very hard to reconcile the possibly conflicting |
| 00:01:15,900 --> 00:01:19,630 | requirements that might emerge in these cases. So for all these reasons, |
| 00:01:19,630 --> 00:01:21,230 | it is very, very difficult to |
| 00:01:21,230 --> 00:01:21,230 | perform requirements engineering in an effective way. |