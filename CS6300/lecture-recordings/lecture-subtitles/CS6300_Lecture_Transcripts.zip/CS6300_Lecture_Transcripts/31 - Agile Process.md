# CS6300 31 - Agile Process

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:02,300 | The next type of software process models that I |
| 00:00:02,300 --> 00:00:06,300 | want to discuss are Agile Software Development Processes. And this |
| 00:00:06,300 --> 00:00:08,470 | is a group of software development methods that are |
| 00:00:08,470 --> 00:00:12,620 | based on highly iterative and incremental development. And in particular, |
| 00:00:12,620 --> 00:00:16,000 | I'm going to discuss Test Driven Development or TDD. The |
| 00:00:16,000 --> 00:00:18,490 | space on the iteration of three main phases. In |
| 00:00:18,490 --> 00:00:20,970 | the first one that we mark as red, we |
| 00:00:20,970 --> 00:00:25,350 | write test cases that encode our requirements, and for which |
| 00:00:25,350 --> 00:00:29,180 | we haven't written code yet. And therefore, they will fail, obviously. |
| 00:00:29,180 --> 00:00:31,800 | So we're in this sort of red or fail phase. From |
| 00:00:31,800 --> 00:00:34,830 | this phase, we move to this phase, in which after we |
| 00:00:34,830 --> 00:00:37,970 | write the just enough code to make the test cases pass. |
| 00:00:37,970 --> 00:00:40,670 | We have a set of test cases that are all passing. |
| 00:00:40,670 --> 00:00:43,810 | And therefore, we can consider this as the green phase. We |
| 00:00:43,810 --> 00:00:46,930 | had enough code to make the test cases pass because the |
| 00:00:46,930 --> 00:00:50,520 | test cases encode our requirements. We have just written enough code to |
| 00:00:50,520 --> 00:00:53,940 | satisfy our requirements. When we do this over time though, |
| 00:00:53,940 --> 00:00:57,080 | what happens is that the structure of the code deteriorates, because |
| 00:00:57,080 --> 00:00:59,100 | we keep adding pieces. So that's why we have the |
| 00:00:59,100 --> 00:01:02,540 | first step, which is refactoring. In this step, we modify the |
| 00:01:02,540 --> 00:01:05,724 | code, and we will talk about refactoring extensively. We'll devote |
| 00:01:05,724 --> 00:01:08,190 | one lesson to it. We modify the code to make it |
| 00:01:08,190 --> 00:01:12,650 | more readable, more maintainable. In general, we modify to improve the |
| 00:01:12,650 --> 00:01:15,560 | design of the code. And after this phase, we will go |
| 00:01:15,560 --> 00:01:17,670 | back to writing more test cases for |
| 00:01:17,670 --> 00:01:19,730 | new requirements, write code that makes these |
| 00:01:19,730 --> 00:01:24,870 | test cases pass, and so on. So we'll continue to iterate among these phases. And |
| 00:01:24,870 --> 00:01:26,500 | also, in this case, we will talk |
| 00:01:26,500 --> 00:01:29,390 | about Agile Software Processes. And in particular, |
| 00:01:29,390 --> 00:01:32,250 | about extreme programming, or XP, and Scrum |
| 00:01:32,250 --> 00:01:32,250 | in more details, in minor course number four. |