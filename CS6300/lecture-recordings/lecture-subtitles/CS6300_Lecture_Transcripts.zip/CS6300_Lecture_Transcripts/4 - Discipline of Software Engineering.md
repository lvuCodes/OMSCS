# CS6300 4 - Discipline of Software Engineering

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,469 | And even if we don't go to these extreme examples, I'm |
| 00:00:02,469 --> 00:00:04,380 | sure that you have all experienced |
| 00:00:04,380 --> 00:00:06,540 | software problems, typically manifested in what |
| 00:00:06,540 --> 00:00:09,630 | we call a crash. And that crash might happen while you're |
| 00:00:09,630 --> 00:00:13,230 | finishing your homework or that three-page long email that you were preparing |
| 00:00:13,230 --> 00:00:15,900 | for the last two hours. But why's it so difficult to |
| 00:00:15,900 --> 00:00:20,220 | build software, or better, why's it so difficult to build good software? |
| 00:00:20,220 --> 00:00:22,200 | And how can we do it? This is exactly the topic |
| 00:00:22,200 --> 00:00:25,190 | of this class. And the reason why software engineering is a fundamental |
| 00:00:25,190 --> 00:00:28,330 | discipline in computer science. To motivate that, in this class, we |
| 00:00:28,330 --> 00:00:32,259 | will study a set of methodologies, techniques, and tools, that will help |
| 00:00:32,259 --> 00:00:35,150 | us build high quality software that does what it's supposed to |
| 00:00:35,150 --> 00:00:38,540 | do. And therefore, makes our customers happy. And that does it within |
| 00:00:38,540 --> 00:00:42,375 | the given time and money constraints. So within the budget that |
| 00:00:42,375 --> 00:00:44,300 | is allocated for the software. Before |
| 00:00:44,300 --> 00:00:46,222 | jumping into today's software engineering techniques |
| 00:00:46,222 --> 00:00:48,010 | though, let me take a step back and look at how |
| 00:00:48,010 --> 00:00:50,240 | we got here, as I believe it is very important to have |
| 00:00:50,240 --> 00:00:52,690 | some historical perspective on how this discipline was |
| 00:00:52,690 --> 00:00:52,690 | born and how it was developed over the years. |