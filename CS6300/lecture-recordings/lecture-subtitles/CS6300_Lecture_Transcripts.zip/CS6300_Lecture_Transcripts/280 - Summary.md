# CS6300 280 - Summary

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:01,600 | Now we are at the end of this lesson, and I |
| 00:00:01,600 --> 00:00:04,450 | just want to wrap it up by summarizing what we've seen. We talked |
| 00:00:04,450 --> 00:00:06,340 | about black-box testing, the testing of |
| 00:00:06,340 --> 00:00:08,760 | software based on a functional specification, |
| 00:00:08,760 --> 00:00:11,510 | a description of the software rather than its code. We saw a |
| 00:00:11,510 --> 00:00:15,500 | systematic way of doing that, that allows for breaking down the problem |
| 00:00:15,500 --> 00:00:19,140 | of testing software, so the problem of going from this functional specification |
| 00:00:19,140 --> 00:00:22,540 | to a set of test cases into smaller steps, more manageable steps. |
| 00:00:22,540 --> 00:00:25,466 | And we saw two main ways of doing this. One by identifying |
| 00:00:25,466 --> 00:00:28,304 | relevant inputs for the main features in the system |
| 00:00:28,304 --> 00:00:31,802 | and then deriving test case specifications and test cases from |
| 00:00:31,802 --> 00:00:34,180 | this set of inputs. And the second way by |
| 00:00:34,180 --> 00:00:36,780 | building a model for the main features of the system |
| 00:00:36,780 --> 00:00:39,210 | and then using this model to decide how to |
| 00:00:39,210 --> 00:00:41,680 | test the system. In the next lesson, we are going |
| 00:00:41,680 --> 00:00:44,440 | to discuss, how to do testing by looking inside the |
| 00:00:44,440 --> 00:00:44,440 | box? So, how to do testing in a white-box fashion. |