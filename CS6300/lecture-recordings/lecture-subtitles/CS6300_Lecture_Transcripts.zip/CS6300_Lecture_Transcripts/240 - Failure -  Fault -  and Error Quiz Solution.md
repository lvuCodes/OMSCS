# CS6300 240 - Failure -  Fault -  and Error Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,190 --> 00:00:02,404 | Before telling you what the right answer is, let |
| 00:00:02,404 --> 00:00:04,240 | me remind you that the fault is related to |
| 00:00:04,240 --> 00:00:06,508 | the code, and is a necessary, but not sufficient |
| 00:00:06,508 --> 00:00:09,560 | condition for the occurrence of a failure. So in this |
| 00:00:09,560 --> 00:00:12,450 | case, a single faulty line is responsible for the |
| 00:00:12,450 --> 00:00:17,435 | failure, which is line three. So the correct answer, is |
| 00:00:17,435 --> 00:00:20,700 | three. At line three, the program computes i times |
| 00:00:20,700 --> 00:00:20,700 | i, instead of i times 2, as it should do. |