# CS6300 323 - On Site Customer

| Timestamp | Content |
|-----------|---------|
| 00:00:00,060 --> 00:00:03,500 | The last practice I want to mention is on-site customer, and what |
| 00:00:03,500 --> 00:00:07,590 | that means is that literally the customer is an actual member of |
| 00:00:07,590 --> 00:00:10,310 | the team. So the customer will sit with the team and will |
| 00:00:10,310 --> 00:00:13,546 | bring requirements to the team and discuss the requirements with them. So |
| 00:00:13,546 --> 00:00:16,461 | the typical objection to this practice is the fact that it's just |
| 00:00:16,461 --> 00:00:19,640 | impossible in the real world. There is no way that the customer |
| 00:00:19,640 --> 00:00:22,550 | can have one person staying with the team all the time, and |
| 00:00:22,550 --> 00:00:25,130 | the answer to that objection is that if the system is not |
| 00:00:25,130 --> 00:00:28,700 | worth the time of one customer then maybe the system is not worth building. In |
| 00:00:28,700 --> 00:00:30,530 | other words, if you're investing tons of |
| 00:00:30,530 --> 00:00:33,440 | dollars, tons of money in building a system, |
| 00:00:33,440 --> 00:00:36,870 | you might just as well invest a little more and have one of the people |
| 00:00:36,870 --> 00:00:39,080 | in the customer's organization stay with the |
| 00:00:39,080 --> 00:00:39,080 | team and be involved in the whole process. |