# CS6300 44 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,650 --> 00:00:07,470 | Hi, and welcome to the first of several lessons on tools of the trade. I'm |
| 00:00:07,470 --> 00:00:12,200 | very excited about these lessons, because I believe that tools are a cornerstone |
| 00:00:12,200 --> 00:00:14,390 | of the software engineering discipline, and it |
| 00:00:14,390 --> 00:00:17,570 | is of paramount importance to know and |
| 00:00:17,570 --> 00:00:20,330 | use them. In this lesson, we will |
| 00:00:20,330 --> 00:00:25,530 | talk about integrated development environments, normally called IDEs. |
| 00:00:25,530 --> 00:00:29,780 | And these are software applications that support developers in many of their |
| 00:00:29,780 --> 00:00:36,870 | everyday tasks, such as writing, compiling, and debugging code. And to make the |
| 00:00:36,870 --> 00:00:42,470 | discussion more concrete we will focus on a specific IDE, Eclipse. We will |
| 00:00:42,470 --> 00:00:42,470 | first present Eclipse, and then get some hands-on experience through a demo. |