# CS6300 259 - Overview Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,190 --> 00:00:03,030 | In this case there's not really a right answer because there's |
| 00:00:03,030 --> 00:00:05,750 | many, many features that you could identify in a piece of |
| 00:00:05,750 --> 00:00:08,655 | software as complex as a, a spreadsheet. So I'm just going |
| 00:00:08,655 --> 00:00:11,900 | to give you three examples. So one could be the cell merging |
| 00:00:11,900 --> 00:00:14,950 | operation. So the operation in which we merge two cells in |
| 00:00:14,950 --> 00:00:18,550 | the spreadsheet. Another example could be chart creation, so I might want |
| 00:00:18,550 --> 00:00:21,370 | to test the feature that allows you to create charts in |
| 00:00:21,370 --> 00:00:23,310 | your spreadsheets. Yet another example could |
| 00:00:23,310 --> 00:00:25,540 | be the test of statistical functions, |
| 00:00:25,540 --> 00:00:29,350 | so the function that allows you to do various statistical calculations on |
| 00:00:29,350 --> 00:00:32,650 | the numbers in your cells. And as I said there's many, many |
| 00:00:32,650 --> 00:00:35,900 | more example that we could use. But the key thing I want |
| 00:00:35,900 --> 00:00:38,770 | to convey here is the fact that there is no way you |
| 00:00:38,770 --> 00:00:42,020 | can look at a spreadsheet with all the functionality that it provides |
| 00:00:42,020 --> 00:00:44,160 | and just go and test it. The first step, what you need |
| 00:00:44,160 --> 00:00:47,430 | to do first, is to identify which ones are the pieces of |
| 00:00:47,430 --> 00:00:50,620 | functionality that I can test individually. So that's why this is the |
| 00:00:50,620 --> 00:00:50,620 | first step in black-box testing. |