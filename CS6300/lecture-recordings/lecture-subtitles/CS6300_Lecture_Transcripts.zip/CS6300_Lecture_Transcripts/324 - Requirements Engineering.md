# CS6300 324 - Requirements Engineering

| Timestamp | Content |
|-----------|---------|
| 00:00:00,210 --> 00:00:02,680 | Now that we saw what the main values and practices |
| 00:00:02,680 --> 00:00:05,200 | of XP are, I want to go back for a minute |
| 00:00:05,200 --> 00:00:08,800 | to discussion of requirements engineering in XP. In XP, user |
| 00:00:08,800 --> 00:00:12,180 | requirements are expressed as scenarios or user stories, as we already |
| 00:00:12,180 --> 00:00:15,500 | discussed. These are written by customers on cards, and what |
| 00:00:15,500 --> 00:00:18,550 | the development team does is to take these cards, take these |
| 00:00:18,550 --> 00:00:22,240 | users stories and break them down into implementation tasks. And |
| 00:00:22,240 --> 00:00:25,310 | those implementation tasks are then used as a basis for scheduling |
| 00:00:25,310 --> 00:00:29,210 | cost estimates. So given these estimates, and based on their priorities, |
| 00:00:29,210 --> 00:00:31,770 | the customer will choose the stories that will be included in |
| 00:00:31,770 --> 00:00:34,980 | the next release, in the next iteration. And at this point, |
| 00:00:34,980 --> 00:00:39,220 | the corresponding cards will be taken by the developers and the, |
| 00:00:39,220 --> 00:00:42,380 | the task will be performed, and the relative, and the corresponding |
| 00:00:42,380 --> 00:00:44,350 | card will be developed. And just to give an idea of |
| 00:00:44,350 --> 00:00:47,330 | the order of magnitude, if you consider a few months project, |
| 00:00:47,330 --> 00:00:50,390 | there might be 50 to 100 user stories for a project of |
| 00:00:50,390 --> 00:00:52,820 | that duration. So, now let me give you an example of what |
| 00:00:52,820 --> 00:00:55,630 | the story card might look like, and I'm going to do it using |
| 00:00:55,630 --> 00:00:58,930 | a story card for document downloading and you can really do all of |
| 00:00:58,930 --> 00:01:00,780 | this, basically as seeing what the |
| 00:01:00,780 --> 00:01:03,440 | scenario is, downloading and printing an article. |
| 00:01:03,440 --> 00:01:06,590 | And it describes basically what happens when you do that, what is |
| 00:01:06,590 --> 00:01:09,530 | the scenario. First, you select the article that you want from a displayed |
| 00:01:09,530 --> 00:01:12,760 | list. You then have to tell the system how you will pay for |
| 00:01:12,760 --> 00:01:15,680 | it. This can either be through a subscription, through a company account or |
| 00:01:15,680 --> 00:01:18,670 | by credit card, and so on. So what developers do, they take |
| 00:01:18,670 --> 00:01:22,020 | this story card, and they break it down in to development tasks. |
| 00:01:22,020 --> 00:01:25,100 | So, here I'm showing you some examples of task cards for the |
| 00:01:25,100 --> 00:01:28,360 | user story that we just saw. In particular I'm showing three task cards |
| 00:01:28,360 --> 00:01:30,740 | and if we look at the third one, there is a name |
| 00:01:30,740 --> 00:01:34,260 | for the task, which is implement payment collection. So this is the development |
| 00:01:34,260 --> 00:01:37,600 | task that we have the perform and here, there's a description of |
| 00:01:37,600 --> 00:01:41,240 | what that developed code should do. And notice that, you know, the task |
| 00:01:41,240 --> 00:01:44,400 | card can even be more. explicit than this, more |
| 00:01:44,400 --> 00:01:44,400 | specific than this, and talk about actual development tasks. |