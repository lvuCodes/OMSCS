# CS6300 254 - Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,450 --> 00:00:03,400 | As we said at the end of the previous lesson, black-box testing is |
| 00:00:03,400 --> 00:00:06,230 | the testing of the software when we look at it as a black box, |
| 00:00:06,230 --> 00:00:09,110 | as a closed box, without looking at it inside, without looking at the |
| 00:00:09,110 --> 00:00:10,750 | code. And there are several advantages in |
| 00:00:10,750 --> 00:00:12,680 | using black-box testing. So let me recap |
| 00:00:12,680 --> 00:00:15,590 | those advantages, some of which we already mentioned, and let me also expand |
| 00:00:15,590 --> 00:00:18,220 | on that a little bit. The first advantage of when I mentioned is that |
| 00:00:18,220 --> 00:00:22,760 | black box focuses on the domain, on the input domain of the software. And |
| 00:00:22,760 --> 00:00:25,750 | as such, we can use it to make sure that we are actually covering |
| 00:00:25,750 --> 00:00:28,400 | this domain, that we are actually covering the important behaviors of |
| 00:00:28,400 --> 00:00:32,200 | the software. A second advantage is that black box testing does not |
| 00:00:32,200 --> 00:00:35,402 | need the code. What that means is that you can perform early |
| 00:00:35,402 --> 00:00:38,801 | test design. So you can start designing and writing your test cases, |
| 00:00:38,801 --> 00:00:41,423 | even before writing your code, so that when the code is |
| 00:00:41,423 --> 00:00:44,520 | ready, we can test it right away. And that helps prevent a |
| 00:00:44,520 --> 00:00:48,054 | problem that is very typical in real life software development, which is |
| 00:00:48,054 --> 00:00:50,790 | getting an idea of the project and having no time to create |
| 00:00:50,790 --> 00:00:53,040 | the tests. In this way, we already have the tests, so |
| 00:00:53,040 --> 00:00:56,170 | we just have to run them. Another advantage is that black-box testing |
| 00:00:56,170 --> 00:00:59,530 | can catch logic defects, because it focuses on the description of what |
| 00:00:59,530 --> 00:01:02,440 | the software should do, and therefore on its logic. If we derive |
| 00:01:02,440 --> 00:01:05,250 | test cases from such description, then we can catch these kind of |
| 00:01:05,250 --> 00:01:07,510 | problems. And finally, black-box testing is |
| 00:01:07,510 --> 00:01:09,900 | applicable at all granularity levels, which |
| 00:01:09,900 --> 00:01:13,490 | means that we can use black-box testing in unit testing, integration testing, |
| 00:01:13,490 --> 00:01:13,490 | system testing, and so on. We can use it at all levels. |