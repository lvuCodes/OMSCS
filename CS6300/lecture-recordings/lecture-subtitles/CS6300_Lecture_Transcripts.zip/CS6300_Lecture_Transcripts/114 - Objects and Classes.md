# CS6300 114 - Objects and Classes

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:02,770 | Let's start with objects. An object is a |
| 00:00:02,770 --> 00:00:06,330 | computing unit organized around a collection of state |
| 00:00:06,330 --> 00:00:09,350 | or instance variables that define the state of |
| 00:00:09,350 --> 00:00:12,390 | the object. In addition, each object has associated |
| 00:00:12,390 --> 00:00:15,150 | with it a set operations or methods that |
| 00:00:15,150 --> 00:00:17,850 | operate on such state. So what that means |
| 00:00:17,850 --> 00:00:21,420 | is that operations and methods read and write |
| 00:00:21,420 --> 00:00:25,210 | instance variables. And in traditional object orientation, we say |
| 00:00:25,210 --> 00:00:28,240 | that operations are invoked by sending a message |
| 00:00:28,240 --> 00:00:30,520 | to the appropriate object, which is what we call |
| 00:00:30,520 --> 00:00:33,660 | normally a method implication. So now that we define |
| 00:00:33,660 --> 00:00:37,590 | what an object is, state variables, or attributes, and |
| 00:00:37,590 --> 00:00:41,440 | operations or methods, let's see what a class is. |
| 00:00:41,440 --> 00:00:44,900 | A class is basically a template. A blueprint, if |
| 00:00:44,900 --> 00:00:47,700 | you wish, from which new objects, which is what |
| 00:00:47,700 --> 00:00:50,655 | we call instances of the class can be created. |
| 00:00:50,655 --> 00:00:52,800 | And notice that the fact of having a blueprint for |
| 00:00:52,800 --> 00:00:55,610 | objects that allows us to create as many objects as |
| 00:00:55,610 --> 00:00:58,390 | we want can further reuse, and also contribute to make |
| 00:00:58,390 --> 00:01:00,300 | the code more readable, understandable, |
| 00:01:00,300 --> 00:01:00,300 | and therefore ultimately more maintainable. |