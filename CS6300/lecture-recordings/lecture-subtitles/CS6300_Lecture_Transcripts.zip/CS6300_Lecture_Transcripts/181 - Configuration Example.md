# CS6300 181 - Configuration Example

| Timestamp | Content |
|-----------|---------|
| 00:00:00,180 --> 00:00:02,880 | What I'm showing here is what an architectural configuration of |
| 00:00:02,880 --> 00:00:05,460 | a system might look like in practice. And as you |
| 00:00:05,460 --> 00:00:08,560 | can see, the configuration includes a set of components, which |
| 00:00:08,560 --> 00:00:12,200 | are these rectangles over here. The components have various kinds of |
| 00:00:12,200 --> 00:00:15,460 | ports, which are the ones marked here on the components |
| 00:00:15,460 --> 00:00:17,760 | with different graphical representations. And |
| 00:00:17,760 --> 00:00:19,760 | the components communicate through various |
| 00:00:19,760 --> 00:00:22,860 | types of connectors, which are the grey elements here which |
| 00:00:22,860 --> 00:00:25,570 | as you can see are used to connect the different components. |
| 00:00:25,570 --> 00:00:28,180 | And something else that you can notice by looking at |
| 00:00:28,180 --> 00:00:30,720 | this configuration is the fact that you can also have |
| 00:00:30,720 --> 00:00:34,980 | hierarchically decomposable components. For example, if you look at the strategy |
| 00:00:34,980 --> 00:00:39,250 | analyzer component, you can see that it has three subcomponents: one, |
| 00:00:39,250 --> 00:00:42,110 | two, and three and two internal connectors as part of |
| 00:00:42,110 --> 00:00:44,832 | it. And it is worth recalling here that a component |
| 00:00:44,832 --> 00:00:47,152 | diagram as we said when first discussed in UML in |
| 00:00:47,152 --> 00:00:51,230 | the course, can also be used to represent an architectural configuration. |
| 00:00:51,230 --> 00:00:52,920 | So sometimes you will see architectural |
| 00:00:52,920 --> 00:00:52,920 | configurations represented as UML component diagrams. |