# CS6300 36 - Choosing a Model Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:02,860 | In this case, I think about the spiral model, |
| 00:00:02,860 --> 00:00:06,610 | and evolutionary prototyping model will work. Definitely you don't want to |
| 00:00:06,610 --> 00:00:09,110 | have a pure water from water. Why? Well because it |
| 00:00:09,110 --> 00:00:11,940 | is very expensive with a pure waterfall model to make |
| 00:00:11,940 --> 00:00:15,460 | changes during the course of the project, especially changes |
| 00:00:15,460 --> 00:00:17,860 | that involve requirements. Why? Because we saw that it can |
| 00:00:17,860 --> 00:00:20,440 | be very expensive. Whereas with the spiral model, we saw |
| 00:00:20,440 --> 00:00:25,220 | that being iterative, we can actually make correction throughout development. |
| 00:00:25,220 --> 00:00:28,840 | Similarly, with evolutionary prototyping, we keep evolving our system |
| 00:00:28,840 --> 00:00:32,170 | based on the customer feedback. And therefore, if something changes, |
| 00:00:32,170 --> 00:00:33,810 | we will get feedback right away, and we will |
| 00:00:33,810 --> 00:00:36,230 | be able to adapt. So the key thing here is |
| 00:00:36,230 --> 00:00:39,060 | that anything that is iterative works better in the |
| 00:00:39,060 --> 00:00:43,400 | case of changing environments. So, situations in which your requirements, |
| 00:00:43,400 --> 00:00:46,720 | the situation, the project might change. Whereas waterfall is |
| 00:00:46,720 --> 00:00:50,410 | more appropriate for situations in which the requirements are stable, |
| 00:00:50,410 --> 00:00:50,410 | we know the domain, and possibly we also know the technologies involved. |