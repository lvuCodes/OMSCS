# CS6300 148 - Recap Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,580 | And in this case, the correct answer is that class |
| 00:00:02,580 --> 00:00:06,870 | diagram and deployment diagrams are the only two UML structural |
| 00:00:06,870 --> 00:00:09,950 | diagrams among these four. So the answer to this quiz |
| 00:00:09,950 --> 00:00:12,250 | was probably pretty obvious, but I wanted to use it |
| 00:00:12,250 --> 00:00:15,840 | also to stress, once more, the difference between structural and |
| 00:00:15,840 --> 00:00:19,560 | behavioral diagrams. Structural diagrams provide the static picture of the |
| 00:00:19,560 --> 00:00:23,100 | system being modeled, presented from different perspective. For example, from |
| 00:00:23,100 --> 00:00:26,630 | the perspective of the class diagram and of the deployment diagram. |
| 00:00:26,630 --> 00:00:29,760 | Behavioral diagrams, on the other hand, provide information on |
| 00:00:29,760 --> 00:00:32,460 | the dynamic behavior of the system being modeled, also |
| 00:00:32,460 --> 00:00:35,020 | presented from different perspective. So it's important to be |
| 00:00:35,020 --> 00:00:38,020 | able to distinguish between these two types of diagrams. This |
| 00:00:38,020 --> 00:00:41,450 | concludes this lesson on object orientation and UML. But |
| 00:00:41,450 --> 00:00:43,960 | I encourage you to look at the references provided |
| 00:00:43,960 --> 00:00:45,390 | in the class notes, in case you want to |
| 00:00:45,390 --> 00:00:45,390 | know more about object orientation, object oriented analysis, and UML. |