# CS6300 117 - OO Benefits Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,080 --> 00:00:01,280 | So, now let's see which ones of these |
| 00:00:01,280 --> 00:00:04,410 | benefits can actually be expected. Definitely, the first one. |
| 00:00:04,410 --> 00:00:07,720 | The modular coding style typical of object-oriented approaches can, |
| 00:00:07,720 --> 00:00:11,280 | and normally does, increase reuse. Similarly, because of the |
| 00:00:11,280 --> 00:00:15,830 | characteristics of typical object-oriented systems, these systems are normally |
| 00:00:15,830 --> 00:00:18,390 | easier to change. Because they're more modular, they're more |
| 00:00:18,390 --> 00:00:21,890 | cohesive, they're more decoupled. And therefore, all of this |
| 00:00:21,890 --> 00:00:25,520 | contributes to increase the maintainability of the resulting systems. |
| 00:00:25,520 --> 00:00:27,810 | So we're going to mark this benefit as well. |
| 00:00:27,810 --> 00:00:31,500 | There's really nothing about object-oriented systems. That make them |
| 00:00:31,500 --> 00:00:34,550 | run faster and, therefore, this is not a benefit |
| 00:00:34,550 --> 00:00:36,432 | that we can expect from the use of an |
| 00:00:36,432 --> 00:00:39,910 | object-oriented approach. Conversely, the last one is an expected |
| 00:00:39,910 --> 00:00:43,950 | benefit because normally, the fact of designing real-world entities, |
| 00:00:43,950 --> 00:00:46,120 | which is one of the characteristics of the object |
| 00:00:46,120 --> 00:00:50,530 | oriented approaches, does increase understandability. It's easier to understand |
| 00:00:50,530 --> 00:00:54,370 | the system because we can relate. To the system because we can recognize in |
| 00:00:54,370 --> 00:00:54,370 | the systems, real world entities that we are used to see and that we understand. |