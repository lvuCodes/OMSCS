# CS6300 336 - Types of Refactorings

| Timestamp | Content |
|-----------|---------|
| 00:00:00,170 --> 00:00:03,630 | There are many refactorings in Fowler's book, and what I'm |
| 00:00:03,630 --> 00:00:06,480 | showing here is just a partial list. And we're not going to |
| 00:00:06,480 --> 00:00:08,930 | have time to go through the complete list of refactorings, |
| 00:00:08,930 --> 00:00:10,830 | so what I'm going to do instead, I'm just going to pick a |
| 00:00:10,830 --> 00:00:13,870 | few of those, but I'm going to explain in more depth, |
| 00:00:13,870 --> 00:00:16,600 | and for which I'm going to provide some examples. In particular, we're |
| 00:00:16,600 --> 00:00:18,000 | going to talk about the collapse |
| 00:00:18,000 --> 00:00:20,630 | hierarchy refactoring, the consolidate conditional |
| 00:00:20,630 --> 00:00:23,600 | expressions, the decompose conditionals, extract |
| 00:00:23,600 --> 00:00:25,418 | method, extract class, and inline class. |
| 00:00:25,418 --> 00:00:25,418 | And we're going to see each of those individually in the rest of the lesson. |