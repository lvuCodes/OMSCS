# CS6300 194 - Adding Attributes

| Timestamp | Content |
|-----------|---------|
| 00:00:00,240 --> 00:00:05,500 | Okay, so let me look at the requirements and |
| 00:00:05,500 --> 00:00:09,150 | it's something that I can see here that we didn't point out before is that |
| 00:00:09,150 --> 00:00:13,540 | there seems to be clearly some concept of a due date. And I'm telling you why |
| 00:00:13,540 --> 00:00:17,610 | I'm saying that because here, for example, I notice that it says when items are |
| 00:00:17,610 --> 00:00:22,580 | due. We mention overdue several times, so is |
| 00:00:22,580 --> 00:00:24,410 | this something we need to keep track of? |
| 00:00:24,410 --> 00:00:27,510 | >> Yeah remember when we used to stamp them on the books? In the stamp pad? |
| 00:00:27,510 --> 00:00:28,240 | >> Oh yeah yeah yeah! Oh course! |
| 00:00:28,240 --> 00:00:30,600 | >> Right? Yeah we definitely keep track of, |
| 00:00:30,600 --> 00:00:32,390 | the system has to keep track of when books are due. |
| 00:00:32,390 --> 00:00:35,300 | >> Okay. So it seems to me that one good way |
| 00:00:35,300 --> 00:00:39,660 | of doing that is by basically adding an attribute to the, item. |
| 00:00:39,660 --> 00:00:40,590 | >> Okay. |
| 00:00:40,590 --> 00:00:41,910 | >> And I'll just call it due date. |
| 00:00:41,910 --> 00:00:42,400 | >> Okay. |
| 00:00:42,400 --> 00:00:45,360 | >> So basically for each item in case it's loaned |
| 00:00:45,360 --> 00:00:48,315 | there will be this attribute that will contain the value of |
| 00:00:48,315 --> 00:00:48,520 | >> Okay. |
| 00:00:48,520 --> 00:00:55,710 | >> Of when, when the item is due. And then, something else that I noticed |
| 00:00:55,710 --> 00:00:58,734 | here is that down here, it seems like |
| 00:00:58,734 --> 00:01:00,900 | the requirements are saying that an item can |
| 00:01:00,900 --> 00:01:04,190 | be renewed only once. So, I guess, that's |
| 00:01:04,190 --> 00:01:05,933 | something we need to keep track of, right? |
| 00:01:05,933 --> 00:01:06,056 | >> Yeah. |
| 00:01:06,056 --> 00:01:06,700 | >> The system needs to know. |
| 00:01:06,700 --> 00:01:08,360 | >> We have to know whether they've renewed it or not. |
| 00:01:08,360 --> 00:01:14,132 | >> Okay so, I'll do a similar thing here. I think I want to go and add a an |
| 00:01:14,132 --> 00:01:19,140 | attribute that we'd call number of times renewed, and add it to the item class. |
| 00:01:19,140 --> 00:01:19,760 | >> Okay. |
| 00:01:19,760 --> 00:01:21,140 | >> And this is kind of more generic |
| 00:01:21,140 --> 00:01:23,180 | than what you need, because here it says only once, but |
| 00:01:23,180 --> 00:01:25,800 | let's say that in the future you want to allow it to, |
| 00:01:25,800 --> 00:01:28,690 | kind of renew twice, you'll be able to use these attributes again |
| 00:01:28,690 --> 00:01:31,090 | because, we can just count how many times it was renewed. Okay? |
| 00:01:31,090 --> 00:01:31,680 | >> Makes sense. |
| 00:01:31,680 --> 00:01:35,980 | >> Alright. And one last thing I want to point out. |
| 00:01:35,980 --> 00:01:38,310 | And this seems obvious but I'm going to check with |
| 00:01:38,310 --> 00:01:43,150 | you anyways. And seems like there is a basically the |
| 00:01:43,150 --> 00:01:46,090 | need to keep track of whether an item is checked |
| 00:01:46,090 --> 00:01:48,210 | out or not. If you look at the text here, |
| 00:01:48,210 --> 00:01:51,080 | the requirements here, I can see that check out and checked out are |
| 00:01:51,080 --> 00:01:55,070 | mentioned five times. So, I'm assuming that that's something also |
| 00:01:55,070 --> 00:01:58,080 | that we want to know about an item, whether it's checked out or not. |
| 00:01:58,080 --> 00:01:59,970 | >> We have to keep track of whether they're checked out. |
| 00:01:59,970 --> 00:02:01,930 | >> Okay, so I'll add an |
| 00:02:01,930 --> 00:02:04,340 | additional attribute there. So I'm going to again go |
| 00:02:04,340 --> 00:02:06,480 | back to the diagram and I'm |
| 00:02:06,480 --> 00:02:12,260 | just going to write here also the checked out attribute. |
| 00:02:12,260 --> 00:02:14,590 | And, I think that's it as far as I'm |
| 00:02:14,590 --> 00:02:16,330 | concerned. Is there anything that you think is missing? |
| 00:02:16,330 --> 00:02:21,077 | >> Well, I do have a question. Would checked out, |
| 00:02:21,077 --> 00:02:27,140 | better not be the case that someone can check out a reference book. |
| 00:02:27,140 --> 00:02:28,400 | >> Oh, I see, I see. |
| 00:02:28,400 --> 00:02:30,120 | >> Okay. I mean, it's only the books and |
| 00:02:30,120 --> 00:02:31,780 | the audio visual material that can be checked out. |
| 00:02:31,780 --> 00:02:37,790 | >> Right, right, right. Okay, so I, I guess, well the way I will fix that is, |
| 00:02:37,790 --> 00:02:42,300 | I'll probably put yet another attribute in the item class, and I'll |
| 00:02:42,300 --> 00:02:45,860 | call it loanable. And basically, this attribute is just telling us whether |
| 00:02:45,860 --> 00:02:49,580 | an item is loanable or not. So, when it's not true and |
| 00:02:49,580 --> 00:02:53,480 | loanable is not on. Basically, that item can be checked out. |
| 00:02:53,480 --> 00:02:55,174 | >> Okay. And, the system would know this. |
| 00:02:55,174 --> 00:02:56,450 | >> The system will know that. |
| 00:02:56,450 --> 00:02:57,160 | >> And prevent it from happening. |
| 00:02:57,160 --> 00:02:58,240 | >> And prevent it from happening. Okay? |
| 00:02:58,240 --> 00:02:58,750 | >> Alright. |
| 00:02:58,750 --> 00:03:02,918 | >> Perfect. So, we're going to do that and, any other objections, |
| 00:03:02,918 --> 00:03:04,035 | any other? |
| 00:03:04,035 --> 00:03:05,730 | >> No, that was my question. |
| 00:03:05,730 --> 00:03:08,040 | >> Okay, perfect, so what I'm going to do next, I |
| 00:03:08,040 --> 00:03:11,130 | mean, I haven't mentioned that yet, but you know classes right |
| 00:03:11,130 --> 00:03:12,890 | now we just looked at the attributes right that give |
| 00:03:12,890 --> 00:03:16,140 | you sort of the state of the class. And there's something |
| 00:03:16,140 --> 00:03:19,185 | else, there's a second part of the class that is kind of |
| 00:03:19,185 --> 00:03:22,520 | an orthogonal aspect, which is what the class can do. And we |
| 00:03:22,520 --> 00:03:25,640 | call those operations. So normally these kinds also have operations, I |
| 00:03:25,640 --> 00:03:28,000 | guess you know it would make sense to you as well. |
| 00:03:28,000 --> 00:03:30,070 | And one way, one very natural way to |
| 00:03:30,070 --> 00:03:33,310 | identify operations is to look at the requirements and |
| 00:03:33,310 --> 00:03:36,850 | look for verbs. Because verbs associated with an item |
| 00:03:36,850 --> 00:03:38,480 | will tell you basically what the item can do. |
| 00:03:38,480 --> 00:03:38,900 | >> Okay. |
| 00:03:38,900 --> 00:03:41,250 | >> So I, I'd like to go back to the requirements and |
| 00:03:41,250 --> 00:03:45,110 | start, the same way in which we underlined, nouns, we're going to underline |
| 00:03:45,110 --> 00:03:49,340 | verbs and we're going to see which ones of those verbs actually represent |
| 00:03:49,340 --> 00:03:53,120 | actions that we want to represent explicitly, we want to model explicitly in |
| 00:03:53,120 --> 00:03:53,950 | our class diagram. |
| 00:03:53,950 --> 00:03:54,490 | >> Okay. |
| 00:03:54,490 --> 00:03:54,490 | >> Okay. |