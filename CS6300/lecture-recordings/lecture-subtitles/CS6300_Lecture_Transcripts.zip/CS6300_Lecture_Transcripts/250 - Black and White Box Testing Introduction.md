# CS6300 250 - Black and White Box Testing Introduction

| Timestamp | Content |
|-----------|---------|
| 00:00:00,370 --> 00:00:02,520 | We're almost at the end of this lesson. In the |
| 00:00:02,520 --> 00:00:05,520 | next two lessons we're going to talk about two main families |
| 00:00:05,520 --> 00:00:07,800 | of testing techniques, black-box testing |
| 00:00:07,800 --> 00:00:10,340 | techniques, and white-box testing techniques. So, |
| 00:00:10,340 --> 00:00:12,730 | what I want to do before getting into the discussion of the |
| 00:00:12,730 --> 00:00:15,385 | specific techniques in this families. I want to give you an |
| 00:00:15,385 --> 00:00:19,440 | overview of what black-box testing and white-box testing are. Black box |
| 00:00:19,440 --> 00:00:21,950 | testing is the kind of testing in which we consider the |
| 00:00:21,950 --> 00:00:25,570 | software as a closed box. That's why it's called black box. |
| 00:00:25,570 --> 00:00:27,770 | So we don't look inside the software, we don't want to |
| 00:00:27,770 --> 00:00:30,131 | look at the code. We just going to look at the description |
| 00:00:30,131 --> 00:00:33,210 | of the software. So this is the testing that is based |
| 00:00:33,210 --> 00:00:36,100 | on a description of the software, which is what we normally |
| 00:00:36,100 --> 00:00:39,690 | call the specification for the software. And what black box testing |
| 00:00:39,690 --> 00:00:44,040 | tries to do is to cover as much specified behavior as |
| 00:00:44,040 --> 00:00:47,290 | possible, and the main limitation black box testing and the reason |
| 00:00:47,290 --> 00:00:51,540 | why this is complimentary to white-box testing is that it cannot reveal |
| 00:00:51,540 --> 00:00:56,590 | errors due to implementation details. Conversely, white-box testing |
| 00:00:56,590 --> 00:00:58,430 | is the kind of testing that looks inside the |
| 00:00:58,430 --> 00:01:00,360 | box. So looks at the code and how |
| 00:01:00,360 --> 00:01:02,760 | the code is written and uses this information to |
| 00:01:02,760 --> 00:01:06,300 | perform the testing. So white-box testing is based |
| 00:01:06,300 --> 00:01:09,120 | on the code, its goal is to cover as |
| 00:01:09,120 --> 00:01:13,210 | much coded behavior in this case, as possible, and |
| 00:01:13,210 --> 00:01:17,100 | its limitation is that unlike black-box testing, it can't |
| 00:01:17,100 --> 00:01:21,880 | reveal errors due to missing paths. Where missing paths are |
| 00:01:21,880 --> 00:01:25,250 | a part of a software specification that are not implemented and |
| 00:01:25,250 --> 00:01:27,320 | the reason why you can not reveal them is because |
| 00:01:27,320 --> 00:01:27,320 | it is focused on the code and not on the specification. |