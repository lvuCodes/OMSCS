# CS6300 99 - Requirements Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:02,940 | After all these talking about requirements, let's have a small quiz, I |
| 00:00:02,940 --> 00:00:04,019 | want to ask you which of the |
| 00:00:04,019 --> 00:00:07,840 | following requirements are non-functional requirements? And here |
| 00:00:07,840 --> 00:00:10,860 | I'm listing the requirements, the first one says at the BowlingAlley program |
| 00:00:10,860 --> 00:00:13,420 | keeps track of the score during a game, the second one is that |
| 00:00:13,420 --> 00:00:16,720 | the WordCount program should be able to process large files. The third |
| 00:00:16,720 --> 00:00:19,580 | one is that the Login program for a website. Should be secure, and |
| 00:00:19,580 --> 00:00:22,880 | finally the last one says that the vending machine program should take coins |
| 00:00:22,880 --> 00:00:25,430 | as an input from the user. So, I want you to mark all |
| 00:00:25,430 --> 00:00:27,590 | the ones that are non-functional requirements, that |
| 00:00:27,590 --> 00:00:27,590 | don't refer to the functionality of the system. |