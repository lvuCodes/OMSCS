# CS6300 16 - Tools of the Trade

| Timestamp | Content |
|-----------|---------|
| 00:00:00,072 --> 00:00:02,960 | We will also look at how tools can improve software phases, |
| 00:00:02,960 --> 00:00:06,660 | the software activities, and can support software development tasks in general. |
| 00:00:06,660 --> 00:00:08,890 | And this is something that I will repeat over and over |
| 00:00:08,890 --> 00:00:12,340 | in the class, tools and automation are fundamental, in software engineering. |
| 00:00:12,340 --> 00:00:15,910 | And they're fundamental for improving productivity, not only efficiency but also |
| 00:00:15,910 --> 00:00:19,820 | effectiveness of our activities in the software development process. So let |
| 00:00:19,820 --> 00:00:22,110 | me go back to one of the diagrams that I showed |
| 00:00:22,110 --> 00:00:25,170 | you before. If you remember we had this qualititive diagram in which |
| 00:00:25,170 --> 00:00:27,170 | we were showing that one of the issues that led to the |
| 00:00:27,170 --> 00:00:30,350 | software crisis was the fact that developers' productivity was not able to |
| 00:00:30,350 --> 00:00:33,580 | keep up with the software size and complexity, with the growth in |
| 00:00:33,580 --> 00:00:36,750 | the importance and the complexity of software. What tools can help us |
| 00:00:36,750 --> 00:00:40,150 | to do is to change this and basically move this curve from |
| 00:00:40,150 --> 00:00:43,950 | this original position up here. So that it gets closer and closer |
| 00:00:43,950 --> 00:00:45,970 | to what we need to develop the software that we need to |
| 00:00:45,970 --> 00:00:50,230 | build. So let me discuss examples on how tools can improve productivity. |
| 00:00:50,230 --> 00:00:52,970 | For example, if we are talking about development, think about |
| 00:00:52,970 --> 00:00:54,890 | what kind of improvement it was to go from punch |
| 00:00:54,890 --> 00:00:58,440 | cards to modern IDEs. If we're talking about languages, think |
| 00:00:58,440 --> 00:01:02,210 | about of how much more productive developers became when going from |
| 00:01:02,210 --> 00:01:05,830 | writing machine code to writing code in high-level languages. And |
| 00:01:05,830 --> 00:01:08,750 | finally, if we talk about debugging, which is a very important |
| 00:01:08,750 --> 00:01:12,140 | and expensive activity, moving from the use of print lines |
| 00:01:12,140 --> 00:01:16,060 | to the use of symbolic debuggers dramatically improve the effectiveness and |
| 00:01:16,060 --> 00:01:18,810 | efficiency of development. And these are just some of the |
| 00:01:18,810 --> 00:01:21,050 | tools that we will discuss in the rest of the class |
| 00:01:21,050 --> 00:01:23,350 | and notice that we will also use the tools in practice. |
| 00:01:23,350 --> 00:01:26,290 | So we will use the tools before projects and also during |
| 00:01:26,290 --> 00:01:30,153 | the lessons and for assignments. In particular, we will use |
| 00:01:30,153 --> 00:01:33,920 | three main kinds of tools. The first type is IDE's. And |
| 00:01:33,920 --> 00:01:37,140 | I'm pretty sure you're familiar with IDE's. These are integrated development |
| 00:01:37,140 --> 00:01:41,250 | environments. So, advanced editors in which you can write, compile, run, |
| 00:01:41,250 --> 00:01:43,950 | and debug and even test your code. We'll also use a |
| 00:01:43,950 --> 00:01:48,190 | version control system, systems that allow you to save, and restore, and |
| 00:01:48,190 --> 00:01:51,750 | check the differences between different versions of the code, in particular |
| 00:01:51,750 --> 00:01:53,950 | we will be working with git. We will also be looking at |
| 00:01:53,950 --> 00:01:57,460 | other kinds of tools like coverage and verification tools. These are |
| 00:01:57,460 --> 00:02:00,310 | tools that can help you during testing and I'm a big fan |
| 00:02:00,310 --> 00:02:02,710 | of these tools, so I'm really going to stress the usefulness |
| 00:02:02,710 --> 00:02:02,710 | of these tools and how you should use them in your development. |