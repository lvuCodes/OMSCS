# CS6300 316 - Incremental Planning

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:03,390 | Incremental planning is based on the idea that requirements are recorded |
| 00:00:03,390 --> 00:00:07,260 | on story cards, sort of use cases or scenarios that the customer |
| 00:00:07,260 --> 00:00:10,450 | provides. So the first step in incremental planning is to select |
| 00:00:10,450 --> 00:00:14,120 | user stories for a given release, and which stories exactly to include |
| 00:00:14,120 --> 00:00:16,975 | depends on the time available and on the priority. For example, |
| 00:00:16,975 --> 00:00:19,147 | scenarios that we might want to realize right away because they are |
| 00:00:19,147 --> 00:00:22,110 | particular important for the customer. After we select user stories for |
| 00:00:22,110 --> 00:00:25,200 | the release, we break stories i to tasks. So what we do, |
| 00:00:25,200 --> 00:00:29,260 | we take the user stories and we identify specific development tasks |
| 00:00:29,260 --> 00:00:32,320 | that we need to perform in order to realize these stories. Once |
| 00:00:32,320 --> 00:00:34,780 | we know our tasks, we can plan our release. And at |
| 00:00:34,780 --> 00:00:38,050 | that point, we can develop, integrate and test our code. And of |
| 00:00:38,050 --> 00:00:41,170 | course, this is more kind of an iterative process right here, |
| 00:00:41,170 --> 00:00:44,250 | so we do this many times. When we're ready, when we accomplish |
| 00:00:44,250 --> 00:00:46,990 | all of our tasks, all of our tests pass and we're happy, |
| 00:00:46,990 --> 00:00:50,410 | we release this software. At the point, the released software is evaluated |
| 00:00:50,410 --> 00:00:53,250 | by us, by the customer, and we can reiterate. We can |
| 00:00:53,250 --> 00:00:53,250 | continue the process, select more stories and continue it this way. |