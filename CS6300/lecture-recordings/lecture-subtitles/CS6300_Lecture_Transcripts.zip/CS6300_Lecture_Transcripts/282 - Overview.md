# CS6300 282 - Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,420 --> 00:00:03,860 | In the last lesson, we talked about black-box testing or functional testing, |
| 00:00:03,860 --> 00:00:06,110 | which is the kind of testing that you perform when you just |
| 00:00:06,110 --> 00:00:09,860 | look at the description of the software. Today we're going to cover white-box |
| 00:00:09,860 --> 00:00:12,490 | testing, which is the kind of testing that we perform when we |
| 00:00:12,490 --> 00:00:15,800 | open up the box. We look inside the program, and we actually |
| 00:00:15,800 --> 00:00:19,490 | test it based on its code. And there is one basic assumption |
| 00:00:19,490 --> 00:00:22,320 | behind the idea of white-box testing, which is a very intuitive one, |
| 00:00:22,320 --> 00:00:26,080 | and the assumption is that executing the faulty statement is a necessary |
| 00:00:26,080 --> 00:00:29,380 | condition for revealing a fault. In other words, if there is |
| 00:00:29,380 --> 00:00:31,690 | a bug in the program there is no way were going to be |
| 00:00:31,690 --> 00:00:34,490 | able to find this bug or this fault, if we don't execute |
| 00:00:34,490 --> 00:00:37,110 | the statement that contains it. Which makes a lot of sense. As |
| 00:00:37,110 --> 00:00:40,240 | we did for black-box testing, we're going to start by summarizing what |
| 00:00:40,240 --> 00:00:43,650 | are the main advantages of white-box testing. The main advantage is that |
| 00:00:43,650 --> 00:00:48,050 | it's based on the code, and as such, the quality of white-box |
| 00:00:48,050 --> 00:00:51,760 | testing can be measured objectively. And what I mean here by objectively |
| 00:00:51,760 --> 00:00:54,390 | is that if you think about black-box testing In many |
| 00:00:54,390 --> 00:00:57,630 | cases, there were subjective decisions, there were had to be made |
| 00:00:57,630 --> 00:01:00,830 | in order to define tests in a black-box fashion. In the |
| 00:01:00,830 --> 00:01:03,990 | case of white-box testing, because everything is based on the quota, |
| 00:01:03,990 --> 00:01:07,965 | we don't have to make such subjective decisions. And similarly, because |
| 00:01:07,965 --> 00:01:10,680 | white-box testing is based on the code, it can be measured |
| 00:01:10,680 --> 00:01:14,250 | automatically. So we can build tools and actually there are tools, |
| 00:01:14,250 --> 00:01:16,860 | and there's plenty of tools, that can be measured, the level |
| 00:01:16,860 --> 00:01:19,670 | of white-box testing can be achieved in a fully automated way. |
| 00:01:19,670 --> 00:01:21,620 | And we're going to see some of them in the course of the |
| 00:01:21,620 --> 00:01:24,600 | class. Another advantage of white-box testing is that it can be |
| 00:01:24,600 --> 00:01:27,700 | used to compare test suites. So if you have two alternative sets |
| 00:01:27,700 --> 00:01:30,270 | of tests that you can use to assess the quality of |
| 00:01:30,270 --> 00:01:34,360 | your software, white-box testing techniques can tell you which one of these |
| 00:01:34,360 --> 00:01:37,580 | two test suites is likely to be more effective in testing |
| 00:01:37,580 --> 00:01:42,350 | your code. And finally, white-box testing allows for covering the coded behavior |
| 00:01:42,350 --> 00:01:44,470 | of the software. What that means is that if there is |
| 00:01:44,470 --> 00:01:47,680 | some mistake in the code and is not obvious by looking at |
| 00:01:47,680 --> 00:01:50,300 | the specification of the code, white box testing might be able |
| 00:01:50,300 --> 00:01:53,330 | to catch it, because it tries to exercise the code. There's many |
| 00:01:53,330 --> 00:01:56,430 | different kinds of white box testing, there are control flow based |
| 00:01:56,430 --> 00:02:00,550 | techniques, data flow based techniques, and fault based techniques. And for each |
| 00:02:00,550 --> 00:02:04,030 | one of these family of techniques there are many variations. So |
| 00:02:04,030 --> 00:02:07,450 | this field is very, very broad. In this lesson we will talk |
| 00:02:07,450 --> 00:02:09,110 | about white-box testing by focusing |
| 00:02:09,110 --> 00:02:09,110 | mainly on control-flow based testing techniques. |