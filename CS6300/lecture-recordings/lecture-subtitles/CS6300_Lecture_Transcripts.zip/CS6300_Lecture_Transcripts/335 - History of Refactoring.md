# CS6300 335 - History of Refactoring

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:02,340 | So if you follow my class so far, you know that |
| 00:00:02,340 --> 00:00:04,570 | I like to give a little bit of history when I talk |
| 00:00:04,570 --> 00:00:06,900 | about a specific topic. So I'm going to do the same also |
| 00:00:06,900 --> 00:00:09,900 | in this case for refactoring. I'm going to start by mentioning, the fact |
| 00:00:09,900 --> 00:00:13,440 | that refactoring is something that programmers have always done. I gave |
| 00:00:13,440 --> 00:00:16,300 | you a trivial example just a minute ago of what refactoring is. |
| 00:00:16,300 --> 00:00:18,080 | So even more complicated refactorings are |
| 00:00:18,080 --> 00:00:20,880 | something that are commonplace for developers. |
| 00:00:20,880 --> 00:00:23,110 | Somehow refactoring is especially important in |
| 00:00:23,110 --> 00:00:25,240 | the context of object-oriented languages and |
| 00:00:25,240 --> 00:00:28,080 | probably it's because the object-oriented features are well suited to |
| 00:00:28,080 --> 00:00:31,640 | make designs flexible and reusable. Because of the fact that help |
| 00:00:31,640 --> 00:00:35,120 | encapsulation, information hiding, and so they make it easier to |
| 00:00:35,120 --> 00:00:38,330 | modify something without changing the functionality that it provides to the |
| 00:00:38,330 --> 00:00:40,960 | outside world. However, you should keep in mind that refactoring |
| 00:00:40,960 --> 00:00:44,330 | is really not specific to object oriented languages, you can also |
| 00:00:44,330 --> 00:00:47,320 | refactor other languages, it's just more common to see it in |
| 00:00:47,320 --> 00:00:50,450 | that context. So one of the first examples of a specific |
| 00:00:50,450 --> 00:00:53,630 | discussion of what the refactorings are is Opdyke's PhD |
| 00:00:53,630 --> 00:00:57,710 | thesis in 1990. Which discusses refactorings for small talk. |
| 00:00:57,710 --> 00:00:59,360 | And some of you might be familiar with small |
| 00:00:59,360 --> 00:01:02,600 | talk, which is a specific objectory language. And in |
| 00:01:02,600 --> 00:01:06,590 | more recent times, refactoring's becoming increasing popular due to |
| 00:01:06,590 --> 00:01:10,370 | lightweight development methodoogies, due to agile development, which is |
| 00:01:10,370 --> 00:01:12,630 | something that we just discussed in this class. For |
| 00:01:12,630 --> 00:01:15,830 | example, when we talked about extreme programming, we mentioned refactoring |
| 00:01:15,830 --> 00:01:17,950 | a few times. And the reason why its so popular |
| 00:01:17,950 --> 00:01:20,690 | is because re-factoring is one of the practices that help. |
| 00:01:20,690 --> 00:01:24,780 | Making changes less expensive. And therefore adapt to changing requirements |
| 00:01:24,780 --> 00:01:26,980 | and changing environments more quickly. |
| 00:01:26,980 --> 00:01:29,140 | And continuing with historical perspective, one |
| 00:01:29,140 --> 00:01:31,760 | of the milestones in the history of re-factoring [INAUDIBLE] is |
| 00:01:31,760 --> 00:01:34,660 | a book by Martin Fowler. This is a book entitled |
| 00:01:34,660 --> 00:01:37,610 | Improving the Design of Existing [INAUDIBLE]. And it contains a |
| 00:01:37,610 --> 00:01:41,320 | catalog of refactorings, a list of bad smells, in code, and |
| 00:01:41,320 --> 00:01:43,450 | we're going to see what that mean exactly. Nothing to |
| 00:01:43,450 --> 00:01:45,570 | do with other kinds of bad smells. It talks about |
| 00:01:45,570 --> 00:01:48,900 | guidelines on when to apply refactoring. And finally, which is |
| 00:01:48,900 --> 00:01:52,540 | very useful, it provides example of code, before and after. |
| 00:01:52,540 --> 00:01:54,660 | Applying the refactoring and we're going to use more of the |
| 00:01:54,660 --> 00:01:57,190 | same style when discussing refactoring in the rest of this |
| 00:01:57,190 --> 00:02:01,090 | lesson. More specifically what we're discussing next, are some examples |
| 00:02:01,090 --> 00:02:01,090 | of refactoring and also some examples of code bad smells. |