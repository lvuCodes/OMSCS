# CS6300 30 - Rational Unified Process

| Timestamp | Content |
|-----------|---------|
| 00:00:00,070 --> 00:00:02,969 | There are two more software process models that I want to cover, so |
| 00:00:02,969 --> 00:00:06,120 | bear with me. The first one is the Rational Unified software Process |
| 00:00:06,120 --> 00:00:09,500 | or IUP, which is s a very popular one based on UML. |
| 00:00:09,500 --> 00:00:12,620 | RUP works in an iterative way, which means it that it performs different |
| 00:00:12,620 --> 00:00:16,360 | iterations. And at each iteration, it performs four phases. So what I'm |
| 00:00:16,360 --> 00:00:19,030 | showing you here, is a high level view of the process. And I |
| 00:00:19,030 --> 00:00:21,630 | don't want you to focus on all the different details, because we |
| 00:00:21,630 --> 00:00:25,170 | will discuss these details later on, in a lesson that is actually dedicated |
| 00:00:25,170 --> 00:00:27,470 | to RUP. What I want to give you now, is just the |
| 00:00:27,470 --> 00:00:31,020 | gist of how this works. So, in each one of these four |
| 00:00:31,020 --> 00:00:34,680 | phases, which I'm going to describe in a second. We perform standard software |
| 00:00:34,680 --> 00:00:38,060 | engineering activities, the ones that we just discussed. And we do them |
| 00:00:38,060 --> 00:00:41,320 | to different extent, based on the phase in which we are. |
| 00:00:41,320 --> 00:00:44,841 | In particular, in the inception phase the work is mostly to sculpt |
| 00:00:44,841 --> 00:00:47,940 | the system. So basically figuring out what is the scope of the |
| 00:00:47,940 --> 00:00:50,220 | work, what is the scope of the project, what is the domain. |
| 00:00:50,220 --> 00:00:52,670 | So that we can be able to perform initial cost |
| 00:00:52,670 --> 00:00:56,190 | and budget estimates. The operational phase is the phase in which |
| 00:00:56,190 --> 00:00:59,910 | we focus on the domain analysis and define the basic architecture |
| 00:00:59,910 --> 00:01:03,030 | for the system. So this is a phase in which analysis |
| 00:01:03,030 --> 00:01:06,290 | and design are particularly paramount. Then there is a construction phase, |
| 00:01:06,290 --> 00:01:09,250 | which is where the bulk of the development actually occurs. And |
| 00:01:09,250 --> 00:01:11,640 | as you can see here, is where most of the implementation |
| 00:01:11,640 --> 00:01:15,280 | happens. And finally, the transition phase is the phase in which |
| 00:01:15,280 --> 00:01:18,090 | the system goes from development into production, so that |
| 00:01:18,090 --> 00:01:20,380 | it becomes available to users. And of course, this is |
| 00:01:20,380 --> 00:01:22,480 | the phase in which the other activities in software |
| 00:01:22,480 --> 00:01:22,480 | development become less relevant and deployment becomes the main one. |