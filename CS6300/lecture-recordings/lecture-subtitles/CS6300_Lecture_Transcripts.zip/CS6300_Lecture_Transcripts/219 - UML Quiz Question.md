# CS6300 219 - UML Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,330 --> 00:00:02,650 | So, since we are talking about use case diagrams, I also want |
| 00:00:02,650 --> 00:00:05,593 | to ask you, what are use case diagrams used for? So, what |
| 00:00:05,593 --> 00:00:08,600 | are they good for? Why are they useful within a software process? |
| 00:00:08,600 --> 00:00:12,130 | Also in this case, I'm providing several possible answers. They are not really |
| 00:00:12,130 --> 00:00:15,420 | used for anything. Or, they can be used to prioritize requirements. Or, |
| 00:00:15,420 --> 00:00:18,220 | maybe they can be used for user interface design. They can be |
| 00:00:18,220 --> 00:00:20,280 | used during requirements elicitation. They can |
| 00:00:20,280 --> 00:00:21,890 | be used for code optimization. And |
| 00:00:21,890 --> 00:00:25,570 | finally, they can be used for test case design. Also, in this case, |
| 00:00:25,570 --> 00:00:25,570 | I would like you to mark all the answers that you think are correct. |