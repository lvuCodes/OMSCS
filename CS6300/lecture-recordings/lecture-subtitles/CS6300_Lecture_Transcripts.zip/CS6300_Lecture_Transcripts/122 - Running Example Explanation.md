# CS6300 122 - Running Example Explanation

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,700 | This concludes the first part of this lesson in which |
| 00:00:02,700 --> 00:00:06,080 | we discussed the basic object-oriented concepts. And, we started to |
| 00:00:06,080 --> 00:00:09,830 | look at how to perform object-oriented analysis. In the second |
| 00:00:09,830 --> 00:00:12,630 | part of the lesson, I will introduce UML, and we will |
| 00:00:12,630 --> 00:00:15,990 | perform the object-oriented analysis steps that we just saw using |
| 00:00:15,990 --> 00:00:19,240 | an example. A course management system so before getting to |
| 00:00:19,240 --> 00:00:22,380 | the second part, let me introduce the example. As we |
| 00:00:22,380 --> 00:00:25,420 | mentioned before, the first step is to start from a textual |
| 00:00:25,420 --> 00:00:27,800 | description of the system the we need to analyze and |
| 00:00:27,800 --> 00:00:30,080 | that we need to build. So that's exactly what I'm going |
| 00:00:30,080 --> 00:00:33,272 | to do. I'm just going to read through this description then we'll |
| 00:00:33,272 --> 00:00:36,590 | reuse throughout the rest of the lesson. The registration manager sets |
| 00:00:36,590 --> 00:00:40,090 | up the curriculum for a semester using a scheduling algorithm and |
| 00:00:40,090 --> 00:00:43,600 | the registration manager here is the registrar. So we will refer |
| 00:00:43,600 --> 00:00:47,510 | to the registration manager both as registration manager and as registrar |
| 00:00:47,510 --> 00:00:50,500 | in the rest of the lesson. One course may have multiple |
| 00:00:50,500 --> 00:00:52,860 | course offerings, which is pretty standard. Each |
| 00:00:52,860 --> 00:00:55,490 | course offering has a number, location, and a |
| 00:00:55,490 --> 00:00:59,160 | time associated with it. Students select four primary |
| 00:00:59,160 --> 00:01:02,410 | courses and two alternative courses by submitting a |
| 00:01:02,410 --> 00:01:05,860 | registration form. Students might use the course management |
| 00:01:05,860 --> 00:01:08,460 | system to add or drop courses for a |
| 00:01:08,460 --> 00:01:11,660 | period of time after registration. Professors use the |
| 00:01:11,660 --> 00:01:15,250 | system to receive their course offering rosters. Finally, |
| 00:01:15,250 --> 00:01:19,280 | users of the registration system are assigned passwords which are used for |
| 00:01:19,280 --> 00:01:21,882 | login validation. So, as you can see, this is a kind of a |
| 00:01:21,882 --> 00:01:25,440 | high-level description of a standard course management system. So, if you ever |
| 00:01:25,440 --> 00:01:27,160 | used a course management system, you'll |
| 00:01:27,160 --> 00:01:27,160 | recognize some of the functionality described here. |