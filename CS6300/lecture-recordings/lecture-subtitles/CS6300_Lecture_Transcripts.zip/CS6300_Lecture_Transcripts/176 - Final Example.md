# CS6300 176 - Final Example

| Timestamp | Content |
|-----------|---------|
| 00:00:00,220 --> 00:00:02,130 | I'm going to conclude this set of examples with |
| 00:00:02,130 --> 00:00:04,750 | a system that you might also know, Bash. And in |
| 00:00:04,750 --> 00:00:08,000 | case you don't, Bash is a Unix shell written as |
| 00:00:08,000 --> 00:00:11,000 | a free software replacement for the traditional Bourne shell, also |
| 00:00:11,000 --> 00:00:13,690 | called sh. So what I'm showing here is the |
| 00:00:13,690 --> 00:00:17,950 | descriptive architecture of the command component of Bash. So, is |
| 00:00:17,950 --> 00:00:22,170 | the architecture, as implemented, of the command component of Bash. |
| 00:00:22,170 --> 00:00:25,390 | And the component is the one here sort of highlighted |
| 00:00:25,390 --> 00:00:28,120 | in gray. And what you can see here, these names are |
| 00:00:28,120 --> 00:00:31,640 | the sub components of the command component. And if we look at |
| 00:00:31,640 --> 00:00:35,000 | this architecture, two design problems of the component can kind of jump |
| 00:00:35,000 --> 00:00:37,870 | at us. The first one is the lack of cohesion within the |
| 00:00:37,870 --> 00:00:40,830 | component. So, if you look here, you can see that only |
| 00:00:40,830 --> 00:00:44,820 | a few connections exist between the sub-components. And having a low cohesion |
| 00:00:44,820 --> 00:00:47,430 | is normally not a good thing for a design. The second thing |
| 00:00:47,430 --> 00:00:50,860 | that we can note is the high coupling. The component has tons |
| 00:00:50,860 --> 00:00:54,200 | of connections with other components. They're, these edges that are |
| 00:00:54,200 --> 00:00:57,890 | leaving the components and going towards other parts of the system. |
| 00:00:57,890 --> 00:01:01,190 | So basically, this component has low cohesion and high coupling, which |
| 00:01:01,190 --> 00:01:04,730 | is exactly the opposite of how a good design should be. |
| 00:01:04,730 --> 00:01:07,410 | Given the structure, it is clear that anytime you change |
| 00:01:07,410 --> 00:01:09,970 | this component you might need to change a bunch of other |
| 00:01:09,970 --> 00:01:13,440 | components in the system. And of course, when changing other components |
| 00:01:13,440 --> 00:01:15,910 | in the system, you might also need to chance the command |
| 00:01:15,910 --> 00:01:19,060 | component as well. And along similar lines, to understand this |
| 00:01:19,060 --> 00:01:21,890 | component you probably need to look at many other parts of |
| 00:01:21,890 --> 00:01:24,690 | the system, which is also less than ideal. And one |
| 00:01:24,690 --> 00:01:27,580 | important point here is that with all these examples, I'm not |
| 00:01:27,580 --> 00:01:30,500 | really trying to criticize any specific system, what I'm trying |
| 00:01:30,500 --> 00:01:34,380 | to show instead, is how complex software architectures can be, and |
| 00:01:34,380 --> 00:01:37,040 | how much they can degrade over time. And this is true |
| 00:01:37,040 --> 00:01:37,040 | for most systems, not just the ones that I showed you. |