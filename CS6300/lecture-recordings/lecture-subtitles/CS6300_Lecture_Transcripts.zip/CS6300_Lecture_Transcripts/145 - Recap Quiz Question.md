# CS6300 145 - Recap Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,190 --> 00:00:02,260 | I'd like to conclude this lesson with a couple of |
| 00:00:02,260 --> 00:00:05,350 | quizzes. Just to recap what we saw. And, make sure that |
| 00:00:05,350 --> 00:00:08,000 | everybody's on the same page. In the first quiz, I want to |
| 00:00:08,000 --> 00:00:11,930 | know whether an UML state transition diagram specifies a set of |
| 00:00:11,930 --> 00:00:15,320 | objects that work together to perform some action. The events that |
| 00:00:15,320 --> 00:00:17,870 | cause an object to move from one state to another. The |
| 00:00:17,870 --> 00:00:20,840 | set of components in a system, or the effects of a |
| 00:00:20,840 --> 00:00:20,840 | state change. And as usual, you should mark all that apply. |