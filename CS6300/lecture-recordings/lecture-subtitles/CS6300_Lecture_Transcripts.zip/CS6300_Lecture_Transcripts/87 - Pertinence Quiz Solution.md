# CS6300 87 - Pertinence Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,190 --> 00:00:03,620 | So the first requirement is definitely pertinent. Members of the gym shall |
| 00:00:03,620 --> 00:00:06,740 | be able to access their training programs. It's pretty normal for members of |
| 00:00:06,740 --> 00:00:09,710 | the gym to have a training program. And therefore, the system should allow |
| 00:00:09,710 --> 00:00:12,900 | them to access them. Similarly for the second one. The system shall be |
| 00:00:12,900 --> 00:00:15,450 | able to read member cards. Normally when you get into a gym |
| 00:00:15,450 --> 00:00:17,420 | if you have a member card, you'll have to either show it to |
| 00:00:17,420 --> 00:00:21,010 | somebody, or nowadays swipe it, and so the system should be able to |
| 00:00:21,010 --> 00:00:23,410 | recognize the customer given the card. |
| 00:00:23,410 --> 00:00:25,710 | The third requirement is probably not pertinent, |
| 00:00:25,710 --> 00:00:29,090 | because I cannot think of any meaningful case in which the system |
| 00:00:29,090 --> 00:00:32,729 | should know what is the members' commute time. The fourth requirement, personal |
| 00:00:32,729 --> 00:00:36,750 | trainers shall be able to add clients, is also probably pertinent. Assuming |
| 00:00:36,750 --> 00:00:38,870 | that we have personal trainers in the gym, and they should be |
| 00:00:38,870 --> 00:00:41,710 | able to get clients, to work with the clients of the gym, |
| 00:00:41,710 --> 00:00:44,140 | and therefore, they should be able to add them as their clients |
| 00:00:44,140 --> 00:00:47,620 | to the system. And finally, the last requirement, the list of members |
| 00:00:47,620 --> 00:00:50,800 | shall be stores as a linked list. This is really something about |
| 00:00:50,800 --> 00:00:54,130 | the how, more than the what. And therefore, for what we say before |
| 00:00:54,130 --> 00:00:54,130 | is probably not a pertinent requirement, so we're not going to mark this one. |