# CS6300 123 - UML Structural Diagrams_  Class Diagram

| Timestamp | Content |
|-----------|---------|
| 00:00:00,200 --> 00:00:04,410 | Let's now start talking about UML, the Unified Modeling Language. |
| 00:00:04,410 --> 00:00:06,530 | And we are going to start by looking at UML |
| 00:00:06,530 --> 00:00:11,390 | structural diagrams. This are the diagrams that represent static characteristics |
| 00:00:11,390 --> 00:00:13,430 | of the system that we need to model. This is |
| 00:00:13,430 --> 00:00:17,170 | in contrast with dynamic models which instead behaviors of the |
| 00:00:17,170 --> 00:00:19,200 | system that we need to model. And we will also |
| 00:00:19,200 --> 00:00:22,424 | discuss dynamic models, later on in the lesson. We're going |
| 00:00:22,424 --> 00:00:25,670 | to discuss several kinds of diagrams, starting from the class |
| 00:00:25,670 --> 00:00:28,228 | diagram, which is a fundamental one in UML. |
| 00:00:28,228 --> 00:00:31,390 | The class diagram represents a static, structural view of |
| 00:00:31,390 --> 00:00:34,190 | the system, and it describes the classes and their |
| 00:00:34,190 --> 00:00:34,190 | structure, and the relationships among classes in the system. |