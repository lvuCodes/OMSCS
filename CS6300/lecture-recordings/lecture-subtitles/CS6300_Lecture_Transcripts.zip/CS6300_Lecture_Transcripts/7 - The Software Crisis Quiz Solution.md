# CS6300 7 - The Software Crisis Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:02,440 | So, if you think about what we just discussed. Definitely one |
| 00:00:02,440 --> 00:00:06,210 | of the causes was the increasing product complexity. Products were becoming more |
| 00:00:06,210 --> 00:00:09,510 | and more complex and software was replacing more and more, what |
| 00:00:09,510 --> 00:00:11,860 | was before, provided by hardware components. |
| 00:00:11,860 --> 00:00:14,160 | Slow productivity growth was another problem, |
| 00:00:14,160 --> 00:00:17,350 | because programmers could not keep up with the additional complexity of |
| 00:00:17,350 --> 00:00:19,720 | the software that they had to develop. I would like to say |
| 00:00:19,720 --> 00:00:22,480 | there was lack of funding for software engineering research because I'm |
| 00:00:22,480 --> 00:00:25,230 | a software engineering researcher, but that was not one of the reasons |
| 00:00:25,230 --> 00:00:27,200 | for the software crisis. Instead, it was |
| 00:00:27,200 --> 00:00:30,140 | the rising demand for software. Again, more |
| 00:00:30,140 --> 00:00:32,060 | and more software was being required and |
| 00:00:32,060 --> 00:00:32,060 | more and more software was replacing hardware. |