# CS6300 41 - Classic Mistakes_ Technology

| Timestamp | Content |
|-----------|---------|
| 00:00:00,080 --> 00:00:02,360 | The final type of classic mistakes that I want |
| 00:00:02,360 --> 00:00:06,470 | to mention are technology related mistakes. One typical mistake |
| 00:00:06,470 --> 00:00:09,990 | in this context is the silver-bullet syndrome. What does |
| 00:00:09,990 --> 00:00:13,340 | that mean? Well, the silver-bullet syndrome refers to situations |
| 00:00:13,340 --> 00:00:15,900 | in which there is too much reliance on the |
| 00:00:15,900 --> 00:00:19,950 | advertised benefits of some previously unused technology. For example, |
| 00:00:19,950 --> 00:00:21,980 | a new technology. And the problem here is that |
| 00:00:21,980 --> 00:00:25,140 | we cannot expect technology alone to solve our software |
| 00:00:25,140 --> 00:00:27,810 | development issues. So we should not rely too |
| 00:00:27,810 --> 00:00:31,020 | much on technology alone. Another typical mistake is to |
| 00:00:31,020 --> 00:00:33,700 | switch or add tools in the middle of |
| 00:00:33,700 --> 00:00:36,010 | a project. And sometimes it can make sense to |
| 00:00:36,010 --> 00:00:38,620 | upgrade a tool, but introducing new tools, which |
| 00:00:38,620 --> 00:00:41,650 | can have a steep learning curve, has almost always |
| 00:00:41,650 --> 00:00:46,290 | negative effects. Finally, a common unforgivable mistake is |
| 00:00:46,290 --> 00:00:50,230 | the lack of an automated version control system for |
| 00:00:50,230 --> 00:00:53,480 | your code and for your various artifacts. Manual and |
| 00:00:53,480 --> 00:00:56,700 | ad hoc solutions are just not an option. It is |
| 00:00:56,700 --> 00:00:59,270 | way too easy to make mistakes, use out of |
| 00:00:59,270 --> 00:01:02,600 | date versions, be unable to find a previous working version, |
| 00:01:02,600 --> 00:01:05,030 | and so on. I saw that happening many times, |
| 00:01:05,030 --> 00:01:08,640 | and it always results in a disaster. So be warned, |
| 00:01:08,640 --> 00:01:11,650 | use a version control system and an automated one. And |
| 00:01:11,650 --> 00:01:11,650 | actually we will use version control systems in our projects. |