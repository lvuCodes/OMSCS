# CS6300 43 - Classic Mistakes Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,060 --> 00:00:02,719 | You probably got this one right. The right answer is that |
| 00:00:02,719 --> 00:00:05,330 | this is a people mistake. And despite the fact that this is |
| 00:00:05,330 --> 00:00:07,550 | an easy answer, I just want to make sure to stress |
| 00:00:07,550 --> 00:00:10,800 | once more. Because this is a very classic mistake. And one that |
| 00:00:10,800 --> 00:00:14,070 | can have dire consequences. You should never add people, to a |
| 00:00:14,070 --> 00:00:18,430 | late project. Because in 99.9% of the cases, that's only going to make |
| 00:00:18,430 --> 00:00:21,390 | things worse. Why? Because these people have to be brought up to |
| 00:00:21,390 --> 00:00:25,590 | speed, and also because having more also makes the communication more difficult, |
| 00:00:25,590 --> 00:00:27,690 | the meetings more difficult and so on. So in |
| 00:00:27,690 --> 00:00:27,690 | short, do not add people to a late project. |