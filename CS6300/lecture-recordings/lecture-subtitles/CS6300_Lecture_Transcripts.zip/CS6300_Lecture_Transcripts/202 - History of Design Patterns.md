# CS6300 202 - History of Design Patterns

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:02,780 | Let's start our decision of design patterns by looking |
| 00:00:02,780 --> 00:00:05,280 | at the history of patterns. As you know, I like |
| 00:00:05,280 --> 00:00:07,810 | to give this sort of historical perspective on how and |
| 00:00:07,810 --> 00:00:10,600 | when concepts were defined. In this case, we have to |
| 00:00:10,600 --> 00:00:14,830 | go back to 1977, when Christopher Alexander, an American professor |
| 00:00:14,830 --> 00:00:18,300 | of architecture at UC Berkeley, introduces the idea of patterns, |
| 00:00:18,300 --> 00:00:21,700 | successful solutions to problems, in his book called a Pattern |
| 00:00:21,700 --> 00:00:25,640 | Language. The book contains about 250 patterns. And the idea |
| 00:00:25,640 --> 00:00:27,700 | is that occupants of a building should be able |
| 00:00:27,700 --> 00:00:30,110 | to design it. And the patterns in the book provide |
| 00:00:30,110 --> 00:00:32,368 | a way to do that. And this idea of design |
| 00:00:32,368 --> 00:00:35,964 | patterns, so, a formal way of documenting successful solutions to |
| 00:00:35,964 --> 00:00:41,200 | problems, inspired several other disciplines. In particular, in 1987, |
| 00:00:41,200 --> 00:00:44,810 | Ward Cunningham and Kent Beck leveraged this idea of Alexander's |
| 00:00:44,810 --> 00:00:48,360 | patterns in the context of an object oriented language. |
| 00:00:48,360 --> 00:00:50,840 | And in this specific the language was Smalltalk. |
| 00:00:50,840 --> 00:00:54,492 | Some of you might know the language. So what Cunningham |
| 00:00:54,492 --> 00:00:56,320 | and Beck did, was to create a 5 pattern |
| 00:00:56,320 --> 00:00:59,880 | language for guiding novice Smalltalk programmers. So they did |
| 00:00:59,880 --> 00:01:03,090 | an experiment and had several developers using their patterns, and |
| 00:01:03,090 --> 00:01:06,330 | the experiment was extremely successful. The users were able to |
| 00:01:06,330 --> 00:01:09,940 | create elegant designs using the provided patterns. And in case |
| 00:01:09,940 --> 00:01:12,210 | you are interested in reading about it, Cunningham and Beck |
| 00:01:12,210 --> 00:01:15,660 | reported the results in the article, Using Pattern Languages for |
| 00:01:15,660 --> 00:01:17,940 | Object Oriented Programs, which was published at the |
| 00:01:17,940 --> 00:01:21,854 | International Conference on Object Oriented Programming, Systems, Languages, and |
| 00:01:21,854 --> 00:01:25,390 | Applications, also called OOPSLA, in 1987. At the |
| 00:01:25,390 --> 00:01:28,480 | same time, Eric Gamma was working on his dissertation, |
| 00:01:28,480 --> 00:01:31,030 | whose topic was the importance of patterns and |
| 00:01:31,030 --> 00:01:34,430 | how to capture them. Between 1987 and 1992, there |
| 00:01:34,430 --> 00:01:37,520 | were several workshops related to design patterns. And |
| 00:01:37,520 --> 00:01:40,740 | in 1992, Jim Coplien compiled a catalog of C++ |
| 00:01:40,740 --> 00:01:43,140 | items, which are some sort of patterns, and |
| 00:01:43,140 --> 00:01:45,130 | he listed this catalog of patterns in his |
| 00:01:45,130 --> 00:01:48,720 | book, which was titled Advanced C++ Programming Styles |
| 00:01:48,720 --> 00:01:52,952 | and Idioms. Finally, in 1993 and 1994, there were |
| 00:01:52,952 --> 00:01:56,160 | several additional workshops focused on patterns. And this |
| 00:01:56,160 --> 00:01:59,625 | workshop brought together many patterns folks, including these |
| 00:01:59,625 --> 00:02:03,040 | 4 guys, Erich Gamma, Richard Helm, Ralph Johnson, |
| 00:02:03,040 --> 00:02:06,040 | and John Vlissides. These guys are also known as |
| 00:02:06,040 --> 00:02:08,970 | the gang of 4. And the result of this collaboration was the |
| 00:02:08,970 --> 00:02:11,840 | famous book Design Patterns: Elements of |
| 00:02:11,840 --> 00:02:14,320 | Reusable Object Oriented Software. So this |
| 00:02:14,320 --> 00:02:17,640 | is basically The Book on design patterns. If you want to buy |
| 00:02:17,640 --> 00:02:17,640 | a book on design pattern, this is the one you should get. |