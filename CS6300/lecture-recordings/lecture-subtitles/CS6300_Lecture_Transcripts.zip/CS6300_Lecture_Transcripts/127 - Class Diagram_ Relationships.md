# CS6300 127 - Class Diagram_ Relationships

| Timestamp                     | Content                                                                    |
| ----------------------------- | -------------------------------------------------------------------------- |
| 00:00:00,130 --> 00:00:02,620 | And that's exactly what we're going to look at next,                       |
| 00:00:02,620 --> 00:00:05,630 | relationships in the class diagram, how they're represented and            |
| 00:00:05,630 --> 00:00:08,010 | what they mean. First of all **relationships** as the                      |
| 00:00:08,010 --> 00:00:12,550 | name says, describe **interactions between classes or between objects in** |
| 00:00:12,550 --> 00:00:15,510 | **my system**. And we will describe three main types                       |
| 00:00:15,510 --> 00:00:19,060 | of relationships. The first one is called a **Dependency**                 |
| 00:00:19,060 --> 00:00:22,450 | relationship. And we can express that as X **uses**                        |
| 00:00:22,450 --> 00:00:25,840 | **Y** and we represent it with a **dashed directed line.**                 |
| 00:00:25,840 --> 00:00:28,170 | So when we have such a line between two classes                            |
| 00:00:28,170 --> 00:00:31,020 | that means that the first class uses the second one. And                   |
| 00:00:31,020 --> 00:00:33,520 | we're going to provide an example of a dependency in a                     |
| 00:00:33,520 --> 00:00:37,960 | minute. The second type of relationship is an **association** that can     |
| 00:00:37,960 --> 00:00:40,880 | also be an **aggregation**. We'll see what the distinction is.             |
| 00:00:40,880 --> 00:00:43,470 | But basically, what this means is that we can express that                 |
| 00:00:43,470 --> 00:00:47,640 | as a **X has a y.** So x contains a                                        |
| 00:00:47,640 --> 00:00:50,950 | y. And if it is in **association**, we indicate it with                    |
| 00:00:50,950 --> 00:00:53,570 | a **solid undirected line**. If it's an **aggregation**,                   |
| 00:00:53,570 --> 00:00:55,740 | we indicate it in the same way, but with                                   |
| 00:00:55,740 --> 00:00:58,510 | a **diamond at one of the ends.** Finally, the                             |
| 00:00:58,510 --> 00:01:02,740 | third type of relationship is what is called **Generalization**.           |
| 00:01:02,740 --> 00:01:05,300 | And this can be expressed as **x is a**                                    |
| 00:01:05,300 --> 00:01:09,620 | **y**. So this is the relationship that expresses **inheritance**.         |
| 00:01:09,620 --> 00:01:13,600 | **Specialization between two classes**. It's represented with a **solid**  |
| 00:01:13,600 --> 00:01:16,190 | **directed line with a large open arrow head at**                          |
| 00:01:16,190 --> 00:01:19,030 | **the end. Going from the more specialized class to**                      |
| 00:01:19,030 --> 00:01:21,770 | **the less specialized class. So going from the subclass to**              |
| 00:01:21,770 --> 00:01:24,740 | **the super class**. So now let's look at each relationship                |
| 00:01:24,740 --> 00:01:24,740 | in more detail using our example, our course management system.            |
![[lvu 2026-02-15 at 03.14PM.png]]