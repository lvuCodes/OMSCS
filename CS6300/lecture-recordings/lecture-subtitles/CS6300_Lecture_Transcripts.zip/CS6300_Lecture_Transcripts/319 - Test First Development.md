# CS6300 319 - Test First Development

| Timestamp | Content |
|-----------|---------|
| 00:00:00,040 --> 00:00:03,610 | Which is test-first development. The key idea is that any program |
| 00:00:03,610 --> 00:00:07,210 | feature that doesn't have an automatic test simply does not exist. If |
| 00:00:07,210 --> 00:00:09,430 | there is a feature, you need to write a test for the |
| 00:00:09,430 --> 00:00:13,630 | feature before. So, what developers do is to create unit tests for |
| 00:00:13,630 --> 00:00:17,420 | each such piece of functionality even before the functionality is implemented. |
| 00:00:17,420 --> 00:00:19,720 | And of course, when you run this test, they will fail. But |
| 00:00:19,720 --> 00:00:22,190 | the beauty of it is that, as you write your code and |
| 00:00:22,190 --> 00:00:25,680 | you add more and more fractionality to the feature that you're developing, |
| 00:00:25,680 --> 00:00:27,820 | these test cases are going to start to pass. |
| 00:00:27,820 --> 00:00:30,190 | And that's extremely rewarding because it gives you immediate |
| 00:00:30,190 --> 00:00:32,530 | feedback, again feedback on the fact that you're |
| 00:00:32,530 --> 00:00:34,530 | developing the code in the right way. As soon |
| 00:00:34,530 --> 00:00:37,000 | as you write it, you will know. And if you write a piece of code and the |
| 00:00:37,000 --> 00:00:38,550 | test says still fail, that means that the |
| 00:00:38,550 --> 00:00:38,550 | code is not doing what it's supposed to do. |