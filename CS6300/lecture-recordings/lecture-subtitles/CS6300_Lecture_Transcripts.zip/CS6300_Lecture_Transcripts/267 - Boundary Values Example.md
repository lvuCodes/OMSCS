# CS6300 267 - Boundary Values Example

| Timestamp | Content |
|-----------|---------|
| 00:00:00,200 --> 00:00:03,320 | So now let's go back to our split example. Let me |
| 00:00:03,320 --> 00:00:05,790 | rearrange things a little bit to make more room. So now I'm |
| 00:00:05,790 --> 00:00:09,160 | going to put the domains for size and for strength one next to |
| 00:00:09,160 --> 00:00:12,210 | the other. So let's look at what some possible inputs will be |
| 00:00:12,210 --> 00:00:15,140 | for the sub domains that we identified when we use the idea |
| 00:00:15,140 --> 00:00:17,790 | of selecting input of the boundary. If we look at the first |
| 00:00:17,790 --> 00:00:21,860 | subdomain, size less than zero, one reasonable input is, size equals to |
| 00:00:21,860 --> 00:00:25,360 | minus 1, because minus 1 is the boundary value for the domain |
| 00:00:25,360 --> 00:00:28,530 | of the integers less than zero. If we look at the third |
| 00:00:28,530 --> 00:00:32,119 | subdomain, possibly interesting case is the one of size of equal to |
| 00:00:32,119 --> 00:00:34,900 | 1, for the same reasoning that we used for the previous subdomain, |
| 00:00:34,900 --> 00:00:37,670 | for size less than zero. And, let's try to select another one |
| 00:00:37,670 --> 00:00:40,870 | for this subdomain, for the integers greater than zero. If there is |
| 00:00:40,870 --> 00:00:44,200 | a concept of maximal integer, we can select that one as our |
| 00:00:44,200 --> 00:00:47,140 | boundary value. And of course we could select much more, but this |
| 00:00:47,140 --> 00:00:50,630 | is just to give you an idea. Other possible inputs. One interesting |
| 00:00:50,630 --> 00:00:53,310 | example for the first one, string with length less than |
| 00:00:53,310 --> 00:00:57,690 | size will be a string with length size minus one. Again |
| 00:00:57,690 --> 00:01:00,240 | this is the boundary value for this domain. And we could |
| 00:01:00,240 --> 00:01:03,500 | continue in this way like for example selecting a string who's |
| 00:01:03,500 --> 00:01:07,310 | length is exactly size as a boundary value for this |
| 00:01:07,310 --> 00:01:10,490 | other domain. Instant one, and we look back actually to this |
| 00:01:10,490 --> 00:01:12,940 | example and look at it in a more extensive way when |
| 00:01:12,940 --> 00:01:15,690 | we actually talk about a specific method for doing this kind |
| 00:01:15,690 --> 00:01:15,690 | of process. |