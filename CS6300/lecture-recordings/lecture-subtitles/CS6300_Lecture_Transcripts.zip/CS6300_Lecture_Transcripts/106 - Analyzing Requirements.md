# CS6300 106 - Analyzing Requirements

| Timestamp | Content |
|-----------|---------|
| 00:00:00,250 --> 00:00:01,940 | Now we are at the point in which we |
| 00:00:01,940 --> 00:00:05,590 | have collected and modeled our requirements. So the next thing |
| 00:00:05,590 --> 00:00:08,310 | that we can do is to analyze the requirements to |
| 00:00:08,310 --> 00:00:11,720 | identify possible problems, and specifically there are three types of |
| 00:00:11,720 --> 00:00:14,646 | analysis that we can perform. The first type of analysis |
| 00:00:14,646 --> 00:00:16,820 | is verification. So in this case we're talking about the |
| 00:00:16,820 --> 00:00:19,700 | requirements verification. And in verification |
| 00:00:19,700 --> 00:00:21,990 | developers will study the requirements |
| 00:00:21,990 --> 00:00:25,270 | to check whether they're correct, whether they accurately reflect the |
| 00:00:25,270 --> 00:00:28,710 | customer needs as perceived by the developer. Developers can |
| 00:00:28,710 --> 00:00:32,170 | also check the completeness of the requirements, check whether there |
| 00:00:32,170 --> 00:00:34,510 | are any missing pieces in the requirements as we |
| 00:00:34,510 --> 00:00:37,710 | discussed earlier. They can check whether the requirements are pertinent, |
| 00:00:37,710 --> 00:00:41,260 | or contain irrelevant information, like the one shown here. |
| 00:00:41,260 --> 00:00:44,670 | And they can also check whether they're consistent, unambiguous, testable |
| 00:00:44,670 --> 00:00:46,920 | and so on, so all those properties that should |
| 00:00:46,920 --> 00:00:50,380 | be satisfied for the requirements. A second type of analysis |
| 00:00:50,380 --> 00:00:53,670 | that is typically performed on requirements is validation. And |
| 00:00:53,670 --> 00:00:56,290 | the goal of validation is to assess whether the collected |
| 00:00:56,290 --> 00:00:59,870 | requirements define the system that the stakeholders really want. |
| 00:00:59,870 --> 00:01:02,330 | So the focus here is on the stakeholders. And in |
| 00:01:02,330 --> 00:01:05,670 | some cases, stakeholders can check the requirements directly if |
| 00:01:05,670 --> 00:01:08,910 | the requirements are expressed in a notation that they understand. |
| 00:01:08,910 --> 00:01:11,120 | Or they might check them by discussing them with the |
| 00:01:11,120 --> 00:01:15,490 | developers. Another possibility is that stakeholders asses the requirements by |
| 00:01:15,490 --> 00:01:18,400 | interacting with a prototype of the system, in case |
| 00:01:18,400 --> 00:01:21,690 | the requirements engineering process that is being used involves |
| 00:01:21,690 --> 00:01:25,300 | early prototyping. And finally surveys, testing, and other techniques |
| 00:01:25,300 --> 00:01:28,400 | can also be used to validate requirements. A final type |
| 00:01:28,400 --> 00:01:30,780 | of analysis that we can perform on requirements is |
| 00:01:30,780 --> 00:01:34,430 | risk analysis. And risk analysis aims to identify and |
| 00:01:34,430 --> 00:01:37,680 | analyze the main risks involved with the development of |
| 00:01:37,680 --> 00:01:40,560 | the system being considered. And if some requirements are deemed |
| 00:01:40,560 --> 00:01:43,320 | to be too risky, like in this case, this might result in |
| 00:01:43,320 --> 00:01:47,880 | changes in the requirements model to eliminate or address those risks. And note |
| 00:01:47,880 --> 00:01:49,950 | that all these analysis activities can |
| 00:01:49,950 --> 00:01:52,390 | be performed in many different ways depending |
| 00:01:52,390 --> 00:01:53,990 | on the modeling languages chosen to |
| 00:01:53,990 --> 00:01:53,990 | represent the requirements and on the context. |