# CS6300 342 - Inline Class

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:03,825 | This new refactoring called inline class is the reverse of the extract class |
| 00:00:03,825 --> 00:00:06,700 | refactoring. And know that this is kind of a general situation in the |
| 00:00:06,700 --> 00:00:09,500 | sense that it is often the case that the refactoring also has a |
| 00:00:09,500 --> 00:00:11,480 | reverse refactoring that does exactly the |
| 00:00:11,480 --> 00:00:13,202 | opposite. So basically, un-dos, in a sense, |
| 00:00:13,202 --> 00:00:16,830 | the operation of the other refactoring. In this case, the motivation for the |
| 00:00:16,830 --> 00:00:19,760 | refactoring is that during system evolution, we might end up with one or |
| 00:00:19,760 --> 00:00:22,530 | more classes that do not do much. In this case what you want |
| 00:00:22,530 --> 00:00:25,350 | to do is to take the class that is not doing that much and |
| 00:00:25,350 --> 00:00:28,740 | move its features into another class. And then delete the original class. |
| 00:00:28,740 --> 00:00:31,010 | So let's use an example similar to the one we've used for |
| 00:00:31,010 --> 00:00:34,000 | the previous refactoring to illustrate how this works. Here we have in |
| 00:00:34,000 --> 00:00:37,750 | this case, two classes, person and office. And the person class is |
| 00:00:37,750 --> 00:00:40,720 | using the office class, but this latter class, the office class, only |
| 00:00:40,720 --> 00:00:44,000 | contains a phone number. So it doesn't really do that much. What |
| 00:00:44,000 --> 00:00:47,020 | we can do is therefore to fold the office class into the |
| 00:00:47,020 --> 00:00:50,470 | person class, by simply moving its only field into the class. And so |
| 00:00:50,470 --> 00:00:53,260 | the result will be this person class that also contains the information |
| 00:00:53,260 --> 00:00:53,260 | about the office number, and overall a simpler design for the code. |