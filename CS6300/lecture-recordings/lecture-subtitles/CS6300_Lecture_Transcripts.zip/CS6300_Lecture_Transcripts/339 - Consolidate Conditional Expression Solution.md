# CS6300 339 - Consolidate Conditional Expression Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,080 --> 00:00:03,230 | So the resulting code will be like this. As you can see here, |
| 00:00:03,230 --> 00:00:06,602 | now I don't have the conditionals any longer, but I just have a call to |
| 00:00:06,602 --> 00:00:09,938 | this notEligibleForDisability method. And this makes the code so |
| 00:00:09,938 --> 00:00:14,092 | much clearer, because if I just need to understand how disabilityAmount works, |
| 00:00:14,092 --> 00:00:17,945 | I can clearly see there is an initial check that is actually checking whether |
| 00:00:17,945 --> 00:00:22,030 | an employee's eligible for disabilities or not. And if the check is false, so |
| 00:00:22,030 --> 00:00:26,180 | if the employee's eligible, then I'll just perform the rest of the computation. |
| 00:00:26,180 --> 00:00:27,710 | Otherwise I'll simply return zero. |
| 00:00:27,710 --> 00:00:30,500 | So if I don't need to understand the details of this check, |
| 00:00:30,500 --> 00:00:33,630 | I can simply look at this method and understand it all. And if I need to look at |
| 00:00:33,630 --> 00:00:36,990 | the details I can just go, and look at the implementation of this method, |
| 00:00:36,990 --> 00:00:39,600 | and I will get exactly the same information that I have here. But I'm sort of |
| 00:00:39,600 --> 00:00:43,220 | separating the concerns, and making the code overall more understandable, and |
| 00:00:43,220 --> 00:00:43,220 | therefore more maintainable, which is the main goal of refactoring. |