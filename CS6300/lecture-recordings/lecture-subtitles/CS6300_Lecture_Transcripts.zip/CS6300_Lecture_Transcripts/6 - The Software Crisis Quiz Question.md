# CS6300 6 - The Software Crisis Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,078 --> 00:00:02,480 | So now let's take a quick break and have a recap |
| 00:00:02,480 --> 00:00:05,300 | of what we just discussed. I want you to think about what |
| 00:00:05,300 --> 00:00:07,850 | are the major causes of the software crisis. I'm going to provide you |
| 00:00:07,850 --> 00:00:10,250 | a set of possibilities and I would like for you to mark |
| 00:00:10,250 --> 00:00:14,160 | all that apply. Was that increasing costs of computers? Was it increasing |
| 00:00:14,160 --> 00:00:17,990 | product complexity, or maybe the lack of programmers? Or was it, instead, |
| 00:00:17,990 --> 00:00:20,000 | this slow programmers productivity growth? The |
| 00:00:20,000 --> 00:00:21,540 | lack of funding for software engineering |
| 00:00:21,540 --> 00:00:25,210 | research? The rise in demand for software? And finally, was it maybe |
| 00:00:25,210 --> 00:00:26,500 | the lack of caffeine in software |
| 00:00:26,500 --> 00:00:26,500 | development organizations? Again, mark all that apply. |