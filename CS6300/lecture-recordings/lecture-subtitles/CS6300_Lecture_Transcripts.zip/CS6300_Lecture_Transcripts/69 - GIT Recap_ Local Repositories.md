# CS6300 69 - GIT Recap_ Local Repositories

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,460 | So, let me start by recapping some of the operations that |
| 00:00:02,460 --> 00:00:06,000 | we can perform on local repositories. I'm just going to list them |
| 00:00:06,000 --> 00:00:09,240 | here and go through them by separating them into three main |
| 00:00:09,240 --> 00:00:12,930 | categories. The first one is commands that, to create a repository and |
| 00:00:12,930 --> 00:00:15,470 | notice that not all of these are git commands, that for |
| 00:00:15,470 --> 00:00:18,710 | example, to create the repository, we would normally want to. Create a |
| 00:00:18,710 --> 00:00:21,560 | directory, which is exactly what we did in our demo. We want |
| 00:00:21,560 --> 00:00:25,310 | to go to that directory and then execute the git init statement, |
| 00:00:25,310 --> 00:00:29,110 | which initializes that directory as a git repository. The second |
| 00:00:29,110 --> 00:00:32,530 | category includes commands that we'll use to modify the content of |
| 00:00:32,530 --> 00:00:35,280 | the repository. We saw that we can use git add |
| 00:00:35,280 --> 00:00:39,190 | to add a specific file or a complete directory to our |
| 00:00:39,190 --> 00:00:41,650 | index. So to the list of files that will be |
| 00:00:41,650 --> 00:00:44,510 | committed, that will be considered in the next commit. Then we |
| 00:00:44,510 --> 00:00:47,620 | can use commit to actually commit the changes that we |
| 00:00:47,620 --> 00:00:50,374 | made to those files to our local repository, and we can |
| 00:00:50,374 --> 00:00:54,030 | also use git move and git rm or git remove |
| 00:00:54,030 --> 00:00:57,420 | to move files around and to remove files. Finally, the |
| 00:00:57,420 --> 00:01:00,270 | third category is the category of commands that we can |
| 00:01:00,270 --> 00:01:04,950 | use to inspect the concrete repository. And this set includes git |
| 00:01:04,950 --> 00:01:06,960 | log, that we can use to see the log of |
| 00:01:06,960 --> 00:01:09,970 | the repository, git status, that can give us important information |
| 00:01:09,970 --> 00:01:12,810 | about the status of the file center repository. Git diff, |
| 00:01:12,810 --> 00:01:15,500 | that we can use to see the differences between for example, |
| 00:01:15,500 --> 00:01:19,160 | our local files. And the remote files. And finally git |
| 00:01:19,160 --> 00:01:23,270 | show, that will show us information about our last commit. What |
| 00:01:23,270 --> 00:01:25,940 | we committed, what were the changes and so on. And again, |
| 00:01:25,940 --> 00:01:29,290 | we saw most or all of these commands in our demo. |
| 00:01:29,290 --> 00:01:31,920 | So let me also remind you of a possible workflow. Which |
| 00:01:31,920 --> 00:01:34,350 | again, we already saw but it's always good to go through |
| 00:01:34,350 --> 00:01:37,670 | it once more. And remember that this is just an example. |
| 00:01:37,670 --> 00:01:40,520 | It's just a possible workflow. You can do many different things, |
| 00:01:40,520 --> 00:01:43,210 | you can have many different workflows with git. This is just |
| 00:01:43,210 --> 00:01:45,980 | up to illustrate some of the things that you can do. So, |
| 00:01:45,980 --> 00:01:49,430 | you might do some local editing. Execute git status to see what |
| 00:01:49,430 --> 00:01:53,020 | files you changed. Then you might run a git diff on the |
| 00:01:53,020 --> 00:01:56,230 | files to see what are these changes. And then you can run |
| 00:01:56,230 --> 00:01:59,460 | git commit -a to commit your changes. And in case you |
| 00:01:59,460 --> 00:02:02,520 | want to specify the commit message right away without having to go |
| 00:02:02,520 --> 00:02:06,040 | through an editor, you can also add the -m parameter and |
| 00:02:06,040 --> 00:02:06,040 | specify the message here on the same line. |