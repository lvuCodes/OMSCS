# CS6300 300 - B&C Coverage Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,130 --> 00:00:02,969 | So let's have another quiz using the example that we just |
| 00:00:02,969 --> 00:00:06,660 | used. This one is about achieving 100% branch and condition coverage. So |
| 00:00:06,660 --> 00:00:08,850 | let me bring back the two tests cases that we just saw, |
| 00:00:08,850 --> 00:00:11,420 | and as we saw a few minutes ago, these tests cases do |
| 00:00:11,420 --> 00:00:15,540 | not achieve 100% branch and condition coverage despite the fact that they |
| 00:00:15,540 --> 00:00:19,430 | achieve 100% condition coverage. So both conditions are both true and false, |
| 00:00:19,430 --> 00:00:21,820 | for these test cases. So what I want you to do is |
| 00:00:21,820 --> 00:00:25,630 | to add a test case, to achieve 100% branch and condition coverages. |
| 00:00:25,630 --> 00:00:25,630 | So specify the test case by writing here the value for x, and the value for y. |