# CS6300 164 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,360 --> 00:00:02,910 | Hello, and welcome to the third part |
| 00:00:02,910 --> 00:00:06,426 | of our software engineering course. In this mini-course, |
| 00:00:06,426 --> 00:00:09,250 | we will discuss software design. We will |
| 00:00:09,250 --> 00:00:13,170 | also introduce the Unified Software Process. And we |
| 00:00:13,170 --> 00:00:15,730 | will work on a more complex project, |
| 00:00:15,730 --> 00:00:18,330 | in which we will develop a distributed software |
| 00:00:18,330 --> 00:00:22,960 | system that involves multiple different platforms. In |
| 00:00:22,960 --> 00:00:25,730 | our first lesson of this mini-course, in particular, |
| 00:00:25,730 --> 00:00:28,150 | we will talk about software architecture. A |
| 00:00:28,150 --> 00:00:31,650 | software engineering discipline whose goal is to lay |
| 00:00:31,650 --> 00:00:34,980 | the foundation on which to build successful |
| 00:00:34,980 --> 00:00:34,980 | and long lasting software systems. So let's begin. |