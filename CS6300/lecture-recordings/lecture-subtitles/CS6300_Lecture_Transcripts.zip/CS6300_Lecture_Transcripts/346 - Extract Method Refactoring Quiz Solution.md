# CS6300 346 - Extract Method Refactoring Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:03,000 | The first scenario is the typical case in which it is |
| 00:00:03,000 --> 00:00:07,040 | recommended to use the extract method refactoring, when there is duplicated code |
| 00:00:07,040 --> 00:00:09,190 | in two or more methods and we want to take this |
| 00:00:09,190 --> 00:00:12,420 | code and factor is out, and basically have the two methods called |
| 00:00:12,420 --> 00:00:14,960 | a third method, which is the one we create using the |
| 00:00:14,960 --> 00:00:18,060 | refactoring. When a class is too large, normally we don't want to |
| 00:00:18,060 --> 00:00:21,330 | apply the extract. Extract method. Instead, in this cases, it is |
| 00:00:21,330 --> 00:00:22,900 | usually more appropriate to use the |
| 00:00:22,900 --> 00:00:26,420 | extract class or extract subclass refactorings. |
| 00:00:26,420 --> 00:00:29,750 | Analogously, when the names of two classes are too similar, extracting a |
| 00:00:29,750 --> 00:00:32,729 | method will normally not help much. And all we need to do |
| 00:00:32,729 --> 00:00:35,810 | in case having too similar names is actually a problem. Is to |
| 00:00:35,810 --> 00:00:39,600 | rename one of the two classes, or both, if we wish. Finally, |
| 00:00:39,600 --> 00:00:42,530 | it is definitely appropriate to apply the extract method of refactoring in |
| 00:00:42,530 --> 00:00:45,900 | cases in which a method is highly coupled with a class other |
| 00:00:45,900 --> 00:00:48,330 | than the one where it is defined. In this case, which we |
| 00:00:48,330 --> 00:00:51,740 | will discuss also later in the lesson, the extract method of refactoring |
| 00:00:51,740 --> 00:00:55,710 | allows us to extract part of the metal to With the other class. |
| 00:00:55,710 --> 00:00:58,690 | Then we can take the matter that we just extracted and move it |
| 00:00:58,690 --> 00:01:01,880 | to the class where it actually belongs. So the extract method is one |
| 00:01:01,880 --> 00:01:01,880 | of the two refactorings that it is appropriate to apply in these cases. |