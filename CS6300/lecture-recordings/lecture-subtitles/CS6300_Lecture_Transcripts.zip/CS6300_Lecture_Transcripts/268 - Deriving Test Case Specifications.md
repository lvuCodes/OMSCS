# CS6300 268 - Deriving Test Case Specifications

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,790 | Now, let's go back to our systematic functional testing |
| 00:00:02,790 --> 00:00:05,540 | approach and all the steps in this process. So |
| 00:00:05,540 --> 00:00:07,680 | far we've seen the first step and the second |
| 00:00:07,680 --> 00:00:10,340 | step. Now we're going to look at this step in which, |
| 00:00:10,340 --> 00:00:13,290 | once we have identified the values of interest, we |
| 00:00:13,290 --> 00:00:18,110 | derive test case specifications for these values, or using these |
| 00:00:18,110 --> 00:00:21,300 | values. And the test case specification defines how the |
| 00:00:21,300 --> 00:00:25,230 | values should be put together when actually testing the system. |
| 00:00:25,230 --> 00:00:29,110 | And test case specification describe how these values should be put |
| 00:00:29,110 --> 00:00:32,360 | together when testing the system. So let me go back one more |
| 00:00:32,360 --> 00:00:34,780 | time to our split program, so that we can use the |
| 00:00:34,780 --> 00:00:37,450 | information that we already computed. At this point what we have is |
| 00:00:37,450 --> 00:00:41,670 | some possible inputs for "string," our first parameter, and for "size," |
| 00:00:41,670 --> 00:00:44,410 | our second parameter. And we want to put them together, to generate |
| 00:00:44,410 --> 00:00:47,080 | the description of what the test case should be. So let |
| 00:00:47,080 --> 00:00:50,420 | me once more rearrange this a little bit. I first remove the |
| 00:00:50,420 --> 00:00:53,360 | description of the subdomains, because we won't use them in this step. |
| 00:00:53,360 --> 00:00:55,800 | And I moved out the set of all our possible inputs, that we're |
| 00:00:55,800 --> 00:00:59,470 | going to combine to create the test case specification. And one possible way |
| 00:00:59,470 --> 00:01:03,320 | of doing that is simply to combine the values for the first parameter, |
| 00:01:03,320 --> 00:01:06,370 | and the values for the second parameter. So the Cartesian product. So |
| 00:01:06,370 --> 00:01:09,060 | if we do that, what we will obtain is, for example, if we |
| 00:01:09,060 --> 00:01:12,470 | consider the first possible input, size is equal to minus 1, we can |
| 00:01:12,470 --> 00:01:15,510 | combine it with these two possible inputs for string, and we will get |
| 00:01:15,510 --> 00:01:18,680 | size is equal to minus 1 string with length minus 2, or |
| 00:01:18,680 --> 00:01:21,680 | size is equal to minus 1 string with length minus 1. And we'll |
| 00:01:21,680 --> 00:01:24,200 | go back in a second to see what this means. Now if we |
| 00:01:24,200 --> 00:01:27,510 | consider the second possible value for size, size is equal to one, we |
| 00:01:27,510 --> 00:01:30,260 | also have two cases so the first one in this case that will |
| 00:01:30,260 --> 00:01:34,030 | be considered a string with length zero. So the antistring. And we can |
| 00:01:34,030 --> 00:01:37,410 | continue combining this value, but one thing I want to point out is |
| 00:01:37,410 --> 00:01:40,570 | that if we just go in this straight forward and brute force sort |
| 00:01:40,570 --> 00:01:43,390 | of way, we will obtain many combinations that don't make any sense, |
| 00:01:43,390 --> 00:01:46,500 | like for example, this combination which doesn't make any sense because we can |
| 00:01:46,500 --> 00:01:50,410 | not create the string with length minus 2. Similar for this combination, because |
| 00:01:50,410 --> 00:01:53,190 | then by the same token, we cannot raise things with length minus 1. |
| 00:01:53,190 --> 00:01:55,730 | And so there's a lot of cases that we will have to eliminate |
| 00:01:55,730 --> 00:01:59,380 | afterwards. So what we're going to see in a few minutes is a possible |
| 00:01:59,380 --> 00:02:02,970 | way in which we can avoid producing these meaningless cases. And at the |
| 00:02:02,970 --> 00:02:06,380 | same time, keep under control, the number of test cases that we generate. |
| 00:02:06,380 --> 00:02:09,070 | So let's go back for the last time to our steps |
| 00:02:09,070 --> 00:02:11,980 | for systematic functional testing. What we just did was to derive |
| 00:02:11,980 --> 00:02:15,040 | test case specification from a set of relevant inputs. The following |
| 00:02:15,040 --> 00:02:18,420 | step is to use these test case specifications to generate actual test |
| 00:02:18,420 --> 00:02:21,170 | cases. And this is normally a fairly mechanical step in the |
| 00:02:21,170 --> 00:02:23,900 | sense that we just have to instantiate what is in the test |
| 00:02:23,900 --> 00:02:27,970 | case specification as actual test cases. And it's really dependent on |
| 00:02:27,970 --> 00:02:32,300 | the specific type of partitions and values identified on the specific context. |
| 00:02:32,300 --> 00:02:35,100 | So instead of looking at that here in the, in the abstract, |
| 00:02:35,100 --> 00:02:35,100 | I'm going to show you with an example later on, in the lesson. |