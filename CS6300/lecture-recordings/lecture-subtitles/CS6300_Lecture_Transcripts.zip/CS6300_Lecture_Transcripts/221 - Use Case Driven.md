# CS6300 221 - Use Case Driven

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:02,370 | Now let's go back to the distinguishing aspects of |
| 00:00:02,370 --> 00:00:04,710 | RUP, starting from the first one. That is, that the |
| 00:00:04,710 --> 00:00:08,170 | rational unified process is use-case driven. So let's see what |
| 00:00:08,170 --> 00:00:11,310 | that means. Generally speaking, we can see a system as |
| 00:00:11,310 --> 00:00:14,500 | something that performs a sequence of actions in response to |
| 00:00:14,500 --> 00:00:18,100 | user inputs. So the user submits some requests, or requests |
| 00:00:18,100 --> 00:00:22,140 | some functionality, and the system responds to those requests. Use |
| 00:00:22,140 --> 00:00:25,750 | cases, as we just said, capture exactly this interaction and |
| 00:00:25,750 --> 00:00:28,620 | answer the question, what is the system supposed to do |
| 00:00:28,620 --> 00:00:32,150 | for each user? So, this is a very important point. |
| 00:00:32,150 --> 00:00:34,160 | So they can represent what a system can do for |
| 00:00:34,160 --> 00:00:37,240 | each of the different types of users of the system. |
| 00:00:37,240 --> 00:00:39,430 | For this reason, and as we will see in more |
| 00:00:39,430 --> 00:00:42,430 | detail, in the rational unified process, use cases are a |
| 00:00:42,430 --> 00:00:46,680 | central element of the whole development life cycle. From requirements |
| 00:00:46,680 --> 00:00:51,360 | engineering, all the way through the process until testing and maintenance. |
| 00:00:51,360 --> 00:00:54,620 | So, once more, use cases are used to support and |
| 00:00:54,620 --> 00:00:54,620 | help each one of these phases in the rational unified process. |