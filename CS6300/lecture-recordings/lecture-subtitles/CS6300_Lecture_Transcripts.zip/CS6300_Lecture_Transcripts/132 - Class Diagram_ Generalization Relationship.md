# CS6300 132 - Class Diagram_ Generalization Relationship

| Timestamp                     | Content                                                                       |
| ----------------------------- | ----------------------------------------------------------------------------- |
| 00:00:00,100 --> 00:00:02,420 | The third type of relationship that we saw, is                                |
| 00:00:02,420 --> 00:00:07,060 | Generalization. Generalization is a relationship between a **general class**, |
| 00:00:07,060 --> 00:00:10,150 | **which we normally call super-class and the more specific**                  |
| 00:00:10,150 --> 00:00:13,510 | **class, a class the refines the super-class and that**                       |
| 00:00:13,510 --> 00:00:16,950 | **we normally call sub-class.** It's also known as a                          |
| 00:00:16,950 --> 00:00:19,690 | **is a kind of** or **is a** relationship because we can                      |
| 00:00:19,690 --> 00:00:22,850 | say that the **subclass is a super class** and                                |
| 00:00:22,850 --> 00:00:25,450 | it's expressed with **a solid line with a big arrow**                         |
| 00:00:25,450 --> 00:00:27,580 | **head at the end**. So let's see an example of                               |
| 00:00:27,580 --> 00:00:30,160 | that. In this case I'm going to indicate. Two of this kind                    |
| 00:00:30,160 --> 00:00:33,950 | of relationships. The first one involving the RegistrationUser and            |
| 00:00:33,950 --> 00:00:37,000 | a student. And the second one, a RegistrationUser and the                     |
| 00:00:37,000 --> 00:00:39,960 | professor. So, basically what we're showing here is a                         |
| 00:00:39,960 --> 00:00:43,170 | typical case in which the registration user is a more general                 |
| 00:00:43,170 --> 00:00:46,630 | concept then the Student and the Professor. So both the student               |
| 00:00:46,630 --> 00:00:50,710 | and the professor are RegistrationUsers. So there is a relationship,          |
| 00:00:50,710 --> 00:00:54,360 | the Professor is a registration user and the Student is a RegistrationUser.   |
| 00:00:54,360 --> 00:00:56,780 | And therefore we can indicate that using                                      |
| 00:00:56,780 --> 00:00:56,780 | the generalization relationship in our class diagram.                         |
![[lvu 2026-02-15 at 03.36PM.png]]