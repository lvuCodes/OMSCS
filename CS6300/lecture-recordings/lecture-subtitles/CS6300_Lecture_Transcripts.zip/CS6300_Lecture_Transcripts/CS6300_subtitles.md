# CS6300 Lecture Subtitles

## 0 - Introduction

| Hi, everybody, and welcome to the first lesson |
| of the Software Engineering Course. In this introductory lesson |
| I will first provide an overview of the |
| whole course and then try to answer two important |
| questions about software engineering, which are, what is |
| software engineering and why do we need it? And |
| to spice up the content a bit I |
| will also interview several experts in the software engineering |
| field from both academia and industry and ask them these |
| very questions. So without any further ado, let's begin the lesson. |

## 1 - Importance of Software Engineering

| First, let me start by asking a couple of very |
| natural questions that you might have when considering whether to take |
| this course. The first one is what is software engineering. |
| And the second, very related one, is why do we need |
| it? So what I did was actually to go out |
| and ask some of the main experts in the field, both |
| in academia and industry, these very questions and let's see what |
| they said. What is software engineering and why is it important? |
| >> Okay, can I start with another question? |
| >> Of course. |
| >> Okay, first what is a computer? It's a programmable device. So the essence |
| of computing is programming. So program development |
| is basically the most essential use of the |
| computer. So software engineering is the discipline |
| that investigates program development. So, how can it |
| been done more efficiently? What's the best |
| way of doing program development? And how can |
| you develop reliable programs? So that's how I would define |
| it. But I consider any |
| software development activity software engineering activity |
| >> Software engineering is the systematic application of methods to build |
| software in a rigorous way. And I think one of the |
| aspects that I like to bring into the notion of software |
| engineering is that it's something that involves not only kind of |
| technically building the system but understanding the |
| requirements, working with stake holders. Trying to |
| find a solution that balances all of the stakeholder needs in order to deliver |
| the software thats tested and its rigorous to meet the needs of a stakeholder. |
| Well, software engineering is the whole process |
| of creation of software using engineering principles. |
| >> My view is kind of a holistic |
| view and I think about it from the perspective |
| of how is software engineering different from programming. |
| So, I think that research about programming is all |
| about the create part of software. And that |
| software engineering is about the entire life cycle. So, |
| that's one aspect. And the other aspect of the |
| definition is it's about quality, the quality of software. |
| Software engineering even considers things long after you ship which we all know |
| is one of the, it is the largest economic piece of software development. |
| >> So, improve, software engineering process |
| for better software productivity and quality. |
| >> The set of activities that one engages in when building software |
| systems or software products. It's fundamentally a venue-creating |
| activity. It involves social processes. |
| >> Software engineering is the act |
| of many people working together and putting |
| together many versions of large and complex |
| systems. And our world depends on software, |
| software is immensely complex and we need |
| many, many smart people to build these things. |
| >> Well, engineering I think is the activity of envisioning and |
| realizing valuable new functions with sufficient |
| and justifiable confidence that the resulting |
| system will have all of the critical quality attributes that are necessary |
| for the system to be a success. And software engineering is the |
| activity of doing this not only for |
| the software components of engineering systems but |
| for the system overall, given that it's |
| so heavily reliant on it's underlying software technologies. |
| >> So, I would say software engineering is the |
| kind of art and practice of building software systems. |
| >> Software engineering, in a nutshell, is a set of |
| methods and principles and techniques that we have developed to enable us to |
| engineer, or build, large software systems that |
| outstrip or outpace one engineer's or even a small |
| team of engineer's ability or abilities to understand |
| and construct and maintain |
| over time. So it requires a lot of people, it requires a long, |
| term investment by an organization or a number of organizations, and often times |
| it requires support for systems that that are intended for one purpose but end |
| up getting used for many additional purposes in addition to the original one. |
| >> Software engineering is about building and constructing very large-scale |
| high-quality systems, so the high quality is the big issue. |
| >> Software engineering is engineering discipline of developing |
| software-based systems, usually embedded into larger systems composed of |
| hardware and and humans [LAUGH] and business |
| processes and processes in general. And why is that important? |
| Well, because software is pervasive in all industry sectors |
| and therefore systems must be reliable, safe and secure. |
| >> Why can't we just get that by sitting down and writing software? |
| >> Well, you could if software was small and |
| simple enough to be developed by one or two |
| people together in a room. But software development now |
| is distributed, involves teams of people with different backgrounds |
| who have to communicate with each other. It also involves customers, |
| clients, users. Software engineers have to work with |
| hardware engineers, with domain experts and therefore, |
| well, no, we can't simply sit down and start coding. |
| >> Software engineering is mostly being able |
| to program. And you need to be able to put big |
| systems together so that they actually work. That's my simple definition. |
| >> And if you don't use software engineering practices, |
| you're not going to be able to put them together? |
| >> Well, you're not going to be able to reliably |
| put them together. So basically, you could maybe hack something up, |
| but it's not going to necessarily stand the test of time. |
| If somebody wants to change it it's probably going to break. |
| >> It's important |
| because if you don't think about how you're building this system and |
| how you're trading off different aspects, |
| like performance and scalability and reliability, then |
| it's going to end up breaking or not lasting very long or not, |
| not doing everything that you want it to do, or being really expensive. |
| >> If it's not done in a principled way it will |
| be bad and every user will suffer. That's why we need |
| software engineering. |
| >> Why is it important? Because, I mean these two goal, productivity, faster, |
| in developing software. And higher quality |
| would be apparently important. Software is everywhere. |
| >> It's important because we use software in everyday life. Everything's |
| built on software systems. And these are ubiquitous across our society. |
| >> It's |
| important because software is everywhere around us and the way we build it, |
| and the way we maintain it, is something that determines almost a basic |
| quality of life nowadays. And getting that software right can make a difference, |
| oftentimes, between a really fun product and one that you won't like to use |
| a reasonably successful company, or one that fails. And in |
| more extreme cases even the difference between life and death, |
| if you think about the software that runs in the |
| airplane on which many of you fly on a regular basis. |
| >> There are programs out there that if they screw up we are all screwed. |
| >> Software engineering is crucially |
| important because it's the engineering discipline |
| that is uniquely capable of carrying out |
| the engineering mission for software reliant systems. |
| >> In the U.S we've all seen an unfortunate example with |
| a system that went badly wrong in healthcare.gov and that system wasn't |
| engineered correctly. And I think if we look at the reasons for |
| that, they stem back to somewhere at the intersection between requirements and |
| architecture and politics and project management, and all of these things are |
| important concepts that have to go into the software engineering mix. |
| >> It would end up in lots and lots of chaos because people |
| wouldn't know how to organize themselves and |
| wouldn't know how to organize software. Many |
| of software engineering has very simple rules that you need to apply properly in |
| order to get things done. And people who look at these rules and think, |
| these rules are so super simple. This is totally obvious. But once |
| you try to apply them, you'll find out they're not obvious at all. |
| >> Now that we've heard these experts, let me show you an |
| example that illustrates what can happen |
| when software engineering practices are not suitably |
| applied. [NOISE]. |

## 2 - Software Failure Quiz Question

| Now that you watched this small video, I like |
| to ask you, what is this? Do you think |
| it's fireworks for the 4th of July celebration, or |
| maybe it was a flare gun in action, or |
| maybe again it was the explosion of the Ariane |
| five rocket due to a software error. What do |
| you think? And in case it helps, I'm also |
| going to show you an actual picture of this event. |

## 3 - Software Failure Quiz Solution

| As you probably guessed, these are not fireworks for the 4th of |
| July but, rather, the explosion of the Ariane 5, which happened 30 seconds |
| or so after takeoff due to a software error. And this is |
| just an example of what can go wrong when we don't build software |
| and we don't test and verify and perform quality assurance of software |
| in the right way, and quite an expensive one. In fact, to develop |
| and to build the Ariane 5 it took 10 years. The cost |
| was around $7 billion and there were $500 million of cargo on board. |
| Luckily, at least there were no humans on the |
| rocket. And you can find more details in case |
| you're interested about the Ariane 5 accident in the |
| lesson notes. I put a couple of links there. |

## 4 - Discipline of Software Engineering

| And even if we don't go to these extreme examples, I'm |
| sure that you have all experienced |
| software problems, typically manifested in what |
| we call a crash. And that crash might happen while you're |
| finishing your homework or that three-page long email that you were preparing |
| for the last two hours. But why's it so difficult to |
| build software, or better, why's it so difficult to build good software? |
| And how can we do it? This is exactly the topic |
| of this class. And the reason why software engineering is a fundamental |
| discipline in computer science. To motivate that, in this class, we |
| will study a set of methodologies, techniques, and tools, that will help |
| us build high quality software that does what it's supposed to |
| do. And therefore, makes our customers happy. And that does it within |
| the given time and money constraints. So within the budget that |
| is allocated for the software. Before |
| jumping into today's software engineering techniques |
| though, let me take a step back and look at how |
| we got here, as I believe it is very important to have |
| some historical perspective on how this discipline was |
| born and how it was developed over the years. |

## 5 - The Software Crisis

| To do that we'll have to go back in time to |
| the late 60s. So what was happening in the 60s? Well for |
| example the first man landed on the moon. That was also |
| time when Woodstock took place and also the time when the first |
| 60 second picture from Polaroid was created. Concurrently to these events, |
| which you probably didn't witness in first person, that was also the |
| time when people started to realize that they were not able |
| to build the software they needed. This happened for several reasons and |
| resulted in what we call the software crisis. So let's |
| look at some of the most important reasons behind this |
| crisis. The first cause was the rising demand for software. |
| Now you're used to see software everywhere: in your phone, |
| in your car, even your washing machine. Before the 60s, |
| however, the size and complexity of software was very limited |
| and hardware components were really dominating the scene. Then things |
| started to change and software started to be increasingly prevalent. |
| So we move from a situation where everything was mostly |
| hardware to a situation in which software became more and more |
| important. To give an example, I'm going to show you the growth |
| in the software demand at NASA along those years. And in |
| particular, from the 1950s to more or less 2000. And this |
| is just a qualitative plot but that's more or less the |
| ways things went. So the demand for software in NASA grow |
| exponentially. And the same happened in a lot of other companies. |
| For example, just to cite one, for Boeing. So the |
| amount of software on airplanes became larger and larger. The |
| second cause for the software crisis was the increasing amount |
| of development effort needed due to the increase of product complexity. |
| Unfortunately, software complexity does not increase linearly with size. It |
| is not the same thing to write software for a |
| class exercise or a small project, or a temp project, |
| than it is to build a software for a word processor, |
| an operating system, a distributed system, or even more complex and larger |
| system. And what I'm giving here is just an indicative size for |
| the software so the class exercise might be 100 lines of code, |
| the small project might be 1000 lines of code, in the other thousand |
| lines of code, and so on and so forth. For the former, |
| the heroic effort of an individual developer can get the job done. |
| So that's what we call a programming effort. If you're a good |
| programmer, you can go sit down and do it, right. For the latter, |
| this is not possible. This is what we called the |
| software engineering effort. In fact, no matter how much programming languages, |
| development environments, and software tools improve, developers could not keep |
| up with increasing software size and complexity. Which leads us to |
| the third problem that I want to mention and the |
| third reason for the software crisis. And this cause is the |
| slow developer's productivity growth. So let me show this again |
| with a qualitative diagram. And this is taken from the IEEE |
| Software Magazine. And what I'm showing here is the growth in |
| software size and complexity over time, and how the developers' productivity |
| really couldn't keep up with this additional software complexity, which resulted |
| in this gap between what was needed and what was actually available. |

## 6 - The Software Crisis Quiz Question

| So now let's take a quick break and have a recap |
| of what we just discussed. I want you to think about what |
| are the major causes of the software crisis. I'm going to provide you |
| a set of possibilities and I would like for you to mark |
| all that apply. Was that increasing costs of computers? Was it increasing |
| product complexity, or maybe the lack of programmers? Or was it, instead, |
| this slow programmers productivity growth? The |
| lack of funding for software engineering |
| research? The rise in demand for software? And finally, was it maybe |
| the lack of caffeine in software |
| development organizations? Again, mark all that apply. |

## 7 - The Software Crisis Quiz Solution

| So, if you think about what we just discussed. Definitely one |
| of the causes was the increasing product complexity. Products were becoming more |
| and more complex and software was replacing more and more, what |
| was before, provided by hardware components. |
| Slow productivity growth was another problem, |
| because programmers could not keep up with the additional complexity of |
| the software that they had to develop. I would like to say |
| there was lack of funding for software engineering research because I'm |
| a software engineering researcher, but that was not one of the reasons |
| for the software crisis. Instead, it was |
| the rising demand for software. Again, more |
| and more software was being required and |
| more and more software was replacing hardware. |

## 8 - Evidence of the Software Crisis

| After recapping the three major issues that characterize a software crisis |
| let's see what was the evidence that there was indeed a |
| crisis. So what I want to discuss now is the result |
| of a study performed by Davis in 1990s. So in even |
| more recent times than the 60s and the 70s. And the |
| study was performed on nine software projects that were totaling a |
| cost around $7 million and I'm going to show you how this |
| projects went using this representation, this pi representation, in which I'm |
| going to discuss what each of the segment of the |
| pi represent. So let's start looking at the first one. |
| This is a software that was usable as delivered. Other |
| software was delivered, and usable, either after some changes or |
| after some major modifications, so within additional costs involved. |
| But the striking piece of information here is that the |
| vast majority of the software, so these two slices, were |
| software that was either delivered but never successfully used or |
| software that was not even delivered. And this corresponded |
| to five over the seven total million dollars for |
| all the projects. So clearly, this shows a pretty |
| grim picture for software development and its success. In short, |
| there was clear evidence the software was becoming to |
| difficult too build and that the software industry was facing |
| a crisis. And this is what led to the |
| NATO Software Engineering Conference that was held in January 1969, |
| which is what we can consider the birth of software engineering. And what |
| I'm showing here is a drawing of the proceedings for that conference. And if |
| you look at the class notes you can see a link to the actual |
| proceedings, in case you are interested in |
| looking at the issues that were discussed. |

## 9 - Software Development

| Now that we saw how software engineering was born and we |
| saw some of the problems that led to the birth of software |
| engineering. Let's see how we can do better. How can we |
| preform software development in a smarter, in a better way, a more |
| successful way? So what I'm going to show here is the |
| way I see software development. To |
| me software development is fundementally going |
| from an abstract idea in somebody's head, for example, the customer's head, |
| to a concrete system that actually implements that idea and hopefully it |
| does it in the right way. And this is a very |
| complex process. It can be overwhelming. So, unless we are talking about |
| the trivial system, it's very complex for us to keep in mind |
| all the different aspects of the systems, and to do all the |
| different steps required to build this system, automatically. So that's when |
| software processes come to the rescue. So what is a software process? |
| A software process is nothing else but a way of breaking down |
| this otherwise unmanageable task into smaller steps. In smaller steps that we |
| can handle. And that can be tackled individually. So having a |
| software process is of fundamental importance for several reasons. First of |
| all, for non-trivial systems, you can't just do it by getting |
| it, by just sitting down and developing. What you have to |
| do instead is to break down the complexity in a systematic |
| way. So software processes are normally systematic. And you need to |
| break down this complexity, in a more or less formal way. |
| So software processes are also a formal, or semiformal, way of |
| discussing, or describing, how software should be developed. |
| So what are the steps involved in developing software? |

## 10 - Software Process

| One thing you need to know right away about software processes |
| is that there's not just one single process, but there are multiple, |
| possible processes, depending on your context, depending on the kind of |
| applications that you are developing. In this course, we are going to try |
| to cover the spectrum of the possible processes, as much as |
| possible, by focusing on four main software processes. The first one is |
| what we call normally the waterfall process. And, we call it waterfall |
| because in the process we go from one phase to the other |
| in the same way in which water follows the flow |
| in a waterfall. The second process that we consider is what |
| we call evolutionary prototyping, and in this case, instead of |
| following this set of rigid steps, all we're trying to do |
| is to start with an initial prototype and evolve it |
| based on the feedback from the customer. We will then move |
| towards a slightly more formal process, which is the rational unified |
| process or the unified software process. And this is a kind |
| of project heavily based on the use of UML, so we |
| will also cover UML when discussing this kind of project. Finally, |
| the fourth kind of process we will consider is the family |
| of agile software processes. And these are processes in which we |
| sacrifice the discipline a little bi,t in order to be more |
| flexible and be more able to account for changes and in |
| particular for changes in requirements. We are going to cover each |
| one of these four processes extensively in the rest of the class. |

## 11 - Preliminary Questions Question

| So, now before we actually jump to the |
| discussion of software processes I want to ask you |
| a couple of preliminary questions. The first one is, |
| what is the largest software system on which you |
| had worked? And you should enter here the size. |
| And the second question I'm going to ask is how |
| many LOC or how many lines of code per |
| day you were producing when working on this system? |

## 12 - Preliminary Questions Solution

| We're going to go back to these two questions |
| and to your answers later. But I wanted to |
| gather this information beforehand, so that your answers are |
| not biased, they're not influenced by this subsequent discussion. |

## 13 - Preliminary Questions Question

| So now I want to ask you one additional question, which is how many lines |
| of code a day do you think professional |
| software engineers produce? Do you think they produce |
| 25 lines of code? Between 25 and 50? Between 50 and 100? Between 100 and 1000? |
| Or more than 1000 a day? And remember |
| that here we're talking about professional software engineers. |

## 14 - Preliminary Questions Solution

| Studies has shown that, on average, developers produce between |
| 50 and 100 lines of code a day. And that |
| might not seem much. Why, why only 50 to |
| 100 lines of code in a whole day? And the |
| answer is because coding is not everything. When you |
| develop a system writing code is not the only thing |
| you have to do. It's not the only activity that |
| you have to perform. And that's a very important point. |

## 15 - Software Phases

| In fact, software processes are normally characterized by several phases, what |
| we call the software phases, and only one of these phases is |
| mainly focused on coding. The other phases are meant to support |
| other parts of software development. The first of these phases is called |
| requirements engineering and that's the phase in which we talk to |
| the customer, to the stakeholders, whoever we are building the software for. |
| And we try to understand what kind of system we need |
| to build. Then we use this information to define our design and |
| the design is the high-level structure, that then can become more |
| and more detailed, of our software system. Once we've defined our |
| design we can actually move to the next phase, which is |
| the implementation, in which we write code that implements the design which |
| we just defined. After implementing the code, we need to verify |
| and validate the code. We need to make sure that the code |
| behaves as intended. And finally, we need to maintain the code. |
| And maintenance involves several activities like, |
| for example, adding new functionality or |
| eliminating bugs from the code or responding to problems that |
| were reported from the field after we released the software. |
| We will look at all of these activities and of |
| the software development process in detail, in the rest of the |
| class. And for each activity, we will look at the |
| fundamental principles and how it is done currently. And in |
| some cases, we will also look at some advance ways |
| to do it. For example, more research approaches for that activity. |

## 16 - Tools of the Trade

| We will also look at how tools can improve software phases, |
| the software activities, and can support software development tasks in general. |
| And this is something that I will repeat over and over |
| in the class, tools and automation are fundamental, in software engineering. |
| And they're fundamental for improving productivity, not only efficiency but also |
| effectiveness of our activities in the software development process. So let |
| me go back to one of the diagrams that I showed |
| you before. If you remember we had this qualititive diagram in which |
| we were showing that one of the issues that led to the |
| software crisis was the fact that developers' productivity was not able to |
| keep up with the software size and complexity, with the growth in |
| the importance and the complexity of software. What tools can help us |
| to do is to change this and basically move this curve from |
| this original position up here. So that it gets closer and closer |
| to what we need to develop the software that we need to |
| build. So let me discuss examples on how tools can improve productivity. |
| For example, if we are talking about development, think about |
| what kind of improvement it was to go from punch |
| cards to modern IDEs. If we're talking about languages, think |
| about of how much more productive developers became when going from |
| writing machine code to writing code in high-level languages. And |
| finally, if we talk about debugging, which is a very important |
| and expensive activity, moving from the use of print lines |
| to the use of symbolic debuggers dramatically improve the effectiveness and |
| efficiency of development. And these are just some of the |
| tools that we will discuss in the rest of the class |
| and notice that we will also use the tools in practice. |
| So we will use the tools before projects and also during |
| the lessons and for assignments. In particular, we will use |
| three main kinds of tools. The first type is IDE's. And |
| I'm pretty sure you're familiar with IDE's. These are integrated development |
| environments. So, advanced editors in which you can write, compile, run, |
| and debug and even test your code. We'll also use a |
| version control system, systems that allow you to save, and restore, and |
| check the differences between different versions of the code, in particular |
| we will be working with git. We will also be looking at |
| other kinds of tools like coverage and verification tools. These are |
| tools that can help you during testing and I'm a big fan |
| of these tools, so I'm really going to stress the usefulness |
| of these tools and how you should use them in your development. |

## 17 - Introduction with Barry Boehm

| Hi, in the last lesson we provided an overview of the course and motivated the |
| need for software engineering. In this lesson, |
| we will present and start discussing several traditional |
| software engineering life cycle models. We will |
| talk about their main advantages, and also about |
| their shortcomings. We will also talk about |
| classic mistakes in software engineering that is well |
| known ineffective development practices, that when |
| followed, tend to lead to better results. And |
| covering those, will hopefully help us to avoid |
| them in the future. And because in this |
| lesson, I will discuss some fundamental aspects of |
| software engineering, to suitably introduce these topics, I |
| went to the University of Southern California, to |
| interview one of the fathers of software engineering; |
| Professor Barry Boehm. |
| >> A well, a software life cycle is a sequence of, of decisions that you |
| make, and it's fundamentally those decisions are |
| going to be part of the history of the |
| software that. You are going to build that other people are going to use, and |
| the process model is basically answering the question of what do I do next and |
| how long shall I do it for. And again, because there are a lot of different ways |
| you can make that decision, you need to |
| figure out which models are good for which particular |
| situations. So, for example, we've, written a book |
| that's called Balancing Agility and Discipline. It says under |
| what conditions should you use agile methods, under |
| which conditions should you invest more time in analyzing |
| the situation and planning what you're going to do and the like. And so, |
| typically if the project is, is small where it's three to ten |
| people, agile works pretty well. If it's 300 |
| people, then I think we don't want to go that way. If the affect of |
| the defect is loss of comfort or limited funds, then agile is fine, |
| but if it is a loss of life, then you don't. On the other hand if, if |
| you have a situation where you have lot |
| of unpredictable change, you really don't want to spend |
| a lot of time writing plans and lots of documents. In some cases you may have a |
| project where you want to do waterfall in |
| some parts and agile in others. So, these are |
| the kind of things that, that make the choice of life cycle process |
| model very important and very interesting as a subject of research. |

## 18 - Traditional Software Phases

| As we just heard from Professor Bohem, software |
| engineering is an important and critical discipline, concerned |
| with cost effective software development. We also heard |
| that this is based on a systematic approach |
| that uses appropriate tools and techniques, operates under |
| specific development constraints. And most importantly, follows a |
| process. As we discussed in the previous lesson, |
| the software development process contains fundamental activities, or phases. |
| Since we will discuss several processes, I'm going to remind |
| you what these phases are. We start with requirements |
| engineering, followed by design, |
| implementation, verification and validation, and |
| finally maintenance. Note that we will revisit each of |
| these phases and devote an entire lesson or more |
| to each phase. So what I want to do next |
| is simply to give you a quick overview of |
| what these phases are. Note also that for now |
| I will follow a very traditional take on these topics. Later on in the |
| class we will see how things can change and did change over the years. |

## 19 - Requirements Engineering

| So, let's start with requirements engineering, which is the |
| field within software engineering that deals with establishing the |
| needs of stakeholders that are to be solved by |
| the software. So why is this phase so important? |
| In general, the cost of correcting an error depends |
| on the number of subsequent decisions that are based |
| on it. Therefore, errors made in understanding requirements have |
| the potential for greatest cost because many other design decisions |
| depend on them and many other follow up decisions depend on them. |
| In fact, if we look at this diagram, which is again a |
| qualitative diagram, where we have the cost of error correction over the |
| phase in which the error is discovered. We can see that if we |
| discover an error in requirements it's going to cost us one. If |
| we find it in in design it's going to cost us five and |
| so on and so forth. And the cost grows dramatically as we |
| go from the requirements phase to the maintenance phase. Why? Because of course |
| if we discover a problem here we're left to undo a |
| lot of the decision that we had made before to correct the |
| error. Whereas if we find an error here we can correct it |
| right away and we don't affect the subsequent phases. So how can |
| we collect the right requirements. Traditional |
| requirements in engineering does so through |
| a set of steps. The first step is elicitation which is the |
| collection of requirements from stake holders and other sources and can be |
| done in a variety of ways, we will discuss some of them. |
| The second is requirement analysis which involved the study and |
| deeper understanding of the collective requirements. The third step is this |
| specification of requirements, in which the collective requirements are suitably |
| represented, organized and save so that they can be shared. Also |
| in his case, there are many ways to do this, |
| and we will see some of this ways when we talk |
| about the requirements engineering in the dedicated lesson. Once the |
| requirements have been specified, they can be validated to make sure |
| that they're complete, consistent, no redundant and so on. So |
| that they've satisfied a set of importance properties, for requirements. |
| Finally, the fifth step is requirements management which accounts for |
| changes to requirements during the lifetime of the project. And here |
| I talked about steps, kind of giving the impression that |
| we're just going from the first step to the fifth one |
| and that this is sort of a linear process. In |
| reality, as we will see, this is more of an iterative |
| process in which will go and cover the different phases in an |
| iterative fashion. We will discuss extensively |
| requirements engineering in our second mini-course. |

## 20 - Design

| Now let's discuss the next phase of software development, |
| which is software design. Software design is the phase |
| where software requirements are analyzed in order to produce |
| a description of the internal structure and organization of |
| the system. And this description will serve as the |
| basis for the construction of the actual system. Traditionally, |
| the software design phase consists of a series of |
| design activities. Which normally consists of the architectural design phase, |
| the abstract specification, interface design, |
| component design, data structure and |
| algorithm design. And notice that this is just a possible list |
| of activities. But you can also characterize design activities in |
| many different ways. And if you're looking at different books, and |
| different sources, you might find different activities described. But the |
| core idea, the important point is that we go from sort |
| of a high-level view of the system, which is the |
| architectural design, to a low-level view, which is the algorithm design. |
| And these activities result in a set of design |
| products, which describe various characteristics of the system. For |
| example, they describe the architecture of the system, so |
| how the system is decomposed and organized into components, the |
| interfaces between these components. They also describe these components |
| into a level of details that is suitable for |
| allowing their construction. We will discuss the details of |
| software design and talk extensively about these different actives and |
| these different products in the third mini course of this class. |

## 21 - Implementation

| After we have designed our system we can implement |
| it. In the implementation phase what we do is basically |
| taking care of realizing the design of the system |
| that we just created and create an actual software system. |
| There are four fundamental principles, four pillars that can |
| affect the way in which software is constructed. The first |
| one is the reduction of complexity. This aims to build |
| software that is easier to understand and use. The second |
| pillar is the anticipation of diversity. Which takes into |
| account that software construction might change in various way over |
| time. That is that software evolves. In many cases, |
| it evolves in unexpected ways. And therefore, we have to |
| be able to anticipate some of these changes. The |
| third pillar is the structuring for validation. Also called design |
| for testability. And what this means is that we |
| want to build software so that it is easily testable |
| during the subsequent validation and verification activities. Finally, and |
| this is especially true within specific organizations and or |
| domains. It is important that the software conforms to |
| a set of internal or external standards. And some examples |
| of this might be, for example, for internal standards, |
| coding standards within an organization, or naming standards within an |
| organization. As for external standards, if for example you |
| are developing some medical software. There are some regulations and |
| some standards that you have to adhere to in |
| order for your software to be valid in that domain. |

## 22 - Verification & Validation

| After we have built our system, verification and validation |
| is that phase of software development that aims to |
| check that the software system meets its specification and |
| fulfills its intended purpose. More precisely, we can look |
| at verification and validation independently. And validation is the |
| activity that answers the question did we build the |
| right system. Did we build the system that the |
| customer wants? That will make the customer happy. Whereas verification |
| answers a different question which is did we build the system |
| right. So given a description of the system that is the one |
| that we derived from the customer through the collection of requirements |
| and then design and so on, did we build a system that |
| actually implements the specification that we defined? And when we look |
| at verification there's many, many ways of doing verification and in fact |
| in the mini course number four we will cover verification extensively. The |
| only thing I want to mention here is the fact that verification |
| can be performed at different levels. In particular, it can be |
| performed at the unit level in which we test that the individual |
| units work as a expected. Can be performed in the integration level |
| in which what we test is the interaction between the different units. |
| So we want to make sure that the different modules talk |
| to each other in the right way. And finally, there is system |
| testing in which we test the system as a whole and we |
| want to make sure that all the system, all the different pieces |
| of the system work together in the right |
| way. And this is also the level at which |
| then we will apply validation and some other |
| testing techniques like stress testing or robustness testing and |
| so on. And as I said I'm not going to say anything more on this topic because |
| we will cover verification, and validation, and testing in |
| particular in great details in mini course number four. |

## 23 - Maintenance

| As we discussed before software development efforts normally result |
| in the delivery of a software product that satisfies |
| the user requirements. So normally our software development organization |
| will release this application to its final users, however, once |
| the software is in operation many things can happen. |
| So, for example, the environment might change. There might be |
| new libraries. There might be new systems in which |
| our software has to operate. Or they may be future |
| requests, so the users may find out that, guess what, |
| they want to do something different with the problem that |
| we gave them. Or, again, and this is one of |
| the most common occurrences, users might find problems with the |
| software and may file bug reports and send the bug |
| reports back to the software developer. These are the reasons |
| why software maintenance is a necessary phase in software development. |
| Software maintenance is the activity that sustains the software product |
| as it evolves throughout its life cycle, specifically |
| in response to bug reports, feature requests and |
| environment changes. Development organisations perform three kinds of |
| maintenance activities: corrective maintenance to eliminate problems with the |
| code, perfective maintenance to accommodate feature request, and |
| in some cases just to improve the software, for |
| example, to make it more efficient, and finally, |
| adaptive maintenance, to take care of the environment changes. |
| And after this activities have been performed, the software developer |
| will produce a new version of the application, will release it |
| and the cycle will continue through out the lifetime of |
| the software. That's why maintenance is a fundamental activity and a |
| very expensive one. And one of the reasons why maintenance |
| is expensive, that I want to mention now, is regression testing. |
| During maintenance every time you modify your application you have |
| to regression test the application, where regression testing is the activity |
| of retesting software after it has been modified to make sure |
| that the changes you perform to the software work as expected, |
| and that your changes did not introduce any unforseen effect. I'm |
| pretty sure that you're familiar with the case of a new |
| version of the software being released and just a couple of |
| days later another version being released to fix some problems that |
| occor with the new version. These problems is what we call |
| regression errors and they're what regression |
| testing targets and tries to eliminate |
| before the new version of the software is released into the world. |

## 24 - Software Phases Quiz Question

| Okay. Now before we jump into the next |
| topic, I just want to take a very quick and |
| simple quiz just to make sure that you |
| guys paid attention to what I just discussed. So |
| I want to ask you what are the traditional |
| software phases. Requirements engineering, |
| design, abstraction, implementation, verification and |
| validation. Or maybe design, |
| optimization, implementation verification and validation |
| and maintenance. Or requirements |
| engineering, design, implementation, verification and |
| validation, and maintenance. |

## 25 - Software Phases Quiz Solution

| And the answer is the third one. The traditional software phases which are the |
| ones that we just discussed are requirements |
| engineering, design, implementation, verification |
| and validation, and maintenance. |

## 26 - Software Process Model Introduction

| At this point, you know the possible activities, the |
| possible phases performed during the software development process. But there |
| this something that we still haven't discussed, which is |
| very important. And that is how should we put these |
| activities together to develop software? And this all comes |
| down to the concept of software process model. Also called |
| software lifecycle model. And what this is, is a |
| prescriptive model of what should happen from the very beginning |
| to the very end. Of a software development process. The |
| main function of the life cycle model is to determine |
| the order of the different activities so that we know |
| which activities should come first and which ones should follow. Another |
| important function of the life cycle model is to determine |
| the transition criteria between activities. So, when we can go from |
| one phase to the subsequent one. In other words, what |
| the model should describe is what should we do next and |
| how long should we continue to do it for each activity |
| in the model. Now let's see a few traditional software process |
| models. I will discuss them here at the high level and |
| then revisit some of these models in the different mini courses. |

## 27 - Waterfall Process

| The first model we want to discuss is the grandfather of |
| all life cycle models. And it is the waterfall model. In |
| the waterfall model the project progresses to an orderly sequence of |
| steps. From the initial software concept, down until the final phase. |
| Which is system testing. And at the end of each phase |
| there will be a review to determine whether the project is |
| ready to advance to the next phase. The pure waterfall model |
| performs well for softer products in which there is a stable |
| product definition. The domain is well known and the technologies |
| involved are well understood. In these kind of domains, the |
| waterfall model helps you to find errors in the early, |
| local stages of the projects. If you remember what we discussed, |
| this is the place where we want to find errors, |
| not down here because finding them here will reduce the cost |
| of our overall software development. The main advantage of the |
| waterfall model is that it allows you to find errors early. |
| However, the main disadvantages of the waterfall model arise |
| from the fact that it is not flexible. Normally, |
| it is difficult to fully specify requirements at the |
| beginning of a project. And this lack of flexibility is |
| far from ideal when dealing with project in which |
| requirements change, the developers are not domain experts or |
| the technology used are new and evolving, that is |
| it is less than ideal for most real world projects. |

## 28 - Spiral Process

| The next model that we will discuss is the spiral |
| model, which was first described by Barry Boehm, which is |
| the professor that we interviewed at the beginning of this |
| lesson. In his paper from 1986 that was entitled A Spiral |
| Model of Software Development and Enhancement. And one of the |
| main characteristics of that paper is that it was describing the |
| spiral model using a diagram, which is the one that |
| I'm showing you here, and this diagram has become very very |
| popular, and you probably saw it either in this |
| form or one of the many variations of the |
| diagram. So I'm not going to discuss all of |
| the details of the spiral model, but I just want to |
| give you an idea of its main characteristics. The |
| spiral model is an incremental risk-oriented lifecycle model that has |
| four main phases listed here: determine objectives, identify and |
| resolve risks, development and tests, and plan the next iteration. |
| A software project will go through these four phases in |
| an iterative way. In the first phase, the requirements will |
| be gathered. In the second phase, the risks and the |
| alternate solutions will be identified, and a prototype will be produced. |
| Software and tests for the software are produced in the |
| development and test phase, which is the third step of the |
| process. Finally, in the fourth phase, the output of the |
| project, so far, is evaluated, and the next iteration is planned. |
| So basically, what the spiral process prescribes is a |
| way of developing software by going through these phases in |
| an iterative way, in which we learn more and more |
| of the software, we identify more and more, and account |
| for, more and more risks and we go more |
| and more towards our final solution, our final release. There |
| are several advantages of using a spiral model. The first |
| one is that the extensive risk analysis does reduce the |
| chances of the project to fail. So there is a |
| risk reduction advantage. The second advantage is that functionality can be |
| added at a later phase because of the iterative nature of |
| the process. And finally, software is produced early in the software |
| lifecycle. So, at any iteration, we have something to show |
| for our development. We don't wait until the end before producing |
| something. And then of course there's also the advantage that we |
| can get early feedback from the customer about what we produced. |
| The main disadvantages on the other hand of |
| the spiral model, are that the risk analysis requires |
| a highly specific expertise. And unfortunately, the whole success |
| of the process is highly dependent on risk analysis. |
| So risk analysis has to be done right. |
| And finally the spiral model is way more complex |
| than other models, like for example, the water fall |
| model. And therefore it can be costly to implement. |

## 29 - Evolutionary Prototyping Process

| The next process model I want to discuss is evolutionary |
| prototyping, which works in four main phases. We start |
| from an initial concept, then we design and implement |
| a prototype based on this initial concept, refine the prototype |
| until it is acceptable, and finally we complete and |
| release the prototype. Therefore, when developing a system using |
| evolutionary prototyping, the system is continually refined and rebuilt. |
| So it is an ideal process when not all requirements |
| are well understood. Which is a very common situation. So, looking |
| at this in a little more details, what happens is that |
| developers start by developing the parts of the system that they |
| understand, instead of working on developing a whole system, including parts |
| that might not be very clear at that stage. The partial |
| system is then shown to the customer and the customer feedback |
| is used to drive the next iteration, in which either changes |
| are made to the current features or new features are added. |
| So, either the current prototype is improved or the |
| prototype is extended. And finally, when the customer agrees that |
| the prototype is good enough, the developers will complete all |
| the remaining work on the system and release the prototype |
| as the final product. So let's discuss as we did |
| for the previous process models, what are the main advantages |
| and disadvantages of evolutionary prototyping. In this case, the main |
| advantage is the immediate feedback. Developers get feedback immediately as |
| soon as they produce a prototype and they show it to |
| the customer and therefore, the risk of implementing the wrong system is |
| minimized. The main negative is the fact that it's difficult to plan. |
| When using evolutionary prototype it is difficult to plan in advance how |
| long the development is going to take, because we don't know how |
| many iterations will be needed. And another drawback is that it can |
| easily become an excuse to do kind of do cut and fix |
| kind of approaches in which we hack something together, fix the main |
| issues when the customer gives us feedback, and then continue this |
| way, until the final product is something that is kind of |
| working, but it's not really a product of high quality. Something |
| else I want to point out before we move to the next |
| software process model is that there are many different kinds of |
| prototyping, so evolutionary prototyping is just |
| one of them. For example, throwaway |
| prototyping is another kind of prototyping in which the prototype is |
| just used to gather requirements, but is thrown away at the end |
| of the requirements gathering, instead of being evolved as it happens here. |

## 30 - Rational Unified Process

| There are two more software process models that I want to cover, so |
| bear with me. The first one is the Rational Unified software Process |
| or IUP, which is s a very popular one based on UML. |
| RUP works in an iterative way, which means it that it performs different |
| iterations. And at each iteration, it performs four phases. So what I'm |
| showing you here, is a high level view of the process. And I |
| don't want you to focus on all the different details, because we |
| will discuss these details later on, in a lesson that is actually dedicated |
| to RUP. What I want to give you now, is just the |
| gist of how this works. So, in each one of these four |
| phases, which I'm going to describe in a second. We perform standard software |
| engineering activities, the ones that we just discussed. And we do them |
| to different extent, based on the phase in which we are. |
| In particular, in the inception phase the work is mostly to sculpt |
| the system. So basically figuring out what is the scope of the |
| work, what is the scope of the project, what is the domain. |
| So that we can be able to perform initial cost |
| and budget estimates. The operational phase is the phase in which |
| we focus on the domain analysis and define the basic architecture |
| for the system. So this is a phase in which analysis |
| and design are particularly paramount. Then there is a construction phase, |
| which is where the bulk of the development actually occurs. And |
| as you can see here, is where most of the implementation |
| happens. And finally, the transition phase is the phase in which |
| the system goes from development into production, so that |
| it becomes available to users. And of course, this is |
| the phase in which the other activities in software |
| development become less relevant and deployment becomes the main one. |

## 31 - Agile Process

| The next type of software process models that I |
| want to discuss are Agile Software Development Processes. And this |
| is a group of software development methods that are |
| based on highly iterative and incremental development. And in particular, |
| I'm going to discuss Test Driven Development or TDD. The |
| space on the iteration of three main phases. In |
| the first one that we mark as red, we |
| write test cases that encode our requirements, and for which |
| we haven't written code yet. And therefore, they will fail, obviously. |
| So we're in this sort of red or fail phase. From |
| this phase, we move to this phase, in which after we |
| write the just enough code to make the test cases pass. |
| We have a set of test cases that are all passing. |
| And therefore, we can consider this as the green phase. We |
| had enough code to make the test cases pass because the |
| test cases encode our requirements. We have just written enough code to |
| satisfy our requirements. When we do this over time though, |
| what happens is that the structure of the code deteriorates, because |
| we keep adding pieces. So that's why we have the |
| first step, which is refactoring. In this step, we modify the |
| code, and we will talk about refactoring extensively. We'll devote |
| one lesson to it. We modify the code to make it |
| more readable, more maintainable. In general, we modify to improve the |
| design of the code. And after this phase, we will go |
| back to writing more test cases for |
| new requirements, write code that makes these |
| test cases pass, and so on. So we'll continue to iterate among these phases. And |
| also, in this case, we will talk |
| about Agile Software Processes. And in particular, |
| about extreme programming, or XP, and Scrum |
| in more details, in minor course number four. |

## 32 - Choosing a Model

| We just saw several software process models, and there |
| are many, many more. And because these process models define |
| the master plan for our project, the specific process |
| model that we choose has as much influence over a |
| project's success as any other major planning decision that |
| we make. Therefore, it is very important that we pick |
| the appropriate model for our development process. Picking an appropriate |
| model can ensure the success of a project. On the |
| contrary, if we choose the wrong model, that can be a |
| constant source of problems and ultimately, it can make the project |
| fail. So how can we choose the right model for a |
| project? To be able to do so, we have to take into |
| consideration many factors. In particular, we need to be aware of |
| what level of understanding we have of the requirements. Do we understand |
| all the requirements? Are we going to be able to collect all |
| the requirements in advance, or collecting requirements is going to be hard and |
| therefore, we might want to follow a process that is more flexible |
| with that respect. Another important point is the expected lifetime of the |
| project. Is this a quick project that we are putting together for |
| a specific purpose or something that's going to last for for a number |
| of years and that we're going to maintain over all those years? |
| That's going to make a difference in the way we decide to develop |
| that project. Also, what is the level of risk involved? Do we |
| know the domain very well? Do we know exactly the technologies involved? |
| Well, if so, we might go with a more traditional process. Otherwise, |
| we might want to be more agile, more flexible. It is also |
| very important to know the schedule constraints. How much time, how many |
| resources do we have for this project? What is the expected interaction |
| with the management and the customer? In particular for this ladder, there |
| are many processes that rely on the fact that there can be |
| a continuous interaction with the customer. If that interaction is not there, |
| there's no way we are going to be able to use these processes. |
| Conversely, there are processes that don't require the presence of the customer |
| at all, except for the initial phase and maybe some checking points and |
| so if the customer is very inaccessible, we might want to follow |
| one of those processes, instead of one of the more demanding ones in |
| terms of customer's time. Finally, it is important to take into account |
| the level of the expertise of the people involved. Do we have people |
| that know the technologies that we're using? Do we know people that |
| know a specific kind of process? |
| Some processes require some specific expertise and |
| we're not going to be able to follow that process if we don't |
| have the right expertise. So we need to take into account all of |
| these aspects, and sometimes more, in order to be able to make |
| the right decision and pick the right software process model for our project. |

## 33 - Choosing a Model Quiz Question

| Now before we move to the last part of the lesson, let's |
| have a quick quiz on software process models to make sure that |
| we are all on the same page. So I am going to |
| ask you two questions. The first question is which of the following models |
| is most suitable to develop a software control system? And when you |
| think about the software control system, you can think about for example |
| the control system for the software in an airplane. Would you rather |
| use a pure waterfall model? Test |
| driven development? Or an evolutionary prototyping approach? |

## 34 - Choosing a Model Quiz Solution

| This is the context in which, typically, a pure |
| waterfall process will work well. Why? Well, because it's a |
| context in which requirements are usually well understood. The |
| domain is well understood, so that kind of system has |
| been built many times before. And also, it's a |
| system in which we don't expect requirements to change dramatically |
| over time. Therefore, a waterfall model, in which we collect |
| all the requirements at the beginning and then we move |
| to the subsequent phases might be the most appropriate one. Probably |
| we don't want to do evolutionary prototyping in the case of |
| the control system for an airplane. Same thing holds for TDD, |
| so we want to be a little more rigorous in those cases. |

## 35 - Choosing a Model Quiz Question

| The second question I want to ask you is which model is the most suitable if you |
| expect mid-course corrections? Would you rather use a |
| pure waterfall model, a spiral model, or evolutionary prototyping? |

## 36 - Choosing a Model Quiz Solution

| In this case, I think about the spiral model, |
| and evolutionary prototyping model will work. Definitely you don't want to |
| have a pure water from water. Why? Well because it |
| is very expensive with a pure waterfall model to make |
| changes during the course of the project, especially changes |
| that involve requirements. Why? Because we saw that it can |
| be very expensive. Whereas with the spiral model, we saw |
| that being iterative, we can actually make correction throughout development. |
| Similarly, with evolutionary prototyping, we keep evolving our system |
| based on the customer feedback. And therefore, if something changes, |
| we will get feedback right away, and we will |
| be able to adapt. So the key thing here is |
| that anything that is iterative works better in the |
| case of changing environments. So, situations in which your requirements, |
| the situation, the project might change. Whereas waterfall is |
| more appropriate for situations in which the requirements are stable, |
| we know the domain, and possibly we also know the technologies involved. |

## 37 - Lifecycle Documents

| Now that we discussed softer process models, there is |
| another important point I want to cover, because it's going to |
| be useful for your projects. Documenting the activities carried out |
| during the different phases of the softer lifecycle, is a |
| very important task. The documents that we produce are used |
| for different purposes, such as communicative details of the software |
| systems. To difference the colors, ensure the correct implementation of |
| the system, facilitate maintenance, and so on. There are standardized |
| document that are provided by IEEE that you can use |
| for this purpose. However, they're kind of heavyweight. So for the |
| project in this class, when we will need them, I will |
| rather use this lightweight documents. That we created by modifying the |
| original ones, and make them a little simpler. In this, |
| our documents are actually used, while teaching this class in the |
| past. So they're well tested and work well for the kind |
| of projects that we will perform. I provide information on how |
| to access these documents in the class notes. |

## 38 - Classic Mistakes_ People

| Now we get to the final part of the lesson. |
| And in this part I want to talk about well known, |
| ineffective development practices. These practices, when followed, tend to lead |
| to predictably bad results. So let's look at some examples of |
| these classic mistakes. And we're going to start with mistakes |
| involving people. And notice that there is a long list. So |
| I'm going to discuss just a few of those mistakes. |
| And I'm going to point you to more information on this |
| topic in the class notes. And some of these mistakes are |
| actually kind of entertaining. So I'll recommend that you look at |
| the class notes and go in more depth in this list. |
| So the first people mistake I want to mention is the |
| one that I define, heroics. And this refers to too much |
| emphasis on can do attitudes, so this idea that one person |
| by himself or by herself can do everything and can make |
| the difference in the whole project. And unfortunately, this encourages extreme |
| risk taking and discourages cooperation, which is plain bad for |
| the project. For example, it might force people not to |
| report schedule slips. It might force people to take on |
| on too much responsibility. And normally, and I saw it |
| happen many times, the final result is a failure. So |
| what you want when you're developing a larger project, is |
| actually to apply soft engineering principles. Have teams, have team |
| work, and have cooperation among the different team members, without pointing |
| too much on single individuals. Another classic mistake |
| is to not create the right working environment. We |
| all like to work in nice environments. And there |
| is strong evidence that the working environments can play |
| a big role in productivity. There is evidence |
| that productivity increases when the workplace is nice, quiet, |
| warm, and welcoming. Finally, some of the most important |
| people relating mistakes are due to poor people management. |
| For example, lack of leaderships, or leadership that is |
| exercised using the wrong means in the wrong way, which |
| can lead to very unhappy personnel and therefore, low |
| productivity, or even people leaving teams. Another classic example of |
| poor management is adding people to a project that |
| is behind schedule, which never works. Why it doesn't work? |
| Because these new people need to be brought up to |
| speed, and that causes further delays rather than improving the |
| situation with the project schedule. |

## 39 - Classic Mistakes_ Process

| Another type of classic mistakes are process-related mistakes. And also |
| in this case, these kind of mistakes can be due |
| to many reasons. And they are of many types. One |
| typical example are scheduling issues, which are due to the fact |
| of being unable to come up with a realistic schedule. |
| So to have an overly optimistic schedule. And this can be |
| because we underestimate the effort involved in different parts of |
| the project. Because we overestimate the ability of the people involved. |
| Because we overestimate the importance, for example, of the use |
| of tools. But no matter what the reason is, the |
| result is typically that the projects end up being late, |
| which is a very common situation. So this is somehow |
| related to planning. And in general, planning is a fundamental |
| factor in software processes and in software development. Mistakes in |
| planning, such as insufficient planning or abandoning planning due to |
| pressure, usually lead inexorably to failure. And speaking of failures, |
| often there are unforeseen failures. Such as |
| failures on the constructor's end, for example, |
| that might lead to low quality or |
| late deliverables, which ultimately affects the downstream activities. |

## 40 - Classic Mistakes_ Product

| The third category of mistakes that I want to |
| mention is product-related mistakes. A |
| typical example of product-related mistake |
| is gold plating of requirements. And what that means is |
| basically is that it's very common for projects to have |
| more requirements than they actually need. For example, marketing might |
| want to add more features than the ones that are |
| actually needed by the users. And of course having more |
| requirements lengthens the project's schedule in a totally unnecessary way. |
| Feature creep is another common mistake and consists in |
| adding more and more features to a product that were |
| not initially planned and are not really needed in most |
| cases. And here there is evidence that the average project |
| experiences about a 25% growth in the number of |
| features over its lifetime which can clearly highly effect The |
| project schedule. Finally, if you're working on a project that |
| strains the limits of computer science. For example, because you |
| need to develop new algorithms for the project, or you have |
| to use new techniques. Then that project might be more research than |
| actual development. And therefore, it |
| should be managed accordingly. For example, |
| by taking into account that you will have a highly unpredictable schedule. |

## 41 - Classic Mistakes_ Technology

| The final type of classic mistakes that I want |
| to mention are technology related mistakes. One typical mistake |
| in this context is the silver-bullet syndrome. What does |
| that mean? Well, the silver-bullet syndrome refers to situations |
| in which there is too much reliance on the |
| advertised benefits of some previously unused technology. For example, |
| a new technology. And the problem here is that |
| we cannot expect technology alone to solve our software |
| development issues. So we should not rely too |
| much on technology alone. Another typical mistake is to |
| switch or add tools in the middle of |
| a project. And sometimes it can make sense to |
| upgrade a tool, but introducing new tools, which |
| can have a steep learning curve, has almost always |
| negative effects. Finally, a common unforgivable mistake is |
| the lack of an automated version control system for |
| your code and for your various artifacts. Manual and |
| ad hoc solutions are just not an option. It is |
| way too easy to make mistakes, use out of |
| date versions, be unable to find a previous working version, |
| and so on. I saw that happening many times, |
| and it always results in a disaster. So be warned, |
| use a version control system and an automated one. And |
| actually we will use version control systems in our projects. |

## 42 - Classic Mistakes Quiz Question

| To conclude this lesson, I'm going to have a |
| simple quiz and what I'm going to ask you |
| is, which kind of mistake adding people to a late project is? And you can pick |
| between a people mistake, a product mistake, a |
| technology mistake, or maybe this is not a |
| mistake at all, it is actually okay to add people to a project that is late. |

## 43 - Classic Mistakes Quiz Solution

| You probably got this one right. The right answer is that |
| this is a people mistake. And despite the fact that this is |
| an easy answer, I just want to make sure to stress |
| once more. Because this is a very classic mistake. And one that |
| can have dire consequences. You should never add people, to a |
| late project. Because in 99.9% of the cases, that's only going to make |
| things worse. Why? Because these people have to be brought up to |
| speed, and also because having more also makes the communication more difficult, |
| the meetings more difficult and so on. So in |
| short, do not add people to a late project. |

## 44 - Lesson Overview

| Hi, and welcome to the first of several lessons on tools of the trade. I'm |
| very excited about these lessons, because I believe that tools are a cornerstone |
| of the software engineering discipline, and it |
| is of paramount importance to know and |
| use them. In this lesson, we will |
| talk about integrated development environments, normally called IDEs. |
| And these are software applications that support developers in many of their |
| everyday tasks, such as writing, compiling, and debugging code. And to make the |
| discussion more concrete we will focus on a specific IDE, Eclipse. We will |
| first present Eclipse, and then get some hands-on experience through a demo. |

## 45 - Eclipse Introduction

| As I just told you, tools are fundamental in |
| software engineering. And I will stress this concept over and |
| over, throughout the class. And today we're going to talk |
| about a tool that is especially important, which is integrated |
| development environments, or IDEs. And you're probably familiar with |
| IDEs. So IDEs are environments that give you support for |
| your development activities. For example, for writing code, editing code, |
| compiling code, and so on. And we will focus specifically |
| on one particular IDE, which is called Eclipse. And |
| what I'm showing here is the two splash screens for |
| two versions of eclipse, Helios and Kepler. Eclipse is an |
| open, extensible development environment that was initially created by IBM |
| and is now managed by the Eclipse Foundation. And of |
| course, there are many other great IDEs such as for |
| example, Microsoft Visual Studio or Netbeans. We will be using |
| Eclipse because it is open and because it is multi-platform, |
| which means that you can use Eclipse |
| no matter what operating system we're using. |
| So if we consider the most commonly used operating system, such as Mac |
| OS, Windows, Linux, Eclipse runs on any |
| of these environments. Therefore, no matter what |
| you're using, you'll be able to install |
| Eclipse, run Eclipse, and follow the class. |

## 46 - IDE Overview

| So, now let's look in a little more detail to what is an IDE. An IDE is a |
| software application that supports software developers in many of |
| their everyday tasks. It has many useful features. Most IDEs |
| provide views that can be used to navigate, project |
| resources from different perspectives. For example, you might want to |
| look at your code differently when you're writing code, |
| and when you're debugging. They also normally provide an intelligent |
| source code editor. For example, an editor that will allow you |
| to browse the documentation when you're writing a code that |
| uses a specific method, or that will give you autocompletion when |
| you start writing the name of an object and you want to |
| get the methods for that object. And all of these things |
| can be very useful while you're developing and can save you a |
| lot of time. Modern IDE's will also normally give you support for |
| version control systems that then you |
| can use for softer configuration management. |
| And we're going to discuss in detail version control systems in |
| the next tools of the trade lesson, and we're also |
| going to see how it can be integrated within an IDE. |
| IDEs also give you builders so they give you build automation |
| tools, they give you runtime support. So that you can |
| run your projects from within the IDE and, for example, |
| observe some aspects of the execution. In addition to giving |
| you support for the runtime, they give you support for testing. |
| Many IDEs allow you to run tests from within |
| the IDE and to check the results of the tests |
| from within the IDE. Not only that. Normally, after you |
| run your tests, if there are some test cases that |
| fail, you can also use your IDEs to do debugging. |
| Many IDEs include graphical debuggers. Debuggers will allow you to |
| navigate through the code, set which points, stop and restart |
| the execution. Inspect variables, and do all of the activities |
| that help debugging. And, to help you be more efficient |
| and more effective when you do debugging. And into addition to |
| all these features that are listed here IDEs can normally provide |
| you even more features through a mechanishm that is called plugins. |

## 47 - Plug-Ins

| In fact most IDEs are extensible through the use of |
| plug-ins. And by the way, note that plug-ins might be |
| called differently on different platforms. For example, if you're using |
| a Microsoft Visual Studio, plug-ins are normally called add-ins, but |
| the concept is more or less the same. So, what |
| is a plug-in? Well, let's imagine our IDE to be |
| this box. A plug-in is additional functionality that you can |
| actually plug into this box so that this box starts |
| offering more features to the user. For example, you |
| can add to Eclipse the Checkstyle plug-in. Which, paraphrasing the |
| Checkstyle website, helps you ensure that your Java code |
| complies with a set of coding standards by inspecting the |
| code and pointing out items that deviate from a |
| defined set of coding rules. Again, this is a functionality |
| the core of Eclipse doesn't have. You can add |
| the Checkstyle plug-in, and this functionality will become available in |
| the IDE. Another example of plug-in is the EGit plug-in which |
| adds support for the Git version control system in Eclipse. And |
| actually this is something that we'll cover in detail, we'll have |
| a demo, and we will actually use it throughout the class, so |
| I'm not going to say anything more about the EGit plug-in for |
| now. But again, what the plug-in will do is to add |
| the Git functionality to Eclipse. A functionality that is not in |
| the core of Eclipse and that is available to the user after |
| you add the plug-in. |

## 48 - Eclipse Demo_ Create Java Project

| In the rest of this lesson we're going to look at eclipse and |
| try to get more familiar with eclipse in a hands on manner |
| through a demo. In the demo we will cover some of the |
| basic aspects of eclipse like how to run eclipse, how to select |
| their workspace, how to create a project, how to create the class |
| within the project and so on. I'll also cover some more advanced |
| aspects, like how to create builders, run your project within Eclipse, and |
| how to use their Eclipse debugger. So let's get to the demo. |
| So let's start Eclipse. Eclipse is going to ask me |
| for the location of my workspace and in this |
| case, I selected a suitable directory and you can |
| also use that checkbox on the left to avoid Eclipse |
| for asking you again about where to put the |
| workspace. And the workspace is basically the place the |
| directory. Where, Eclipse will place all of your projects. |
| So, now when you start Eclipse, if it's the first |
| time you might get this Welcome screen. It's not going to happen |
| again on subsequent executions, but I just wanted to make sure |
| that I covered all the bases. And so, whatcha want to |
| do here is to basically go to the java perspective |
| which you can do by clicking over there or you can |
| also use the menus. So in this case we will have |
| to go to Window, open Perspective, and if the Perspective is |
| not here, you'll have to click on Other. And at this point, |
| that you can click on Java Perspective, then you |
| click okay. And the perspective is basically, the visual work |
| space where you will be operating. So, after we selected |
| perspective, we can actually close the welcome screen. And here, |
| you see that you have this different areas and on |
| the left You have the package explorer. This is the |
| area where your packages will be, you've got a task list, |
| and an outline on the right which we'll cover later. |
| And then you have underneath, the bottom, a problems, java |
| doc and declaration views and we will see some of |
| these views in actions later. And here in the center |
| you have the area. Which is called a code editor, |
| which is where you'll be writing, editing, and modifying, basically, |
| your code. This is where most of the action takes |
| place. So let's start by creating a Java project. And |
| to do that we can use either the context menu, or |
| you can just use the menu, select new Java project. |
| You'll be greeted by this, wizard, and. And at this |
| point in the wizard, you can select the name of |
| your project. I'm just going to call it a very simple way |
| my project. And I going to use the default location for |
| the project, as you can see it will be placed |
| in the work space that I selected before. I'm going to |
| also use the default. Java Runtime Environment, which is Java 1.7 |
| in this case. I'm going to keep the selected default layout |
| and the, then I'm going to go to the next step. Here, |
| we're first presented with the location of the source code for |
| our project. The default is a directory SRC in my project |
| and for the output file, the directory bin. So repeat, we're now |
| going to change that. Here in case you need other projects to |
| build your own, then you can specify them here. Here we |
| are building a simple project, so there's no need for that. |
| And here we can specify which libraries our project requires. As |
| you can see, the Java library's already specified. And you can |
| also add other jars, which can even be External jars. And |
| finally this is the tab that allows you to specify which |
| part of you project. So how your project will be exported, |
| so let's not worry about that for now. let's click finish. |
| And as you can see here on the package explorer, my |
| project appeared. So now we can open the project by clicking |
| on the triangle right next to it, and as you can |
| see there is the SRC directory, where my source code will go, |
| and there's also an indication that we're using the JRE, so that's |
| the Java system directory within our project. And this is just for people |
| who are interested in what happens you know, under the hood. So |
| if you don't care about that, you can just skip this part. So |
| basically here I'm showing you how we can go to the directory |
| where the project was created. We can see the bin and src directories. |
| And there's also some other files here that you can |
| see these 'dot' files that you will not normally, see. And |
| those are kind of bookkeeping files. So these are files that |
| contain information about your project and that are created automatically by |
| Eclipse. And, for example, will have various indication about the |
| configuration of the project, some settings and the class path for |
| the project. And, as I said, you don't have to worry |
| about this if you just want to go Eclipse as you're never |
| going to mess with the command line. |

## 49 - Eclipse Demo_ Create a Class

| So now that we know, we saw what happens under |
| the hood, and as I said, don't worry about it if |
| you don't care about that part. Now we can go back |
| to Eclipse, and we can start creating a package. A package |
| is basically a way of organizing your classes into a |
| hierarchy. In this case, I'm going to specify the package name as |
| edu.gatech, which means that I'm creating really two packages, a package |
| gatech inside package edu. And I can start creating classes inside |
| my packages. So here, I can use the contextual menu, select |
| New>Class, and I'll get another wizard that will allow me to |
| specify the name of the class. I'm not very creative here, |
| so I'm just going to call it Hello World. There's many other parameters |
| you can set, and in particular, you can define whether you |
| want a main method in your class. Where having a main |
| method means that your class can be the main class in |
| your project, can be the one that is run when you run |
| your project. After we click the button, the Finish button, we, |
| we get the class. So we also get template code for the |
| class, as you can see here, so we go to the editor |
| function, you can see that there is a to do. Where you |
| have to put your code, and here we are simply, basically printing, |
| you know, the typical first program. We just going to print Hello World |
| in Java. And something you can note is that as we are |
| typing, Eclipse gives us a auto complete suggestions, which is very helpful. |
| For example, in case you don't remember the exact syntax, |
| or the method, or you don't remember the parameters of the |
| method. Which is, you know, often the case especially where you |
| work with large libraries. So having that feature can really, really |
| help you. So now if we want to run our code |
| we can either click on the button up here, or we |
| can right-click in the Call window and select Run As Java |
| Application. And if we do that, Eclipse will run our tool, |
| and it will create, as you can see here, a console view that basically contains |
| the textual output of my program. And as expected, the output is Hello World. |

## 50 - Eclipse Demo_ Run Configuration

| So now that we have run our program, let's see what |
| happens exactly when you run a program within Eclipse. And to |
| do that I'm going to use the menu over here which is |
| the Run menu and I'm going to select Run Configurations, and this |
| brings up a window where you can change or run configurations. |
| Well first of all, you can see that here on the |
| left under Java application. Eclipse automatically created a Hello World run |
| configuration for our program. And this is where you can configure |
| the different parameters for your execution. For example, |
| you can select the main class. So here |
| it's, obviously, edu.gatech.HelloWorld. You can define different program |
| arguments. We don't have any for now. You can |
| also pass arguments to the virtual machine. You |
| can define which Java runtime environment you want to |
| use, Classpath and other environmental options. So let's |
| now try to pass some arguments to our program. |
| So for example here, I am just going to write George as |
| a possible parameter. I say Apply so that modify the configuration and |
| if i run the program of course, the output is not changing |
| because my program does not use the argument. But, let's see if |
| we do use the argument, what happens. So I'm going to slightly |
| modify the final program so that now, instead of printing hello |
| world, it will print hello followed by the first argument that I |
| will pass to the program. And if I do that, and I |
| go and I run the program, what I get is exactly what I |
| was expecting, which is Hello George. So this is the way in which you |
| can pass arguments to your execution, which |
| is something that might come in handy |
| for some other projects. When you need to run some code with an argument. |

## 51 - Eclipse Demo_ Debugging

| Now let's look at how we can do debugging within |
| Eclipse. I created a new file called AddNumbers which I'm |
| showing here. It takes two numbers, parses them into integers, |
| adds them and prints the sum, supposedly, of the two numbers. |
| Now we look at the run configuration for this program, |
| and here you can see that we're passing two arguments, |
| two and five, to the program. So now let's run |
| our program and see what happens. And the result says that |
| 2 plus 5 is equal to 10, which is not |
| exactly correct. So we need to debug our program. We |
| need to figure out what's wrong with the program, why |
| the wrong result was, produced. So we're going to add a break |
| point here by double-clicking here on the side of the |
| code. And the break point is basically a place where I'm |
| telling my debugger to stop during the execution because I |
| want to inspect the state of the program. So to start |
| debugging, we select Debug as Java Application from the Context |
| menu, similar to what we were doing for running the program. |
| And as you can see, this asks us whether we want |
| to pass to the debug perspective, which is a, a perspective |
| specifically designed for debugging. We say yes. And as you |
| see here, it shows us, it's like a different, set of |
| views, so we can see the code down here with an |
| indication of where the execution is. And of course the execution |
| stopped at the break point, which is exactly where |
| we told the debugger to stop. So let's look at |
| some of the other views in this perspective. The view |
| here on the right-hand side, for example, shows the variables |
| in scope and the break points that are currently active |
| for the debugging session. This is where the editor is |
| at. The outline of the program and the console at |
| the bottom. So now let's execute one line by clicking |
| on the Step Over button here at the top, and this will |
| execute the line that is currently highlighted and therefore it will move to |
| the next line. And as you can see, one nice feature is that |
| if I move the mouse over a variable, I can see the value |
| of the variable. And the same thing I can do if I look |
| at the variables windows here on the right. If I click it, it |
| will tell me what is the value of the variable, and in case |
| of more complex variables you can even expand it and get more details. |
| So now let's step over another line by clicking again this button, |
| and as you can see now we get to the line that |
| is actually performing the sum, supposedly, so now let's do the same |
| thing that we did before, and let's mouse over b, and we can |
| see that the value of b is five, as expected. So now |
| let's step over this line as well, and execute the actual sum. And |
| doing the mouseover thing, we can see that the value of sum |
| is ten, which is not right, of course. In fact, if we check |
| a gain we can see that value of A is two. The |
| value of B is five and therefore it's clear that there's something |
| wrong going on here, and at this point we can notice that |
| here we are doing multiplication instead |
| of addition. And therefore that's what the |
| error is. And this is clearly a very simple case. Right? A |
| case in which probably you just needed to look at the code and |
| you didn't need the debugger. But you probably got the idea right? |
| So this can be extremely useful when you're debugging, when you're studying more |
| complex programs. If you want to stop the debugger because you're |
| done with your debugging session as in this case, you can |
| either click here on the Terminate button or you can also |
| just simply tell the debugger to continue the execution, to resume |
| the execution until the program terminates naturally. So, in this case, |
| we're going to click here just to show what happens. And what |
| happens is that, you know, the execution will just continue until |
| the program exits. So now let's say that we want to fix |
| this problem that we just discovered. So we replace the multiplication |
| with an addition, we save the program, and we execute the |
| program again by clicking on this button. And at this point, |
| unsurprisingly, we get the right result as shown in the console. |

## 52 - Lesson Overview

| Hi and welcome to the second lesson on tools of the trade. In the |
| previous lesson we talked about IDEs. Integrated |
| Development Environments and in particular we discussed |
| the eclipse ID. Today we're going to |
| talk about another fundamental type of tools |
| in the software engineering arena. Version control |
| systems. And these are also called, revision |
| or source control systems. In particular, we will focus on a |
| specific version control system called git. And as we did for eclipse, |
| we will first present git from a conceptual standpoint. And then |
| we will do a demo. To get some hands-on experience with GIT. |

## 53 - Interview with John Britton

| >> And I thought that the best way to break the ice on version |
| control systems and Git and some other |
| related concepts was to interview John Britton who |
| works with GitHub. So let's go and see what John has to say about |
| Git, about version control systems in general, |
| and about GitHub. John is in Tapei, if I'm not wrong. |
| >> That's correct. |
| >> Okay so we're, you know we couldn't |
| go there so we're interviewing him remotely. And I |
| want, I just want to thank you so much and John for agreeing to talk to us. |
| >> Thank you very much for having me it was my pleasure. |
| >> And, I'm just going to ask, a few |
| general questions because John is an expert on, |
| Git and GitHub. John is a developer and |
| a community builder is active in both the |
| open source and the open education areas. And |
| as an educational liaison we have, is working |
| to improve Computer Science education by bringing the |
| principles of open source into the classroom. And |
| I'm going to start with an general question, |
| which is what is a version control system? |
| >> So, a version control system is |
| a tool that software developers use. Anybody |
| who's doing you know, working with digital |
| assets, digital projects can also use for |
| keeping track of, you know, revisions of your project, and when I say revisions, I |
| mean essentially snapshots of your project over time. So you can imagine doing |
| some work and then every so often, be it, every couple of |
| hours, every couple of days, saving a permanent snapshot of your project. |
| >> Why is this useful? I understand that |
| it is nice to take a snapshot of your |
| project, but what did you do with the |
| snapshot afterwards? I think the most immediately obvious benefit |
| to having snapshots of your project to keeping |
| revisions is that you can go back. If you |
| have ever worked on a project and got to |
| a point where you solved a bunch of your |
| problems, and there is just one more step to do. And |
| you start working on trying to solve that last step, and |
| you break things, you make it worse then it was an |
| hour ago. At that point its easier to just go back |
| to what you had then trying to figure out what you |
| broke. So you can always go back in time, and the |
| other big one is being able to collaborate with multiple people, |
| so its pretty seldom these days that you. Work on a production |
| totally on your own. It's most common to work in, you |
| know, in teams and small groups. And so, using a revision |
| control system allows you to collaborate with other people. And make |
| sure that you don't step on each other's toes as you're working. |
| >> Alright, that's great, because those are exactly some of the |
| topics that we're going to cover in the lesson. And so since we're |
| going to talk about the specifics of version control system which is |
| Git and you're definitely an expert in, in Git. So what would |
| you say is specifically special about Git? What characterizes it |
| and how does it compare to other version control systems. |
| >> So if any of you have used version control systems before, you |
| may have heard of something like subversion, CVS, or maybe a commercial solution |
| like ProForce. I think the main important characteristics of Git are first that |
| it's open source. And the second, |
| that it's a distributed version control system. |
| So what that means, the distributed version |
| control system is essentially a system for tracking |
| revisions of your software that doesn't have any |
| central repository. So the biggest characteristic is that |
| I can do my work and you can also work on the same project at |
| the same time without communicating with each other |
| and without communicating to a central system. |
| >> Okay, great. And so now that we saw what Git is, what is |
| GitHub and how does it fit into |
| this picture of the distributed, revision control system? |
| >> So GitHub is, the world's largest code host, and we essentially have a |
| website where you can collaborate with people |
| when you're writing code. There's two ways you |
| can use GitHub. You can use it publicly for open source and you can use |
| it in private within your team, or your company, or within your class. And, Git |
| Hub started out just as a way to host your Git repositories. But it's |
| actually grown into quite a bit more. It's |
| an entire collaboration system around your code. |
| >> How many users do you have? |
| >> I would say that we're approaching five million. |
| I don't know the exact number. We're definitely more |
| than four million right now. But yeah, I'd say |
| somewhere, somewhere close to between four and five million. |
| >> So that's a lot space I'd guess. Terabytes of disk |
| space, I would imagine. |
| >> There are a lot of GIT repositories on, on our servers. |
| >> Something else you want to say? I |
| guess that the when taking about GitHub there's one |
| thing that you kind of can't leave out and |
| that's that's a feature that's called a pull request. |
| So when you're using GitHub, you can share |
| your Git repository, do some work, and actually do |
| do a code review. Of proposed changes which |
| is what we call a pull request on github.com. |
| Essentially what it let's you do is have a discussion |
| about a set of proposed changes and leave feedback in |
| line with the code. You could say for example, this |
| method needs to be re-factored or I think I found if |
| off by one error here, just different kinds of feedback |
| so that before you totally integrate some proposed changes. You have, |
| kind of a conversation about what your code. And I |
| think that's really valuable when you are working in a team. |
| >> Thank you, John, that was very informative and |
| thanks again for taking the time to talk to us. |
| >> No problem, thanks for having me. I'll talk to you soon. |
| >> Let's thank again John for enlightening us |
| on some aspects of version control systems, Git and |
| GitHub. And now, let's go over some of the |
| topics that we discussed with John to recap them. |

## 54 - Version Control System Introduction

| So first of all, what is a version |
| control system? A version control system or VCS, |
| is a system that allows you to manage |
| multiple revisions of the same unit of information. For |
| example of documents, of source files or any |
| other item of that sort. And as the graphical |
| depiction shows, a VCS allows a multiple actors. |
| Here we have four, to cooperate and share files. |
| Now, let's drill into this concept in a little |
| more detail. And let's do that by discussing why |
| is VCS useful, especially in the context of software |
| engineering and of software development. So first of all, |
| using a version control system enforces discipline, because it |
| manages the process by which the control of items |
| passes from one person to another. Another important aspect |
| of VCS is that it allows you for archiving versions. |
| So you can store subsequent versions of source controlled |
| items into a VCS. And not only you can |
| store versions, you can also maintain a lot of |
| interesting and important historical information |
| about these versions. For example, |
| a VCL will store information such as, who is |
| the author for this specific version stored in the system. |
| Or, for another example, on what day and what |
| time that version was stored. And a lot of other |
| interesting information about the specific version of the |
| item. Information that you can then retrieve and for |
| example, use to compare versions. Obviously, the fact of |
| having a central repository in which all these items |
| are stored enables collaboration, so people can more easily |
| share data, share files, share documents through the use |
| of VCS. And I'm sure that you all had |
| the experience of deleting a file by mistake or |
| modifying a file in the wrong way, or in the |
| most common case of changing something in your code for instance. |
| And breaking something and not being able to go back |
| to a version that was working. Not remembering, for example, what |
| is that you changed that broke the code. In all |
| these cases a version control system can be extremely useful because |
| it will allow you to recover from this accidental deletions |
| or edits. And for example, to go back of yesterdays version |
| that was working perfectly, and also to compare, for example, yesterdays |
| version with today version and see what is that you changed. |
| Finally, a version control system will normally also allow you to |
| conserve and save disk space on both the source control client |
| and on the server. Why? Well, for instance because it's centralizing |
| the management of the version. So instead of having many copies |
| spread around, you'll have only one central point where these copies |
| are stored or a few points where these copies are stored. |
| In addition, version control system often |
| uses efficient algorithms to store these changes. |
| And therefore, you can keep many versions without taking up too much space. |

## 55 - VCS Quiz Question

| Now before we continue, and we look at more details |
| of version control systems, I want to ask you a |
| quick question about VCS. I want to know whether you |
| have used a version control system before, and if so, |
| which one or which ones. I'm going to list in |
| here some of the most commonly used version control systems, |
| like CVS, Subversion, GIT, and I'm also allowing you to |
| specify other VCS in case you have used different ones. |

## 56 - VCS Quiz Solution

| And of course there's no right answer for this. I just wanted to collect some |
| statistics. To see what kind of previous |
| experience you have with this kind of systems. |

## 57 - Essential Actions

| What I want to do next, is to look at how |
| version control systems actually work. We saw what they are. We |
| saw why they are useful. But how do they actually work? |
| And we're going to do that by starting from some essential |
| actions that version control systems perform. The first one is the |
| addition of files. So, when you use a version control system, |
| you can add a file to the repository. And at that |
| point the file will be accessible to other people who have access |
| to the repository. And now the fundamental action is commit. |
| When you change a file, a file that is already in |
| the repository, when you make some local changes to a |
| file that is already in the repository, you want then to |
| commit your changes to the central repository, so they can |
| become visible to all of the other users on the repository. Finally, |
| another fundamental action is the action of updating a file. If |
| we have a repository and someone else can modify the files |
| in the repository, I want to be able to get |
| the changes that other people made to the files in the |
| repository. And these are just three of the basic actions, but |
| there are many, many more. And we'll see several of those. |

## 58 - Example Workflow

| Before looking at additional actions, though, I would like to |
| see what is the basic workflow in a version control system |
| using the three actions that we just saw. And to |
| do that I'm going to use two of our friends, Brad |
| and Janet. So we have Janet here, Brad, and a |
| VCS that they are using. Now imagine that Janet creates a |
| file called foo.txt and puts some information in the file. |
| At that point she might want to add the file to |
| the repository and to commit it so that her changes |
| and the file get to the central repository. And when she |
| adds and commit, that's exactly what will happen, in foo |
| will be come available here, and will be accessible to the |
| other users. In this case it'll be accessible to Brad. |
| If Brett were to run an update command, what will happen |
| is that the file foo.txt will be copied on the local |
| work space of Brad and Brad will be able to access |
| the file. At this point Brad might want to modify |
| the file, for example add something to this existing file. |
| After doing that, he also may want to share the |
| updated file with Janet. To do that, he will commit the |
| file and the result will be exactly the same of |
| when Janet committed her file. That the updated file will |
| be sent to the repository and the repository will store |
| that information and make it available for other users. So now, |
| if Janet performs an update, she will get the |
| new version of foo.txt with the additional information that was |
| added by Brad. And we will see all of this |
| in action in our next demo in a few minutes. |

## 59 - Donts in VCS

| Before getting to the demo, I want to say a few |
| more things. In particular, I discuss the main don'ts in VCS. So, |
| what are some things that you don't want to do, and |
| you should not do, when you're using a version control system? And |
| I'm going to mention two, in particular, because these are two |
| that I witnessed several times when I was teaching this class and |
| also when collaborating with other people. So, there are two kinds |
| of resources that you don't want to add to a VCS normally. |
| One is derived files. For example an executable that is |
| derived by compiling a set of source files, where the |
| source files all already in the repository. At that point, |
| there is no reason to also add the executable file in |
| the repository. So in general, any executable file should not |
| be added to repository. The second class of files that I |
| want to mention is these bulky binary files. If you |
| have one such file, it is normally not a good idea |
| to store them under a version control system, to store them |
| in the repository. There might be exceptions to these rules, but in |
| general, these are the kind of files that you want to |
| keep local, and you don't want to put in the VCS repository. |
| Another typical mistake, and that happens all the time, especially to |
| novice users of VCS. Is that you get your file from VCS |
| and so you get your local copy of the file that |
| was in the VCS, and you want to make some changes, and |
| before making the changes you decided, no, no let me actually save |
| a local copy of the file, and I'm going to work on |
| that one. Or let me save it before I modify it, or |
| let take a snap shot of a whole tree of files. Just because |
| I don't really trust the fact that VCS is going to be |
| able to help and is going to be able to recover from possible |
| mistakes. Never ever do that. I have seen that done many times, |
| and it always leads to disasters. First of all it is useless, and |
| second it's risky. Because then what happens is that at |
| the time in which you have to turn in your assignment, |
| in the case you are doing an assignment, but even in |
| more serious situation, when you have to turn in your code, |
| for example to your colleagues. You always end up being confused |
| about which is the version that you're really using. So absolutely |
| no local copies. No local redundancy when you're using a version |
| control system. Trust the version control system, and trust the version |
| control system to be able to manage your versions. You |
| can always save it, commit it, retrieve previous versions, and you'll |
| be able to do everything that you can do by copying |
| the file yourself, and even more. So again, try the VCS. |

## 60 - Two Main Types of VCS

| Something else I want to mention is that there |
| are many different version control systems but we can classify |
| them normally in two main types: centralized VCS's and |
| decentralized VCS's. So what is the difference between these two? |
| Let's use again our friends Janet and Brett. |
| In the case of a centralized version control system |
| there is a single centralized, as the name says, |
| repository. On which they are commiting their files. So when |
| Janet commits a file. The file will go from |
| her local working directory to the repository, and the same |
| will happen to Brett. The decentralized system is a little |
| more interesting because in this case, they will both have |
| sort of a local repository in which they can commit |
| their changes. So they can commit changes without the other |
| users of the VCS being able to see these changes. |
| And when they're happy with the version. And when they're |
| ready to release the version, they can push it to a central |
| repository. And at that point, it will become available to the other |
| users of the repository. To the other users of the VCS. There |
| are several advantages in a distributive |
| system. I'm just going to mention a few, |
| because there are really many. One is the fact of having this |
| local version. If you used VCS before, I'm sure you've been in |
| the situation in which you want to kind of take a snapshot |
| of what you have. But you don't want that snapshot to be available |
| to the other users. Because it's still not ready to be |
| released, to be looked up. If you're using a centralized system, |
| there's really no way you can do that, unless you make |
| a local copy, which is something we said you don't want |
| to do. With a distributor, with a decentralized VCS you can |
| commit your local changes here, in your local repository, and you |
| can push them to the central repository only when you're ready. |
| Another big advantage, is that you can use multiple remote repository. |
| In fact, centralized is not the right name for this |
| one. This is just a remote repository, and I can have |
| more than one. For example, Brad might want to push |
| to another remote repository. As well. For instance, this could be |
| a repository where the files are accessible for wider distribution. |
| Imagine developing a software system in which a team is sharing |
| internal versions, and then only some of these versions are actually |
| pushed to the repository that is seeable to the whole world. |

## 61 - Introduction to GIT

| One good representative of distributed version control systems, is |
| GIT. A distributed version control system that was initially designed |
| and developed by Linus Torvalds. I'm pretty sure you |
| know who Linus Torvalds is. He's basically this guy who |
| started and created the Linux operating system. And Linus |
| was unhappy with the existing version control systems, and wanted |
| a different one. He wanted to use it for maintaining |
| the Linux kernel. In particular, he wanted one with some |
| key characteristics. For example, the fact that it was distributed. He |
| wanted it to be fast. He wanted it to have a |
| simple design. And he wanted to have a strong support for |
| parallel branches, because many people were contributing to the kernel at the |
| same time. And therefore there many different branches of development. And |
| finally, he wanted for the virtual control system to be able to |
| handle large projects. As the Linux kernel is, and to do |
| it in an efficient way. So if you want to get an idea |
| of how popular GIT is today, there was a survey performed across the |
| Eclipse IDE users, and it showed that in 2013 GIT was used by |
| about 30% of the developers. So the, it had a 30% adoption rate. |
| So we will use a GIT as a version control system for the class. |

## 62 - Installing GIT Question

| As we did for Eclipse, and IDEs in general, we want |
| to start a GIT in a hands on way. So we're going |
| to start by seeing how to install GIT. And GIT is also |
| multiplatform, so you can install it no matter what operating system you |
| are using, unless of course you are using some arcane operating system. |
| But if you are using Linux, for instance, there should be a |
| package available that can install GIT for your specific distribution. If you're |
| using Mac OS, GIT is also available as part of XCode and |
| also as an independent package. Finally, if you're using Windows, GIT is |
| available as a package with an installer. In general, you can go |
| here to get information about how to get GIT, where to download |
| it, how to install it, and so on. So, now what I'd |
| like for you to do is to go, get GIT, install it, |
| in case you don't have it installed already on your machine. And |
| after that, you should be able to run GIT from the command |
| line. And, that's exactly what we're going to do through a demo. |

## 64 - GIT Workflow

| But before jumping into the demo I would like |
| to give a high level overview of the GIT workflow, |
| which will help you better, following the demo. So let |
| me start by representing four fundamental elements in the GIT |
| workflow which are these four: the workspace which is your |
| local directory. The index, also called the stage, and we'll |
| see in a minute what the index is. Then, we |
| have the local repository. We'll also refer to this as |
| HEAD in the, when we explain the different commands |
| and then, the word flow. And finally, the remote repository. |
| If you consider a file in your work space it |
| can be in three possible states. It can be committed |
| which means that the data, the latest changes to the |
| file are safely stored here. It could be modified, which |
| is the case of the file being changed and no, |
| none of these changes being saved to the local repository |
| so locally modified or it can be staged. And |
| stage means that the file is basically part of this |
| index. And what that means, that it's been tagged |
| to be considered in the next commit. And I know |
| that this is not all 100% intuitive, so let's |
| look at that again by considering the actual workflow and |
| let's see what happens when you issue the different |
| commands in git. So the first command that you normally |
| run in case you, you're getting access to a remote |
| repository, is the git clone command. And the git clone, |
| followed by the url for that repository, will create a |
| local copy of the repository in your workspace. And of |
| course, you don't have to do this step if you're |
| creating the repository yourself. The next command that we already |
| saw is the command add. And what the command add |
| does is to add a file that is in the |
| workspace to this index. And we say that after that, the |
| file is staged. So it's marked to be committed, but not |
| yet committed. And here I'm just mentioning this minus u option. |
| If you specify the minus u option, you will also consider deleted |
| files File, but let's not get there for now, we'll talk |
| about that when we do the demo. As I said, if you |
| add the file, it just gets added to this index but |
| is not actually committed, so what you need to do, is to |
| commit the file, so when you execute git commit, all the |
| files that are staged, that are released it here, their changes |
| will be committed to the local repository. So your files, as |
| I was saying, they can be in three states. They will |
| go from the modified state to the stage state when you |
| execute the app. And then from the stage state to the |
| committed state when you perform a GIT Commit. Okay, so at |
| this point your changes are safely stored in the local repository. |
| Notice that you can also perform these two steps at |
| once by executing a Commit -a. So if you have |
| a set of modified files, and all these files are |
| already part of the repository, so they're already known to diversion |
| control system, you can simply execute a commit -a. |
| And what the commit -a command will do, it |
| will stage your file and then commit them. All at |
| once. So it's a convenient shortcut. Of course, as I said, |
| this will not work if the file is a new file. |
| So if a file is a new file, you have to manually add |
| it. Otherwise commit -a will just stage and commit at once. |
| As we discussed when we looked at the diffence between centralized |
| and decentralized version console system. We saw that in the case |
| of the decentralized, there is a local repository which is this one. |
| And then you have to explicitly push your changes to a remote |
| repository, and this is exactly what the git push command does. It pushes |
| your changes that are in the local repository to the remote repository |
| so at this point all of your changes will be |
| visible to anyone who has access to the remote repository. |
| Now, let's see the opposite flow so how does it |
| work when you're actually getting files from the repository instead |
| of committing files to the repository. So the first command |
| I want to mention is the get fetch command and |
| what the get fetch command does is to get files from |
| the remote repositories to your local repository, but not yet to |
| your working directory. And we will see what is the usefullness of |
| doing this operation. Of having the files all in the local respository, |
| but not in your local directory. So, what that means, just to |
| make sure that we're on the same page. Is that you |
| will not see these files when you workspace. You will still have |
| your local files here. So this is sort of a physical distinction. |
| In order to get your data files from the local repositories to |
| your workspace you have to issue another command. Which is |
| the command git merge. Git merge will take the changes in |
| local repository and get them to your local workspace. So at |
| this point your files will be updated. To what is in |
| the remote reposity. Or at least what was in the |
| remote reposity at the time of the fetch. SImilarly to what |
| happened for the add and commit. There's a shortcut which is |
| the command git pull. So in case you want to get |
| the changes directly. To your work space with a single |
| command, you can issue a git pull command and what will |
| happen, is that the changes will get collected from the |
| remote repository and they will go to your local repository and |
| to your work space, at once. So this has the |
| same affect as performing a git fetch and a git merge. |
| So if we can do everything in one command, why, |
| why we want to fetch and berch as two separate operations? |
| So one of the reason is because this allows us |
| to compare files before we actually get the latest version |
| of the files. In particular, I can run the command |
| git diff head to get the difference between my local files, |
| the files in my working directory, and the files in |
| my local repository. So what I can do, I can |
| fetch the files from the remote repository, and once I |
| fetch these files. I can run a git diff head and |
| check what the differences are. And based on the differences decide |
| whether I want to merge or not. So while we are talking about |
| git diff, there is something else that you can use with the |
| diff command. So what you can do, you can run git diff |
| without further specifying head. In this case, what the command tell you |
| is the difference between the files that you have in your work |
| space and the ones that are staged for a commit. So basically, |
| what it will be telling you, is that what you could still |
| add to the stage for the further commit, and that you |
| haven't already. So what local changes will not make it to the |
| next commit, basically. And this you can use, for example, as |
| a sanity check before doing a commit to make sure all the |
| local changes that you have, and that you want to commit, |
| are actually staged and therefore will be considered. So now we will |
| cover all of the commands that we saw here. In our practical |
| demo. But please feel free to refer back to this Git Workflow |
| to get a kind of a high level vision. Or maybe you want to keep it next to |
| you, because this really gives you the overall structure |
| and the overall view of what happens when you |
| run the different commands. And it also helps you |
| visualize The different elements that are relevant when you're |
| using GIT. So the workspace, once more, the index |
| or stage, the local repository, and the remote repository. |

## 65 - GIT Demo_ Intro to Git

| In this first part of the git demo, we will |
| call it the basics of git. So for example, how to |
| introduce yourself to git, how to create a repository, how to |
| commit changes and get changes from the repository, and so on. |
| So after you installed git you should have the git tool |
| available on the command line, so you can run the command |
| git and, if you just execute git you will get the |
| usage information for git, with the most commonly used git commands. |
| And to find information on any command, you can simply |
| type git help and the name of the command. For |
| example, let's try to write git help init. And that |
| brings up the git manual page for git init, which describes |
| the command, the synopsis, and so on. Now, let's get |
| started with using git by introducing ourselves to git, which is |
| the first thing we need to do. To do that |
| we use the git config command, in particular we are going to |
| write to the git config minus, minus global |
| user dot name. Which means we are telling it |
| our user name. We'll specify our user name which |
| in this case is George P. Burdell. You could |
| also provide your email address in the same |
| way. So you still use the git config --global |
| command. But in this case you will write user.email |
| as the property. And then you'll specify a suitable |
| email address. In this case, the email address of George P. |
| Burdell. We will now look at some commonly used commands that to |
| create and maintain a local repository. Let's first create a |
| new project and call it my project. So, to do that we |
| are simply going to create a directory and then we're going |
| to move into that directory. Now, if we try to call the |
| git status command at this point to see what's the state of |
| my project, of course git doesn't know anything about this project, right? |
| So, you will get an error. It will tell you that, basically, |
| we're not in a git repository. So how do we create a git |
| repository? How do we make this? A Git repository, but we do it |
| by calling git init and the output will tell you that the |
| repository was initialized. If we check the status again, you will see |
| that now Git recognizes the repository and will tell you that there is |
| nothing to commit because, of course, |
| the repository is completely empty. So let's |
| just create a new, empty file. Which we're going to call REAME. So |
| now if you run git status, as you can see, git will |
| tell you there is a file that's called README, but it's untracked. |
| Now what that means is that the file not staged, if you |
| remember our lesson. So what we need to do, we first need |
| to tell git that, you know, this needs to be considered. And |
| the way we do that, is by calling the git at command |
| and then we specify README as the argument for the command. If |
| we call again, Git status. Now, as you can see, Git knows |
| that there is a new file called README, because the file |
| is staged. So Git is aware of the fact that this |
| file has to be committed. So, to commit a file, |
| we simply execute git commit, which will open a text editor, which |
| can be different, depending on what is your environment, and here |
| we need to add a comment to be added to the commit. |
| So here we simply write in Added README file, then we |
| can close and save And this will add the file to the |
| Git repository. The local Git repository of course. At this |
| point, if we ran Git status again to see where we are. |
| You can see that Git tells you that there is nothing |
| to commit. Because of course the only file that we have, is |
| committed to the repository. Now, let's make some changes to our |
| README file. I'm just going to add some text here. Once more, we |
| can run git status, and at this point, git knows about |
| this file. So, it will know that README file has been modified. |
| Remember that before, it was telling you that it was a new |
| file, now it knows that there was a different version in the |
| repository. So something we can do, at this point, for example, is |
| to check the differences. Between this file and the committed one by |
| executing get diff readme and if you look at the output of |
| the get diff command here, you can see that this line, readme |
| file content was added and you'll see that it was added because |
| there's a plus sign before that line. In case of deletion of lines, |
| you'll see a minusm sign there. So at this point, if we |
| want to commit our file, remember that we'll always have to tell git |
| that we want to stage the file before committing it. Otherwise, it |
| will be ignored by the commit operation. So to tell git, that the |
| file has to be staged, we will, can use the usual git |
| add command. But if you remember the lesson, we can also use a |
| shortcut. So you, we don't really have to do this in two steps. |
| We can simply say, git commit -a, and this will tell git to |
| commit all of the files that git knows about, which in this |
| case is only the written file of course. Something else that we can |
| do, is that we can also provide the right away message for |
| the commit, without having to open an editor. So, to do that we |
| can specify the -n option. And at this point a we can |
| just put a in double quotes our content we press enter and as |
| you can see it will notify us that one file was changed |
| and in particular it will also tell you that there was an a |
| insertion again if we run git status you will see that |
| there is nothing else to commit. So now let's imagine that |
| you want to see the version history for your repository. You |
| can do that by running the git log command. So if |
| you run that, it will show you all the different commits |
| For your repository. And each commit has got a commit ID, as |
| you can see here and the one down here is |
| the first commit, where as the one above is the second commit. |
| And as you can see, we'll also show you the comments associated |
| with each commit. And in case you wanted to see the changes introduced |
| by a commit. You can use that git show command, and you |
| can provide the commit ID for the commit that you're interested in. |
| And you don't really need to provide the whole ID, you can |
| provide the first four or more characters. So that's what we're going to |
| do here. So we're going to specify the second commit, and when we |
| execute the command it will show use the changes introduced by that commit. |
| To fetch a repository from a remote server, you can |
| use the git clone command. So you will write git clone |
| and then specify the URL. For the remote repository. Here |
| we are using the SSH protocal and there are different protocals |
| that can be used, so the remote repository can be |
| made available in different ways. As you can see, when you |
| clone the project, the project is cloned into the local directory. |
| If you wanted to import the project under a different name. |
| You could just specify the name that you want for the |
| Local Directory. For example, in this case, myproject2. And, |
| so here you'll get the project in my local work space |
| with the name that I specified. So, let's go inside one |
| of these two projects that have the same content because they're |
| coming from the repository. If you want to see the details |
| of the server you can use the remote command and specify |
| the flag -v. And here we'll show you what is the remote |
| repository now let's go ahead to make some changes to the project |
| for example let's add a file. So I'm just going to create this |
| empty file which I am going to call new file I'm going to |
| add it to my index so that it gets committed. Later on and |
| then I'm going to run git commit to actually commit it to the |
| local repository. And I'm going to specify the comment for the commit right |
| away here from the command line. So when we do that the |
| file gets added to my local repository. And if we want to double |
| check that, we can run git log. And if you look at |
| the last commit at the top, you can see that it's telling |
| me that the new file was added to the repository, showing the |
| comment that I added. But this is just for the local repository, |
| so I need to use the git push command to push it |
| to the remote repository. And at this point, when I run that, |
| my local changes will be committed. To the remote repository. So now |
| let's go to the other copy of the project that we created. |
| The one under directory myproject2. If you remember this project was |
| linked up to the same remote project. But of course, if we run |
| get log here, we don't see this latest change that we made, because |
| we didn't synchronize this local copy with the remote copy. And so we |
| just have these files, the README and ,Five that worked there before. |
| So what we need to do is that we need to pull the |
| changes from the remote repository using git pull, and when we do that, |
| that will actually pull these changes and therefore, create the new files that |
| we created in the other directory. And if we run git log now, |
| you can see that now we have the new entry. The comment at |
| the top, that says this new file was added and of course, this |
| is just an example, so we had two copies of the project on the |
| same machine and for the same user, so the normal users scenario for |
| this, it will be that, each user will have their local copy, but this |
| should have given you the idea of how, git allows you to work |
| on some local file. Commit them and push them to a remote repository and |
| other users to get your changes, do further changes push |
| them as well and then, you know, they will allow you |
| to get their changes, and so on and so forth. So |
| really allows this collaboration between different users and keeping track |
| of all the changes made by the different users. So now |
| let's look at some more advanced concept, which are the concept |
| of branching, and merging. So what branching means is basically is |
| to make a copy, to create a branch of the current |
| project so that we can work on that copy indpendently from the |
| other copy, from the other branch. And then we can decide whether |
| we want to keep, both branches, or we want to merge them at |
| some point. And you can of course have multiple branches, not just two. |
| And the reason why this is particularly useful is because in many |
| cases if you think, about the way we develop software in general, |
| we work with artifacts. We might have the need to create kind |
| of a separate copy of your work space. To do some experiments for example. |
| So you want to change something in |
| the code, you're not really sure it's going to |
| work and you don't want to touch |
| your main copy. So that's the perfect application |
| for branching. If you want to do |
| something like that...you want to experiment or do |
| some modifications that you're not sure about, |
| you will branch your code, you will do |
| the changes...and then if you're happy with |
| the changes, you will merge that branch |
| with the original one, or worse if you're not happy with the changes you will |
| just throw away that branch. So this is just one possible use of branch but |
| it's one of the main uses of that. So in all let's see how that |
| can be done with git. So first of all if you |
| want to see which branches are currently present in your project, you can |
| simply execute git branch, and in this case, you can see |
| that there's only one branch, which is called master, and the star |
| there indicates that this is our current branch. So how do |
| we create a new branch? So we simply run the command |
| git branch and specify a name for the new branch, for example we'll |
| call it newBranch, to make it very explicit. At this point, |
| if we run git branch of course, we will have |
| a new branch plus master will still be our current branch. So |
| if you want to switch to the new branch, we will use |
| the git checkout command and specify the name of the branch that |
| we want to become our current branch. So when we run that, |
| git will tell us that we switched to the new branch. And |
| if we run git branch you will see that now the star |
| is next to newBranch because that's our current branch. There is a |
| shortcut for these two commands. If you run the command git |
| checkout specify the -b flag and then the name of |
| the new branch it will do both things at the same |
| time. It will create the new branch called testing in this |
| case, and then it will switch to new branch and then |
| it will tell you after executing the command. So now if |
| we look at the git branch output, you can see that |
| there is three branches and we are currently on the testing branch. |
| So now let's create a new file and just call it test |
| file, put some content in there, save it, we edit and commit it. |
| And as you can see, now in this current branch, we have our |
| testFile. So now let's switch to a different branch. So let's go back |
| to the master branch using the usual git checkout command. So now if |
| we do an ls, if we check the content of the current directory, |
| we can see that the testFile is not there, because of course, it's |
| not in this branch. so now let's assume that we are happy with |
| the testFile that we created, with the modification that we made on the |
| branch. And so we want to merge that branch with our master branch. |
| To do that we can call the git merge command and |
| we'll specify the branch that we want to merge with the current |
| one. So we will specify testing in this case. That will merge |
| the testing branch with the current branch, which is the master. Which |
| means that now the testfile is in my current working directory, |
| is in my current, Current branch. And if I run the branch, |
| you'll see that the testing branch is obviously still there, so let's |
| assume that we want to delete the testing branch at this point |
| because we don't need it anymore. We could simply execute |
| the branch -d which stands for -delete, specify |
| the name of the branch and this will eliminate that |
| branch as confirmed by running the command git branch or the |
| testing branch no longer shows up. So, something that might |
| happen when you merge a branch is, is that you |
| might have conflicts For example, in case you change the, |
| the same file into different branches. So, let's see an example |
| of that. So, we're going to check which branches we have, |
| so we have two branches, in this case, master and newBranch |
| Our current branch is master. Let's open this file called new |
| file and, add some content there. So now let's commit |
| this changes to the get to the local repository. Now |
| let's switch to the other branch and if you remember we |
| do this by running git checkout and the name of the |
| branch. And at this point we do the same operation here. |
| So we take this file and we change it here to. In this |
| case we have content that reflects the fact that we are. In the |
| new branch just for convenience. At this point, we also can move the |
| file here. The comment here is, of course, that this is the new |
| file in the new branch. So, at this point, what we have here |
| is that we have this file called newfile that has been modified |
| independently both in the master branch and in the new branch. So we |
| have a conflict. Right? So, now, let's switch back to the master branch. |
| So now, let's say we want to merge the two branches. So |
| since we are in master, we want to say that when I |
| merge the new branch into the current one. And when we run |
| that, we get an auto merging conflict. So at this point what |
| we can do, is that we can manually fix the conflict by |
| opening the new file. So the file that was showing the conflict. |
| So here you can see the kind of of information that you get |
| in the conflicted file. So it's telling you basically that there is |
| in the head which is the, the master this conflict. Which is new |
| file in master. Which is the content that we added of course. And |
| then you know, under, you know, the separator you can see the content |
| that was added in the new branch. Which is the contents in new |
| file, in new branch. So basically, what this is showing you is the |
| parts of the file that are conflicting. In this case, we only have |
| one line, is basically the whole file into two versions and you can |
| decide which version you want to keep or how you want to merge in |
| general, the two pieces. So here, let's assume that we |
| want to keep the content from the master. So what we're |
| going to do is we're going to elimate the annotations |
| and we're going to eliminate the additional content. We save this |
| file. So at this point what we need to do |
| is simply to commit the modified file (the merge file) and we |
| do that in the normal way. We call git add, specifying |
| the file, so git add newfile. Then we run git commit |
| newfile, and we specify in the comment for clarity that this is the merged file, |
| so that we performed a merge. And at this point we are done with our merge. |

## 66 - GIT Demo_ Git + Eclipse

| Now that we saw some of the git basic |
| functionalities in practice, let's go a step further. If |
| you remember I mentioned before that many of these |
| version control systems are actually integrated into IDE's. So |
| what were going to look at next is what happens |
| if we put together git and eclipse. And the |
| result is egit, or EGit is a plug in |
| for the eclipse IDE that adds git functionality to eclipse. |
| So let's see how that works in practice. So |
| support for git is available in many IDE's including |
| Eclipse. And if you want to get github |
| for Eclipse, you should go to eclipse.github.com and you can |
| download the plugin. So this bring us to the |
| plugin page and you can use the provided URL |
| and directions to install the plugin. In this case |
| we're going to copy this address. So we're going to |
| Eclipse, Help, Install new software. We can click on Add |
| to add a new site from which to get software. We |
| paste the location that we just copied here. And we |
| can give it a descriptive name. In this case I'll just |
| call it Eclipse Git plugin. Then when I click okay, |
| Eclipse will go, and look for plugins. And as you can |
| see, there are two options. We can select both of them, |
| and click on next. You can see that the Eclipse identified |
| a few dependencies. You can click next and accept them. You can |
| accept the terms and conditions for the plug in, and then just |
| finish. And at this point, Eclipse will install the plugin, which might |
| take a little bit of time. So we're just going to speed it up. |
| And when Eclipse is done, you will get this prompt that will |
| tell you that you need to restart Eclipse for the plugin to |
| be actually installed. And at this point, you want to click yes. And |
| when Eclipse restarts. You'll have your plugin. We're going to go to the git |
| repository perspective that we can select here. And when we click |
| OK, you can see that our display will change. And since |
| we don't have any repository yet, we are provided with the |
| possibility of adding an existing local git repository, cloning a git repository |
| or creating a new local git repository. We're going to add an |
| existing local repository. This is the one that we created earlier, |
| so we'll select it and click finish, and you can see |
| that my project is now added to this set of git repositories. |
| Now let's check out the project from the repository by selecting import |
| project. And here you can import something as an existing project, you |
| can use a new project wizard, and in this case I chose |
| the option of importing as a general project. Then I click Next and |
| as you can see, I have the project name up there and |
| I can click Finish. So now, if I go to the resource perspective |
| by clicking here, I can see that the project has been added |
| to my set of projects. And I can see all the files within |
| the project, particularly, if I click on the README, you can see |
| that we have the Readme file that we created before. Same thing for |
| the test file. One thing I can do at this point, it |
| to execute different git commands, perform |
| different git operations by using the team |
| submenu in the contactual menu. And here there are several things |
| I can do including some advanced commands. And just to give it a |
| shot, I am going to try to click show local history, and this |
| shows the history of the file. For example it shows the author and |
| it shows when he was created, when he was authored. let's make |
| some changes to this file by adding some new content. Okay. I saved |
| the file and now I can see that error that indicates that my |
| file was locally changed. So now if I go to the team menu, |
| you can see that I have the option to add to the index, |
| to stage the file. And now I got this new label that star |
| that shows the files added to the index. And now at this point, |
| I can go to the team menu again and I can actually commit |
| the file by selecting the corresponding entry. This allows me to enter |
| the commit message, exactly in the same way which I could do |
| that from the command line with the textual editor. And after I |
| put the comment there, I can actually commit. And now if we |
| look at the history view, we can see here that we have |
| a new version for the file that we just modified. And we |
| can also see the commit comment. And, at this point, if we |
| had remote repository we could push our changes to that remote repository |
| as well. Again, using the team submenu and |
| the contextual menu. And, speaking of remote repositories, what we |
| are going to see next is how to use GitHub |
| repositories which are remote repositories that are hosted on GitHub. |

## 67 - GIT Demo_ Github

| In the interview that we did at the beginning of the class, |
| we talked with John about GitHub, where GitHub is a Git hosting website, and |
| John told you all about it. For this class, we will be |
| using GitHub as our Git hosting. Let's see how GitHub works in practice and |
| let's see some of the common features offered by GitHub. |
| This is what we'll do in the third part of this Git demo. What I'm showing here |
| is the GitHub website and as I said, GitHub is a Git hosting website and |
| you can create an account on GitHub by simply signing up on the website. And |
| because we already have an account that we're simply going to sign in |
| to see what kind of functionality GitHub offers. And we're going to specify our |
| username and password. And as you can see on the GitHub website, |
| you can use this menu up on the right to create a new repository or |
| change the account settings. Let's click on our user profile. And |
| here we can see some statistics for our user. For |
| example, we can see statistic about our contributions and our repositories. So |
| now if we go to the Repositories view, we can create a new repository. |
| We give it a name. Let's call it myrepo. We can provide the description for |
| the repository. If we want, we can initialize the repository by adding a README |
| file. And even though we are not doing it right now, if you can see up here, |
| you can also add a license here on the right and it allows you |
| to choose from a set of predefined licenses. And you can also a .gitignore file, |
| which, in case you don't know what that is, it's a very convenient file that |
| will automatically exclude from the repositories file that should not be added. |
| So if you remember in the lesson we said there are things that you should not |
| add to the repositories. For example, derived files. So |
| here, using this menu, you can pick the type of project that you have. |
| For example, Java project or PHP project or many other kinds of projects. And |
| the GitHub will automatically add that file for you. |
| But let's skip that for now and simply create our repository. And |
| that creates a repository that contains the README file because that's what we |
| decided to do. And it also allows you to edit the README file by clicking on it. |
| It will bring up an editor and here you can write, you know, |
| for example, initial readme for your project. Then you can add your |
| commit message up there and then you can commit the changes to your README file. |
| The site also provides many other features, like, for example, creating issues, |
| pull requests, adding and editing a wiki, and also, you know, |
| defining other characteristics and settings for the repository. Now, if we go to |
| the repository, you can see that we also get the HTTPS link for the repository. |
| So this is the URL that you can use to clone your repository. If you remember, |
| with a git clone command, that's the URL that you can specify. So |
| let's try to do that and clone that repository. So we're going to copy this URL. |
| To do that, we're going to execute git clone and specify the URL that we |
| just copied. And you can see that the project was created, was cloned locally. |
| And if we go under myrepo, which is the name of the repository, you can see that |
| the README file that we created on GitHub is here. So if we create a new file, |
| which we're going to call again, newFile just to be clear. And then we |
| can add it, commit it, specifying as usual a commit message. So at this point, |
| we can push our locked out changes to the remote GitHub repository. And |
| because the GitHub repository is password protected, |
| we have to specify our login and password. And of course, if you |
| pass the wrong password, GitHub is not going to let you in. So let's try again. |
| Let's try to get the password right this time. I'm going to specify again, |
| my login and my password. At this point, the push is successful and |
| my changes are actually pushed to the master, which is the GitHub repository. |
| To double check that, let's go back to the GitHub repository and as you can see, |
| that the file that we added, newFile, is there as expected. And of course, |
| there's many more things that you can do on the GitHub website, so |
| I strongly encourage you to go and try out things. But |
| the key message here is that the GitHub is a Git hosting website where you |
| can get an account and create your remote repositories. |

## 68 - GIT Recap

| Now that we are done with our demo, I just want |
| to go through a quick GIT recap to remind you of the |
| main commands that we saw, and what they do. And you can |
| also use these as sort of a reference when you work with |
| GIT. And by the way, if you look around and you do |
| a search, you can see that there's tons of examples on the |
| web of GitHub tutorials, videos, examples, manuals. So feel free to |
| explore. And I'm actually going to put some references to tutorials and |
| videos that I found particularly useful in the notes for the class. |

## 69 - GIT Recap_ Local Repositories

| So, let me start by recapping some of the operations that |
| we can perform on local repositories. I'm just going to list them |
| here and go through them by separating them into three main |
| categories. The first one is commands that, to create a repository and |
| notice that not all of these are git commands, that for |
| example, to create the repository, we would normally want to. Create a |
| directory, which is exactly what we did in our demo. We want |
| to go to that directory and then execute the git init statement, |
| which initializes that directory as a git repository. The second |
| category includes commands that we'll use to modify the content of |
| the repository. We saw that we can use git add |
| to add a specific file or a complete directory to our |
| index. So to the list of files that will be |
| committed, that will be considered in the next commit. Then we |
| can use commit to actually commit the changes that we |
| made to those files to our local repository, and we can |
| also use git move and git rm or git remove |
| to move files around and to remove files. Finally, the |
| third category is the category of commands that we can |
| use to inspect the concrete repository. And this set includes git |
| log, that we can use to see the log of |
| the repository, git status, that can give us important information |
| about the status of the file center repository. Git diff, |
| that we can use to see the differences between for example, |
| our local files. And the remote files. And finally git |
| show, that will show us information about our last commit. What |
| we committed, what were the changes and so on. And again, |
| we saw most or all of these commands in our demo. |
| So let me also remind you of a possible workflow. Which |
| again, we already saw but it's always good to go through |
| it once more. And remember that this is just an example. |
| It's just a possible workflow. You can do many different things, |
| you can have many different workflows with git. This is just |
| up to illustrate some of the things that you can do. So, |
| you might do some local editing. Execute git status to see what |
| files you changed. Then you might run a git diff on the |
| files to see what are these changes. And then you can run |
| git commit -a to commit your changes. And in case you |
| want to specify the commit message right away without having to go |
| through an editor, you can also add the -m parameter and |
| specify the message here on the same line. |

## 70 - GIT Recap_ Remote Repositories

| SImilarly, let's go through some commands that you can run on |
| remote repositories. First command is the command to copy a repository, |
| which is git clone in which you get a remote repository and you make a lot of |
| copy in your working directory. The repository can be specified as a URL. |
| It can be a local file, it can be specified using the HTTP or |
| the SSH protocol, and there's also other ways to do it. |
| This creates a complete local copy of the repository, as it says, and links it |
| to the remote repository, which is what is called the origin. And if you want, |
| you could also actually link to the repository, later. Then the normal way of |
| receiving changes from a repository is to perform a git pull command. And we saw |
| that you can also perform the same operation through two commands, get fetch and |
| git merge. In case you want to inspect the changes before actually merging them, |
| before actually getting them in your local copy. And |
| if you want to send changes that you have in your local repository to |
| a remote repository, you will use the git push command. |

## 71 - GitHub Setup Assignment Question

| This is ultimately pretty simple. All you need to do is visit |
| github.com/join and set up a free GitHub account. If you already have a GitHub, |
| account you can sign in using your existing account. If you want to |
| use a separate identity for the class, feel free to set up a second one. |

## 73 - Gathering Requirements Question

| Gathering requirements is one of the most difficult tasks a software |
| engineer faces. In industry, you may gather requirements from end users, |
| external clients, or from co-workers in other areas of your own |
| company. Occasionally, you may receive a well documented set of requirements. |
| However, in most cases, you will need to glean the requirements |
| from conversations with the prospective clients, and distill them down into |
| something actionable on your own. Suppose a teacher came to you |
| with a request for a piece of software their students could |
| use to find out the average length of the sentences in |
| their essays. What questions come into mind to help you figure |
| out the full requirements for this project. Write down a list |
| of at least ten questions that might help you determine them. |
| Please take the time to do this before moving on. There's |
| no penalty for looking ahead, but if you skip this exercise |
| you'll cheat yourself out of the benefits of brainstorming and getting |
| your mind around the project before being bombarded by more information. |

## 75 - Choosing Good Questions Question

| Now that you've written some of your own questions, consider the following |
| three. Which is the most likely to be useful for determining the detailed |
| requirements? Maybe, what OSes should it run on? Or maybe, how will the |
| user specify input? Or finally, how many lines of code should it take? |

## 76 - Choosing Good Questions Solution

| The last question is almost never a reasonable one. For one |
| thing, the client should not need to know or care about |
| how many lines of code make up the program's source code. |
| In forming requirements, you should avoid |
| implementation specific questions that do not |
| directly interface with the user. The first question is very relevant |
| in some situations. For example, a graphic sentence with video game or |
| performance is key. However, you should not write any operating system |
| specific code unless absolutely needed, and should strive to make your code |
| platform independent whenever possible. The |
| second question, however, is very relevant. |
| Now that you've thought a bit about what you might ask of |
| the client requesting this program, let's watch Alvin, one of Udasea's |
| engineers, asking his own questions. He'll be speaking with Lauren, the client. |

## 77 - Requirements Interview

| Hi, I'm Lauren. |
| >> Hi, I'm Alvin. |
| >> I'm an instructor at a university nearby and I've been noticing that when |
| my students write their essays, they have |
| very long, very wordy sentences and I would |
| like to develop some kind of tool that they can use to keep track of |
| this and maybe perfect their writing style. |
| Do you think that's something you could do? |
| >> I think so. Let's start by helping me get acquainted with the students |
| in the class. So how many students do we have in this class typically? |
| >> Usually about 45 per unit, but I can have up to six units a semester. |
| >> 45 students, and six sections per |
| semester. That's a farily reasonable size. So, |
| do you know anything about what the students are using as far as computers go? |
| >> I don't know what kind of computers they're using. And they |
| could be, I don't know, anywhere from having no tech experience to |
| being pretty proficient. |
| >> Do you know anything about how |
| familiar the students are with computers in general? |
| >> I'm sure we have some people on the low end that have |
| never done any type of programming, and |
| then some people who are pretty self-sufficient. |
| >> Okay, and I guess my last question related to |
| the students is, what is the students actually submitting to you. |
| >> They've been sending just raw text files via email to me. |
| >> So from the sounds of things |
| we have a fairly broad, I guess base |
| of students to work with, both in technical proficiency |
| as well as their operating system environments potentially. |
| So I think what we'll probably do to start |
| off with is make a command line, Java |
| based tool. That the students can run and we'll |
| give them a fair amount of you know, documentation |
| on how to use the tool. And I expect |
| that there will be a lot of little error conditions that may happen |
| that we want to produce a reasonably friendly message were anything to go wrong. |
| >> Yeah. That'd be great. |
| >> So, a little bit more, I guess about |
| the actual essay itself, its submission, what constitutes a word? |
| >> I really only care about the longer words, so, is there a |
| way that we can only count words that are maybe above three letters? |
| >> I think |
| that's something we can do. And I think |
| that because you seem a little bit unsure |
| we might be able to have that be |
| a little bit more flexible than we otherwise would. |
| >> Great. |
| >> What does a sentence mean to you? Is it kind of flexible? |
| >> I would say anything that ends in a period or |
| even a question mark. Maybe even an exclamation mark. or, something |
| even, maybe even with a comma or semi-colon. I really only |
| care about the sentences that aren't gramatically correct and are too long. |
| >> I think we can probably make that a little bit more flexible too |
| so that way, you can kind of say we're going to, or you want to include them. |
| >> Mm-hm. |
| >> So maybe, sounds like you are little bit on the fence |
| about whether or not say, a comma should be considered a sentence. |
| >> Mm. |
| >> Entirely on its own or not. So we |
| can probably make that a little bit configurable as well. |
| And so, just to confirm the actual end result to |
| the student is the average number of words per sentence? |
| >> Yeah, yeah that'd be fine. |
| >> Okay, overall to start off with, looks like we have some |
| sort of customization of the word length that we want to look for. |
| >> Mm-hm. Yeah. |
| >> We have some kind of variability in |
| what we want to have as acceptable sentence structure. |
| So, periods, question marks, semicolons, things like that. And, the end result |
| to the student is if we're successful, they'll get the average number of |
| words per sentence. Otherwise we tell them something a little bit helpful to |
| kind of put them on the right track to use the tool correctly. |
| >> Yeah that's the error codes right? |
| >> Hopefully not error codes but something a little bit nicer. |
| >> [LAUGH] Okay. |
| >> So I think I have enough to |
| get started and produce something that's you know, |
| a reasonable I guess, rough draft. Of something |
| that you can use to help your class out. |
| >> Great. Thank you. |
| >> Thank you. |

## 78 - Average Sentence Length Requirements

| You've heard Alvin come up with several conclusions for how to |
| set up the program. And we're going to ask that you follow his |
| instincts. We'll spell that out here in a little more technical details |
| so that everyone is working from the same basic starting point. The |
| program must be written in Java and must not make you any |
| nonstandard Java libraries. You will be tested on a machine with the |
| vanilla installation of Java 1.6. Your program must compile on the command |
| line using the Java C command without any additional options. All code |
| required to execute the program that is not part of the |
| standard JDK, must be included as source code with your program. |
| Your program should be an application. That is, it should have |
| a main method and should be executable from the command line using |
| the Java command. The user should be able to provide a |
| file path to the file they wish to be analyzed as a |
| command line argument. User should be able to specify which delimiters |
| count as sentence separators, using the flag -d, defaulting to Lauren's initial |
| thoughts on what should be used as delimiters. The user should be |
| able to specify a lower limit for word length, using the flag -l, |
| defaulting to Lauren's guess at what value might be good. Finally, the program's |
| output should be the average sentence |
| length. Rounded down to the nearest integer. |

## 79 - Lesson Overview

| Hello and welcome to the second part of our software engineering course. In the |
| previous mini-course, we discussed some basic principles |
| behind software engineering. We provided an overview of |
| several software process models and we introduced |
| some important tools that can help developers |
| increase their productivity. In this mini-course, we |
| will focus on requirement and prototyping. More precisely, |
| we will discuss in depth requirements |
| engineering activities. We will also discuss |
| techniques to perform a system analysis |
| and design in an object-oriented fashion. So, |
| let's start the first lesson of this mini-course, which is about the use |
| of engineering techniques to understand and |
| specify the purpose of a software system. |

## 80 - Interview with Jane Cleland-Huang

| As we did for other lessons, before starting this |
| lesson on requirements engineering, I want to ask a world |
| expert on this topic a few questions. I'm here with |
| Jane Cleland-Huang, a professor at the DePaul University. And Jane |
| is a world expert in the area of requirements |
| engineering, which is the theme of this lesson. So I'm |
| talking to Jane who is currently in Chicago and I |
| want to. Ask her a few questions about requirements engineering. |
| So hi Jane how are you? |
| >> Fine. Thank you Alex. |
| >> And thank you so much for agreeing to |
| be interviewed for our course, I'm sure the students |
| will really benefit from this. And let me start |
| with the first question which is what are software requirements? |
| >> That's an interesting question. And software requirements |
| basically provide us a description of what a |
| system has to do. So, typically they describe |
| the functionality of the features. That the system has |
| to deliver in order to satisfy its stakeholders. |
| And we usually talk about the requirement specification |
| in terms of what the system's going to |
| do. And we describe it sometimes formally in |
| terms of set of shall statements, that the |
| system shall do this or shall do that. |
| Or we can use various templates to specify |
| both textural requirements. But requirements can also be represented |
| informally in, in the form of user stories, or use cases, or more |
| formally in the form of state transition diagrams and even in kind of |
| formal specifications. Especially for critical parts of safety critical systems. |
| >> And another should discuss what the |
| requirements are. What is the requirements engineering? |
| >> So, that's also an interesting question because if you notice |
| it's it's engineering and I'm sure in the |
| other parts of the software engineering process that |
| you're discussing in your course. Parts such as |
| testing or coding. They don't have the word engineering |
| there and I think one of the reasons |
| requirements engineering has that term is because it covers |
| a number of different activities. So it includes |
| things such as working with stakeholders to elicit or |
| to proactively discover what their requirements of the |
| system are. Analyzing those requirements so that we |
| understand the tradeoffs. So you might have different |
| stakeholders that care about different things, and it |
| might not be possible to deliver all of those things, so we have to analyze the |
| feasibility of the requirements, explore the tradeoffs, emerge |
| conflicts. And then of course the specification part, |
| which we talked about a little bit already, |
| and the validation, so did we in fact get |
| the requirements right? Did we build a system |
| that actually matches our, our requirements. And then on |
| into the requirements management process. And the requirements |
| management process. Kind of like goes through things like |
| change management. So what if customer or stakeholders |
| need the system to change? How do we manage |
| changing requirements? And I think this is one of |
| the reasons that we've coined the term engineering because |
| that it's, has to be a systematic process which |
| extends across. The whole of this is life cycle. |
| >> And I guess my last question here is |
| so now that we heard about software requirements and |
| about software requirements engineering, why is requirements engineering so |
| important? So what happens if we don't do it right? |
| >> Well, I'm sure that, you know, |
| many people have probably read the kind of |
| report like Spanish report, and other reports of failed |
| project, and things like that, and are aware that |
| one of the major reasons for projects failing |
| is because we didn't get the requirements right |
| in the first place. So if we don't understand |
| the requirements then we're simply going to build the |
| wrong system. Getting requirements right includes all sorts of |
| things such as finding the right group of stakeholders so we don't exclude major |
| groups of stakeholders. Understanding the requirements correctly. |
| There will be many, many different examples of |
| projects that have failed. For example, in |
| America the healthcare.gov failure, and while we cannot |
| put the blame squarely in the area |
| of requirements, because obviously the project was challenged |
| for a number of different reasons. But |
| clearly it underperformed in many respects related to |
| security, performance, and reliability and these are all |
| parts of the requirements process. Things that should |
| have been discovered and the system should have |
| been built in order to meet those requirements, |
| getting the requirements right in the first place. |
| Puts us, a project on the right foot. |
| And so that gives us a much better chance |
| of delivering to the customer what they need. And |
| designing a solution that really meets those requirements. So, |
| it's a critical part of the overall software engineering success. |
| >> Okay. So that's critical. I mean, we better get our requirements right. |
| >> Yeah. |
| >> That's, that's the message. |
| >> Yeah. |
| >> Okay. Well, thank you so much Jane, for taking |
| the time off your busy schedule to speak with us. |
| I'm sure. The students really appreciate this, and we'll talk to you soon. |
| >> Bye Alex, thank you. |
| >> Bye, Jane, bye bye. Jane gave |
| us an interesting perspective on requirements engineering |
| and its importance. Let's now start our |
| lesson with a general definition of requirements engineering. |

## 81 - General RE Definition

| Basically, and roughly speaking, requirements engineering, which is |
| also called in short, RE, is the process |
| of establishing the services that the customer requires |
| from the software system. In addition to that, requirements |
| engineering also has to do with the constraints |
| under which the system operates and is developed. Requirements |
| engineering is a very important activity for several |
| reasons. In particular, as we also saw in earlier |
| lessons, many errors are made in requirement specifications. So many |
| errors are made because we don't do requirements engineering in |
| the right way. And many of these errors are not |
| being detected early. But they could be if we were |
| to do RE in the right way. And, unfortunately, not |
| detecting these errors can dramatically increase software costs. So that's |
| the reason why requirements engineering is important, and why it |
| is important to do it in the right way. The final |
| result of the requirements engineering process is a software |
| requirements specification that we also called SRS. We will discuss |
| SRS later in more details and also when we talk |
| about the projects for the course. For now, it is |
| enough to say that the software requirements specification and |
| the requirements engineering, in general, should focus on what the |
| proposed system is intended to do, and not on the |
| how it will do it. In fact, how the system |
| will do what it is required to do is something that we |
| will discuss when we talk about design of a system in later phases. |

## 82 - Software Intensive Systems

| In our initial definition of requirements engineering, we talked about |
| software systems. But what do we really mean when we |
| use the term software? Software is an abstract description of |
| a set of computations that becomes concrete, and therefore useful, only |
| when we run the software on some hardware, and that, |
| in the context of some human activity that it can |
| support. So what does that mean exactly? What that means |
| is that when we say software, what we really mean is |
| a software intensive system. That is, the combination |
| of 3 things, the software, the hardware on which |
| the software runs, and the context in which the |
| software is used. Just to illustrate, let me show |
| you this through a picture. What I'm showing here |
| is a customer, a user, that is using, is |
| accessing, an ATM machine. And this action involves several |
| things. There is the software that drives the logic |
| of the ATM machine. There is the hardware on |
| which the software runs. And there is the context |
| In which the software is used. And in this |
| case, the context is the bank. And only by |
| considering these 3 things together can we really understand |
| the functionality that is represented here. So the bottom |
| line here is that we usually take hardware and |
| context for granted in this equation. But they actually |
| need to be explicitly considered when building a |
| system. Otherwise, we might forget this is all |
| the functionality, and ultimately of the requirements. And |
| we might end up with the wrong system. |

## 83 - Software Quality

| So, let's see how this affects the concept of software |
| quality. Another way to express what we just said is |
| to say that the software runs on some hardware and |
| is developed for a purpose that is related to human |
| activities. And given this perspective, we can define what we |
| mean by software quality in this light. Software quality is |
| not just a function of the software. So, the software |
| itself does not define the quality of the overall system. |
| Rather, software quality is a function of both the |
| software and its purpose. Where purpose has to do with |
| the way in which the software will be used. So |
| a software system can be of low quality not only |
| because it does not work well. So, for example, not |
| only because it crashes. Of course, that's an issue. But |
| just as importantly, a software can also be of low |
| quality because it does not fulfill its purpose, and this |
| happens quite often. It is unfortunately not rare for |
| the software producers to have an inadequate understanding, or even |
| a complete misunderstanding of the purpose of the software, |
| of what the users want to do and will do |
| with it. Turning these around, we can therefore define |
| the quality of software in terms of fitness for purpose. |
| The more the software fulfills its purpose, the more |
| the software is on target, the higher is its quality. |
| And identifying the purpose of the software, so hitting |
| this target, is exactly the goal of requirements engineering. |
| And it is the reason why requirements engineering is |
| such a fundamental activity in the context of software engineering. |

## 84 - Identifying Purpose

| And identifying the purpose of a softer system means |
| defining the requirements for the system. And if you have |
| ever done anything like that, for example, we did |
| it for the first project in the previous mini course, |
| you will know that it is an extremely hard |
| task. Identifying the purpose of the software and defining its |
| requirements is very, very hard. Why is it so hard? |
| First of all, the purpose of most systems is inherently, |
| extremely complex, so this has to do with the |
| sheer complexity of the purpose of the requirements. Just think |
| of how complex is the functionality provided by most systems. |
| Second, it is hard, very hard to extract from humans |
| this purpose and make it explicit. So, paraphrasing a |
| famous quote from the late Steve Jobs, often people don't |
| know what they want until you show it to them. |
| It's hard to figure out what people really want. Third, |
| requirements often change over time. Customers change their |
| mind. Designing and building a system raises new requirements. |
| So for many reasons requirements tend not to |
| be stable, tend to evolve. And that, of course, |
| makes it harder to collect them. Finally, for |
| any realistic system, there are many stakeholders and they |
| often have conflicting goals and requirements. And it |
| can be very hard to reconcile the possibly conflicting |
| requirements that might emerge in these cases. So for all these reasons, |
| it is very, very difficult to |
| perform requirements engineering in an effective way. |

## 85 - Completeness and Pertinence

| These issues and difficulties can result in requirements |
| that show various problems. Two particularly relevant and |
| common problems are completeness and pertinence. Or better, |
| the lack of completeness and pertinence. Completeness refers to |
| the fact that it is often extremely difficult |
| to identify all of the requirements. That is it |
| is very difficult to have a complete picture |
| of the purpose of the software. So what happens |
| is that incomplete requirements are collected and the software |
| is missing functionality that is important for the user. Pertinence |
| conversely has to do with the relevance of the |
| requirements. To avoid completeness problems developers often end up collecting |
| a lot of irrelevant when not conflicting requirements. In |
| these cases what can happen is that the software could |
| either end up being bloated that is it might |
| contain a needed functionality. The functionality represented by these extra |
| requirements or it might even be impossible to build the |
| software due to the conflicting additional requirements. And to make |
| things even worse collecting all of these requirements sometimes doesn't |
| even solve the completeness issue. So you might end up |
| with a set of requirements that is not only incomplete |
| but it also contains extra information that can be harmful |
| to the system. So again the bottom line is that |
| gathering an adequate, accurate, complete, |
| and pertinent set of requirements that |
| identify the purpose of a software system is an arduous task. |

## 86 - Pertinence Quiz Question

| Now that we talked about completeness and pertinence, let's consider an |
| information system for a gym. I'm going to give you a |
| list of possible requirements and I want you to mark in |
| that list all the requirements that you believe are pertinent. So let |
| me read the list. Members of the gym shall be able |
| to access their training programs. The system shall be able to |
| read member cards. The system shall be able to store members' |
| commute time. Personal trainers shall be able to add clients. And the |
| list of members shall be stored as a linked list. |

## 87 - Pertinence Quiz Solution

| So the first requirement is definitely pertinent. Members of the gym shall |
| be able to access their training programs. It's pretty normal for members of |
| the gym to have a training program. And therefore, the system should allow |
| them to access them. Similarly for the second one. The system shall be |
| able to read member cards. Normally when you get into a gym |
| if you have a member card, you'll have to either show it to |
| somebody, or nowadays swipe it, and so the system should be able to |
| recognize the customer given the card. |
| The third requirement is probably not pertinent, |
| because I cannot think of any meaningful case in which the system |
| should know what is the members' commute time. The fourth requirement, personal |
| trainers shall be able to add clients, is also probably pertinent. Assuming |
| that we have personal trainers in the gym, and they should be |
| able to get clients, to work with the clients of the gym, |
| and therefore, they should be able to add them as their clients |
| to the system. And finally, the last requirement, the list of members |
| shall be stores as a linked list. This is really something about |
| the how, more than the what. And therefore, for what we say before |
| is probably not a pertinent requirement, so we're not going to mark this one. |

## 88 - Completeness Quiz Question

| So now that we saw which of these requirements are pertinent and |
| which ones are not, can we consider the above list of requirements |
| of the list of these requirements marked here as a complete list |
| of requirements for a gym? And you have two options, yes or no. |

## 89 - Completeness Quiz Solution

| And the answer is clearly no. |
| Obviously, there are many missing requirements here. |
| For example, requirements about registration for the |
| customers, requirements about fitness program creation, membership |
| types, and so on. Plus, we are also missing all of the nonfunctional |
| requirements, which we haven't seen yet, but that we will discuss in a bit. |

## 90 - Irrelevant Requirements Quiz Question

| In the previous quiz, we saw that some of the requirements |
| that they put in the list were not pertinent. They were |
| irrelevant. So let me ask you. Why can irrelevant requirements be |
| harmful? Why is that a problem to have irrelevant requirements? So |
| here, I'm giving you four possible answers. And I'd like for |
| you to mark all that apply. Can irrelevant requirements be harmful |
| because they may lead to missing functionality in the final product. |
| Because they can introduce inconsistency. Because |
| they can waste the project resources. |
| Or because they may introduce bugs in the software system. And |
| as I said, more than one can be a valid reason. |

## 91 - Irrelevant Requirements Quiz Solution

| So let's go through the list. Definitely irrelevant requirements |
| cannot lead to missing functionality in the final product, because |
| irrelevant requirements actually refer to unneeded functionality in the system. |
| So functionality that is put in the requirements, but it |
| is not really needed. So we're not going to mark |
| this one. Indeed, irrelevant requirements can introduce inconsistencies. So they |
| could be irrelevant requirements that not only are not pertinent |
| but they are inconsistent with some of the pertinent requirements. |
| They can also waste project resources, because if we spend time |
| designing and then implementing the parts of the system that we |
| refer to these irrelevant requirements, of course, we are wasting project |
| resources. And I will not mark the last one because there's really |
| no correlation between any irrelevant requirements and bugs in the software |
| system. Of course, by implementing the part of the system that refers |
| to an irrelevant requirement you might introduce a bug. But that's |
| not necessarily the case, and there really no correlation between the two. |

## 92 - Best Practices

| But we collect requirements all the time, right? Every |
| time we build a software system. So how do people |
| cope with these difficulties? What are the best practices? |
| In practice, developers or analysts usually identify a whole bunch |
| of requirements. Sometimes the easiest and most obvious ones. They |
| bring those to the stakeholders, and the stakeholders have to |
| read the requirements, understand them, and if they agree, sign |
| off on them. And the problem is that in general, |
| these requirements documents are difficult to read. They are long, they |
| are often unstructured. They typically contain a lot of information. And |
| in general, they are not exactly a pleasant read. So what |
| happens is that often the stakeholders are short on time, overwhelmed |
| by the amount of information they're given and so they give |
| in to the pressure and sign. And this is a bit |
| of a dramatization clearly but it's clear that what we are |
| looking at is not an ideal scenario. Clearly this is not |
| the way to identify the real purpose of a software system to |
| collect good requirements. And since one of the major causes for project |
| failure is the inadequacy of requirements, we should really avoid this kind |
| of scenario. We should follow a |
| rigorous and effective requirements engineering process instead. |

## 93 - RE Definition Breakdown

| But how can we do that? How can we identify the purpose |
| of the system and collect good requirements? To answer that question, let me |
| give you another definition of requirements |
| engineering. And this one is a classical |
| one, one that summarizes what we discussed so far, and then we can |
| use as some sort of reference. And it is a little long. |
| Definitely longer than the one that we saw at the beginning. But it's |
| an important one and it contains a lot of very relevant points. So, |
| we're going to go through it and highlight these points. So the definition says, |
| that the requirements engineering is a set of activities concerned |
| with identifying and communicating the purpose of a software intensive |
| system and the context in which it will be used. |
| And this is exactly what we said at the beginning. But |
| something we can highlight in here, is the fact that |
| we're talking about a set of activities. So, what that means |
| is that requirements engineering is not just a phase or |
| a stage. It also says that it's about identifying and communicating. |
| And what that is telling us is that communication is |
| as important as the analysis. So, it's important to be |
| able to communicate these requirements not only to collect them. |
| And we will discuss many reasons why that is the |
| case. It explicitly talks about purpose. So that allows me |
| to stress, once more, that quality means fitness-for-purpose. We cannot |
| say anything about quality unless we understand the purpose. And |
| the last thing I want to point out in this first |
| part of the definition is the use of the term |
| context. This is also something else that we mentioned at |
| the beginning, that designers, analysts, need to know how and |
| where the system will be used. Without this information, you |
| cannot really understand what the system should do and you |
| cannot really build the system. So now, let's continue and |
| read the second part of the definition that says, hence. |
| Requirements engineering acts as the bridge between the real-world needs of |
| users, customers, and other constituencies affected by a |
| software system and the capabilities and opportunities afforded |
| by software-intensive technologies. This is a long sentence, |
| but also here, we can point out a |
| few interesting and relevant points. Let me start |
| by highlighting two parts. Real-world needs, and the |
| capabilities, and opportunities. So, what are these two |
| parts telling us? They are telling us that requirements |
| are partly about what is needed, the real-world needs |
| of all these stakeholders. But they're also partly about what |
| is possible, what we can actually build. We need |
| to compromise between these two things. And, finally, I would |
| like to point out this term constituencies, which indicates |
| that we need to identify all of the stakeholders, not |
| just the customer and the users, so anybody who is |
| affected by a software system. It is very important to |
| consider all of these actors. Otherwise, again, |
| we'll be missing requirements, we'll be missing |
| part of the purpose of the system and we will build a suboptimal system. |

## 94 - Defining Requirements

| So at this point, we have talked quite a bit about |
| requirements engineering, but we haven't |
| really discussed what are requirements exactly. |
| So what is a requirement? To define that I am going |
| to use this diagram which is a classical one. So you might |
| have seen it before. So, discussing this diagram allows me to |
| point out a few interesting things about requirements and define them |
| in a better way. At a high level this diagram contains |
| two main parts, the domain of the machine, which is the hardware, |
| operating system, libraries and so on, on which the |
| software will run. And the domain of the application, which |
| is a world in which the software will operate. |
| And the machine domain is characterized by computers, which are |
| the hardware devices, and programs, which is the software |
| that runs on these devices. The application domain, conversely, is |
| characterized by domain properties, which are things that are true |
| of the world anyways, whether I'm building my system or |
| not, and requirements, which are things in the world we |
| would like to achieve by delivering the system that we are |
| building. Basically, to put it in a different way, the former, |
| the domain properties, represents the assumptions that we make on the |
| domain. And the latter, the requirements, are the actual requirements |
| that we aim to collect. So we have something here, right, |
| at the intersection of this application domain and this machine domain. |
| And what is that? And this is what we normally call |
| the specification, which is a description, often a formal description, |
| of what the system that we are building should do to |
| meet the requirements. So this is a bridge between these two |
| domains. And as the graphical depiction shows, the specification is written |
| in terms of shared phenomena. Things that are observable in both |
| the machine domain and the application domain. And just to make |
| things a little more concrete, I want to give you a |
| couple of examples of what these phenomena, these shared phenomena, are. |
| And we can think about two main kinds of phenomena. |
| The first one are events in the real world that the |
| machine can directly sense. For example, a button being pushed or |
| a sensor being activated. These are events that happen here, but |
| that the machine can detect. So they're events that can |
| be used to define the specification. And the second type of |
| phenomena are actions in the real world that the machine can |
| directly cause. For example, an image appearing on a screen or |
| a device being turned on and off. Again, this is something |
| that the machine can make happen and then can have manifestation in |
| the real world. And again this is therefore something on which |
| the specification can predicate, something that |
| we can describe in our specification. |
| And this is sort of a philosophical discussion, but even if |
| you don't care about the philosophical discussion, the one take away point |
| that I would like for you to get from this discussion is |
| the fact that when writing a specification you have to be aware |
| of the fact that you're talking about shared phenomena. Events in the real |
| world that the machine can sense and actions in the real world that the |
| machine can cause. So this is what the specification is about, a bridge between |
| these two worlds that define what the |
| system should do to satisfy the requirements. |

## 95 - Defining Requirements Quiz Question

| Since we just discussed application |
| domain, machine domain, and the specificiation, |
| let's make sure that these concepts are well understood. To do that, |
| I'm going to use a quiz, and I would like for you |
| to refer to the figure that we just discussed that I'm also |
| reproducing here on a small scale on the right. And then |
| referring to the figure, you should indicate for each of the items |
| that I'm going to show you here shortly. Whether they belong to |
| the machine domain. In this case, we're going to put a one next |
| to the icon. The application domain, in this case you should |
| put two. Or their intersection, and in this case you should |
| put three. So this is the lists of items. So let |
| me read it. An algorithm sorts a list of books in alphabetical |
| order by the first author's name. A notification of the arrival |
| of a message appears on a smart watch. An employee wants to |
| organize a meeting with a set of colleagues. And finally, a |
| user clicks a link on a web page. So again, put 1, |
| 2, or 3 here in these lots, depending on whether you think that these items |
| belong to the machine domain, the application |
| domain, or their intersection. So, their specification, here. |

## 96 - Defining Requirements Quiz Solution

| So let's look at each one of these items individually, starting from |
| the first one. And here this item has to do with how |
| the machine stores the information and |
| how the corresponding algorithm is written. |
| But it has no bearing in the real world. That is, in |
| the application domain. Therefore this. Definitely |
| belongs to the machine domain, and |
| we're going to put a one here. What about a notification of |
| the arrival of a message on a smart watch? This is an |
| event that is generated within the machine, but it has an effect, |
| an observable effect, in this case, in the real world as well. |
| Therefore, we're going to mark this as three. So this is an |
| event. This is something that belongs |
| to the intersection between the application |
| domain and the machine domain. So it's something that could be in |
| the specification. Now what about an employee that wants to organize a |
| meeting with a set of colleagues? This is an event that belongs |
| to the application domain because it is a fact that it's true |
| that exists. In the real world independently from the existence of a machine. |
| Therefore, we're going to mark this as two. |
| Finally, the event of a user clicking on a |
| link on a web page is an event that occurs in the real world but that has an |
| effect also within the machine and, therefore, we're |
| going to mark this as three, something that happens |
| at the intersection. between these two domains, and once |
| more, something that could be in a specification. |

## 97 - Functional and Nonfunctional Requirements

| Among the requirement that we can collect from the application |
| domain, we need to distinguish between two main types. And you've |
| probably heard about these ones. |
| Functional requirments and non-functional requiremnts. Functional |
| requiremetns have to do with the functionality of the system, with |
| what the system does with the computation. For example the elevator |
| shall take people to the floor they select. That's a functional |
| requirement, that has to do with the functionality of the system. |
| Or for a very simple one, the system has to output |
| the square root of the number past as |
| an input. So these kind of requirements have in |
| general well defined satisfaction criteria. So, for example, if |
| for the latter one that we mentioned it is |
| pretty clear how to check whether the output |
| is actually the square root of the number passed |
| in input. Non-functional requirements, conversely, refer to a system's |
| non-functional properties, systems qualities. |
| Such as security, accuracy, performance, |
| cost. Or, you know, usability, |
| adaptability, interoperability, reusability and so |
| on. So, all these qualities the don't necessarily have to |
| do with the functionality. And, unlike functional requirements, non functional |
| requirements Do not always have clear satisfaction criteria. For example, |
| if we say that the elevator must be fast, that's |
| a non-functional requrement. Right? It has to do with the |
| speed of the elevator, which is a quality of the |
| elevator. But, it, it's not clear how such a requirement |
| could be satisfied. How could we tell whether the elevator |
| is fast or not. So, what we need to do |
| in these cases Is that we need to refine these |
| requirements so that they become verifiable. For the example that |
| I just mentioned, for instance, we might say that the |
| elevator must reach the requested floor in less than 30 |
| seconds from the moment when the floor button is pushed. |
| This is still a non-functional requirment, but is a verifiable one. |

## 98 - User and System Requirements

| Another important distinction, when talking about requirements, is that |
| between user and system requirements. So, let's start with defining |
| user requirements. Those are requirements that are written for the |
| customers and they're often in natural language and they don't |
| contain technical details. And the reason for that is |
| that their purpose is to allow customers, stakeholders, to check |
| that the system will do what they intended. So it's |
| a way for the analyst, the developers, to communicate with |
| the customers, with the stakeholders. System requirements, on the |
| other hand, are written for developers. Contain detailed functional and |
| non functional requirements. Which we just discussed, and which |
| are clearly and more rigourously specified than the user requirements. |
| And the reason for this difference is that the |
| purpose of the system requirements is to tell developers what |
| to build. They must contain enough details so the |
| developers can take them and use them to design and |
| then develop a system. Just to give you a concrete |
| example, here I'm showing you a user requirement that just says |
| that the software must provide a means of representing and accessing |
| external files created by other tools, and the corresponding system requirement. |
| And as you can see, even if we don't read the |
| whole requirements. The former is an informal and high level description |
| of a piece of functionality, whereas the latter describes the same |
| functionality but in a much more extensive and rigorous way. As |
| I said, this is something that the developers can use to |
| design and then build a system whereas this is something that |
| can be used to communicate. With the stakeholders, with a non-technical |
| audience. And we need to define both because they serve different purposes. |

## 99 - Requirements Quiz Question

| After all these talking about requirements, let's have a small quiz, I |
| want to ask you which of the |
| following requirements are non-functional requirements? And here |
| I'm listing the requirements, the first one says at the BowlingAlley program |
| keeps track of the score during a game, the second one is that |
| the WordCount program should be able to process large files. The third |
| one is that the Login program for a website. Should be secure, and |
| finally the last one says that the vending machine program should take coins |
| as an input from the user. So, I want you to mark all |
| the ones that are non-functional requirements, that |
| don't refer to the functionality of the system. |

## 100 - Requirements Quiz Solution

| So, the first requirement clearly refers to some specific functionality of |
| the Bowling Alley system, because it talks about what the system has |
| to do from a functional standpoint. So, it's definitely not a non-functional |
| requirement. On the other hand, the fact that the Word Count system |
| should be able to process large files, is telling us something not |
| about the functionality of the system, but rather about its qualities. The |
| fact that it has to be scalable, that it has to be |
| efficient and so we can consider this to be a non-functional requirement. |
| Similarly, the fact that the Login program for a |
| website should be secure is definitely telling us something |
| about the quality of the system that has little |
| to do with its functionality. And so this is |
| also a non-functional requirement. Finally, the fact that the |
| Vending Machine program should take coins as an input |
| from the user is telling us something about the |
| functionality of the program and therefore, is a functional requirement. |

## 101 - Requirement Origins

| Now that we know what the requirements are and |
| their main types, let's discuss where requirements come from and |
| there are many possible sources for requirements so I'm |
| going to list here the main ones. The first one are |
| clearly stakeholders, anybody who is effected by the system |
| and its functionality. Customers, users, and so on. The second |
| typical social requirement is the application domain. For example, |
| the fact that my software is running within a bank, |
| or within a school. Why is the application domain a |
| social requirement? Well, because there are constraints that are characteristics |
| of the application domain that will affect the functionality of |
| the system. For a simple example, just think about regulations. |
| So banking regulations and school regulations in these cases. Those |
| are things that might affect the functionality of my system |
| and, therefore, that may become part of my requirements. And, |
| finally, documentation can be an additional source of requirements. For example, |
| notes, papers, manuals, books. So everything that refers to |
| the functionality of the system that we're going to build. |

## 102 - Elicitation Problems

| Unfortunately, extracting requirements from these sources is not |
| a straightforward task, as there are many issues involved |
| with the requirements elicitation. One first problem is the |
| thin spread of domain knowledge. Knowledge is rarely available |
| in an explicit form, that is, it is |
| almost never written down. Moreover, knowledge is often distributed |
| across many sources. For example, in the graphical depiction |
| here, to find out that this is the purpose |
| of the project. The developer, the analyist, needs to talk |
| to a lot of different people. And, to make things even |
| worse. There are often conflicts between the knowledge gathered from |
| different sources. A second issue is the fact that the knowledge |
| is often tacit. What is also called the say, do |
| problem. In the example shown here. For instance. We have a |
| customer that is describing to the analyst. The way in which |
| he accomplishes a task. So it performs these three steps and |
| reaches the goal. Whereas in practice, the actual way in |
| which this task accomplished is by going through a larger number |
| of steps to get to the same goal. So the point |
| here is that, even if the knowledge were more concentrated, so |
| not as spread as in this example. People simply find |
| it hard to describe knowledge that they regularly use. So it |
| is hard to make this knowledge explicit, to pass this knowledge |
| to someone else. Yet another |
| problem is limited observability. Identifying requirements |
| through observation is often difficult as the problem owners might be |
| too busy to perform the task that we need to observe. |
| Or they might be doing a lot of other things together |
| with the task that we need to observe, so that becomes |
| confusing. That introduces noise. Moreover, even when this is not the |
| case, the presence of an observer might change their problem. It |
| is very typical for human subjects to improve or modify an |
| aspect of their behavior, which is being experimentally measured in response |
| to the fact that they know that they're being studied. You know |
| that somebody's studying you and you change the way in which you behave. |
| A typical issue. Finally, the information that we collect might be biased. |
| For several reasons. People might not feel free to tell you what you |
| need to know. Or, people might not want to tell you what |
| you need to know. For example, in all the common cases in which |
| the outcome might effect them, people might provide you a different picture |
| from the real one. In order to influence you. So, they might have |
| a hidden agenda, and mislead you, either |
| consciously or unconsciously. So, all these issues |
| add to the complexity of collecting requirements, |
| of identifying the purpose of a system. |

## 103 - Traditional Techniques

| To cover the intrinsic problem of eliciting requirements, |
| many different techniques have been proposed. So here |
| I list some of most traditional techniques for |
| requirement elicitation and as I present those, please keep |
| in mind that these techniques can be used |
| separately or combined. A first technique is called background |
| reading. And, this technique involves collecting information by |
| reading existing documents such as company reports, organizational charts, |
| policy manuals, job descriptions, documentation of existing systems and so |
| on. And, this technique is especially appropriate when one Is |
| not familiar with your organization for which the requirements are |
| being collected. So you want to get some background before interviewing |
| actual people. And one of the main imitations of these |
| kinds of approaches is that written documents might be out |
| of sync and they often are out of sync with |
| reality. Tend to be long winded. It may contain many irrelevant |
| details, so you may have to look at a lot |
| of materials to extract enough information. The hard data and |
| samples techniques consist in deciding which hard data we want |
| to collect and choosing the sample of the population for which |
| to collect such data and hard data includes facts and |
| figures such as forms, invoices, financial information, survey results, marketing |
| data, and so on. And the sampling of this data |
| can be done in different ways. For example, the typical ways |
| to do random selection. Interviews are another typical approach for |
| requirement solicitation, and this is the approach that we use for |
| the first project in this course, for instance. Interviews can be |
| structured in which case there is an agenda of fairly open |
| questions or they can be open ended in which case there |
| is no preset agenda and the interview is more of a |
| conversation. On the positive side, interviews can collect a rich set |
| of information because they allow for uncovering opinions as well as |
| hard facts. Moreover, they can probe in depth through follow |
| up questions. On the more negative side, interviewing requires special |
| skills that are difficult to master and require experience. And |
| it is not enough to collect a lot of information. If |
| this information is hard to analyze or even irrelevant, it |
| might become useless. So you need to know how to conduct |
| an interview in order to take advantage of these techniques. |
| Surveys can also be extremely useful for gathering new requirements because |
| they can quickly collect information from a large number |
| of people. Moreover, they can be administered remotely. For |
| example, by email, through the web. On the other |
| hand, surveys tend to severely constrain the information that |
| the user can provide and might miss opportunities to |
| collect unforeseen, relevant information. Finally, meetings are generally used |
| for summarization of findings and collection of feedback, so as |
| to confirm or refute what has been learned. So the |
| only additional thing I want to mention about meetings |
| is the fact that it is fundamental that have clearly |
| stated objectives and are planned carefully. This is something that |
| should be quite obvious, but doesn't always happen in practice. |

## 104 - Other Techniques

| So just for completeness, I want to mention some other |
| techniques besides the traditional ones that we just saw that |
| can be used for requirements solicitation. And these other |
| techniques can be divided in three main groups. There are |
| collaborative techniques that were created to support incremental development |
| of complex systems with large diverse user populations. An example |
| of such techniques which is widely used and you |
| might know is brainstorming. There are also social approaches and |
| these are approaches, techniques that exploit the social |
| sciences to better collect information from the stakeholders and |
| the environment. And among those I just want to mention |
| ethnographic techniques which are based on the idea of |
| collecting information on the participants by observing them |
| in their original environment. Finally cognitive techniques, leverage cognitive |
| science approaches to discover expert knowledge for example they |
| can be used to understand the problem solving methods. |
| And in case you're interested in finding out more about this and |
| other techniques, I'm providing some references in the notes for the lesson. |

## 105 - Modeling Requirements

| Once we collected the required knowledge on the requirements for |
| the system that we're developing, we need to model it in |
| a structured and clear way, so that it can be |
| analyzed and refined. And there are really tons of ways to |
| do that, depending on your focus and objectives. More specifically, |
| when modeling requirements you need to decide what you want to |
| model and how you want to model it. So let's look |
| at these two aspects independently. What you decide to model depends |
| on where your emphasis is. That is on which |
| aspects of the requirements you want to focus. For |
| example if your emphasis is on the characteristics of |
| the enterprise of the company that you are analyzing you |
| may want to model goals and objectives of the |
| company, or its organizational structure, its task and dependencies |
| and so on. Conversely, if your focus is on |
| information and behaviors, you might want to concentrate on aspects |
| such as the structure of information, various behavioral views |
| some of which we will see in the next |
| lesson, or maybe time or sequencing requirements. Finally, if |
| you're mostly interested in the quality aspects of your |
| system, you will focus on the various non-functional properties |
| of the software that are relevant in the context |
| considered. For example reliability, robustness, security, and so on. |
| You will just pick the ones that are relevant for |
| your context. And as we said, there's a second dimension. |
| After you have decided what to model in your system, |
| you have to decide how you want to model it. |
| So I want to show here some options for modeling |
| enterprises, information, and quality aspects. And as you can see |
| here for each type of information there are many possible |
| models that we can use to represent it. And all |
| these models have advantages and |
| disadvantages, different levels of formality and |
| different focus. Something else that I want to point out |
| about these models is the fact that these models are often |
| orthogonal to one another, especially if we consider models in different |
| categories. So what that means is that they're complimentary rather than |
| mutually exclusive. Different models can be used to provide views |
| of the requirements from different perspectives, and we will not see |
| most of these models in this course, but I wanted to |
| list them anyways to give you an idea of how many |
| there are and how vast is this area. As far |
| as we are concerned in the course and for the |
| projects we will express requirements using one of two main |
| ways. Using natural language, that is informal specifications and using |
| UML diagrams, which is graphical models. And we will introduce |
| UML and the most important diagrams in the next lesson. |
| And the only other type of models that I want |
| to mentions explicitly are goal models because they're extremely popular. |
| So the main idea with goal models is it start with the main goal of |
| the system and then keep refining it |
| by decomposing it in sub-goals. So it's kind |
| of a very natural way of progressing. |
| And you continue this refinement until you get |
| to goals that can be operationalized, and represent |
| the basic units of functionality of the system. |

## 106 - Analyzing Requirements

| Now we are at the point in which we |
| have collected and modeled our requirements. So the next thing |
| that we can do is to analyze the requirements to |
| identify possible problems, and specifically there are three types of |
| analysis that we can perform. The first type of analysis |
| is verification. So in this case we're talking about the |
| requirements verification. And in verification |
| developers will study the requirements |
| to check whether they're correct, whether they accurately reflect the |
| customer needs as perceived by the developer. Developers can |
| also check the completeness of the requirements, check whether there |
| are any missing pieces in the requirements as we |
| discussed earlier. They can check whether the requirements are pertinent, |
| or contain irrelevant information, like the one shown here. |
| And they can also check whether they're consistent, unambiguous, testable |
| and so on, so all those properties that should |
| be satisfied for the requirements. A second type of analysis |
| that is typically performed on requirements is validation. And |
| the goal of validation is to assess whether the collected |
| requirements define the system that the stakeholders really want. |
| So the focus here is on the stakeholders. And in |
| some cases, stakeholders can check the requirements directly if |
| the requirements are expressed in a notation that they understand. |
| Or they might check them by discussing them with the |
| developers. Another possibility is that stakeholders asses the requirements by |
| interacting with a prototype of the system, in case |
| the requirements engineering process that is being used involves |
| early prototyping. And finally surveys, testing, and other techniques |
| can also be used to validate requirements. A final type |
| of analysis that we can perform on requirements is |
| risk analysis. And risk analysis aims to identify and |
| analyze the main risks involved with the development of |
| the system being considered. And if some requirements are deemed |
| to be too risky, like in this case, this might result in |
| changes in the requirements model to eliminate or address those risks. And note |
| that all these analysis activities can |
| be performed in many different ways depending |
| on the modeling languages chosen to |
| represent the requirements and on the context. |

## 107 - Requirements Prioritization

| Why collecting, modeling, and analyzing requirements? We might realize |
| that the resources available for the project are not enough |
| to satisfy all of them. For example, there's not |
| enough time, not enough money, not enough manpower. And therefore, |
| there are some requirements that we won't be able |
| to satisfy. In these cases, we must prioritize our requirements, |
| by classifying them in one of three classes. The |
| first class is mandatory requirements, and these are the requirements |
| we must satisfy. Then there are the nice to have requirements that are the |
| ones that we will satisfy if resources |
| allow. And finally, there are the superfluous |
| requirements, and those are the requirements that |
| we're going to keep around, but that we're |
| going to postpone. For example, we might decide |
| to satisfy them in the next release. |

## 108 - Requirements Prioritization Quiz Question

| Now that we talked about requirements prioritization, let's try to see |
| how this might work in practice. Imagine that you have collected the |
| folowing set of five requirements for an ATM system, but only |
| have resources to satisfy two of them. Possibly three. I would like |
| for you to look at this list and suitablely prioritize the |
| requirements by marking them as mandatory, in this case you're going to put |
| an M in the space. Nice to have, in this case you're |
| going to put an N. Or superfluous, in this case you're going to put |
| an S. This is the set of requirements, the first one |
| says that the system shall check the PIN of the ATM |
| card before allowing the customer to perform an operation. The second |
| says that the system shall perform an additional biometric verification of |
| the customer identity for example a check of the customer's finger |
| prints before it allows the customer to perform an operation. Then |
| we have that the system shall allow customers to withdraw cash |
| using an ATM card. The system shall allow customer to deposit |
| money using an ATM card. And the system shall allow |
| customers to change the pin of their ATM card. So again, |
| mark those as mandatory, nice to have, or superfluous considering the |
| fact that you can satisfy only two, possibly three of them. |

## 109 - Requirements Prioritization Quiz Solution

| Looking at the requirements, and knowing that we have only two |
| that we can satisfy for sure, it makes sense to first mark |
| as mandatory the ability to withdraw cash, which is the most typical |
| use of an ATM machine. We are therefore going to mark this requirement |
| with an M, for mandatory. It also makes sense to mark as |
| mandatory the fact that the ATM system checks the PIN of the |
| card being used by the customer, as that's the typical level of |
| security that the customer would expect, |
| therefore we're going to mark as mandatory |
| also the first requirement here. And of course we |
| could also perform biometric verification, but based on our knowledge |
| of the domain, it seems like that should be |
| an additional verification, rather than the main and only verification |
| for the system. We will therefore mark it superfluous. |
| That is something that we can postpone until a later |
| release, the second requirement. Finally, |
| another typical operation that customers |
| perform at ATM machines is depositing. Whereas changing an ATM |
| card's PIN is not such a common operation. We'll therefore mark |
| it nice to have this fourth requirement and as superfluous, the |
| last one. So at the end, what we have is that |
| we have two mandatory requirements which are the two that we can |
| satisfy for sure. One, nice to have the requirement, which is |
| the possible third requirement which we might have time to satisfy. And |
| the other two that are marked as superfluous, as something that |
| we might do later, for example in a subsequent release. And of |
| course there is something subjective in these answers. But |
| again, based on our knowledge on our understanding of |
| the domain, these are the one that makes more |
| sense for an ATM system as we know it. |

## 110 - Requirements Engineering Process

| Let's now put together all that we have discussed |
| and see how a requirements engineering process actually works. |
| So, first of all, we saw that requirements engineering |
| consists of three main steps. Elicitation of the requirements, |
| in which we extract requirements from various sources. Modeling |
| in which we represent the requirements using one or |
| more notations or formal reasons and analysis, in which |
| we identify possible issues with our requirements and there is |
| actually a 4th step that we kind of mention |
| but not explicitly. And this is the negotiation that can |
| happen between the stakeholders and the developers, during which |
| requirements are discussed and modified until an agreement is reached. |
| So if you want to think of this as a |
| process, so as a sequence of steps, we can see |
| that we start from elicitation. So we start by eliciting |
| an initial setup requirements. We negotiate and refine this set, |
| then we model the resulting requirements. And finally, we |
| analyze such requirements. However, the process doesn't really stop here. |
| Why? Well, because as a result of the analysis, |
| we might have to perform further elicitation. And so this |
| process is not really a sequential one, but rather |
| an iterative process. So, in practice, we continue to iterate |
| over these four steps gathering a better and better understanding |
| of the requirements at every iteration until we are happy |
| with the settle requirement that we gather and stop the process. |

## 111 - SRS

| Before I conclude this lesson, I want to say |
| a few additional things about the Software Requirement Specification document |
| or the SRS. And I want to do that because this |
| is a very important document and some of the projects |
| actually require you to produce one. So why is |
| the Requirement Specification such an important document? That's because a |
| Software Requirement Specification document is an important fundamental way to |
| communicate. Requirements to others. For example they represent a common |
| ground between analysts and stakeholders. Note however, that different |
| projects might require different software requirement specifications so you |
| need to know your context. For example, the SRS |
| document that you have to create for a small project |
| performed by a few developers can in most cases. |
| Be a concise and informal one. Conversely the software |
| requirement specification for a multi-year project, involving a number |
| of developers can be a fairly complex and extensive document. |
| So again you have to be aware of your |
| context and build your software requirement specification accordingly. In |
| order to have a common format for the SRS |
| document, IEEE defined a standard that divides the document in |
| predefined sections. And in the context of this course, |
| we will use a simplified version of the IEEE |
| SRS format that includes three main sections. An introduction, |
| which discusses the purpose, context, and objectives of the project. |
| A user requirements definition, which contains the user |
| requirements. And the system requirements specification, which includes both |
| functional and non-functional requirements. And we provide more information |
| about this format when we discuss the projects. So |
| to conclude the lesson, I want to point |
| out and in some cases recap a few important |
| characteristics that requirements should have. First of all, requirements |
| should be simple. Not compound. Each requirement should express |
| one specific piece of functionality that the system |
| should provide. Requirements should be testable. We mentioned |
| this before, but I want to stress it |
| because it is a very important point. Untestable requirements |
| such as the system should be fast, are |
| useless. Requirements should be organized. Related requirements should be |
| grouped, more abstract requirements should contain more detailed |
| requirements, and priorities should be clearly indicated when present. |
| Finally, requirements should be numbered, so |
| that they can be traced. For example, |
| numbered requirements will allow you to trace |
| them to design. Implementation and testing elements |
| and items, which is something that you might have to do for one of |
| the projects. And that we will discuss in more detail in a later class. |

## 112 - Lesson Overview

| Hi. In the last lesson we discussed |
| requirements engineering. This lesson is about object orientation |
| and other related concepts. The lesson is split |
| in two main parts. In the first part, |
| we will provide a quick introduction to |
| object orientation and object oriented analysis and design. |
| In the second part, we will cover the |
| essential of UML, which is the notation that |
| we will use in the rest of the course and also in our projects. |

## 113 - Object Orientation Introduction

| Let's start with a quick introduction to object orientation and |
| the fundamental concepts behind it. And let's start by discussing what |
| exactly is object orientation? If you're younger than me, it |
| could be that the first programming language you learned was already |
| an object-oriented language. But things were not always like this. |
| Before object orientation became prevalent, people were not used to thinking |
| in terms of objects. So what happened afterwards? And what does |
| it mean to think in terms of objects and to follow |
| an object-oriented approach? First of all, it |
| means to give precedence of data over function. |
| Did items rather than functionality become the center |
| of development activities. This also allows for enforcing |
| the very important concept of information hiding, |
| which is the encapsulation and segregation of data |
| behind well-defined and ideally stable interfaces. In order |
| to be able to hide the design and |
| also implementation decisions. And note that the terms |
| encapsulation and information hiding are often used interchangeably, although |
| some people prefer to think of information hiding |
| as being the principle and encapsulation being the technique |
| to achieve information hiding. The key concept though, |
| no matter which term you use, is really to |
| gather, to seclude this data behind sort of |
| a wall and give access to the data only |
| through interfaces that you, the developer define. And why is |
| that important? Oh, for many reasons, and one of the main |
| ones is that it makes code more maintainable. Because the |
| rest of the code, the rest of the system doesn't have |
| to be concerned on how the implementation details or the |
| design are defined. And therefore, any change that happens behind this |
| wall doesn't concern the rest of the system. And, doesn't |
| affect the rest of the system, as long as you keep |
| your interfaces consistent. Another advantage of focusing on |
| objects and encapsulating the information into cohesive entities is |
| that it allows the reuse of object definitions |
| by incremental refinement. Which is what we normally call |
| inheritance. And inheritance is definitely a fundamental concept |
| in object orientation. For example, we can define a |
| car as a refinement of the vehicle. That there's |
| some additional characteristics with respect to a generic vehicle. |
| And then we can use the car wherever a vehicle can be used, which is what we |
| call polymorphism. And we'll continue this discussion for a |
| very long time. Because there's so many things that |
| could be discussed when we talk about object orientation, |
| its characteristics and its advantages. But in the interest |
| of time, let's for now just stop here. And |
| start talking about two key concepts in object orientation. |

## 114 - Objects and Classes

| Let's start with objects. An object is a |
| computing unit organized around a collection of state |
| or instance variables that define the state of |
| the object. In addition, each object has associated |
| with it a set operations or methods that |
| operate on such state. So what that means |
| is that operations and methods read and write |
| instance variables. And in traditional object orientation, we say |
| that operations are invoked by sending a message |
| to the appropriate object, which is what we call |
| normally a method implication. So now that we define |
| what an object is, state variables, or attributes, and |
| operations or methods, let's see what a class is. |
| A class is basically a template. A blueprint, if |
| you wish, from which new objects, which is what |
| we call instances of the class can be created. |
| And notice that the fact of having a blueprint for |
| objects that allows us to create as many objects as |
| we want can further reuse, and also contribute to make |
| the code more readable, understandable, |
| and therefore ultimately more maintainable. |

## 115 - Benefits of OO

| So in more general terms, why do we want to |
| use object orientation? The first reason is that object |
| orientation can help reduce long-term maintenance costs by limiting |
| the effects of changes. As we saw, the effect |
| of using encapsulation and information hiding makes it easier |
| to modify parts of the system without affecting the |
| rest of the system. Object orientation can also improve |
| the developing process by favoring code and design reuse. |
| In general, object orientation helps |
| enforcing good design principles. Principles such |
| as the ones that we saw in encapuslation, information hiding, high |
| cohesion, low coupling and we will discuss these aspects more extensively |
| in the next mini course which is centered around design concepts. |

## 116 - OO Benefits Quiz Question

| Now let's make sure that we understand the benefits of |
| object orientation through a quiz. Imagine that acme corporation decided |
| to use an objetory entered approach in its software development |
| process. If this is the case what benefits can they expect |
| to receive from this decision. And here I'm listing some |
| possible benefits. Increased reuse because of the modular cooling style. |
| Increased maintainability because the system design can accommodate changes more |
| easily. Increased speed because object oriented systems tend to run faster. |
| And increased understandability because the |
| design models real world entities. So, |
| I would like, as usual, for you to mark all that apply. |

## 117 - OO Benefits Quiz Solution

| So, now let's see which ones of these |
| benefits can actually be expected. Definitely, the first one. |
| The modular coding style typical of object-oriented approaches can, |
| and normally does, increase reuse. Similarly, because of the |
| characteristics of typical object-oriented systems, these systems are normally |
| easier to change. Because they're more modular, they're more |
| cohesive, they're more decoupled. And therefore, all of this |
| contributes to increase the maintainability of the resulting systems. |
| So we're going to mark this benefit as well. |
| There's really nothing about object-oriented systems. That make them |
| run faster and, therefore, this is not a benefit |
| that we can expect from the use of an |
| object-oriented approach. Conversely, the last one is an expected |
| benefit because normally, the fact of designing real-world entities, |
| which is one of the characteristics of the object |
| oriented approaches, does increase understandability. It's easier to understand |
| the system because we can relate. To the system because we can recognize in |
| the systems, real world entities that we are used to see and that we understand. |

## 118 - OO Analysis History

| The use of object orientation and object oriented |
| concepts led to what we call OOAD, object oriented |
| analysis and design. OOAD is a software engineering approach |
| whose main characteristics is to model a software system |
| as a group of interacting objects, and we'll |
| see what that means. In particular, in this lesson |
| we will specifically focus on the first part of |
| this, object oriented analysis, which is a requirements analysis |
| technique that concentrates on modeling real world objects. And |
| as I usually like to do, I would like |
| to start by providing some historical perspective on object |
| oriented analysis to better understand how we went from a |
| function-centric world to a data-centric world. And several people |
| contributed to this shift in perspective, but I'd like |
| to mention a few that were particularly influential. Starting |
| from James Rumbaugh, which in the 90s developed an integrated |
| approach to object oriented modelling with three main aspects. |
| A data aspect, so the modelling was based on |
| using an extended version of entity relationship diagrams to |
| describe classes and inheritance. So that's what was called |
| the object model. And the second aspect has to |
| do with functions. So data flow diagrams were used |
| to represent the functional aspects of the system, where |
| each function was then becoming a method in a class. |
| So this is what is called the functional model. |
| So object model and functional model. The third model |
| in Rumbaugh's methodology had to do with control. So |
| it was representing the dynamic aspects of a system. And |
| it uses state machines, which we'll cover in more |
| detail, to represent how a system would evolve going from |
| one state to the other based on what happened |
| to the system. These three models together represented what was |
| called the Object Modeling Technique, or OMT. And |
| OMT combined with contributions from several people, and in |
| particular Jacobson and Booch, evolved into what we call |
| the Unified Modeling Language, which is UML, which is |
| probably the modeling language that most of you |
| are familiar with. UML extends OMT by providing more |
| diagrams and a broader view of a system from |
| multiple perspectives. So, in the second part of the |
| lesson, we will cover some of these |
| diagrams in details, but before that, I'd like |
| to talk a little bit more about object |
| oriented analysis, and how we can perform it. |

## 119 - OO Analysis Overview

| So let's look at the object-oriented analysis in a |
| little more detail. As I said earlier, traditional analysis |
| and design techniques were functionally oriented. What that means |
| is that they concentrated on the functions to be performed, |
| whereas the data upon which the functions operated were |
| secondary to the functions themselves. Conversely, object oriented analysis, is |
| primarily concerned that with a data objects, so we |
| went from a functional oriented view to a data oriented |
| view, what that means is that during the analysis phase, |
| we define a system first in terms of the data |
| types and their relationships, and the functions or methods are |
| defined only later and associated with specific objects which are sets |
| of data. So let's see how we can perform object |
| orientated analysis in practice, so the basic idea is to be |
| focused on the objects of the real world. So to |
| go from a real world objects to a set of requirements. |
| And we can describe this as a four-step process. The first |
| step is to obtain or prepare a textual description of the |
| problem to be solved. So obviously, we need to start from |
| some description of the system that we need to build. And |
| this is a very practical oriented approach, so that the next |
| thing we do is that we take the description and we |
| underline nouns. In this description. And the nouns that we underline |
| will become classes in my analysis. We then look at adjectives in |
| the document. We underline those, and we use that |
| information to identify the attributes of the classes that we've |
| previously identified. At this point we focus on active |
| verbs in the description, and the analysis of the active |
| verbs will give us the operations that we'll need |
| to define for our classes. So, again, underline nouns, and |
| those will become the classes in my system. Then, |
| objectives. And, those will be the attributes of the classes. |
| And, finally, active verbs that will become the operations of my classes. And |
| of course, this is a high level view to take this with a |
| grain of salt. But we will see that it's a very good pragmatic |
| approach to identifying requirements, starting from a |
| description of the system to be built. |

## 120 - Modeling Classes Quiz Question

| Now let's see how object oriented analysis might work |
| in practice by considering the following requirement for an online |
| shopping website. The requirement says that users can add |
| more than one item on sale at a time to |
| a shopping cart. So, looking at this requirement I |
| would like you to tell me which of the following |
| elements should be modeled as classes. And the elements |
| are: item, sale, shopping cart, time and user. So mark |
| all that apply. |

## 121 - Modeling Classes Quiz Solution

| Looking at the requirements, item is definitely a relevant element |
| for my system, so it is appropriate to model item as |
| a class. Sale, on the other hand, is more of |
| a characteristic of an item, an attribute of an item, rather |
| than a class in itself. So, we're not going to mark |
| this one. Shopping cart sounds, as well, as an important element |
| for my system. Time can be an important system in some |
| contexts, but in this case we're measuring time just because more |
| than one item at a time can be added to the shopping cart. |
| So, time really doesn't have any reason for being modeled as a class. |
| And finally, user also seems to also have an important role to play |
| in the system, and therefore we will model user as a class as well. |

## 122 - Running Example Explanation

| This concludes the first part of this lesson in which |
| we discussed the basic object-oriented concepts. And, we started to |
| look at how to perform object-oriented analysis. In the second |
| part of the lesson, I will introduce UML, and we will |
| perform the object-oriented analysis steps that we just saw using |
| an example. A course management system so before getting to |
| the second part, let me introduce the example. As we |
| mentioned before, the first step is to start from a textual |
| description of the system the we need to analyze and |
| that we need to build. So that's exactly what I'm going |
| to do. I'm just going to read through this description then we'll |
| reuse throughout the rest of the lesson. The registration manager sets |
| up the curriculum for a semester using a scheduling algorithm and |
| the registration manager here is the registrar. So we will refer |
| to the registration manager both as registration manager and as registrar |
| in the rest of the lesson. One course may have multiple |
| course offerings, which is pretty standard. Each |
| course offering has a number, location, and a |
| time associated with it. Students select four primary |
| courses and two alternative courses by submitting a |
| registration form. Students might use the course management |
| system to add or drop courses for a |
| period of time after registration. Professors use the |
| system to receive their course offering rosters. Finally, |
| users of the registration system are assigned passwords which are used for |
| login validation. So, as you can see, this is a kind of a |
| high-level description of a standard course management system. So, if you ever |
| used a course management system, you'll |
| recognize some of the functionality described here. |

## 123 - UML Structural Diagrams_  Class Diagram

| Let's now start talking about UML, the Unified Modeling Language. |
| And we are going to start by looking at UML |
| structural diagrams. This are the diagrams that represent static characteristics |
| of the system that we need to model. This is |
| in contrast with dynamic models which instead behaviors of the |
| system that we need to model. And we will also |
| discuss dynamic models, later on in the lesson. We're going |
| to discuss several kinds of diagrams, starting from the class |
| diagram, which is a fundamental one in UML. |
| The class diagram represents a static, structural view of |
| the system, and it describes the classes and their |
| structure, and the relationships among classes in the system. |

## 124 - Class Diagram_ Class

| So how do we represent a class in a class |
| diagram? Class is represented as a rectangle with three parts. The |
| first part is the class name. Classes should be named using |
| the vocabulary of the domain, so we should pick names that |
| make sense. And the normal naming standard requires that the classes |
| are singular nouns starting with a capital letter. The second part |
| of the class are the attributes of the class, where the |
| set of attribute for the class, we find the state for |
| the class. And, we can list an attribute simply by |
| name, or we can provide the additional information. For example, |
| we might define the title of the attribute, and we |
| might also define the initial. Value for the attribute. Finally, the |
| third part of the class consist of the operations of |
| the class. And normally, the operations of the class are represented |
| by name, with a list of arguments. That the operation |
| will take as input, and with a result type. So the |
| type of the result produced by the operation. Something |
| else you can notice in this representation is the |
| fact that there is a minus before these attributes |
| and a plus before this operation. This indicates what is |
| called the visibility of these class members. So the |
| minus indicates that the attributes are private to the class. |
| So only instances of this class, roughly speaking, can |
| access these attributes. And notice that this is what allows |
| to enforce the information hiding principle, because clients of |
| the class cannot see what's inside this box, what are |
| these attributes. The plus conversely indicates that this is a |
| public operation. So something that is visible outside the class. |
| And, in fact, normally, this is what we use to |
| define the interface for my class. So we encapsulate the |
| state of the class and we make it accessible to |
| the extent that we want and that is needed through |
| a set of public operations. Last thing I want to |
| note is the use of these ellipses that we can |
| utilize if we want to indicate that there are more |
| attributes for example, or more operations. But we just don't |
| want to list them now. Okay now that we know what |
| a class is, and how it is represented, let's start |
| our analysis of our course management system. By identifying the |
| relevant classes in the system, we need to bring back the |
| description of our system. And what we want to |
| do, is that we want to go through the description |
| and underline the relevant nouns in the description. And here |
| I encourage you to stop the video and to do |
| the exercise of underlying such nouns yourself before listening to |
| my explanation into how I do it. For example in |
| this case I might want to underlined the registration manager which |
| is a noun and probably a relevant one. The scheduling |
| algorithm, also seems like a relevant concept, so |
| is the course. The course offerings, again, course offerings |
| over here. Definitely, the students seem to be a |
| relevant noun and so is probably the registration form |
| and the professors. Okay, so, at this point, I |
| identified seven possible classes for my system. So, what |
| I'm going to do is simply to create classes for |
| each one of these nouns. So my initial class |
| diagram looks exactly like this, with the seven classes where |
| for each class, I picked the name that is representative of |
| the domain. So, in this case, it's pretty straightforward. The |
| registration form is called registration form, the student is called student |
| and so on and so forth. But you can already |
| see how this analysis method is starting from a description of |
| the real world and it's just identifying objects or classes |
| in the real world and transforming them into entities in my |
| analysis document. |

## 125 - Class Diagram_ Attributes

| Now that we identify the classes in my system, |
| let's see how we can identify the attributes for |
| these classes. First of all let's recall what attributes |
| are. Attributes represent the structure of a class the individual |
| data items that compose the state of the class. |
| So how do we identify these attributes? Attributes may be |
| found in one of three ways. By examining class |
| definitions, by studying the requirements, and by applying domain knowledge. |
| And notice that I want to stress, that this is always |
| a very important aspect. No matter what kind of system you're |
| developing. Domain knowledge tends to be fairly important to identify things |
| Which might not be provided in the descriptions of the system |
| that tend to be incomplete. And that you can derive by |
| the fact that you are familiar with the domain. So always |
| keep in mind the domain knowledge is important for analysis, for |
| design, for requirements gathering and so on. So now let's go |
| back to our description of the system. As I said, |
| I will bring you back for each step of our |
| analysis. And in this case, we're going to focus on |
| course offering. And we can say that the course offering, according |
| to the description, has a number, a location, and a |
| time. So this is a pretty clear indication that these are |
| important aspects of the course offering. So they probably should |
| become attributes of the course offering class. So now if we |
| report here that sentence, and once more, we underline |
| the information that we underlined in the description. We can |
| clearly see how this can be mapped into the definition |
| of the class. So our class course offering after this |
| step the analysis will have 3 attributes: number, location, and |
| time. And as you can see here, I'm not specifying |
| the type or any other additional information. So in this |
| first step I'm just interested in having a first draft. |
| of the class diagram, that I can then |
| refine in the next iterations of my analysis. |

## 126 - Class Diagram_ Operations

| At this point we have our classes, our attributes, |
| what we're missing is the operations for the class. |
| Let me remind you that operations represent the behavior |
| of a class, and that they may be found by |
| examining interactions among entities in the description of my |
| system. So once more, let's bring back our description, and |
| let's in this case focus on this specific item. |
| That says that the students may use the system to |
| add courses. So this is clearly indicating an action |
| that the students should be able to perform. But notice |
| that this doesn't mean that this is an operation that |
| should be provided by the student's class. It rather means |
| that there should be, somewhere in the system, the possibility |
| of performing this operation. So let's see what this means |
| for our example. This might mean, for example, if we |
| focus on the RegistrationManager, so that there should be an |
| operation in the RegistrationManager that allows me to add |
| a student to a course. And this, in turn, means |
| that both Course and CourseOffering should provide a way to |
| add a student. And therefore, I add this corresponding operation |
| to the RegistrationManager, to the Course, and to the CourseOffering. |
| So after doing that we will continue and populate in |
| a similar way, the other classes in the system. So |
| let me recap. Now we saw how to identify classes. |
| How to identify members of the classes, and |
| particular attributes, and operations. There is one thing that |
| we're missing, a very important aspect of the |
| class diagram which is the relationships between these classes. |

## 127 - Class Diagram_ Relationships

| And that's exactly what we're going to look at next, |
| relationships in the class diagram, how they're represented and |
| what they mean. First of all relationships as the |
| name says, describe interactions between classes or between objects in |
| my system. And we will describe three main types |
| of relationships. The first one is called a Dependency |
| relationship. And we can express that as X uses |
| Y and we represent it with a dashed directed line. |
| So when we have such a line between two classes |
| that means that the first class uses the second one. And |
| we're going to provide an example of a dependency in a |
| minute. The second type of relationship is an association that can |
| also be an aggregation. We'll see what the distinction is. |
| But basically, what this means is that we can express that |
| as a X has a y. So x contains a |
| y. And if it is in association, we indicate it with |
| a solid undirected line. If it's an aggregation, |
| we indicate it in the same way, but with |
| a diamond at one of the ends. Finally, the |
| third type of relationship is what is called Generalization. |
| And this can be expressed as x is a |
| y. So this is the relationship that expresses inheritance. |
| Specialization between two classes. It's represented with a solid |
| directed line with a large open arrow head at |
| the end. Going from the more specialized class to |
| the less specialized class. So going from the subclass to |
| the super class. So now let's look at each relationship |
| in more detail using our example, our course management system. |

## 128 - Class Diagram Relationships Quiz Question

| Before doing that, though, now that we discuss the different kinds |
| of relationships among classes in the class diagram. I would like |
| to ask you to look at a list of relationships that |
| I'm providing here and mark the relationships that you think actually |
| hold for the classes in the system that we are modeling. |
| So here I have a list of possible relationships for each |
| relationship. I'm first defining what the relationship is and then what |
| kind of relationship that is, for example, for the first one I'm |
| saying that the registration manager uses |
| the scheduling algorithm, which is a dependency |
| relationship. And similarly for the other ones. So like for you to go back |
| to the example, look at the classes that we defined, think about the |
| requirements, and identify which ones of this |
| relationships you think hold in the system. |

## 129 - Class Diagram Relationships Quiz Solution

| So, I'm going to start by marking the |
| relationships that actually hold in the system. |
| Which are these ones. And then what I'm going to do, I'm going to explain this |
| answers. Not here but in the next part of this lesson. By looking at the |
| different relationships in the context of our |
| example. Which will make the explanation much clearer. |

## 130 - Class Diagram_ Dependency Relationship

| So let's start with the dependency example. A dependency, |
| as we said, expresses the relationship between a supplier |
| and a client that relies on it. There is |
| a dependency because changes in the supplier can affect the |
| client. Here in this example I am showing that |
| a dependency example involving the registration manager and the |
| scheduling algorithm. As you can see the, the dependency |
| is indicated with a dashed line pointing from the client |
| to the supplier. And here it's pretty clear why |
| the RegistrationManager is dependent on the Scheduling Algorithm. It's |
| because the RegistrationManager uses this Scheduling Algorithm. And therefore, |
| if the Scheduling Algorithm changes, the RegistrationManager might be |
| affected by that change. Another less obvious example is |
| the dependency between the Registration Manager and the Student. |
| In this case, because the Registration Manager gets a |
| Student object as a parameter here there is a dependency |
| between the two. Again, if the Student class were to change the Registration |
| Manager might be affected because it's relying on the Student for it's behavior. |

## 131 - Class Diagram_ Association & Aggregation Relationships

| The next example of relationship we're going to look at is |
| the association relationship. This is a relationship in which objects of |
| one class are connected to objects of another. And it's |
| called an has a relationship. So it means that objects of |
| one class have objects of another class. So let's see |
| what that means. Let's do it by considering two classes in |
| our example system. The student class and the course offering class. |
| In this case, there is an association between the student and |
| the course offering, because the student is registering for the |
| course offering. So, in a sense, the course offering has students. |
| Contains students, to indicate this fact we add a solid |
| line between the student class and the course offering. And the |
| fact that having a solid line doesn't really tell us |
| much about the nature of the relationship, so to clarify such |
| nature we can use what we call adornments that we |
| can apply to associations we can add to associations to clarify |
| their meaning. In particular we can add a label to |
| an association and the label describes the nature of the relationship. |
| In this case, for example, it clarifies that the student |
| registers for CourseOffering. We can also add a triangle to |
| further clarify the direction of the relationship. So in this |
| case, the triangle will indicate that it's the student That registers |
| for the course offering, and not the other way around. Another |
| important adornment or limitation that we can put on an association, |
| is multiplicity. Multiplicity defines the number of instances of one |
| class that are related to one instance of the other |
| class. We can define multiplicity at either end of the |
| relationship. In this case, for instance, we can say that |
| if we look at the student, the student can register |
| for two or more course offerings. Whereas, if we look |
| at the course offering, we can say that each course |
| offering can have or can enroll between 1 and 50 students. |
| So as you can see by adding a label, a direction, |
| and multiplicity, we make it much clearer what the relationship is |
| and what it means and what are its characteristics. As we |
| saw when we introduced relationships, there is a different kind of |
| association, kind of a specialized one, which we call aggregation. So |
| here we're going to look at an example of an aggregation. So |
| first of all what is an aggregation? An aggregation is a |
| relationship between 2 classes in which 1 represents a larger class |
| like a whole which consists of smaller classes which are |
| the parts of this whole. So let's look at an example |
| in the context of our system. Let's consider a Course |
| and the CourseOffering. And in this case, we can see |
| that the Course consists of multiple CourseOfferings. So in |
| a sense, a course is a whole and the course offerings |
| are the parts of this whole. So this a perfect case |
| in which we will use an aggregation to express this relationship. |
| So we will add a solid line with a diamond on the side of the whole class |
| to indicate that the course consists of multiple course offerings. |
| And as we did for associations even though we |
| are not going to do it for this specific |
| example, we could also in this case add multiplicity |
| information on the aggregation to indicate how many classes |
| of the two types are involved in the relationships. |

## 132 - Class Diagram_ Generalization Relationship

| The third type of relationship that we saw, is |
| Generalization. Generalization is a relationship, between a general class, |
| which we normally call super-class and the more specific |
| class, a class the refines the super-class and that |
| we normally call sub-class. It's also known as a |
| kind of or is a relationship because we can |
| say that the subclass is a super class and |
| it's expressed with a solid line with a big arrow |
| head at the end. So let's see an example of |
| that. In this case I'm going to indicate. Two of this kind |
| of relationships. The first one involving the RegistrationUser and |
| a student. And the second one, a RegistrationUser and the |
| professor. So, basically what we're showing here is a |
| typical case in which the registration user is a more general |
| concept then the Student and the Professor. So both the student |
| and the professor are RegistrationUsers. So there is a relationship, |
| the Professor is a registration user and the Student is a RegistrationUser. |
| And therefore we can indicate that using |
| the generalization relationship in our class diagram. |

## 133 - Class Diagram_ Creation Tips

| The last thing that I want to mention about class diagrams is |
| some creation tips. So something I know based on my experience and the |
| experience of others, I can recommend to do when creating a class |
| diagram. So the first tip is to understand the problem. So take the |
| time to look at the description of the system that you have |
| to build, to make sure that you understand the domain. That you understand |
| what you are supposed to build. Because that is going to save you |
| time later. It's going to help you identify from the beginning, a more relevant |
| set of entities in the description of the system. This |
| one might seem trivial but is very important to choose |
| good class names. Why? Because class names communicate the intent |
| of the class, and clarify what the class refers to. So |
| having a good class name allows you, makes it easier, to |
| create the mapping between the real-world object and the entities in |
| your model. And of course, it also makes it easier |
| to understand the system, after the system is built. Third tip, |
| concentrate on the what. So here, in the class diagram, |
| we're just representing the structure of the system. We're representing |
| what is in the system. What are the entities? What |
| are the characteristics of the entities? We are not focusing |
| at all, on how things are done. So, be careful. |
| DonÃ¢Â€Â™t think about the how, just think about the what. |
| Proceed in an itinerary way. So, start with a simple |
| diagram and refine it. There is no need to identify, |
| right away, all of the details of the system you need to |
| build. It is much easier to look at the description, identify an initial |
| rough class diagram and then refine it, because in this way, you'll |
| also gather more understanding of the system as you build it, and you'll |
| most likely end up with a better product at the end. And |
| if you proceed in this way, then make sure to refine until you |
| feel the class diagram is complete, until you feel that you represent |
| the system that you're supposed to build. So your final goal should be |
| to have a class diagram that is complete. |
| So it represents all of the relevant entities |
| in the system and their characteristics, and it's |
| correct so it represents them in the right way |

## 134 - UML Structural Diagrams_ Component Diagram

| There's two more structural diagrams that I want to |
| mention before we move to the behavioral ones. The |
| first one's the component diagram. A component diagram is |
| a static view of components in a system and of |
| their relationships. More precisely, a node in a component |
| diagram represents a component where a component consists of one |
| or more classes with a well-defined interface. Edges conversely |
| indicate relationships between the components. You can read this relationship |
| as component A uses services of component B. And notice that the |
| component diagrams can be used to represent an architecture, which is |
| a topic that we will cover extensively in the next mini-course. |
| So let's illustrate this with an example. So, what I'm representing |
| here is a component diagram for our example system, the course |
| management system. And as you can see, it's slightly more complex |
| than the other diagrams that we saw. But there's really no |
| need to go through all the steps and all the details. |
| Important thing is to point out some key aspects of |
| this diagram. So the first one is that these rectangular |
| nodes are the nodes in the system, so are my |
| components. For example, student is a component, schedule is a component, |
| and so on. And as far as edges are concerned, |
| I'm representing two kinds of edges. The first kind of dashed |
| edges which were part of the original uml definition and |
| indicate use. So an edge, for example, between this compnent and |
| this compnent indicated that the seminar management uses the |
| facilities component. More recently, in UML two, a richer representation |
| was introduced, which is the one that I'm also showing |
| here. So if we look at this part of the |
| diagram, you can see this sort of you now, |
| lollipop socket representation. And in this case, what this represents, |
| is that a lollipop indicates a provided interface. So an |
| interface that is provided by the component. So, for example, |
| this security component provides encryption capabilities. The socket, |
| conversely, indicates a required interface. So, for example, in |
| this case, it's saying that the facilities component |
| is needing access control capabilities, which, by the way, |
| is provided by the security component. So in |
| a sense these sockets and lollipop indicate interfaces between |
| a provider of some of functionality, and the client |
| of that functionality and you can look at those |
| as basically APIs. So sets of methods that |
| provide a given functionality. To give you another |
| example, if we look at the persistence components |
| the persistence component provides, unsurprisingly, persistent services. And |
| those persistent services are required by several other |
| components in the system. And in turn, the persistent |
| components relies on the University database component to |
| provide such services. So, there's the University DB components |
| provide these sort of low-level database services that are used |
| by the persistence component To in turn provided services. Last thing |
| I want to note is that components or relationships can be |
| annotated, so, for example if we look at the seminar management |
| and the student administration components you can see that they |
| are annotated here to indicate that they are user inferfaces. So |
| that's all I wanted to say on the component diagrams, but |
| again the key piece of information is that they represent components |
| in the system where a component consists of one or more classes indicate the |
| interfaces that these components provide or require. |
| and describe the interactions between these components. |

## 135 - UML Structural Diagrams_ Deployment

| The last UML structural diagram I want to discuss |
| is the deployment diagram. The deployment diagram provides a static |
| deployment view of a system, and unlike previous diagram, |
| it is about the physical allocation of components to computational |
| units. Think, for example, of a client-server system in |
| which you'll have to define which components will go on |
| the server and which component will go on the |
| client. For deployment diagram, the nodes correspond to computation unit; |
| for example, a specific device. And the edges indicate communication |
| between these units. Also in this case, I'm going to illustrate deployment |
| diagrams using an example for our course management system. And |
| also in this case, I'm going to use a slightly more complex |
| diagram than usual. But I don't want you to look |
| at all the individual details. Instead, I would like to focus |
| on a few main aspects. So, if you look at |
| this diagram, there are three things that you should clearly see. |
| First, you should see how the system involves four |
| nodes, a web server, an application server, a DB |
| server, and a mainframe. Second, you should see which |
| components are deployed on which nodes. For example, the student |
| component is deployed on the application server. And finally, |
| you should see how the nodes communicate with one |
| another. For example, you can see that the application |
| server and the university database communicate using a JDBC protocol. |

## 136 - UML Behavioral Diagrams_ Use Case

| We now discuss UML's behavioral diagrams. Those diagrams that |
| have to do with the behavior, the dynamic aspects |
| of the system, rather than the static ones. The |
| first behavioral diagram I want to discuss is a very |
| fundamental one, the Use Case Diagram. So, let's start |
| by seeing what a Use Case is. A Use Case |
| represents two main things. First the sequence of interactions |
| of outside entities which is what we normally call actors |
| with the system that we're modelling and the second thing |
| is the system actions that yield an observable result of values |
| to the actors. And basically these two things, and nothing else |
| that the outside view of the system. So the view of |
| the system in which we look at the interaction between |
| this system, and the outside world. If you want to parallel, think |
| about designing a house. Considering how you would use the house. |
| And you might have seen use cases called with different names. |
| So for example, they're also called scenarios, scripts or user stories, |
| but in the context of UML, we'll call the use cases. |
| Now let's look at the basic notation for a use case, |
| which is fairly simple. We have a use case which is represented |
| by an oval, with a name, which is the name of |
| the use case. We have an actor, which is represented by |
| this icon and is normally identified by a role name. And |
| finally we have an edge which is a solid line that connects |
| actors and use cases and indicates that an actor |
| is the actor of a given use case. And just |
| for completeness let me note there are some additional notational |
| elements but now for simplicity we'll just use these ones. |

## 137 - Use Case Diagram_ Actors

| Now, let's look at use cases in a little more detail. |
| And start by defining exactly what an actor is. An actor |
| represents an entity, which can be a human or a device, |
| that plays a role within my system, so that interacts with my |
| system. It's some entity from the outside world, with respect to |
| my system, that interacts with my system. It is important to |
| clarify that an entity can play more than one role. For |
| example, you might have somebody working in a bank that can be |
| both an employee of the bank, or a customer of |
| the bank, depending on how it interacts with the banking |
| system. And, obviously, more than one entity can play the |
| same role. Using the same example, we can have both an |
| employee of the bank and just a regular customer, playing |
| the role of the customer. So again, it all depends on |
| what the entity does, how the entity interacts with the |
| system, what kind of functionality of the system the entity uses. |
| And finally, actors may appear in more than one use case. |
| So it's fairly normal for the same actor to interact with |
| the system in different ways. And therefore, to appear in more |
| than one use case. Just think about the use cases in |
| scenarios of usage. If the same actor can interact with the |
| system in different ways, that actor will appear in multiple use |
| cases. Now let's go back to the description of our course |
| management system, and see how we can identify actors in the system. |
| And as we did for the class diagram before, I encourage |
| you to stop the video and try to identify the actors |
| in the system yourself, before I do it. |
| If we look at the description, we can see that, for example, the Registration |
| Manager is clearly an actor for the system. Students are actors |
| for the system. Professors are actors for the system. And notice |
| that we're not doing the same thing that we were doing |
| when identifying classes. Here we're identifying |
| entities that are from the outside |
| world, and have an active role in interacting with my |
| system. Again, Registration Manager, that we will just call registrar for |
| simplicity, students, and professors. So once we have identified the |
| actors for our example, we can simply draw them, using the |
| notation that we just introduced. So we have the registrar, |
| and notice how for every actor we clarify the role that |
| the actor plays. We have the professor, and we have |
| the student. So here, these are the three actors that we |
| identified for our system. |

## 138 - Building a Use Case Diagram

| Now if you want to build a use case diagram for |
| our example, we have to add the use cases for |
| these different actors. For instance, if we consider the student |
| and the registrar, they might be both interacting with the maintain |
| schedule system, the registrar by updating the schedule and the |
| students by using the schedule that has been updated by the |
| registrar. As you can see, different roles for the same |
| use case. Another possible use case is the request course roster. |
| And on this case, the professor will request the roster |
| by interacting with the system. We will continue in this way |
| by further refining and by further adding use cases as we |
| identify possible interactions of the actors that we identified with our |
| system. So in summary, what the use case diagram is doing |
| is to show the actors and their interaction with the system |
| through a set of use cases. At this point, it should |
| be pretty clear that sure, this gives us an idea of |
| the interactions but we don't really know how these interactions occur. |
| So there is one piece that is missing, which is how |
| do we document the use cases, how do we describe what |
| happens and what these interactions actually are. And that's exactly what |
| we're going to discuss now, how to document use cases. So the |
| behavior of a use case can be specified by describing its |
| flow of events. And it is important to note that the |
| flow of events should be described from an actor's point of view, |
| so from the point of view of the external entity that |
| is interacting with my system. So the description should detail what |
| the system must provide to the actor when the use case |
| is executed. In particular, it should describe how the use case |
| starts and ends. It should describe the normal flow of events, |
| what is the normal interaction. And in addition to the normal |
| flow of events, it should also describe possibly alternative flows of |
| events. For example, in the case in which there are multiple |
| ways of accomplishing one action or performing a task. And finally, |
| it should also describe exceptional flow of events. For example, assume that |
| you are describing a use case for withdrawing money from an |
| ATM. You may want to describe the normal flow of events in which |
| I insert my card, I provide my pin and so on. |
| An alternative one in which, in addition to withdrawing cash, maybe I'll |
| also first ask for some information about how much money is |
| in my account. And finally, I may want to also describe an exceptional |
| flow of events in which I get my pin wrong and, |
| therefore, I'm not able to perform the operation. One more thing I |
| want to mention, when we talk about documenting use cases, is |
| the fact that the description of this information can be provided in |
| two main ways, in an informal way or in a formal |
| way. In the case of an informal description, we could just have |
| a textual description of the flow of events in natural language. |
| In the case of a formal or structured description, we may use, |
| for example, pre and post conditions, pseudo |
| code to indicate the steps. We could |
| also use the sequence diagrams, which is something that we will see in a minute. |

## 139 - Use Case Example

| So, as we did for the previous cases, now let's look |
| at an example. Let's consider a specific use case, maintain curriculum, in |
| which we have the registrar that interacts with the system to do |
| operations for maintaining the curriculum. And, let's define the flow of events |
| for this use case. To do this, we're going to go back, as |
| usual, to the description of our system. So this is the one |
| that you already saw several times, but I would like for you |
| to do something. I would like for you to stop the video, |
| look back at the spec, the one that is shown here. |
| And write on your own, what you think is the informal flow |
| of events that categorizes the interaction of the registration manager with |
| the system. And it is very important that you keep in mind |
| something as you're doing that. You should keep in mind that, |
| as it always happens, when extracting |
| requirements from an initial specification, in |
| particular an informal one like this one, a high-level one, you |
| will have to be able to read between the lines and fill |
| in the blanks. That is, you have to provide the information |
| for the missing parts using your domain knowledge. So try to |
| do that exercise. Read the description, and see how you will |
| define the steps, the flow of events for the maintain curriculum use |
| case. If you're done with that, now let's see the possible |
| informal paragraph that describes that flow of events. And the one |
| I'm providing now is just one possibility, based on my experience |
| and based on the way I see this possible flow of events. |
| So yours might look different, of course. In my case, because |
| the description was measuring the fact that every user has got |
| a log-in and a password. I decided that the first step |
| should be that the registrar logs onto the system and enters his |
| or her password. As it normally happens with password protected systems, |
| if the password is valid, the registrar will get into the |
| system. And the system at this point should ask to specify |
| a semester for which the maintain curriculum activity has to be performed. |
| The registrar will therefor enter the desired semester. The interface |
| I envisioned is one in which the system will prompt |
| the registrar to select the desired activity. Add, delete, review, |
| or quit. And if the registrar selects add, the system |
| will allow the registrar to add a course to the |
| course list for the selected semester. Similarly, if the registrar |
| selects delete, the system will let the registrar delete a |
| course from the course list for the selected semester. And again |
| similarly, if the registrar selects review, the system will |
| simply display the course information in the course list for |
| the selected semester. And finally, if the registrar selects quit, |
| the system will simply exit and our use case will |
| end. So, again, there's the main knowledge that goes into |
| this. But this is a good example of how you |
| can refine the initial description to identify these scenarios that |
| then you will use to specify and implement your system. |
| And as we discussed a few minutes ago, we provided the information |
| that is requested for the use case, how the use case starts, |
| by logging into the system. And how it ends, by selecting quit. |
| We described the normal flow of events. And, of course, these flow |
| of events could be improved, because right now even though we described |
| how the use case starts and ends, we just described one possible |
| flow of events. But there's many alternative ways we could provide and |
| we do not describe any exception of flow of events. So this could |
| be the starting point for multiple use cases, or |
| for use cases just richer and contains more information, more |
| steps to a richer flow. But you should have |
| gotten the idea of what a use case should be. |

## 140 - Role of Use Cases

| As I mentioned when we started talking about use cases, use |
| cases are fundamental in UML, and in general. So, now I |
| would like to discuss why they're so important and what are |
| the different roles that use cases can play. The first obvious one |
| is for requirements elicitation. It is much easier to describe what |
| the system should do if we think about the system in |
| terms of scenarios of usage. Rather than trying to describe the |
| whole functionality of the system at once. So, use cases can help |
| performing a more effective requirement solicitation. As we will |
| see when we discuss the unified software process, they can |
| be used for architectural analysis. So, use cases are the |
| starting point for the analysis of the architecture of the |
| system that can help identify the main blocks of |
| the system. And therefore, can help define in the initial |
| architecture. And as I said, we'll talk more extensively about |
| that. They can be used for user prioritization. For example, |
| imagine to have multiple actors in the system, and you |
| might want to prioritize some of them. For instance, using |
| again the banking system example, we might want to first |
| provide functionality for the administrators of the bank. And only |
| in a second time provide functionality for the customers, because |
| of course, if the administrator cannot perform any operation, the |
| customers cannot use the system. So again, they can be |
| used to prioritize the users. Or the actors, and therefore |
| define which part of the system should be built in which order. |
| Related to this point, they can be used for planning. If I |
| know which pieces of functionality I need to build and in which |
| order, I can better plan the development of my system. And again, |
| we will see how this becomes very important in many different software |
| life cycles. So, both in the unified software process, for instance, but |
| also in more agile development processes. And finally, use cases can be |
| used for testing. If I have an early description of what the |
| system should do, what are the main pieces of functionality of the system. And I |
| know how the interaction between the actors and |
| the system is, I can easily define test |
| cases, even before writing the code, even before |
| defining my system. And when we discuss testing, |
| we will get back to this and talk a little more extensively about this, as well. |

## 141 - Use Case Diagram_ Creation Tips

| Now, as we did for the class diagram, let's look at |
| some creation tips for use case diagrams. The first tip is that |
| when you define a use case, use a name that communicates purpose. |
| It should be clear what the use case refers to by just |
| looking at the name of the use case. Second tip is |
| to define one atomic behavior per use case. So try not to |
| put more than one specific scenario into a use case. Why? Because |
| these will make the use cases easier to understand and better suited |
| for their roles that we just discussed to define test cases, |
| to do planning, to define an architecture and so on and |
| so forth. Define the flow of events clearly. So again, do |
| it from the perspective of an outsider. An outsider should be able |
| to read the description of the flow of events and understand |
| exactly how the system works or how that specific piece of |
| functionality works. As we suggested for the class diagram, provide only |
| essential details. So there is no need to provide all the nitty |
| gritty details about the use case, just provide enough details so |
| that the use case is complete and understandable. And finally, even |
| though we didn't cover that, there is a way to factor |
| common behaviors and factor variants when defining use cases. So I will |
| encourage you to look at how to do that. For example, |
| by looking at the additional UML documentation and to try to |
| factor out this common behaviors and variants. Typical example would be |
| a system that requires login, like the one that we just discussed, |
| will probably require an initial login step for each use |
| case. It is possible that instead of describing the same steps, |
| or same sub-steps, for each use case, you can factor |
| that out. And create a use case that you should then |
| include in your own use cases. As I said, we |
| didn't cover this for simplicity, but feel free to further read |
| about UML and to see how you can actually factor out |
| behaviors and factor variants. Which can be very useful in practice. |

## 142 - UML Behavioral Diagrams_ Sequence

| Now that we have seen use cases, the next behavioral |
| diagram I want to discuss is the sequence diagram. So |
| what is a sequence diagram? It is an interaction diagram |
| that emphasizes how objects communicate and the time ordering of |
| the messages between objects. To illustrate sequence diagrams in a |
| practical way, and hopefully in a clear way, I will |
| introduce them by creating an actual sequence diagram using an |
| example taken from our course management system. So let's see what |
| are the steps needed to build such a sequence diagram. The first |
| thing we want to do is place the objects that participate in |
| the interaction at the top of the diagram along the x-axis, and |
| you also want to place them in a specific way. You want |
| to place objects that initiate the interaction at the left, and place |
| increasingly more subordinate objects to the |
| right. So basically, this should reflect |
| the way the events will flow for the majority of the interactions |
| in the system. Next thing you want to do is to add |
| what is called the object lifeline. It's a vertical line that |
| shows the existence of objects over a period of time. And |
| it's normally represented with a dashed line, except for the outermost |
| object for which it is a solid line. Now that you |
| have your object lifeline you can start placing messages that these |
| objects send and receive. You want to put them along the |
| y-axis in order of increasing time, from top to bottom. And |
| you can also put a number on the message to further |
| clarify the sequence. So in this case what we're showing |
| is that the student will send the fill in info |
| message to the registration form. And this is the first |
| message in the sequence diagram, the first interaction. Then the student |
| might submit the form and this is also a message |
| that goes to the registration form. At this point, when |
| the submission takes place, the registration form will send the |
| message, so it will invoke some functionality in the registration manager. |
| Specifically you will invoke the add course functionality |
| and pass Joe, the name of the student and |
| Math 101 which is the specific course for which |
| Joe is registering. Then the registration manager will ask |
| the Math 101 course whether it accepts registrations, |
| and the interaction will continue. So that Math 101 |
| will actually check for a specific offering, if everything |
| goes fine, you will receive an ack, you'll send |
| back the act to the registration manager and so |
| on. Until at the end, Joe will be registered for |
| Math 101. As you can see, it is very |
| easy to see how the interaction occurs between these different |
| objects at run time, dynamically. So what the behavior |
| of the system is for this specific scenario. So the |
| last notational element that I want to add to this |
| diagram is the focus of control. Which is this tall |
| thin rectangle, that shows the period of time |
| that an object is performing an action, either |
| directly or indirectly. So if we look at |
| the registration form, this is telling us that |
| the registration form is active for this amount |
| of time. And the same thing we can |
| do for the registration manager, the Math 101 |
| course offering, and the Math 101 specific section. |

## 143 - UML Behavioral Diagrams_ State Transition Diagram

| The very last diagram that I want to discuss is |
| the state transition diagram. The state transition diagram is defined for |
| each relevant class in the system and basically shows the |
| possible live history of a given class or object. So what |
| does it mean to describe the life history? It means |
| that it describes the possible states of the class as defined |
| by the values of the class attributes. And it also describes |
| the events that cause a transition from one state to another. |
| Finally, it describes the actions that result from a state |
| change. So if you put all of this together you |
| can see how this can represent the whole history of |
| the class, from its creation to its destruction. So let me |
| discuss the transition diagram in more detail, and also provide |
| information about the notation used to represent them. We have |
| states, that are represented by ovals with a name. And |
| we have transitions marked by the event that triggers the transition. |
| What transitions indicate is the passage from one state to |
| another state as the consequence of some external stimuli. Notice |
| that not all events will cause a state transition. So |
| for example, some events might be consumed within a single state. |
| And we'll get to that in a second. But in |
| most cases, an event will trigger some state transition. Events |
| may also produce actions and they may also have attributes |
| which are analogous to parameters in a method call. And Boolean |
| conditions that guard the state transition that is prevented |
| from happening in the case the conditions are not |
| satisfied. States may also be associated with activities and |
| actions. Specifically, activities are operations performed by an object |
| when it is in a given state and that |
| takes time to complete. Actions, conversely, just like the |
| actions corresponding to an event are instantaneous operations that |
| are performed by an object. And can be triggered |
| on entry. So, when the object reaches a given state, |
| when the object exits that state, and also when a |
| specific event occurs. And in this case, this notation is |
| basically a shortcut for any event that will cause a |
| state transition that will bring the object back into the |
| same state. Since we have several actions and activities, it |
| is probably worthwhile clarifyinig the ordering of such actions and |
| activities. So the way in which these actions and activities |
| occur is, first of all, we have the actions on the |
| incoming transition, so this is performed first. Then if there is an |
| entry action that is the next action that would be performed, then |
| we have activity and event actions as appropriate. And finally exit actions. |

## 144 - State Transition Diagram Example

| As usual were going to illustrate these kind of diagrams by |
| using an example. In particular we are going to describe the state |
| transition diagram for part of our example, for part of |
| our course management system. And we're going to focus on the course |
| offering class. When the class is created, it enters the |
| initialization state, in which the activity performed is to initialize the |
| course. At this point, a simple case is the case in |
| which the class is cancelled, so there is a cancelled event. |
| And if that happens, the class is simply cancelled. So it |
| gets into this final state, which is the state cancelled. And |
| the activity in this case is to notify the registered students. |
| Obviously if this is the flow there will be no registered students. |
| However something else can happen when we are in this initial |
| state. So what can happen is that a student can register, so |
| in this case the add student event is triggered. And the |
| corresponding action is to set the count, in this case it would |
| be the count of students for the course offering, to one. And |
| there will be a change of state and the course offering will |
| get into this open state. And the action that will be performed |
| on entry will be to register the student. At this point more |
| students may register. So other student events might occur and notice that we |
| have a curve here that tells us this event will trigger this |
| transition only if the count is less than 10. So we're assuming |
| that we're not going to have more than 10 students just for lack |
| of a better number in our course offering. So if that |
| happens, if the count is less than ten so then the count |
| is incremented so the increment count action takes place. And the |
| system goes back into the open state, and the new student |
| is registered. Now here we have an interesting transition, because there's |
| no event triggering the transition, but simply the fact that the |
| count is equal to 10. So you can imagine this as |
| being a transition that is always enabled so can always be triggered, |
| but will be guarded. By the fact that the count has |
| to be exactly ten. So basically this transition will take place |
| only when enough students are added, such we get to count |
| them. Being incremented and being equal to ten and then the transition |
| will occur. And we will get into the closed state, in |
| which the class is no longer open because there are enough students |
| registered. And at this point, what will happen is that the |
| course will be finalized. So there will be this activity which performs |
| some operation that is needed to finalize the course. Another possibility |
| is that when we are in the open state, the course |
| is cancelled. And if the course is cancelled, in this case, |
| we go again to the cancel state. But here, the activity |
| of notifying registered students makes more sense. Because we will have |
| at least one registered student in this state, and therefore we'll |
| need to notify such student that the course offering has been |
| cancelled. Finally, is it also possible also to cancel a course |
| after it has been closed? And in this case again, the |
| same thing will happen. The class will reach the cancelled state and |
| all the students, in this case ten students, that are registered |
| for the course will be notified that the course has been cancelled. |
| So, if we look at this state transition diagram, you can |
| see that it's pretty easy to see what the evolution of objects |
| of this class can be. How they can go from their initial |
| state to various final states depending on what are the external events |
| that reach the system. |

## 145 - Recap Quiz Question

| I'd like to conclude this lesson with a couple of |
| quizzes. Just to recap what we saw. And, make sure that |
| everybody's on the same page. In the first quiz, I want to |
| know whether an UML state transition diagram specifies a set of |
| objects that work together to perform some action. The events that |
| cause an object to move from one state to another. The |
| set of components in a system, or the effects of a |
| state change. And as usual, you should mark all that apply. |

## 146 - Recap Quiz Solution

| A UML state transition diagram does not specify a set |
| of object that work together to perform some action, because |
| this is what a sequence diagram does instead. Conversely, the |
| second one is correct. As we said, a state transition diagram |
| describes the events that cause a transition from one state |
| to another. Again, a UML state transition diagram does not |
| specify the set of components in a system, because this |
| is what a component diagram does, not a state transition diagram. |
| As for the last one, this is correct, |
| because, as we also discussed, a state transition diagram |
| describes the actions that result from a state |
| change, that is, the effects of such state change. |

## 147 - Recap Quiz Question

| And for the last quiz, I want to know |
| which of the following diagrams are UML Structural |
| Diagrams? Use case diagram, class diagram, deployment diagram |
| and sequence diagram. Again, mark all that apply. |

## 148 - Recap Quiz Solution

| And in this case, the correct answer is that class |
| diagram and deployment diagrams are the only two UML structural |
| diagrams among these four. So the answer to this quiz |
| was probably pretty obvious, but I wanted to use it |
| also to stress, once more, the difference between structural and |
| behavioral diagrams. Structural diagrams provide the static picture of the |
| system being modeled, presented from different perspective. For example, from |
| the perspective of the class diagram and of the deployment diagram. |
| Behavioral diagrams, on the other hand, provide information on |
| the dynamic behavior of the system being modeled, also |
| presented from different perspective. So it's important to be |
| able to distinguish between these two types of diagrams. This |
| concludes this lesson on object orientation and UML. But |
| I encourage you to look at the references provided |
| in the class notes, in case you want to |
| know more about object orientation, object oriented analysis, and UML. |

## 149 - Lesson Overview

| Hi. And welcome the third lesson on tools of the trade. In the previous |
| two lessons, we talked about integrated development |
| environments and version control systems. Today, we're going |
| to talk about the android system. An |
| operating system designed for mobile devices. Such |
| as phones, and, tablets. And as we did for our two previous tools of the |
| trade lessons. We will discuss both the |
| conceptual characteristics of android, and also its |
| practical aspects, through a demo. So let's go and see what this is all about. |

## 150 - Android Introduction

| So what is Android? As many of you probably already |
| know, Android is an operating system designed for mobile devices. Where |
| mobile devices are devices that are, of course, mobile, and |
| that are characterized by the fact of having touch screens and |
| sensors. Typical examples would be smart phones, like the one |
| that you probably have in your pocket, and tablets, that are |
| very commonly used nowadays. An |
| important characteristic of the Android operating |
| system, it is based on the Linux kernel. So it is |
| running customized version of the Linux kernel. And in order |
| to be able to run application, it is powered by |
| a Java-based virtual machine, which is called the Dalvik VM. |
| The Dalvik VM is a type of JVM which is used |
| in Android devices to run applications. An important point about |
| the Dalvik VM is that it is optimized for mobile |
| devices. What that means is that it is optimized for |
| low processing power and low |
| memory environments. Therefore, Android applications or |
| Android apps, as we normally call them, |
| are Java-based applications that run on Dalvik. |

## 151 - Basic Architecture of Android

| Now that we saw some high level information on what |
| Android is, let's discuss the basic architecture of the Android |
| system. Let's start at the highest level were we have |
| the Android apps which are applications, as we just saw, |
| that are written in Java, and that get compiled into |
| byte code, packaged and installed on the Android system. Basically, any |
| applications that you ever used on any Android-powered phone or |
| tablet is an app. Typical examples will be the Contacts app, |
| so your address book. The Phone app in your smartphone, |
| this is the app that allows you to make and receive |
| phone calls. The browser, and of course games are also |
| apps. Like for example, Angry Birds or Candy Crush, just in |
| case you ever played any of those. Right underneath the |
| apps, we have the application framework. The application framework is that |
| layer that provides the services that are needed by Android |
| apps to run. Such as the Window manager, the telephony manager, |
| the location manager and the resource managers and there's |
| many more. So basically, the apps rely on this |
| layer to get information and to be able to |
| work, to operate and to interact with the underlying |
| phone. Going down one more layer, we have the |
| Android native libraries which provide APIs for various functionalities. |
| For example, the DB APIs, the webkit APIs, the |
| SSL APIs, OpenGL and so on. For instance, SQLite is |
| the library that provides DB application for the |
| DB APIs that your applications can use to |
| store information. This layer, in addition to the |
| libraries, also contains the Android runtime which consists of |
| the Dalvik virtual machine which we just discussed, |
| and also the core Java libraries. Basically the core |
| Java libraries are the Android version of the |
| standard Java libraries, also called JDKs. Finally, the basic |
| layer, the layer on which all of this runs, is |
| the Linux kernel, which is the core of the Android operating |
| system and it is a standard Linux kernel, as we said, |
| with some customizations made by Google. The Kernel interacts with the |
| hardware and includes all the essential hardware drivers to access the |
| network, the file system, the screen, and so on. So basically, |
| these layers give you an idea of how the whole system |
| works, starting from the apps, which are at the highest level, |
| down to the lowest level, which is |
| the Linux Kernel that interacts with the hardware. |

## 152 - Android App Components

| So now that we saw the general structure of |
| the Android system, let's move our focus to the |
| Android apps, which is, after all, what we are interested |
| in developing. An Android application is slightly different from the |
| traditional application, as it is a collection of several |
| components of different types. We have activities, services, content providers, |
| and broadcast receivers. And all these four components are |
| connected by intents and tied together by what we call |
| a android Manifest. Which is a xml file that declares the components and some |
| properties of your application. So, now let's |
| look at each one of those elements individually. |

## 153 - Activity

| Let's start with activities, in Android and activity is a single |
| screen with a user interface. What I am showing here is a |
| phone dialer, that you're probably pretty familiar with, because it is, |
| you know, in one form or another, present in all smart |
| phones. And this corresponds to an activity. There's another few things |
| to know about activities. First of all, activities are independent units. |
| But they can work together to form a cohesive whole and |
| we'll see what that means. And one of the nice things about |
| activities, is that they can be invoked by other applications. |
| For example, assume that you're a runner and you're using the |
| Run Keeper to keep track of your runs. Run Keeper |
| can invoke a camera activity. When you're taking a picture during |
| a run. So even though the camera activity is an |
| independent one, it can be used by another application. Finally, from |
| the programmatic standpoint, and as we will see in our |
| demo, we can create an activity by simply extending the activity |
| class, which is part of the Android system. |

## 154 - Service

| The next component that I want to discuss is a |
| service. A service is an application component that performs a usually |
| long running operation in the background while not interacting with |
| the user. A typical example of a service, is a service |
| for playing music which will run in the background even |
| when we are not using the music app directly. Another typical |
| example is a download service, such as the one that |
| takes care of downloading updates in the background. Once more services, |
| they run in the background and they don't interact with |
| the user. So they perform some long running function while not |
| interacting with the user. Therefore, unlike an activity, services do not |
| provide a user interface. Similar |
| to activities from the programmatic standpoint, |
| the way to create a service is simply to extend |
| the service class, and we'll talk more about this. And there's |
| just a few things that I want to mention about services, |
| just to further clarify what they are. A service is not |
| a way to offload some work that should be logically done |
| by the application. But the service is a way for the |
| app to tell the system about something that it wants to |
| continue doing in the background, even when the user leaves the |
| application. In addition, a service is also a way for the |
| application to expose some of this functionality, for example the music |
| playing functionality. By doing so, applications can bind to the service |
| and using the service. For example, imagine a turn by turn navigation |
| app, such an app will bind to the music player service to be able to |
| stop the audio temporarily when making an announcement. |
| For example, when a turn is up coming. |

## 155 - Content Provider

| The third kind of component that I want to mention |
| is the content provider. The content provider provides a structure interface |
| to a set of data such as for example a set |
| of pictures or media files in general. As we saw earlier, |
| Android contains an implementation of the SQ Lite Database manager. So, |
| very often, apps rely on a SQ Lite database to store |
| the data and a provider to give it access to such |
| data. In some cases, a provider can be used for accessing |
| data within an application. In which case the data will |
| be application data, such as a list of items to be |
| bought for a shopping list management application. There is a |
| much more interesting case, though. More generally a provider can be |
| used by an application also to share data with other |
| applications. In the case represent here for instance, this content provider |
| is being accessed by three different application. If you want an |
| example, a typical one will be an address book, the contact |
| app in your smartphone, for instance. The address |
| book could use a provider to give access to |
| the user contacts to other applications such as, for |
| example, a telephone application, a voice over IP application, |
| a messaging application, and so on. So in |
| this case, all these applications will be able to |
| access the same data through a common, well-structured interface, |
| which is the one provided by the content provider. |

## 156 - Broadcast Receiver

| The fourth and final component that we are going to |
| cover is the broadcast receiver, which is a receiver, |
| as the name says, that can be registered to |
| receive system or application events. To illustrate, consider here, my |
| broadcast receiver. Where as here, we have the Android |
| system. What the broadcast receiver can do is to |
| register with the Android system for a specific event of |
| interest. And the Android system will notify the broadcast receiver |
| every time an event of that kind will occur. For |
| an example, consider a music player. A music player could |
| use a broadcast receiver to register for the event of |
| incoming phone calls, because it wants to suspend playing music |
| every time that there is a phone call incoming. Similarly, |
| it could also register for the end of the phone |
| call because it might want to resume playing music every |
| time a phone call is ended. So broadcast receivers are extremely |
| useful and can be used in many, many applications. |

## 157 - Intents

| As we said at the beginning, the four components that |
| we just saw can be connected by using intents. So, |
| what is an intent? An intent is an abstract description |
| of an operation to be performed and it consists of two |
| main parts, an action and a set of data. The |
| action is the action to be performed, which is indicated as |
| a string. And the data is the data on which |
| the action will operate. For example, consider a phone call intent. |
| Such an intent might have call as an action. |
| And, information from the contact database, in particular |
| a phone number, as data. So, why are |
| intents useful? Well, because they provide the developers with |
| a way to perform late binding between different |
| applications to connect applications that were not initially meant |
| to be connected. That is, they allow for |
| binding at run time to otherwise completely decoupled applications. |
| So let's see an example of how this works. To do |
| that, let's use the same example as before. So imagine that |
| you're browsing your contacts, so activity one will be the contact |
| application. So an activity in the contacts application. So you use that |
| activity and you get to the person that you want to |
| call. At this point you click on the phone icon and |
| the result is the generation of an intent. And the intent |
| is exactly the one that we saw before. It's an intent in |
| which the action is call, and the data is the |
| phone number for the person that you want to call. When |
| this intent is generated what happens is that the call |
| activity of the phone app is being activated with the final |
| result that the person that you were looking up will |
| be called by your phone. So why does that happen? How |
| can it be that I perform an action in one activity |
| and another activity is started as a consequence? To answer that, |
| let's see how the binding between these two activities |
| happens through intents. And there's different ways in which that |
| can happen. The first possibility is a direct binding. |
| In this case the activity or the app generating the |
| intent will directly start an activity from another application. |
| Similarly, the app generating the intent could directly start the |
| service. For example, by requesting an audio player service |
| to play a given audio file or a stream. Finally, |
| and this is the most interesting type of binding, |
| the activity generating the intent, so in this case the |
| contacts application, could broadcast the event. And in this |
| case the intent will be delivered to all interested broadcaster |
| receivers. So we just saw the broadcast receivers and |
| this is the way in which some information can be |
| broadcasted. So in this case clearly it would not be |
| a system event but it will be an application event. |
| Going back to our example of the phone call, |
| because the phone application previously notified the Android system |
| that it was supporting the action call, the system |
| will notify the phone app that a call intent has |
| been generated. So that's why this works. The phone |
| app says, I can handle calls. When a call intent |
| is broadcasted, the activity is bound to the intent. |
| The activity is notified about the intent, and can react |
| to it. And in case you're curious, this also the |
| reason why for instance if you have more than one app |
| that can make phone calls, for example you have a voice |
| over IP application or multiple ones, and you have your regular |
| phone application, when you select the phone icon in your contacts |
| you are provided with a choice of which app to use |
| to call. That's because there are multiple parties, multiple activities, that |
| could handle that intent and therefore unless you define some default |
| behavior you will have to choose which one should be activated as |
| a consequence of the generation of the intent. So, similar to broadcast |
| receivers, intents are also extremely useful in many situations to bind the |
| activities that would be otherwise completely |
| decoupled, as we said at the beginning. |

## 158 - Manifest

| If you remember at the beginning of the lesson, I said |
| the Manifest is what keeps an Android application together. So |
| what is a Manifest exactly? In a Manifest is a |
| XML file that declares, among other things, all of the steady |
| components of your app. Activities, services and content providers. Broadcast |
| receivers could be defined in either statically in the Manifest or |
| dynamically in run time. So they don't necessarily have to |
| be in the Manifest, but they might be. The second thing. |
| That the manifest declares are all the permissions required |
| for your app to work. For example, if the application |
| requires network access or access to calling and messaging capabilities, |
| that must be specified in the manifest. The manifest also |
| specifies the entry point for the application. That is, |
| which activity should be launched when the application is executed. |
| So what that means is that when you click on |
| an app to start the app up the system will |
| look into the Manifest to see which activity has to be |
| started as a consequence of that. So which one is the |
| entry point for your application as we were saying. The Manifest |
| also declares the version of the app, and this is used for |
| updates. Because the system is able to check which version you |
| have and which one is the latest version available for that application. |
| And finally, the manifest also declares the lowest Android SDK version |
| for which is app is valid. So this is something that is |
| checked at installation time to make sure that the application can run on |
| your version of the operating system. So |
| again, nothing too exciting, but information that |
| is necessary for the system to understand |
| how your application is structured and what |
| the different parts are and what is |
| needed for the application to operate correctly. |

## 159 - Android Activity Lifecycle

| Now that we saw the main components of an Android |
| application, there is one last, but very important aspect of |
| Android that we need to cover, which is the Android |
| activity lifecycle. So I'm going to use this classic diagram |
| to illustrate such lifecycle. But before getting to describing the |
| different parts, let's see why we have a lifecycle in |
| the first place. The point here is that because Android |
| apps run in a multitasking environment, the runtime system routinely |
| suspends, stops, and even kills applications and activities. If |
| you want an example, just think of the case of |
| a phone call that arrives while you're writing an |
| email message. In such cases, what happens is that the |
| phone application replaces your email client and gets in |
| the forefront. So apps must be able to react to |
| these occurrences and suitably handle them. Luckily, the Android system |
| is nice enough to notify activities when it needs to |
| change their state, for example, when it needs to suspend, or |
| kill them. And it does so by calling some special methods in |
| the activities. Therefore, when you develop an application, an Android app, |
| you must be aware of what these methods are, and suitably implement |
| them. We will therefore now have a look at these methods, |
| and see what they mean when they get called, and how this |
| relates to the different states of an activity. And we're going to |
| do that using this diagram that I introduced here. In order to |
| better illustrate how this all works I'm going to |
| complicate the picture a little bit by adding information about |
| what happens when going from one phase of the lifecycle |
| to another one. Because this will have to make the |
| diagram more self-explanatory. Let's start from here, from the |
| moment when an activity, or an app is launched. We |
| will call our activity A, and what happens is that |
| when A is started, the system will call different methods |
| on the activity, and will put the activity in the foreground. |
| What that means is that the activity will stay on the |
| screen, visible, the user will be able to interact with the |
| activity, and the activity will be in the running state. And so |
| this is when you're looking at your device and you are |
| seeing in the foreground your activity and you can interact with it. |
| At this point two things might happen if another activity is |
| launched. In the first case A might lose is focus but still |
| be visible. This is the case in which the new |
| activity that is being created is maybe an activity that doesn't |
| take up the whole screen, so my original activity is still |
| visible in the background. Or a case in which the activity |
| is a transparent activity, so it has focus but I can |
| still see the original activity behind it. In this case the |
| system will call onPause on Activity A. And the activity will |
| be in the paused state. A paused activity is completely alive |
| in the sense that it maintains all state information and |
| remains attached to the window manager. But what can happen is |
| that the activity might be killed or destroyed for example in |
| case in which there is not enough memory to run both |
| the new activity and the original activity. So the second case |
| is a case in which the new activity that is being |
| launched is completely obscuring my original activity. Which is a kind |
| of more standard case. So, for example, you receive a phone |
| call while you're editing a message. The phone app completely |
| replaces the email client on your device, and becomes the |
| new running activity, the one in the foreground. In this |
| case the system will call onStop on the original activity and |
| the activity will be in the stop state. Similar to |
| the pause state, also in this case the activity A |
| still retains all of state information but it is more |
| likely that it will be killed or destroyed by the system. |
| So let's look at what can happen from these two states |
| in a little more detail. As we said there are cases |
| in which an app with higher priority might need memory from |
| the system, resources from the system. And the activity that's paused or |
| stopped will be killed. In this case, if the user happens |
| to go back to the activity, the system will recreate it |
| basically, so it will restart it from scratch. So this is |
| the reason why it is very important that when your application goes |
| into the paused or stopped state, which means when the |
| system calls onPause or onStop in your app, you suitably save |
| the state of the application so that the state can |
| be restored if the activity is killed and recreated afterwards. A |
| second possibility when your activity is paused or stopped is |
| that the activity is finishing or is being completely destroyed by |
| the system. In this case, the onDestroy method is called and |
| the activity is shut down for good. The third possibility is |
| that the activity is not killed, is not destroyed, and the user |
| simply returns to the activity. For example, you go back to editing |
| your email after finishing your phone call. In this case, the system |
| will call onRestart() on the activity and the activity will go back |
| to the running state. So what I just covered are kind of |
| the main paths through an activity lifecycle. But I'll strongly encourage you |
| to read more about this, and to make sure to go through |
| this lifecycle until it is clear to you what the different states |
| are, and what you should do for each of them |
| when the system invokes state changing methods on your activity. |

## 160 - Android Demo_ Download & Install SDK

| Now that we covered all the main conceptual |
| aspects of the Android system, let's look at how |
| these aspects work in practice through a demo. |
| Let's start our Android demo by downloading the Android |
| SDK, which will allow us to build Android apps. To do that, we need to go to |
| the site developer.android.com. Here, we click on Develop. |
| Then we click on Tools. And finally, we click |
| on Download here on the left. This brings us to |
| this page in which we can get the Android SDK. And |
| we can get it as a bundle, where the bundle |
| includes various things such as the Eclipse IDE, plus the ADT |
| plugin, Android SDK Tools and other parts. So for now, |
| what we're going to do, we're just going to download the Android SDK. |
| So we're going to skip that and we're going to go to DOWNLOAD |
| FOR OTHER PLATFORMS. And here where it says SDK Tools Only, |
| you can pick the version of the Android SDK for your platform. |
| So if you work on a Mac, you will pick this one |
| and, otherwise, you can pick the Linux version or the Windows version. |
| And once you click on that, you will get the SDK package. |
| Now that you have downloaded the Android SDK for your platform, you |
| can unzip it and you can do that graphically or as I'm |
| doing here from the command line. So I'm just going to run unzip |
| and pass the file as a parameter. And I'm doing the command |
| line version because that's, you know, a little more |
| challenging so the, the GUI one, you'll basically just click |
| on the archive. And as soon as we have unpacked |
| the SDK, we can move into the android-sdk directory. We |
| can look at the content of the directory. And as |
| you can see, there are several files and directories inside. |
| And the one that we're interested in right now is |
| the tools directory. So that's where we're going to go next. |
| And again, if you're doing this through a GUI, we'll just click |
| on the tools directory. And here, we have a bunch of applications. These |
| are all part of the Android SDK. And what we're interested in is |
| this android command. So we're going to run it, which you can do again |
| from the command line or just by clicking on it. You'll probably |
| get an error here but don't worry about it. We're going to fix it |
| in a minute. So when we run the command, we're going to get the |
| Android SDK Manager, which allows us |
| to manage the different packages |
| that are part of the Android SDK so to |
| see which ones are installed and to install new ones. And |
| as you can see, you can install different versions |
| of Android. And for each version, there is a corresponding |
| API version. And you can also see that the, |
| the one selected by default is the latest version, which, |
| in this case, is Android 4.4 and API version |
| 19. So all the corresponding parts are selected for installation |
| and, similarly, the platform tools and the build tools are also |
| selected. And you can see on the right that none of |
| these packages is currently installed. So we click Install to install |
| these nine packages. Next, we have to accept the license in |
| order to be able to install the packages. So we do |
| that. We click Install again. And if you want, you can |
| also look at the log here to see what's happening during |
| the installation. And you can see that there's an error there referring |
| to the fact that, you know, stopping |
| the ADB server failed and that's okay because |
| we haven't installed the server yet. So |
| you might see exactly the same error. And |
| at this point, you know, just you know, you just have to wait until the |
| installation finishes. So we're going to stop here |
| and we're going to go to the next step. |

## 161 - Android Demo_ Download & Install Plugin

| Now that we have installed the Android SDK, the next |
| thing I want to do is to install the Eclipse |
| plug-in for the Android SDK. And the Eclipse plugin will |
| allow us to develop Android apps from within Eclipse. To do |
| that we are going to go back to the page where |
| we were, so the download page for the developer.android.com website. |
| So as you can see, here in the download section |
| there is an option that is Setting Up An Existing IDE, |
| which is what we want to do because we want to set |
| up Eclipse. And you can see that there's also another entry which |
| is called Android Studio. And this one is a different IDE, it's |
| kind of a more experimental one, it's a newer one, and so we're |
| not going to use it for now, but just for your information, this |
| is another possibility. So, if you don't want to develop from within Eclipse |
| using the plugin you can also use the Android Studio. But for |
| most of the examples in the class and for the project, we're going to |
| be working with Eclipse. So, for now, it's recommended that |
| you use the Eclipse plugin instead of Android Studio. So, we're |
| going to ignore the Android Studio for now. Okay, so when we |
| click on Setting Up an Existing IDE and we click on |
| installing the Eclipse Plugin. This will bring up a page that |
| gives us all the information that we need to install that |
| plugin. In particular, what we're going to do, we're going to take this |
| URL down here, we're going to copy it, and we're going to use |
| it to download the plugin from within Eclipse. So let's switch |
| back to Eclipse now. So, to install the plugin in Eclipse, |
| we're going to go to the help menu, install new software, down |
| there. And this will bring up a page in which we |
| can add a new site. Let's just give a name to |
| the site. Let's call it Android Eclipse plugin. And let's use |
| the URL that we copied here, which is the location of |
| the plugin. And after we have done that, we can click, |
| okay. And the Eclipse will go and download the description of |
| the plugin from the site and as you can see |
| there are two different parts of the plugin. There is developer |
| tools and we just going to select all of them. And similarly there |
| is a native development tools, that we're also going to select. |
| And at this point, we're just going to click Next and install everything. |
| If you installed plugins before, you know, that now you're going to |
| be presented with a set of dependencies. We just accept the dependencies. |
| We'll have to also accept the license for the |
| software. Which we do we click Finish and then Eclipse |
| starts installing the software. And just something I want to |
| mention while the installation proceeds is that some of |
| the software in the plugin is unsigned. Which means that |
| it's theoretically untrusted so when Eclipse will |
| get to that point, it will raise a warning, and |
| it will notify you that you are installing some unsigned software. |
| This is exactly what is happening here. It is telling you |
| that you are installing software that contains unsigned content. And that you |
| can look at the details if you want, you can see |
| which software is that. But in this case, you can safely install |
| the software anyways. So you want to go and click okay, |
| which will continue the installation process. And when you're done with the |
| installation, Eclipse will let you know that you need to restart Eclipse |
| for the software to actually install, we'll click yes. After restarting Eclipse, |
| you should now see two buttons, up in the toolbar |
| of Eclipse. The first one is the Android SDK manager. And |
| the second button is the Android virtual device manager. But |
| before looking at what these buttons do, let's go to Eclipse |
| preferences up here, and we're going to look at the |
| Android preferences that were also added by the plugin. So we |
| go to this window, we click on Android, which will open |
| the preferences for the Android platform. And after that, you should |
| see the same, information that I have here on this window. |
| So you should see that there's a version of Android installed. And |
| also a version of the Google API's. So now, if you |
| expand the Android entry here on the left, you can see that |
| there's other specific configurations that you can set. But we're not |
| going to worry about that for now. So we're just going to close this |
| window, and we're going to go back to the two buttons that we |
| mentioned before. And we're going to bring up the SDK Manager. And |
| this is exactly the same Android SDK Manager that we saw in a previous part |
| of the, of the demo. But here, you can notice that the packages that we |
| installed before, so the Android SDK Tools, |
| the Platform-tools and the Build-tools and the Android |
| version 4.4 and the corresponding API, are now |
| marked as installed as indicated on the right. |

## 162 - Android Demo_ Create an AVD

| So now, let's start the Android virtual device |
| manager by clicking on this button, and this is |
| the place where you can create and configure |
| Android virtual devices, which is what we normally call |
| emulators. So if you click on the second |
| tab, you can see some standard pre-defined configurations. Just |
| as an example let's pick one, for example the |
| Nexus 4 configuration. So this will emulate a Nexus |
| 4 and now when we click on the Create AVD, |
| this will create the device, and the configuration and a |
| lot of the information is already filled out as you |
| can see. And now we can pick the Target API and |
| version of Android. And the next thing I will recommend |
| to select is Snapshot in the Emulation Options because that |
| makes the boot up time for the emulator considerably faster. |
| So after we've done that, we'll click on OK, which will |
| create the actual virtual device, and this is going |
| to take just a little bit of time because the |
| configurations being set up. And after we're done, we |
| can see that now we have the newly created virtual |
| device for the Nexus 4 right here in our |
| list. So now we can select our emulator and start |
| it. And when we click on Start we're presented with |
| this window, in which we can select some launch options. |
| And the one I'm going to select here is this Scale |
| Display to Real Size, which means that we're going to see the |
| emulated device in real size instead of full screen which will |
| give us an idea how big is the actual display. So we |
| click Launch. And this might take some time the first time |
| you do it, but then it'll be faster after that. So what |
| happens is basically, the emulator's being created and as soon as |
| it is created, it is launched. So after the device is started, |
| it'll start booting the operating system, the Android operating system. And |
| when that is done you will be presented with the opening |
| screen for the operating system, because this is the first time |
| that we run the emulator. So the only thing I want |
| to point out here, is that here, on the right, you |
| have a set of buttons which correspond to the buttons that |
| you normally have in in any of your mobile devices. So |
| you have the volume buttons, the power button, the home button, and |
| other navigation buttons, and you can use those to interact |
| with other applications in the emulator. So what we're going to |
| do next is we're going to click OK here then |
| and we'll get to the initial screen of Android. And at |
| this point we have our fully functional, fully configured emulator |
| and we can run our apps on this emulator, which is |
| what we're going to see next. We're going to see how |
| to write applications, compile them, and run them on the emulator. |

## 163 - Android Demo_ Create & Run an App

| So let's create our first Android app. To do |
| that, we go to the Package Explore>Contextual Menu>New>Other. This brings |
| up the window in which we can select different types |
| of applications and in particular Android applications. As you can |
| see, we have several options. And the one that |
| we want to pick is Android application project, so we select |
| it. We click Next. So this will start this widget |
| in which we can choose different properties of the application, |
| in particular the name. I'm going to call the application converter because |
| the application I want to write is a simple application that |
| ocnverts between kilometers and miles. The next thing I can select |
| is the Minimal Required SDK. So this is the information for |
| backward compatibility. So it's saying that my application should run for |
| any version of Android between 2.2 and 4.4, which is the |
| current version. And the next thing I want to do is |
| to change the package name, so I'm going to use the |
| package name that we usually use for our example, so |
| edu.gatech. Now we click Next to continue. This brings up this, |
| new window in which we can select our configuration options. |
| We're just not going to change any of those, so we |
| just click Next again. More options here. So for example, |
| you can select the foreground. You can select whether you want to |
| trim the surrounding black space for your application. You can |
| select the icons again. We're just going to keep the default values. |
| And, we're going to move forward. The next thing we can do |
| is to choose the type of activity that we want to create. |
| And, in this case, wer'e going to go with a blank activity. |
| And, this leads us to the last screen of the wizard in |
| which we can pick the activity name. We're fine with Main |
| Activity. You can choose the name for the layout and the navigation |
| type. We're just going to keep none for the navigation type. And we |
| click Finish. So at this point our app and initial activity gets created. |
| So now you can see that our Android project has |
| been created, so we can click here and expand the project |
| and see the content of the project. As you can |
| see here, we have a source folder that contains our package |
| and main activity. We have the libraries required for Android, |
| an assets folder, the binary folder where our compiled code will |
| go. Then the libraries, in particular the Android support library. |
| And finally, a directory with all the resources for my project. |
| So, just for example, the icons for the project, and here |
| want to point out a few things. So, I'm going to open the |
| layout folder and here you can see that there's a layout file |
| for the main activity. It's in XML format. So if I click |
| and open this file, I can see that we have two views |
| of this file, a graphical layout view, and, an XML view. So, |
| the nice thing about this is that, with the visual editor I |
| can actually drag and drop widgets into my layout, into my activity. |
| And then those will be automatically reflected in the XML |
| view. So, next I'd like at the strings.xml file in the |
| values folder. So, this is the file that contains all of |
| the strings that are defined within your application. So, it's a |
| centralized place where you can change the strings for your |
| app. So, next I want to look at the android manifest file |
| which is something that we discussed in our lesson. So, basically, |
| this is the file that defines the structure and some configuration |
| options for our app. So, now let's go back to our |
| main activity layout. Let me make this full screen so that we |
| can see better, and zoom in a little bit. Let's go |
| to graphical layout, by default it will just have a hello word |
| string here, so we're just going to delete that. What we need |
| first is a text view So I'm going to take the text view |
| and drag it here. Then I can change the text in this |
| text view by using the property window here on the right and |
| put the text distance here and as you can see that gets |
| reflected in the GUI. Now we're going to add a text field, a numeric |
| text field in particular. Here it is, we want to use one with |
| decimal values. And as you can see here, you can also check what's |
| the distance between the different widgets. And as you can see, each |
| of these elements has got an assigned ID, which you can see here |
| on the right. And if you want, you can go and change |
| that ID. And the ID is then used within the application to refer |
| to this element. In this case, we're going to call it |
| text1. So if you change that, Android will ask you whether |
| you want to update all of the references to this element, because |
| you changed its ID. So let's say Yes in this case, and |
| that will change all the XML and Java resources accordingly. Now |
| that we added this, let's add some radio buttons to our activity. |
| We can do that from our phone widgets set of entries. So |
| in particular here you can see that we have the radio button |
| group, so we just place it at the appropriate distance from |
| the other widgets. So, now let's go an check out our |
| XML view, of the layout and as you can see, |
| all the changes that we made, all the elements that we added, |
| are now reflected automatically, as I said, into the XML view. |
| So, you can also change the properties and attributes of these elements |
| here and they will be reflected in the graphical layout, as |
| well. So, for example in this case, let's imagine that we want |
| to delete the last radio button. So we can do |
| it here in the XML file. Let's give some names at |
| the first radio button. Let's call it miles and the second |
| radio button we will give it the name kilometers. So now, let's |
| see how this is reflected into our graphical layout. As |
| you can see, we have only two radio buttons, as expected. |
| And the labels for these radio buttons are miles and kilometers. |
| At this point, let's try to run this on our emulator. |
| So to do that, we have to go to the |
| menu up there and select the virtual device that we |
| created earlier, the one for the Nexus 4. At this |
| point, to run it, we minimize again our windows so that |
| we can go to the package explorer. We select Converter>Run |
| As>Android Application. And when we do that, the clips will deploy |
| our applicatoin on the emulator and will run it there. |
| And before the emulator is actually launched you will get this |
| option in which you can decide whether you want to monitor |
| logcat or not and what logcat basically does is |
| to show you logs from the emulator within the IDE. So |
| normally you might want to say yes to see what's happening inside |
| the emulator. As you can see, now we have the logcat |
| view down there. We're going to maximize it. You can see |
| there's some information about the emulator. So now let's look at |
| our console. Let's change to the Android console. And if you look |
| at the output here on the console you can see that our |
| activity has been started so we can switch to the emulator to |
| see how our activity running. And in the device, you can see |
| that we have the widgets that we added. So we have the distance, |
| we have the two radio buttons and what we can do here, |
| we can enter an actual value. Like for example, two, three, four, five. |
| And the way we want our application to behave, is that when |
| we click kilometers, the application will |
| do the conversion automatically, and vicea versa. |
| So let's go and implement this functionality in our |
| app. So, to do that, I'm going to minimize the console. |
| going to go back to my IDE, and I'm going to |
| select again, Activity Main. In this case, I want to have |
| the XML view. And the way which I can |
| do this, is by connecting my widget to the code |
| and I do that by adding this entry here, |
| in which I say that onClick so the onClick property |
| is linked to the handleClick method and I'm going to |
| copy this and do exactly the same for the second radio |
| button. So what that means is that every time you click |
| the radio button, handleClick will be invoked. So now we need |
| to implement the handleClick method in our activity. So let's go |
| back to the main activity, to the Java code. And as |
| you can see, this is the code that was auto generated. |
| So first I'm going to be writing the signature of my callback |
| on my handle, so the name is handleClick, and the |
| parameter is a parameter of type view. Next, we're going to |
| check the status of a radio button that's been clicked. |
| So we want to see whether it's checked or unchecked, and |
| I do this using the method isChecked of the view |
| object, of the view class. Next we want to get a |
| reference to our text box, and we're going to do this |
| using the ID for the text box that I mentioned before. |
| And we're not looking at all the details of this code, |
| but there's something I want to clarify here, is that we're |
| using this class R here, that we haven't mentioned before. And |
| R is basically a static class that gets associated to your Android |
| app, and contains references to all of your resources. So for |
| example in this case we're using R to access the IDs and |
| within these IDs the text one ID which is the one |
| corresponding to our text entry. And now that we have a reference |
| to the text entry, we can actually use that to read |
| the value that was entered by the user in that entry |
| and we're going to use the method parseDouble of the Double |
| class to do that. So we're going to get from the text |
| entry the text. We're going to convert it to a string, and |
| then we're going to parse it into a double. At this point, |
| what we need to do is to figure out which radio |
| button was actually clicked. If you remember, we associated the same method |
| handleClick to both radio buttons. So this method gets |
| invoked when either one is clicked. So in order to be |
| able to distinguish between the two, and in order to know |
| which one was actually clicked, what we need to do is |
| to get the ID of the element that was clicked. |
| And we do that by using the method, Get ID of |
| the view object. Now to match the ID, we use again, |
| class R, as before. And in particular, ID of class R, |
| so we have the first, ID which is our ID radio0, |
| which is the one corresponding to miles. So now we're |
| going to use the value that we set before and if |
| check is true. So if the radio button corresponding to the |
| miles was actually clicked, that means that we are converting |
| the value that was in the text entry from kilometers to |
| miles. So we going to use this method kilometer to miles which |
| we haven't written yet and we going to pass the distance which |
| is the current value in the text entry to this method. This |
| method will return the corresponding value in miles and then we'll use |
| that to update the text in the text field. So at this |
| point our conversion would be complete. So at this point we need |
| to handle the second case. Which is of course the case in |
| which we click the other radio button. So the one with id |
| radio1, also here, we make sure that the radio button is |
| actually checked. And if it is, in this case we are converting |
| from miles, to kilometers. So we do exactly the same thing |
| that we did before, but we invoke a different method. So |
| in this case we invoke the method miles to kilometers, again |
| passing the distance as an input. At this point we're almost done, |
| so we're just going to clean up the code a bit here, |
| then I'm just going to copy and paste in the two methods, |
| the kilometer to miles, and the miles to kilometer, in the |
| interest of time. So I'm not going to write them in real time. |
| And as you can see, the first method performed the |
| conversion from miles to kilometers by using the proper conversion |
| factor and returning a string value for the converted value |
| and the second method does the opposite. So converts kilometers to |
| miles. So at this point we're ready to run our |
| code. To do that we use the run menu here, |
| which allows to run the convertor application and as we |
| did before, we can go and look at the console |
| to figure out what's going on and as you can see |
| the console tells us that our app is being installed on the |
| emulator, sucessful install, and after it's done we can switch to |
| our emmulator and we can see our application running as we did |
| before. But in this case, with a complete code behind it. |
| So here we can enter, for example, our distance in miles, so |
| let's just put one mile to see how the conversion works |
| in this case and as you can see, the distance gets converted |
| back and forth correctly. So, now let's use a |
| slightly larger number. So for example, let's use the |
| distance between the Earth and the moon and we |
| can convert that from miles to kilometers and back |
| to miles again. So, we have successfully written, deployed |
| and ran in an emulator, our first Android app. |
| And notice that you can run exactly the same |
| app on any of your mobile devices, if you want. |

## 164 - Lesson Overview

| Hello, and welcome to the third part |
| of our software engineering course. In this mini-course, |
| we will discuss software design. We will |
| also introduce the Unified Software Process. And we |
| will work on a more complex project, |
| in which we will develop a distributed software |
| system that involves multiple different platforms. In |
| our first lesson of this mini-course, in particular, |
| we will talk about software architecture. A |
| software engineering discipline whose goal is to lay |
| the foundation on which to build successful |
| and long lasting software systems. So let's begin. |

## 165 - Interview with Nenad Medvidovic

| Because the topic of today's lecture is software architecture, |
| it seemed appropriate to start the lesson by asking a |
| world expert on this topic, what is software architecture, and |
| why it is important. To do that, let's fly to |
| California, and more precisely, Los Angeles, and visit Professor |
| Nenad Medvidovic. Hi, I'm here visiting Professor Nenad Medvidovic from |
| the University of Southern California. And Neno is one of |
| the world experts in software architecture, actually one of the |
| authors of, of a recent book which is, sort of the |
| book in software architecture. What I would like to discuss with |
| Neno is the concept of software architecture and its importance. Because |
| people are very familiar with the idea and the cost of the |
| design. And software architecture is something is very related to that, |
| but is less known. So I would like for Nenad to |
| elaborate on that, and tell us why is it important to |
| focus also on this specific you know, architectural aspects of the software. |
| >> When you |
| build any software system, even a simple, relatively simple |
| one. You're going to go through, a process of making |
| many, many design decisions. Hundreds or thousands sometimes even tens |
| of thousands of design decisions, so any program that you |
| write at some point you get to deciding what |
| the interface of a particular method is going to be. |
| Are you're going to put in a parameter that is |
| an integer or a float. When you're writing your routine |
| about some sort you have to decide whether you're |
| going to use a static data structure or a |
| dynamic data structure. All these things are design decisions. |
| Many of them however, will typically, in the average |
| case, not really impact the success of your system |
| and the long term well-being of your system. But |
| typically the things that software engineers start struggling with |
| are other design decisions. Design decisions that are the equivalent |
| of load baring walls in a building |
| >> Mm hm |
| >> These are the things that, if you |
| don't get them right, or if you compromise |
| them, will in fact potentially impact how the |
| system operates. They might result in failures of different |
| kinds. They may result in a system that |
| is not easily maintainable and so forth. In |
| a sense, to make a long story short, |
| architectural design decisions are really the principle design decisions |
| in your system. These are the things that are |
| very important. All of the other design decisions you |
| could sort of tag with being important, but they're |
| sort of below this very important or highly important threshold. |
| >> So if you need to change a low level design decision, sometimes |
| it's kind of easy to do. It might change a little structure. Is it |
| the case that you know, being the architecture is sort of the pillar of |
| the software, is that going to be much |
| more difficult to change an architectural decision? |
| And architecture is deemed to be you know, |
| say if you start with the wrong architecture the |
| software is going to, you know, necessarily be unsuccessful. |
| Or you can also do something that is better. |
| >> A system could be successful and very poorly architected. Just |
| like a building or an airplane or a car, any other |
| engineering artifact could be successful but poorly architected. So success we |
| can separated from this, but the, the point that you make in |
| asking this question is an important one. The |
| non-architectural design decisions, should be on the |
| average, there are exceptions and we need to |
| acknowledge that there is no one size fits all |
| type of solution for anything in software engineering |
| really. But on the average, the non-architectural design decisions, |
| should be much easier to make. So the |
| scale of the consequences of making such a change. |
| Really can vary from very minor, highly localized |
| to very important and sometimes, even system wide. |
| >> To conclude, I just like to ask you about some concept that is |
| we here about a lot. Which is |
| architectural erosion. Since, we're talking about in with |
| fine architecture and software evolution. So, what is, |
| exactly, an architectural erosion and why does that |
| happen? So, to go back to our non software metaphors. Imagine you buy a car. |
| And your car has four wheels, it has a steering wheel, it has |
| a nice chassis, it looks pretty nice. At one point, you end up |
| replacing its 150 horsepower engine with |
| a 250 horsepower engine because that's what |
| you want. And you start putting a spoiler on the back of the car |
| and then you replace the headlights. And then you replace the side view |
| mirrors with smaller ones because you want your car to be more aerodynamic. |
| And then you start tinkering with other things, like you cut the, maybe |
| the roof of the car because you want to turn it into a convertible, |
| et cetera. And in the end, what you have is |
| a car that is still your car. Looks very different, It's |
| structural and behavioral properties are very different And, what you |
| might find is that the car doesn't handle nearly as well. |
| For example, in a very sharp turn it might not |
| be able to negotiate a steep hill as well. Because you |
| pretty much changed it all along the way. Architectural erosion in |
| the case of a software system is the exact same thing |
| with one huge caveat. Very few, if any of us, |
| will ever put a new engine into our car or tinker |
| with the structural soundness of the car by cutting off the |
| roof etc. In a software system we do it all the |
| time. We'll add a feature. We'll change one bit of the |
| user interface here. We'll port it to a new platform, some |
| kind of a, a mobile platform, for example. And pretty soon, |
| what you end up with is really a software system that, |
| that is maybe a distant relative of your original |
| system. It is a mutant in many ways, because often |
| times these little tinkerings happen on a one off |
| basis. There is no over-arching vision of how you should |
| do this. So, you are basically going through a |
| subsequent set of steps where you are making locally optimal |
| decisions for any one of these changes and what |
| you might end up finding is that the globally optimal |
| behavior of the system is badly compromised. The structural |
| soundness in a sense of the system badly compromised. |
| The non-functional properties of the system could be seriously |
| affected. This is how security flaws creep into systems. This |
| is how reliability flaws. This is how we use |
| the usability of a system often times suffers. And most |
| importantly for software engineers, the people who actually build the |
| software, the maintainability of the system becomes a huge problem. |
| Because now you're looking at this thing, it's got all these various appendages, |
| its original design has pretty badly eroded and yet somehow you have to |
| figure out how to keep fixing it. Making sure that it operates in |
| a continuous fashion because many of these systems live for 20, 30, 40 years. |
| >> Thank you so much for your insight; it is a perfect |
| introduction for our lesson. So we'll get to the lesson now. And. |
| >> Thank you very much. |
| >> Thank you. |

## 166 - What is Software Architecture

| After this interesting conversation with Neno, let me start |
| the lesson by defining what a software architecture is. |
| And to do that, I'm going to use two |
| seminal definitions. The first one is from Dewayne Perry |
| and Alex Wolf. And they define a software architecture |
| as elements, form and rationale. In this definition, the |
| elements are the what, which means the processes, data, |
| and connectors that compose a software architecture. The form |
| is the how, the set of properties of |
| in relationships among these elements. And, finally, the rationale |
| is the why, the justification for the elements and |
| their relationships. The second definition I want to use |
| is from Mary Shaw and David Garland. And |
| they defined a software architecture as a level of |
| design that involves four main things, a description of |
| elements from which these systems are built, the interactions |
| among those elements, the patterns that guide their composition, and |
| finally, the constraints on these patterns. As you can see, these |
| definitions are fairly similar and there are many more alternative |
| definitions of software architecture. In fact, if we try to search |
| the term software architecture, we get over two million entries. |
| And if we look at the images in the results of |
| the search this is what we get. And I like this |
| sort of graphical depiction because it gives you a clear idea |
| the software architecture are prevalent concept, given the number of |
| results. But they also show you clearly, that software architecture are |
| complex entities, if you look at some of these pictures. |
| And ultimately, they show that software architecture are presented in all |
| kinds of ways including in 3D, if you look at this |
| picture. We cannot clearly cover all of these definitions in one |
| lesson. So what I will do instead, is to introduce |
| a very general definition that encompasses most of the existing ones. |

## 167 - General Definition of SWA

| I'm going to define a software systems architecture as |
| the set of principal design decisions about the system. Where |
| principal here, implies a degree of importance, that grants |
| a design decision architectural status. And the point here, as |
| we discussed with Neno early on, is that when |
| building a system, we make tons of design decisions, and |
| most of them do not affect the architecture of |
| the system. For example, the effect of choosing a for |
| loop, instead of a while loop, in the code, or the |
| fact of deciding that we are going to use data structure A |
| instead of data structure B. Some decisions however, do affect the |
| architecture of the system. And in some cases the distinction between these |
| two kinds of design decisions is clear. In some other cases |
| it is much fuzzier and it depends on the context. The |
| bottom line here, is that if you believe that something is |
| an important design decision, that becomes an architectural decision. That is a |
| decision that impacts a system's architecture. In this spirit, |
| we can see a software architecture as the blueprint |
| for a software system, that we can use to |
| construct and evolve the system. And the key point |
| about software architecture is that this blueprint encompasses every |
| facet of the system under development. It encompasses its |
| structure, of course, but not only. It also involves |
| the behavior of the system, the interactions within the system, |
| and the non-functional properties of the system. And we will see |
| how this happens in the rest of the lesson. Another important |
| point about software architecture is that there is a temporal aspect |
| to it. And the point here is that you don't build the |
| software architecture in a single shot, but you do it iteratively, |
| over time. So, basically, you go from having no architecture to |
| your final architecture. So, at any point in time, there is |
| a software architecture, but it will change over time. And this happens |
| because design decisions are made, unmade and changed over a system's lifetime. |

## 168 - Prescriptive vs Descriptive Architecture

| We can look at the software architecture from two |
| main standpoints. There are prescriptive and descriptive software architectures. |
| So what does that mean? A prescriptive architecture captures |
| the design decisions that are made prior to the |
| system's construction. This is what we normally call the |
| as-conceived software architecture. Conversely, |
| a descriptive architecture describes how |
| the system has actually been built. So it's based |
| on observing the system as it is and extracting |
| the architecture from the observation. This is what we call |
| the as-implemented software architecture. And one key point here is |
| that often, these two architectures, the prescriptive and the descriptive |
| architectures end up being different. So let's see why that happens. |

## 169 - Architectural Evolution

| To do that let's look at how architectural evolution |
| occurs in practice. Ideally when a system evolves, its prescriptive |
| architecture should be modified first. Just like when you |
| modify a building. You change the blueprint and then you |
| change the actual building. You don't go the other |
| way around. In software, unfortunately this rarely ever happens in |
| practice. In practice the system, and therefore it's descriptive |
| architecture are often directly modified. Like in this case that |
| I'm showing here. So what happens is that the architecture |
| as conceived does not change. Whereas the architecture as implemented, does |
| change. And therefore these two things start diverging. And this really |
| happens for a number of reasons. So I'm just going to list |
| a few of those reasons here. In some cases it |
| just happens for plain sloppiness. I need to make this modification |
| and I don't really want to go back and look at |
| the prescriptive architecture modified. I'm just going to make the change, and |
| maybe I'll fix the description later. And then you never really get |
| to it. In other cases you do this because of the perception |
| of short deadlines. If you have to do something by this afternoon, |
| you're not going through a four |
| month software architecture review, you normally just |
| get to it, and do it. In some cases a prescriptive architecture |
| is not even present, so there's a lack of documentation. So in these |
| cases, clearly, you cannot go and modify something that does not even |
| exist, and so you jump directly to the code and start modifying that. |
| And as I said there's many, many more |
| other reasons why that happen. But important point here is |
| that it does happen and it does happen often |
| and the result is that prescriptive and descriptive architectures diverge. |

## 170 - Architectural Degradation

| And there are two important and related concepts that |
| have to do with the way software architecture |
| evolves. The first one is Architectural Drift, which is |
| the introduction of architectural design decisions that are orthogonal to |
| a system's prescriptive architecture. That is, they're not included |
| in, encompassed by, or implied by the prescriptive architecture. |
| And the result of Architectural Drift is that you |
| start from a clean architecture, like the one that I'm |
| showing here, and then you start adding pieces without following a clear plan. |
| Like, for example, here, we add an additional room here, but we don't really |
| do it in the right way so we need to add something else |
| to keep it stable. And then maybe we want some more room so we |
| add a tent. And then another side of the house, it doesn't really |
| follow the same architecture but it doesn't matter, we just put it there because |
| we want to expand. And maybe then we want to put something classic |
| there, even though it doesn't really fit |
| the overall design and the overall architecture. |
| So I think you get my point, the fact |
| that the architecture then becomes unnecessarily complex, hard to understand |
| and ultimately awkward, just like the one that I'm |
| showing here, that goes from the original building into this |
| final monstrosity. The second concept is Architectural Erosion, which |
| is the introduction of architectural design decisions that violate a |
| system prescriptive architecture. So in this case, that we were |
| introducing decisions that were orthogonal, |
| here, were introducing this decisions |
| that don't comply with the prescriptive |
| architecture. And the result of Architectural Erosion |
| is typically a poor architecture an |
| architecture that is going to have problems in |
| the future. So both Architectural Drift |
| and Architectural Erosion take you away in |
| different ways from what you think your software architecture is or should be. |

## 171 - Architectural Recovery

| And sometimes, architectural drift and erosion gets you so |
| far away from the point where your software architecture should |
| be, that your architecture is completely degraded. And at this |
| point, you have two main options. The first option is |
| to keep frantically tweaking the code. And this normally leads |
| to disaster. Why? Because you only make things worse. You |
| don't know exactly what you are changing and therefore, you're |
| basically stabbing in the dark, trying to fix your system. |
| The other possiblity is that you can try to |
| determine the software system architecture |
| from its implementation level artifacts, |
| so you try to derive what the architecture is |
| and try to fix it, once you have derived the |
| architecture. And this is what is normally called, architectural |
| recovery, determining a software architecture from an implementation and fixing |
| it. And as you can imagine, this is normally |
| a more recommended way to go than the first solution. |

## 172 - Architectural Recovery Quiz Question

| Now that we discussed some important concepts about |
| software architectures, I would like for you to |
| tell me which of the following sentences is |
| true. Prescriptive architecture and descriptive architecture are typically the |
| same. Architectural drift results in unnecessarily complex architectures. |
| Architectural erosion is less problematic than architectural drift. And |
| the best way to improve a degraded architecture, |
| is to keep fixing the code until the system |
| starts looking and behaving as expected. Which of these sentences is true? |

## 173 - Architectural Recovery Quiz Solution

| The first sentence is definitely false. Prescriptive architecture |
| and descriptive architecture tend to diverge as systems evolve, |
| and sometimes, even when the system is first developed, |
| as we will see in some of the upcoming |
| examples. Conversely, the second sentence is true. By |
| adding unnecessary elements to the architecture, architectural drift can |
| transform an otherwise clean architecture into a complex sub-optimal, |
| and often ugly, architecture. The third sentence is false. |
| Architectural erosion and architectural drift are, indeed, different phenomena. |
| But they both result in a less than ideal, and |
| in some cases, highly degraded architecture. And the fourth |
| sentence is also false, as we discussed a minute ago. |
| Just tweaking at the code is very unlikely to |
| improve the code. Quite the opposite, actually. The best way |
| to repair a degraded architectural design is to first, understand |
| the current architecture, and then, try to fix it in |
| a more principled way. |

## 174 - Real World Example

| Now to drive home some of the points that I just |
| made, I would like to show you a few real world examples |
| of architectures that kind of went astray. The first example I |
| want to use is an example from the Linux kernel. Actually, from |
| an earlier version of the Linux kernel. A research group studied |
| the documentation of Linux, and also |
| interviewed several Linux developers. And by |
| doing that, they were able to come up with a software |
| architecture of Linux at different levels of obstruction. So the one that |
| I'm showing you here on the left, is the |
| software architecture at the level of Linux's main subsystems. So |
| this is the prescriptive architecture of Linux at the level |
| of Linux's main subsystems. So the researchers, after identifying this |
| architecture, they showed it to the developers, and the |
| developers agreed that, that was indeed the architecture of the |
| system. The researchers then studied the source code of Linux |
| and reverse engineered its actual architecture. So the architecture as |
| implemented, it's descriptive architecture. And this one here, on the |
| right, is the result. And as you can see, they found |
| a number of differences or violations between the prescriptive architecture and |
| the descriptive architecture. In particular, if we look at this architecture, |
| we can see that pretty much everything talks to everything else, |
| which is, in general, not a good thing. And in addition |
| to that, there are also several things that don't really make |
| much sense. For example the library calls the file system and |
| also the network interface which doesn't make much sense. Another thing |
| that is kind of weird is the fact that file system |
| calls the kernel initialization code. Which is also a little bit |
| weird. So basically, the bottom line here is that not even |
| the developers realized how the actual architecture of the system was, |
| and how it was different from the architecture they have conceived. |
| And in fact another interesting thing here is the reaction of |
| the developers when they were shown the actual architecture. So basically |
| they justified the differences by saying things such as, well you |
| know it had to be done fast, and therefore I changed it |
| and then I didn't have time to go back and update the documentation |
| and things of this sort. And by the way these are exactly some |
| of the reasons that we mentioned early on in the lesson for the |
| discrepancy between prescriptive and descriptive software |
| architecture. So one last thing that I |
| want to mention here as an aside and we can get back to |
| that later is the fact that you can probably clearly show how representing |
| software architectures graphically can be extremely useful, because it allows |
| for easily seeing the structure of the system. Look at different |
| views identify problematic points and so on. And we will see |
| how that can be useful in many cases also later on. |

## 175 - More Examples

| As another example, I want to show you the architecture of the |
| iRods system. This is a data grid system that was built by |
| a biologist. And it's a system for storing and accessing big |
| data. So what I'm going to do, I'm going to do the same thing |
| that I did for the Linux system. I'm going to show you |
| here, on the left hand side, this clean prescriptive architecture for the |
| iRODS system. And I'm going to show you here on the right the |
| actual architecture of the system. The |
| descriptive architecture of iRODS. So here, |
| even if we don't go in and look at the details, you |
| can see very easily that the system is badly drifted and eroded |
| with respect to the way it was supposed to be. Continuing |
| with the examples. What I want to show you now is the |
| view of the complete architecture of HADOOP. As many of you probably |
| already know, HADOOP is an open source software framework for storage and |
| large scale processing of data sets. It's very broadly used. And here |
| is a picture of the architecture, and I hope you can see it |
| because the architecture is so complex and so broad and so |
| intertwined, and in order to be able to represent it here |
| in one page, I had to zoom out quite a bit. |
| But also in this case, you don't really have to look |
| at details. The important point here is that in this software architecture |
| 61 out of the 67 components in the system have circular |
| dependencies. Which means that they depend on each other in a |
| circular way and this is normally not a good thing and also |
| in this case a few developers when shown the diagram had no |
| idea that the structure of the system was so complex and messy. |

## 176 - Final Example

| I'm going to conclude this set of examples with |
| a system that you might also know, Bash. And in |
| case you don't, Bash is a Unix shell written as |
| a free software replacement for the traditional Bourne shell, also |
| called sh. So what I'm showing here is the |
| descriptive architecture of the command component of Bash. So, is |
| the architecture, as implemented, of the command component of Bash. |
| And the component is the one here sort of highlighted |
| in gray. And what you can see here, these names are |
| the sub components of the command component. And if we look at |
| this architecture, two design problems of the component can kind of jump |
| at us. The first one is the lack of cohesion within the |
| component. So, if you look here, you can see that only |
| a few connections exist between the sub-components. And having a low cohesion |
| is normally not a good thing for a design. The second thing |
| that we can note is the high coupling. The component has tons |
| of connections with other components. They're, these edges that are |
| leaving the components and going towards other parts of the system. |
| So basically, this component has low cohesion and high coupling, which |
| is exactly the opposite of how a good design should be. |
| Given the structure, it is clear that anytime you change |
| this component you might need to change a bunch of other |
| components in the system. And of course, when changing other components |
| in the system, you might also need to chance the command |
| component as well. And along similar lines, to understand this |
| component you probably need to look at many other parts of |
| the system, which is also less than ideal. And one |
| important point here is that with all these examples, I'm not |
| really trying to criticize any specific system, what I'm trying |
| to show instead, is how complex software architectures can be, and |
| how much they can degrade over time. And this is true |
| for most systems, not just the ones that I showed you. |

## 177 - Architectural Design Quiz Question

| At this point, we have seen some examples of |
| things that might go wrong with the software architecture. So |
| I'd like to ask you also to recap some of |
| the concepts that we've touched upon. What are ideal characteristics |
| of an architectural design? And I'm showing you three possibilities |
| here: scalability, low cohesion, and low coupling. And some of |
| these concepts we did not explicitly define, but we talked |
| about it when discussing the examples that we just saw. |

## 178 - Architectural Design Quiz Solution

| So, let's look at these three characteristics one by |
| one. Scalability for software architecture is its ability to handle |
| the growth of the software system. For example, for a |
| web based system, scalability could be the ability to handle |
| a larger workload by adding new servers to the system. |
| Scalability is therefore an important characteristic of a software architecture, |
| especially for the kinds of systems that can grow over |
| time. So, we're going to mark it as an ideal characteristic. |
| Cohesion is a measure of how strongly related are |
| the elements of a module. Clearly, we should shoot |
| for high and not low cohesion when developing a |
| system. We want to develop modules whose elements cooperate to |
| provide the specific piece of functionality rather than modules |
| consisting of a bunch of elements that provide different |
| unrelated pieces of functionality. Therefor, low cohesion is definitely |
| not something that we want. We want high cohesion instead. |
| As for coupling, coupling is a concept related to cohesion |
| and is also a measure. In this case though, it |
| is a measure of how strongly related are the different |
| modules in a system. Low coupling, which is often correlated with |
| high cohesion, is an important and ideal characteristic of a |
| software architecture as it indicates that the different modules in |
| the system are independent from one another. Each module provides |
| a specific piece of functionality and it can provide it without |
| relying too much on other modules. |
| Basically, systems characterized by low coupling |
| and high cohesion, are systems that are easier to understand, and to maintain. |

## 179 - Architectural Elements

| Now that we have discussed a few foundational aspects |
| of software architectures, and we have looked at some real |
| world examples that help us to illustrate some of these |
| points, to discuss some of these aspects. I want to |
| introduce and define the different elements that compose a software |
| architecture and also talk about architectural styles. So let's start |
| by discussing a software architecture's |
| elements. A software system's architecture |
| typically is not, and should not be, a uniform monolith. |
| On the contrary, an architecture should be a |
| composition and interplay of different elements. In particular, |
| as we quickly mentioned at the beginning of |
| the lesson, there are three main types of elements |
| in an architecture. Processing elements, data elements, and |
| interaction elements. Processing elements are those elements that implement |
| the business logic and perform transformations on data. |
| Data elements, also called information or state, are those |
| elements that contain the information that is used |
| and transformed by the processing elements. And finally, |
| the interaction elements are the glue that holds |
| the different pieces of the architecture together. Now, |
| the processing elements and the data are contained |
| into the system components, whereas the interaction elements |
| are maintained and controlled by the system connectors. |
| And components and connectors get all cooked together |
| into a systems configuration, which models |
| components, connectors and their relationships. So |
| now, let's look at components, connectors |
| and configurations in a little more detail. |

## 180 - Components -  Connectors -  and Configurations

| And let's start with software components. A |
| software component is an architectural entity that encapsulates |
| a subset of the system's functionality and or |
| the system's data. So basically components typically provide |
| application specific services. In addition to that, a |
| software component also restricts access to that subset |
| via an explicitly defined interface. And, in addition, |
| which I'm not showing here, a component |
| can also have explicitly defined dependencies |
| on its required execution environment. In complex |
| systems, interactions might become more important and |
| challenging than functionality. And this is why |
| connectors are very important architectural elements. A |
| software connector is an architectural building block |
| tasked with effecting and regulating interactions among |
| components. So basically, connectors typically provide application |
| independent interaction facilities. And it's worth noting here |
| that in many software systems, connectors might simply be |
| procedure calls or shared data accesses. So all constants |
| that we're familiar with. But consider that much more |
| sophisticated and complex connectors are also possible. And |
| components and connectors are composed in a specific way |
| in a given system architecture to accomplish that system's |
| objective And this is expressed through an architectural configuration. |
| More precisely, an architectural configuration, or topology, is a |
| set of specific associations between the components and connectors |
| of a software system's architecture. So now, let's look |
| at an example that brings all of this together. |

## 181 - Configuration Example

| What I'm showing here is what an architectural configuration of |
| a system might look like in practice. And as you |
| can see, the configuration includes a set of components, which |
| are these rectangles over here. The components have various kinds of |
| ports, which are the ones marked here on the components |
| with different graphical representations. And |
| the components communicate through various |
| types of connectors, which are the grey elements here which |
| as you can see are used to connect the different components. |
| And something else that you can notice by looking at |
| this configuration is the fact that you can also have |
| hierarchically decomposable components. For example, if you look at the strategy |
| analyzer component, you can see that it has three subcomponents: one, |
| two, and three and two internal connectors as part of |
| it. And it is worth recalling here that a component |
| diagram as we said when first discussed in UML in |
| the course, can also be used to represent an architectural configuration. |
| So sometimes you will see architectural |
| configurations represented as UML component diagrams. |

## 182 - Deployment Architectural Perspective

| A system cannot fulfill its purpose until it is |
| deployed. And deploying a system involves physically placing the |
| system's executable modules on the hardware devices on which |
| they are supposed to run. So when you do that, |
| you're basically mapping your components and connectors to specific |
| hardware elements. Here in this diagram, for instance, I'm |
| showing the same components that we saw in the |
| previous diagram, but we see them deployed on a laptop, |
| which is depicted here in this way, and on two |
| smartphones that are represented here, or PDAs, if you wish. |
| So why do we this, why do we create |
| a deployment perspective for our architecture? Well, because the deployment |
| view of an architecture can be critical in assessing whether |
| the system will be able to satisfy its requirement. Because |
| doing this mapping allows you to discover and assess other |
| characteristics of your system that you might not have considered |
| up to now. For instance, using a deployment view like this |
| one and knowing the characteristics of the hardware devices, one might |
| be able to assess the system in terms of available memory. |
| Is there going to be enough memory available to run the system, |
| for example, on this device? Power consumption. Is the power consumption |
| profile going to be larger than what the device can handle? |
| Or again the required network bandwidth. Does the system have enough |
| network bandwidth to enable the required interactions? And so on. So all |
| of these characteristics, all of these qualities, you can assess when |
| you do this final mapping of the components to the hardware elements. |

## 183 - Architectural Styles

| The last topic I want to cover in |
| this lesson is architectural styles. So, let's see |
| what those architectural styles are. There are certain |
| design choices that when applied in a given context |
| regularly result in solutions with superior properties. What |
| this means is that, compared to other possible alternatives, |
| these solutions are more elegant, effective, efficient, dependable, |
| evolve-able, scale-able, and so on. Architectural styles capture exactly |
| these solutions. They capture idioms that we can |
| use when designing a system. For a more formal |
| definition, let's look how Mary Shaw and David Garlan |
| define a architectural style. They say that an architectural |
| style defines a family of systems in terms |
| of a pattern of structural organization; a vocabulary of |
| components and connectors and constraints on how these components |
| and connectors can be combined. So in summary we |
| can say that an architectural style is a named collection |
| of architectural design decisions applicable in a given context. And I |
| want to stress that it is important to study and |
| know these architectural styles for several reasons. Because knowing them allows |
| us to avoid reinventing the wheel. It also allows us |
| to choose the right solution to a known problem and in |
| some cases it even allows us to move on and |
| discover even more advanced styles if we know the basic ones. |
| So we should be familiar with architectural styles, what |
| they are, and in which context they work, and |
| in which context they do not work. So as |
| to be able to apply them in the right situations. |

## 184 - Types of Architectural Styles

| So what does it mean to know architectural styles? There |
| are many many, many architectural styles. So we cannot cover them |
| all here. What I want to do instead is, I want to |
| mention a few of those. And then I want to go in |
| more depth, on one of them. So the first item I |
| want to mention is pipes and filters. And pipes and filters indicate |
| an architectural style in which a chain of processing elements, which |
| can be processes, threads, co-routines, is arranged so that the output |
| of each element is the input of the next one |
| and usually with some buffering in between consecutive elements. A |
| typical example of this, if you're familiar with Unix are |
| Unix pipes, that you can use to concatenate Unix commands. |
| Another style I want to mention is the event driven |
| one. An event driven system typically consists of event |
| emittors, like the alarm over here, and event consumers, like |
| the fire truck, down here, and consumers are notified when events |
| of interest occurr and have the responsibility of reacting |
| to those events. A typical example will be a GUI, |
| in which widgets generate events and listeners listen to those |
| events and react to them. For example, they react to |
| the push of a button. A very commonly used |
| architectural style is Publish-subscribe, represented by the paper boy. Over |
| here. And this is an architectural style in which senders |
| of messages, they're called publishers, do not send messages directly |
| to specific recievers. Instead, they publish messages with one |
| or more associated texts without knowledge of who will |
| receive such messages. Similarly subscribers will express interest in |
| one or more tags. And will only receive messages of |
| interest according to such tags. A typical example of |
| a publish-subscribe system, will be Twitter. And I'm pretty |
| sure that most of you are familiar with the |
| client-server architecture. In which computers in a network, assume one |
| of two roles. The server provides the resources and |
| functionality. And the client initiates contact with the server, |
| and requests the use of those resources and functionality. |
| Also in this case, a typical example would be |
| email, in which an email server provides email storage |
| and management capabilities, and an email client will use |
| those capabilities. You may also be familiar with peer-to-peer, |
| or P2P, systems. A P2P system is a type |
| of decentralized and distributed network system in which individual nodes |
| in the network, that are called peers, act as independent |
| agents that are both suppliers and consumers of resources. This |
| is in contrast to the centralized client-server model, where client |
| nodes interact with the central authority. And I'm not going to |
| say anything more about peer-to-peer, because I'm going to show you |
| two examples, of peer-to-peer systems in the rest of the |
| lesson. And you probably have at least heard of rest. |
| Which in this case is not an invitation to |
| relax as the graphic might indicate. But rather stands for |
| Representational State Transfer. REST is a hybrid architectural style |
| for distributed hypermedia systems, that is derived from several other |
| network based architectural styles. And that is characterized by |
| uniform connector interface, and even if I'm not going to say |
| anything else about the rest, I wanted to mention |
| it, because it is an extremely well known architectural style. |
| And the reason for this is that REST is |
| very widely used, because it is basically the architectural style |
| that governs the world wide web. So we use it |
| all the time when we browse the internet, for instance. |

## 185 - Architectural Styles Quiz Question

| Consider now the following architectural styles |
| that we just saw: pipes and filters, |
| event-driven, publish-subscribe, client-server, peer-to-peer, and rest. |
| I'm showing you here, a list of |
| four different systems, and I would like for you to mark here which |
| architectural style, or styles, characterize Each of |
| these systems. Again, mark all that apply. |

## 186 - Architectural Styles Quiz Solution

| Okay, let's start with the Android Operating System. The Android |
| system, heavily based on the generation and handling of events, |
| so it is mostly an event driven system. However, it |
| also has some elements of publish, subscribe, in the way |
| elements in the system can register for elements of interest. |
| So we can mark both styles here. So what about |
| Skype? We haven't discussed Skype yet. So here we probably |
| had to take a little bit of a wild guess. |
| But as we will see in more detail in the |
| rest of the lesson. Skype is mainly a peer to |
| peer architecture, with some minimal elements of a client server |
| architecture. For example, when you start Skype and sign in |
| to a conceptually centralized server. So let's move to the |
| World Wide Web. As we just discussed, the Word Wide |
| Web is based on a rest architecture. And because rest |
| style, is a hybrid derived from other architectural styles, including the |
| client server architectural styles. Both of those styles apply here. |
| And finally Dropbox is by and large, a client server |
| architecture. As conceptually, we upload our documents to a Dropbox |
| central server, and get the files from the same server. |

## 187 - P2P Architectures

| We're not going to be able to study indepth |
| any of the architectural styles that we just discussed. However, I |
| want to at least discuss two representative examples of P2P |
| architectures. Because, these are systems that you probably used, or at |
| least, you used one of them. And, they will allow |
| me to highlight some interesting points. So, as we just mentioned, |
| P2P systems are decentralized resource sharing and discovery systems. And the |
| two systems that I want to discuss, and that are representative |
| of this kind of architectures, are Napster and Skype. And you may or |
| may not be familiar with Napster, but I'm pretty sure that you know Skype. |

## 188 - Napster Example

| So let's start by considering Napster. In it's first |
| incarnation, Napster was a peer-to-peer file sharing system. And |
| it was mostly used, actually, to illegally share mp3s. |
| Which is also why it got sued and later |
| on, it basically ceased operations. But nevertheless, I think |
| Napster is an interesting example of mixed architecture. And |
| I'm going to illustrate the way Napster works by showing |
| you, here, the basic configuration of Napster and the interactions |
| between its elements. So let's look at how such interaction |
| can take place for the three peers shown here. And |
| in this case Peer A and B are the only |
| ones really involved in the action. So let's look at |
| a typical sequence of events for the Napster system. We |
| have Peer A that will start by registering, here, with |
| the content directory. Peer B will also register with the |
| content directory. And when these two peers register, the content directory |
| will know what kind of content they can provide. Later on, |
| Peer A will request a song. And one first observation that |
| we can make, based on this interaction, is the fact that, |
| up to now, this is a purely client-server system. This is |
| the client. This is the client. And this is the server. |
| And the interaction is a typical client-server interaction. But now we're |
| at the point in which things start to change a little |
| bit. At this point, after Peer A has requested the song, |
| the peer and content directory will look up its |
| gigantic index and will see that Peer B actually has |
| the song that Peer A requested. So it will |
| send to Peer A a handle that Peer A can |
| use to connect directly to Peer B. So this |
| is where the system is no longer a client-server system. |
| Because at this point, the two peers are connected directly. |
| So at this point, we have a peer-to-peer interaction. And, |
| after getting the request from Peer A, then Peer B |
| will start sending the content to Peer A. And I said |
| earlier that one of the useful things about representing an |
| architecture and interaction within an |
| architecture graphically, is the fact that |
| it allows you to spot possible problems. And in this |
| case, by representing the Napster architecture in this way, and by |
| studying how things work, we can see that there's an |
| issue with the architecture of Napster that will not make this |
| architecture scale. As some of you might have already noticed, this peer |
| and content directory is a single point of failure, and is very |
| likely to cause problems when the number of peers grows too large. |
| Because at that point, there are going to be too many requests to |
| the peer and content directory, and the peer and content directory is |
| unlikely to be able to keep up with all the requests. So |
| some changes in the architecture will have to be made. In the |
| case of Napster, we didn't see this problem occurring because, as I said |
| earlier, Napster got sued and ceased operation before the problem |
| actually manifested. Now looking at the system for an architecture-style |
| perspective, we can see that Napster was a hybrid architecture |
| with both client-server and peer-to-peer elements. And something I would |
| like to stress here, is that this is not at |
| all uncommon. So in real world nontrivial architectures, it is |
| very common to see multiple styles used in the same |
| system. The next system that we will consider, Skype, is instead, |
| an example of a well-designed, almost purely peer-to-peer system. |

## 189 - Skype Example

| So even if you're too young to have used Napster, |
| I'm pretty sure that most of you know and use Skype, |
| a Voice Over IP and instant messaging service. Many of |
| you, however, probably don't know how Skype works. To understand that, |
| let's have a look at Skype's architecture, which I'm sketching |
| here, and which is a peer-to-peer architecture with a small twist. |
| So first of all, by looking at the architecture we can |
| see that whereas Napster was a client-server system with an element |
| of peer-to-peer, Skype is a much more decentralized system. Why |
| is that? Well, if we look here, we can see |
| that there is a login server -- this node over |
| here -- and that means that every Skype user has to register |
| with this centralized service. But that's the only interaction of |
| this kind within Skype. After you log in, all you |
| get is a connection through a super node like this |
| one. So, what are super nodes? Super nodes are highly reliable |
| nodes with high bandwidth that are not behind a firewall |
| and that runs Skype regularly, which means that nodes that shut |
| down Skype occasionally will not qualify as super nodes. And one |
| interesting thing about super nodes is that they're not owned by |
| Skype. They're just regular nodes that get promoted by Skype to |
| super nodes, and that know about each other. So basically Skype |
| has an algorithm that looks at the nodes in the system |
| and decides whether a node can be a super node or |
| not based on its characteristics. So now that we've discussed |
| super nodes, let's see what will happen if peer two wanted |
| to communicate with peer three. So let's represent this by |
| creating a dashed line between peer two and peer three. In |
| this case, peer two will contact this super node, which |
| is super node A. And super node A, based on its |
| knowledge of the Skype network and the position of the super |
| nodes, will contact and route the communication through super node C, |
| which will in turn route the communication to peer three. |
| And in that way peer two and peer three will be |
| able to communicate with each other. And this will happen just |
| as if peer two and peer three were connected directly, as |
| peers, even though the communication goes through two super nodes. Another |
| thing that is important to know about the behavior of Skype |
| is that, if the link between super nodes A and C |
| were to go down. So let's assume that there is a |
| problem with this link, then Skype will automatically, or automagically |
| reroute the communication through super node B, which will in |
| turn reroute it super node C, which will again reroute |
| to peer three. So peer two and three will still |
| be connected, but this time they will be going through |
| three super nodes. And just in case you wondered, this |
| is exactly what happens when you are talking over Skype. |
| The quality of the communication degrades, and you are reconnected. |
| So there is this rerouting going on through different nodes. So |
| although this architecture is more effective than the Napster's one, it |
| is not without problems. For example, you might remember that a |
| few years ago, Skype went down for about 36 hours. And |
| later on it was discovered that the cause was the algorithm |
| used by Skype to determine which nodes could be super nodes. |
| And remember, as I said, that one requirement for these nodes |
| is that have to up all the time. So what happened |
| is most of the super nodes were running on Windows machines, |
| and Microsoft pushed a critical patch that required a reboot to |
| be installed. So a large number of machines, and therefore a |
| large number of super nodes were down roughly at the same |
| time throughout the globe. And Skype's algorithm for determining super nodes |
| didn't have enough nodes to work with. So the whole system |
| crashed and burned. So the message I want to give here, |
| is that when you have a large peer to peer distributed |
| system, such as this one, such as Skype, |
| these kind of perfect storms can happen. Because you |
| are not really in control. Because the control |
| is distributed. So the algorithms become more complex. So |
| to wrap up our Skype example, in case |
| you are interested, Skype then fixed the issue by |
| changing the algorithm for identifying super nodes. And |
| more recently actually, Skype ditched peer-to-peer super nodes altogether. |

## 190 - Takeaway Message

| And I want to conclude this lesson with three takeaway |
| messages. The first one is that having an effective architecture is |
| fundamental in a software project. Or as I say here, |
| a great architecture is a ticket to a successful project. To |
| put it in a different way, although a great architecture |
| does not guarantee that your project will be successful, having a |
| poor architecture will make it much more difficult for your project |
| to be successful. The second message is that an architecture cannot |
| come about in a vacuum. You need to understand |
| the domain of the problem that you're trying to solve |
| in order to define an architectural solution that fits the |
| characteristics of the problem. So a great architecture reflects a |
| deep understanding of the problem domain. And finally, a great |
| architecture is likely to combine aspects of several simpler architectures. |
| It is typical for engineers to see problems that are |
| new, but such that parts of the problems have already |
| been solved by someone else. An effective engineer should |
| therefore, first of all, know what is out there, |
| know the solution space. Second, an engineer should understand |
| what has worked well and what has failed miserably in |
| similar occasions in the past. And finally, an effective |
| engineer should be able to suitably combine existing solutions appropriately |
| to come up with an effective overall solution for |
| the specific problem at hand. And this is just as |
| true in the context of software architectures. When defining a software |
| architecture, you should innovate only as much as you need to and |
| reuse as much as you can. As we said early in the |
| lesson, by doing so, that is, by innovating only as much as |
| you need to and reusing as much as you can, you will |
| be able to avoid reinventing the wheel. You will be able to |
| choose the right solution to known problems. And identify suitable solutions for |
| new problems. So ultimately, you will be able to realize an effective |
| software architecture that will help the success of your project. |

## 191 - Introduction

| Hello and welcome to a tale of analysis and design, featuring |
| Spencer Rugaber, as the librarian, and Alex Orso, |
| as the software engineer. [SOUND] |
| >> Hi! I'm here waiting for Spencer, my librarian friend. He needs some |
| help developing an information system for a library. So I asked him to write |
| down the requirements for the libra... Oh, [SOUND] that must be him. |
| >> Hello Alex. |
| >> Hey Spencer. How's it going? |
| >> Good. Did you get those requirements I emailed you? |
| >> Oh, you emailed them. Now let me check. |
| And, by the way, get some coffee for you here. |
| >> Thank you very much. |
| >> Oh yeah. They're right here. Let me see. Oh, good. Oh, yeah, |
| good. We have, what we need. So the, the way I like to do |
| this is. I like to start by |
| looking at the requirements and identifying the nouns |
| in the requirements, because those tell us |
| the kind of the relevant elements in the, |
| in the requirements. So if you don't mind we can start looking at those and |
| you can tell me you know, whether the ones that I am identifying make sense or not. |
| >> Sounds good. |
| >> All right. |

## 192 - Analyzing Requirements

| Okay so let me start underlining these nouns, and I'll start |
| identifying the ones that are relevant, and I'll ask you some |
| questions or you can ask me questions if |
| you see something that doesn't make sense to you. Good enough. |
| >> okay, let's see, patron. It seems to |
| me that patron is definitely an important entity. |
| >> That's, that's what its all about. |
| >> Okay, all right, so actually, the way |
| I'm going to do this, I'm going to take all these relevant |
| entities and I'm going to start putting them into what I call a class |
| diagram. So you don't really need to know what that is exactly, but imagine |
| this being a, a diagram in which I'm drawing, I represent in all development |
| items as rectangles with a given name and, and then later on some attributes. |
| >> Okay. |
| >> Okay, and I'm, I'm just going to put |
| them there. So I'm going to start with patron. |
| I'm going to create one class for the |
| patron. I'm going to give it the name patron. |
| And by the way, assuming that you'd probably figure out, it's important that we |
| represent, we use the right names so that it's clear when we're looking at |
| the class diagram what we're referring to, so I'll just use the, the nouns |
| themselves as names. Okay, library card seems to be also a relevant element. |
| >> Every patron has a library card. |
| >> All right, perfect, so we'll just |
| create a library card here. And let's see. |
| As, as long as they're in the system. And I saw that there's a system |
| here, this concept of system, this concept |
| of library. And based on my experience, normally, |
| those are kind of in an overarching themes. So this is really what we are |
| modeling. So the only |
| thing that will make a difference is |
| if there were more than one library or more than one system. Is that the case? |
| >> We just want one system for our one library |
| >> Okay so, in this case I won't even represent |
| those because basically what I'm representing is the system and |
| the library. |
| >> I understand, I understand. |
| Okay and then, oh name, address and phone |
| number are interesting because these are important entities, |
| but this seems like, you know, they're not |
| entities in themselves, so they're more attributes |
| of something else. I would imagine that |
| this is the way you identify, or these |
| are elements that are important for the patron? |
| >> That's what we take down when we issue the cards. |
| >> Okay. Perfect. So, I'm going to |
| take those and make those attributes of the patron, which means |
| that I'm going to take the class that I created before, and I'm |
| just going to write them down here so that they're represented and, |
| and we know that these are kind of what characterizes the patron. |
| >> Gotcha. |
| >> Okay? And then, I guess similar consideration for the library |
| card number. So this is to be associated with the library card? |
| >> It's printed right on it. |
| >> All right, so we'll put this as |
| an attribute of the library card, then. And then, in addition, at any particular point |
| in time. Okay, so time seems to be a relevant entity right, |
| because time seems to occur several times in this description. For example, I |
| think you guys keep track of how long a book has been loaned, right? |
| >> Right. |
| >> And there's some time associated also here. |
| >> And a children's age. |
| >> Oh yeah. The children's age here that |
| I didn't see before. Yeah. So, what |
| I'm going to do, I'm going to represent this in |
| a sort of generic way, as a date. |
| >> Okay. |
| >> These are kind of, kind of classes, utility |
| classes we call them, that are normally in every system. |
| >> Okay. |
| >> So I'm just going to put it down here |
| as a utility class that will be used |
| by different elements in the diagram. Okay, so |
| I want to calculate the items. So the items also |
| I mean I for what I know about libraries they |
| seem to be pretty relevant elements, right? So these are all |
| >> This is what we check out, this is what we're for. |
| >> Okay, so then items definitely will become a |
| class, and then we have a due. Oh there's also |
| this concept of fines. I guess that seems to be |
| important. Right? You guys give fines to people who are late. |
| >> Right, right. |
| >> Right, collect fines and so on. So we create a fine class down here and |
| the children. So children are special customers, right? It's |
| their age makes a difference? Is that the way it works? |
| >> Right. They, they can only check out a few books. |
| >> Okay. So I'll create them a special |
| kind of case, a special kind of customer so |
| I just create here a class for children. And |
| I can see that they're categorized by their age. |
| >> Right. |
| >> So I'll just put the age here as an attribute of the child. |
| And, okay, so the next one is |
| restriction. And restriction is kind of tricky because just |
| to be sort of a general concept. I mean, |
| in a sense, all of those are restrictions, right? |
| >> Right, this is just another one of these requirements. |
| >> Oh, okay, so, so we don't need to represent it explicitly, right? |
| >> Right, right. |
| >> It's just telling us how the children, yeah, okay, right; this is |
| just another requirement, so I just won't consider that for now. And oh, |
| I see that these books and audio video materials, I guess these |
| are things that the patrons can check out, right? |
| >> Those are some of the items, right. |
| >> There are two |
| more down here, right? Reference books and magazines? |
| >> But, they can't be checked |
| out, but they're definitely in the library. |
| >> Okay, so then I'm going to represent all of those |
| actually, now. So, I'm going to have books, I'm going to have audio |
| video materials, reference books, and magazines. And |
| I'm just going to have those as classes. Then, |
| okay here we have week, and we |
| already represented this general concept of time, so |
| week will be represented by the date class as well. And oh, I see best sellers. |
| So best sellers are also, I guess, items that can be checked out, right? |
| >> Right. |
| >> Okay, so I'll |
| just represent those as a class as well and an additional item that |
| is relevant for the library. And the limit, this is also a time limit, right? |
| >> Right. |
| >> So it can also be represented with a, with a class. |
| Oh, here we have cents, and for cents, same consideration that made |
| for time. This is kind of the money, is a general concept |
| that in all currency, many, in many IT systems. So, I'm, I'm |
| going to just have a money class here, which is another utility class. |
| >> Okay |
| >> Okay, and, oh, here I have value, so value is a property. |
| Let me look again at the requirement. Oh, it's the value of the item. So value |
| I'm going to put in the item as an attribute. Okay? |
| >> Okay. That's how much it cost us. |
| >> Okay. Perfect. |
| >> Seems like we got them all. Right? Anything I forgot? |
| >> That looks like it. |
| >> Okay, so this one, what I'd like to do. We have a kind of |
| a first take, first cut at the class diagram. I'd like to kind of |
| move to that and go through the different classes with you. And I'll ask |
| you some questions again. And you can |
| tell me whether there is something that |
| jumps at you that's not right. And |
| then we're going to try to refine that. |
| >> Okay |
| >> Okay. |
| >> Sounds good. |

## 193 - Refining Classes and Attributes

| Okay, so this is our first, class diagram. |
| >> So, let me ask you something about. |
| >> Okay. |
| >> What we've done so far. I also sent, in what |
| I sent you, I also had some stories about how the actual |
| >> Library is used. You asked me to do |
| that and are we going to take, use that here? |
| >> Glad you asked actually. yeah. Those are, you know, what we call use |
| cases, or what we will use as scenarios kind of things that we will |
| use to derive use cases. And they're also a very good |
| way of extracting requirements. We're not going to look at them right |
| now because now, because we're more working on kind of the static |
| structure of the system. But after we're done with the class diagram, |
| you know, we will do it at a different time. But |
| we're going to use those to see how the |
| libraries actually use them, and see whether we can get more |
| information that we can use to refine our requirements based on that. |
| >> Okay. |
| >> Okay, |
| So, for now, we'll just focus in on the, |
| structure, but, just so you know, I'm, |
| I'm glad you sent them, because they were going |
| very useful as well. |
| Okay. So let's see. Well, first of all, let |
| me, seems like that this is already pretty crowded, |
| right? We have a number of, classes. So let's |
| see if there's, some class that may be superfluous and |
| we can model in a different way. So, for |
| example, you, while, while thinking of this I was thinking, |
| the library card, it doesn't really contain much |
| information, right? So is it basically just the number? |
| The card has a number on it. We have a separate vendor that does that for us so. |
| >> Oh. |
| >> We don't need, it doesn't need to be part of this system, |
| we just have to make sure that every patron has a library card. |
| >> Okay, so basically for you, in a sense, the library |
| card is just an ID that gets associated with a patron. |
| >> That's right. |
| >> So I think that the best way to represent this, I mean, unless you |
| need an entity because you are creating it |
| yourself, but it seems like you are not. |
| I would just remove this one and I would like to put this, |
| basically to take the library card number and add it to the pattern. |
| >> Okay, makes sense. |
| >> Okay, so I'll add it here. And as |
| an additional attribute. Okay, and it will eliminate this class. |
| >> Okay. |
| >> Okay. |
| Oh, and, wait a second, so I guess |
| also the child needs a library card number, right? |
| >> Child needs a library card number, but let me ask you about that. Is, |
| is child a separate class, or is it just another kind of patron? |
| >> Oh, I see, I see. Because, yeah, it |
| is sort of a special patron, right? And, so |
| maybe we should, maybe we should represent it as |
| a kind of a refinement of the patron. |
| Hm, but then that made me think. So what is |
| the only thing that characterizes children? Is it just the age? |
| >> Well, if they're, that they can't check out more than five books. |
| >> Okay. And the, and the only difference is the |
| fact that they are less than, you know, twelve years old. |
| >> Twelve or less, right. |
| >> Twelve or less. So, I guess, you know, I would probably |
| like to represent this by making the age explicit in the patron rather |
| than to represent it as a class. And I'll tell you why, |
| because one, one of the issues, and you know, that might happen |
| again, is that, basically, there are patrons that are children. And they're |
| no longer children, when they come you know 13 or older right. |
| >> Right. |
| >> And if we represent them with a separate class in a sense, then we |
| cannot really change the type of an instance of these classes. |
| So we're left to kind of destroy the patron, create |
| a new one, so that means we also have to transfer |
| any history we want to keep history and so on. |
| So I, I think I kind of like better the idea |
| that I represent the age exclusively in |
| the patron, and then I'll behave differently, based on whether the |
| patron is 12 years old, or younger, or 13 or, |
| 13 or older. This, do you see any problem with that? |
| >> It makes things a little simpler. |
| >> Okay, |
| and we actually, it allows us also to eliminate |
| one class here. So I'm going to proceed this way. |
| I'm going to eliminate the children class, and I'm going to |
| put the age in the patron. Okay, and let me |
| see. But in this spirit, actually, something else that jumps |
| at me is this idea of the bestseller, because I |
| kind of feel like, we might have the same |
| problem. So, what is the story? What is a bestseller. |
| >> Well it's |
| an item that we want to restrict how |
| long people can keep, because there is such demand for it. |
| >> I see, and so basically a book that's a |
| bestseller, like the New York Times bestseller, is a bestseller forever? |
| >> No, no, no it's hot for |
| awhile, and then it becomes just a regular item. |
| >> I see. Hm. Then I guess it's a |
| similar situation to the one I was mentioning before, right? |
| >> Okay. |
| >> That if we have a book, |
| it will kind of have to change its type if it becomes a best seller. |
| Then we have to change its type again, if it's no longer a best seller. |
| >> Right. |
| >> So it seems to me that a better |
| way to represent this, is just to eliminate this BestSeller |
| class and instead, I'm going to put the best seller |
| attribute, which would just be a Boolean in the book. |
| >> Okay, what do you mean by Boolean? |
| >> Right. We don't know what Boolean is, right? The Boolean is |
| basically just a number. It can have two values, right? True or false. |
| >> Okay. |
| >> So we usually, normally use it |
| in this in this case. Imagine one, zero, |
| right? Then it's just kind of the basic. |
| >> Okay. |
| >> You know, the bits, right? |
| >> Okay. |
| >> So, this is just telling us, it's like a flag |
| that is telling this book is a best seller, or not. |
| >> Okay. |
| >> It's very easy to change this value and make a book a best |
| seller or not a best seller, than |
| just creating and destroying instances of these classes. |
| >> Okay, makes sense. |
| >> Okay, so at this point, this already looks better, right? Because we have, |
| less classes, and I think we did, yeah, we |
| did some serious cleanup. That's good. Okay, so now that |
| we eliminated some of this, what I would like to |
| do, as I said, we are going to both clean |
| up, but also refine. I would like to go |
| back to our, requirements and see whether we can identify |
| additional attributes for this, class that maybe are not as |
| obvious as the one that we saw so far, okay? |

## 194 - Adding Attributes

| Okay, so let me look at the requirements and |
| it's something that I can see here that we didn't point out before is that |
| there seems to be clearly some concept of a due date. And I'm telling you why |
| I'm saying that because here, for example, I notice that it says when items are |
| due. We mention overdue several times, so is |
| this something we need to keep track of? |
| >> Yeah remember when we used to stamp them on the books? In the stamp pad? |
| >> Oh yeah yeah yeah! Oh course! |
| >> Right? Yeah we definitely keep track of, |
| the system has to keep track of when books are due. |
| >> Okay. So it seems to me that one good way |
| of doing that is by basically adding an attribute to the, item. |
| >> Okay. |
| >> And I'll just call it due date. |
| >> Okay. |
| >> So basically for each item in case it's loaned |
| there will be this attribute that will contain the value of |
| >> Okay. |
| >> Of when, when the item is due. And then, something else that I noticed |
| here is that down here, it seems like |
| the requirements are saying that an item can |
| be renewed only once. So, I guess, that's |
| something we need to keep track of, right? |
| >> Yeah. |
| >> The system needs to know. |
| >> We have to know whether they've renewed it or not. |
| >> Okay so, I'll do a similar thing here. I think I want to go and add a an |
| attribute that we'd call number of times renewed, and add it to the item class. |
| >> Okay. |
| >> And this is kind of more generic |
| than what you need, because here it says only once, but |
| let's say that in the future you want to allow it to, |
| kind of renew twice, you'll be able to use these attributes again |
| because, we can just count how many times it was renewed. Okay? |
| >> Makes sense. |
| >> Alright. And one last thing I want to point out. |
| And this seems obvious but I'm going to check with |
| you anyways. And seems like there is a basically the |
| need to keep track of whether an item is checked |
| out or not. If you look at the text here, |
| the requirements here, I can see that check out and checked out are |
| mentioned five times. So, I'm assuming that that's something also |
| that we want to know about an item, whether it's checked out or not. |
| >> We have to keep track of whether they're checked out. |
| >> Okay, so I'll add an |
| additional attribute there. So I'm going to again go |
| back to the diagram and I'm |
| just going to write here also the checked out attribute. |
| And, I think that's it as far as I'm |
| concerned. Is there anything that you think is missing? |
| >> Well, I do have a question. Would checked out, |
| better not be the case that someone can check out a reference book. |
| >> Oh, I see, I see. |
| >> Okay. I mean, it's only the books and |
| the audio visual material that can be checked out. |
| >> Right, right, right. Okay, so I, I guess, well the way I will fix that is, |
| I'll probably put yet another attribute in the item class, and I'll |
| call it loanable. And basically, this attribute is just telling us whether |
| an item is loanable or not. So, when it's not true and |
| loanable is not on. Basically, that item can be checked out. |
| >> Okay. And, the system would know this. |
| >> The system will know that. |
| >> And prevent it from happening. |
| >> And prevent it from happening. Okay? |
| >> Alright. |
| >> Perfect. So, we're going to do that and, any other objections, |
| any other? |
| >> No, that was my question. |
| >> Okay, perfect, so what I'm going to do next, I |
| mean, I haven't mentioned that yet, but you know classes right |
| now we just looked at the attributes right that give |
| you sort of the state of the class. And there's something |
| else, there's a second part of the class that is kind of |
| an orthogonal aspect, which is what the class can do. And we |
| call those operations. So normally these kinds also have operations, I |
| guess you know it would make sense to you as well. |
| And one way, one very natural way to |
| identify operations is to look at the requirements and |
| look for verbs. Because verbs associated with an item |
| will tell you basically what the item can do. |
| >> Okay. |
| >> So I, I'd like to go back to the requirements and |
| start, the same way in which we underlined, nouns, we're going to underline |
| verbs and we're going to see which ones of those verbs actually represent |
| actions that we want to represent explicitly, we want to model explicitly in |
| our class diagram. |
| >> Okay. |
| >> Okay. |

## 195 - Identifying Operations

| >> And before we get started actually, I'd like to mention that there's |
| just, you know, FYI, there's different kinds |
| of verbs because what I'm looking for |
| is really action verbs. So verb, verbs that clearly express an action that |
| can tell me that, you know, what, for example, an item could do, 'kay? |
| >> Okay? |
| >> Not the verbs that represent, for example, relationships, 'kay? |
| >> Okay. |
| >> So, and the, there, and the ones |
| that I've identified und, underlined here actually, I, |
| I underlined complete sentences so that you kind of we can look at the verbs in |
| in context. And the first one is this |
| sentence that says that the library may need |
| to know or to calculate the items a |
| patron has checked out, when they are due, and |
| any outstanding overdue fines. So I, I will |
| imagine that this is representing a situation in |
| which you bring up a patron's record and |
| you start looking up this information. Is that [CROSSTALK] |
| >> The, the patron often wants to know what they have currently checked out. |
| >> Oh, |
| alright. |
| >> Or when are their due or how much they're owed or. |
| >> Oh, in fact, and then now that you mentioned it, |
| I think you sent me. One of the scenarios you sent |
| me had to do with that, right, with the patron coming |
| in and asking for this information. So yeah, and it makes |
| a lot of sense. So what I'm going to do, I'm going to |
| model this by adding this three operations to the patron method. |
| The first one, I'm going to call, itemsCheckedOut and, basically, it's an |
| operation, but you don't need to, you know, understand the implementation |
| details, but when you call this operation, it will |
| give you back exactly this information, so the items |
| that are checked out by that patron. The second |
| one, I'm going to call it whenDue. That will tell you |
| basically when a, when an item is due. And |
| the third one is going to be called the outstandingOverdueFines and, |
| you know, as the name says, it's going to tell |
| you what are the outstanding overdue fines for that patron. |
| >> Okay. |
| >> And as you might notice I mean, |
| I, I'm going to separate the, the, the attributes |
| from the operations by having a separate kind |
| of subrectangle so, in this way, it's clear |
| what is attribute and what is, what is |
| an attribute and what's an, what's an operation. |
| >> Gotcha. |
| >> And let me see then. Okay, for the |
| second one you can see that that patron can check |
| out books and audio visual materials. So I guess, |
| similarly you, you build kind of the record for a patron. |
| The patron will give you an item and you will record |
| the fact that the patron is kind of checking it out. |
| >> Right. And is that operation related to this, |
| the checked out attribute that we did a minute ago? |
| >> It is actually because what will happen then again, you know, if we jump |
| ahead a little bit would be that every time you invoke this operation. So I'm |
| going to represent this as a checkOut operation |
| for the patron. Every time you invoke this, |
| you will also have to say something about the item and so we will also |
| flip kind of that that, that build information in the, in the, in the item. |
| >> Okay. |
| >> Mm, 'kay? And, and finally, here, I can see that |
| a patron can request a book or an audio video item Is |
| not currently in. So I guess this is referring to items that |
| are already checked out but for which there is interest. Is that? |
| >> Right. So, particularly, the popular items the patrons want to get on |
| the list so that they get notified when it comes back in and. |
| >> Oh. |
| >> And check it out. |
| >> I see. I see. Okay. Then I'm going to do |
| the same thing here. I'm, I'm going to add this method, |
| which I'm going to call request and I'm going to put it |
| here in the list of the methods in the list. |
| >> Okay. |
| >> Of operations for the, for the patron, okay? |

## 196 - Adding Relationships

| OK I like the way this class diagram is |
| coming along. So at this point I think we |
| have all the classes that we need. For each |
| class we specified the attributes or the characteristics of the |
| class. And we also specified the operations so we |
| know what the class can do And, I like to |
| kind of move forward on this, but I first |
| want to see that you're fine with the class structure. |
| So that's the way the class structure is going |
| to be in terms of attributes and operations. So anything |
| that bothers you? Well, one thing I didn't understand |
| is how come you put check out over where |
| the patron when it's really the item being checked |
| out? Right. Okay. So that actually is you know, is a perfect |
| segway for the next thing that really wanted |
| to model. Because what you're talking about is basically a |
| relationship between two classes which is something we haven't touched on |
| yet. So we haven't, haven't looked at individual classes. But now, it |
| is typical, now we are looking more at requirements, we're starting to |
| find more things about our system, and what you're pointed out right |
| now is the fact that patron and item are somehow related. So |
| this checkout operation is not really something that belongs only on in |
| the patron, because it needs to know about the item. And it |
| doesn't belong only on the item because it needs to know about |
| the patron. So, it's something that associates the patron and |
| the item. Okay. And that's exactly the way we call |
| in the UML which is the notation that we're using |
| here this kind of relationship. So, we're going to represent that |
| by drawing a line between these two classes that tells |
| us there is an association. And we're also going to |
| give a name to this. Since this refers to the |
| fact of checking out items. We're just going to call |
| it, checkout. Gotcha. And notice that this basically you |
| know,eventually will end up kind of replacing this attribute. Because |
| the existence of this association will tell us that |
| this is checked out. We're, we're not going to, you know, |
| do it right now, but in the final cleanup |
| or the diagram, this name will disappear. Okay. Okay. |
| And so since we started talking about relationships and |
| associations, is there any other kind of relationship that you |
| see here? Well, what you just did with checked |
| out is, it seems similar to the whole issue |
| of requests. It is, it is. So a request |
| is something else that happens in both, you know, in |
| the patron and in the item, it involves both. |
| And in fact in a request, I would definitely |
| represent this as an additional association. So I will |
| just draw an another line between these two that represent |
| that specific kind of relationship and I will call it |
| request. So that indicates that this association refers to a |
| request that also connects the patron with an item. Okay. |
| And, let's see. Any, anything else that jumps at you? |
| Yeah, well, how about all these ones down at the |
| bottom? I mean book and item's got to be |
| related, right? A book is a kind of item, And |
| audiovisual... are there associations between them? Can you repeat |
| that, you said that the book, yeah? Is |
| a kind of item. Perfect, that's exactly what we're |
| modeling next, which is, this, what we call the |
| is-a relationship. So you said, a book is an item? |
| A book is an item. And, we can model that in the diagram. So, we do that |
| using another kind of relationship between the classes. So |
| we're going to represent that as a specialization we call it. |
| And, a specialization is indicated in this way. Okay? |
| With this arrow at the end, so a solid |
| with this kind of arrow at the end. And |
| we can do the same for book, magazine, reference book |
| and audiovisual material. So we're all going to connect, |
| we're going to connect all of them, to the |
| item, using the same kind of connection. And now |
| that we have connected all these four, with item |
| and indicated them in subclasses. That's something else that we can |
| do. So we can make this kind of cleaner. And I'll |
| tell you what I mean by that. So now we have |
| this loanable attribute that refers to item, but it seems to |
| me from what you were saying before, that loanable is not |
| really an attribute of an item. Right? It's more of a |
| characteristic of the type of item. Right. Is that right? Right. |
| Books, and audio/visual are loanable but the others aren't. |
| Okay, and so representing it here, it's okay to, |
| it will work. But it's not really right so from |
| the style standpoint it doesn't really you know, |
| it's not the best way of modeling this. What we're going to |
| do instead, we're going to use this specialization relationship to make |
| that more explicit. To make it cleaner. Okay, so what |
| I'm doing here is I'm going to take this hierarchy |
| of classes, this is just on two levels now, and I'm |
| going to kind of make it a little richer. |
| So I'm going to add an intermediate set of |
| classes. And in particular I'm going to have these two |
| classes that I'm going to call non loanable item and loanable |
| item. So, they're both items but they tell me |
| clearly that some items are loanable and some items |
| are not. Okay. Okay. And then I'm simply going to |
| put book and audio video material as subclasses of loanable |
| item and reference book and magazine as subclasses of non-loanable |
| item. So, if we look at this diagram now it's |
| pretty clear what is loanable and what is not. And |
| it's actually is a very clean, much cleaner |
| design. And, and I see you've, gotten rid of |
| the loanable attribute, too. I did. Because at |
| this point this is already represented by the fact of |
| having these two classes. And actually, something else that I did |
| is that I moved all these attributes, value, |
| due date, renewed and checked out, that makes |
| sense only for loanable item. From item to |
| loanable item. So at this point, this really |
| is telling me that, you know, these |
| characteristics are just meaningful for the loanable item, |
| and not for the other ones. Well, speaking of that, the way that you got the |
| lines going in the diagram here is you still have |
| request and checked out going to item, even though you |
| can't request non loanable Items. You can't check out non |
| loanable Items. Oh, you were right actually. You got me on |
| that one. You're exactly right. So this associations are between |
| the two wrong classes. So, I guess, at this point, |
| you can probably go and fix the diagram yourself. Well, |
| can we just make the lines go from patron to loanable |
| item instead of to item? That's exactly the way in which we |
| are going to fix it. So, we're going to move these two associations down |
| here. And at this point, this will represent the right relationships in |
| the, in the diagram, and in the system. Makes sense to me. |

## 197 - Refining Relationships

| Spencer, I gotta tell you, I'm impressed. |
| You're getting very good at this. So, why |
| don't you go wild and continue, there |
| anything else you think we can improve here? |
| >> Well something was bothering |
| me, that what happens if there's more |
| than one book with the same title and somebody puts in a request? |
| >> Oh, I see. That's a good point. So basically what you are telling me is |
| there's kind of a difference between an item and |
| the title, so the title is kind of a more |
| general concept, in a sense. So if you can |
| have multiple copies of a given title, is that right? |
| >> Yeah, we have five copies of Tom Sawyer, and the |
| persons, the patrons, really putting in a request for any Tom Sawyer. |
| >> They don't want like copy number three of Tom Sawyer, right? They want, |
| they want to read Tom Sawyer. Okay and I can represent that. So, in which |
| I suggest we do that, and you can tell me whether it makes sense to you is by |
| introducing an additional class, which I call Title. And |
| that represents exactly the concept that you're mentioning. So |
| this is a title which represents some |
| specific content. That is not related to a specific |
| physical element. Like it can be rated to multiple, |
| physical elements. So basically I'm going to create this title. |
| And then I'm going to create a relationship between |
| the title and the item. And what |
| the relationship is telling me, the the association |
| between these two in this case. Is an association, |
| that we call aggregation. So it's a special kind of association, that basically |
| indicates that an item of this type, so a title can |
| consist of a multiple elements of this type of multiple items. |
| So it's telling me that one title can |
| consist of multiple items, and I'm going to indicate |
| it with this annotation, which is a this |
| diamond at the top of the association. |
| >> And so we can move our request |
| line, up from loanable item to |
| title, because that's what they're really requesting. |
| >> Definitely, definitely, and in fact, |
| you know, that represents exactly the situation |
| that you are mentioning, at this point when the patron makes a request. |
| It makes a request to a title and not to a loanable item. And then, and |
| when the actual loan will take place, |
| then that will be connected to a specific item. |
| >> Right. Okay that makes sense. |
| >> Makes sense? |
| >> Yeah. |
| >> Okay, good. |

## 198 - Refining the Class Diagram

| Okay, so let me see if |
| anything changed after we did this last modification. |
| Acutally, there is someting that I would like |
| to do here. Because looking at this a little |
| bit more, I noticed that there are two |
| attributes, renewed and due date. That we have in |
| loanable Item, right? But they don't seem to |
| be really, attributes or characteristics of loanable Item. |
| They're more of the characteristics of the association between the |
| Loanable Item and the patron. Wouldn't you agree? |
| >> Well, yeah, it's not like you could |
| only renew a book once in it's entire history. |
| >> Right. Exactly, exactly. So, that's why what l like |
| to do is I would like to move those out of loanable |
| item. And actually there is a construct that we can use |
| to express this. It's called, we haven't seen it yet, but it's |
| a special kind of class. It's called an association |
| class. So, it's a class that is connected to |
| a specific association. So what we can do |
| here, we can create this class, which I'm going to |
| call checked out. I'm going to, associate it with |
| this, association. I'm going to connect it with this association. And |
| then I'm going to move the due date and the |
| renewed attributes From the LoanableItem here in this checked |
| out class. So in this way, seems to me that |
| it makes it very explicit for somebody looking at this |
| class diagram, that these characteristics are characteristics of the loan, |
| and not of the elements involved in the loan. |
| >> Can you do the same thing with Fine, isn't Fine a property of the |
| loan? Yeah, actually is right because |
| a fine is a fine for a specific loan, right? |
| >> That's correct. |
| >> Okay, so yeah. Then we can do that. |
| We don't need to represent fine as a class, we can just transform |
| that into an attribute that we can put into the checked out association class. |
| >> Gotcha. |
| >> Anything else? |
| >> Yeah. It occurred to me that there's another thing that happens in one |
| of my scenarios, I put down |
| about the patron actually returning an item. |
| >> Right. Okay, so we would probably need an additional operation, |
| I guess, for the patron. |
| >> Right. |
| >> So, okay, so what I'm going to do, that's pretty easy |
| to do, I'm just going to add the return operation here in the |
| patron, and when that happens, that will mean that I'll get rid |
| of this association class because the item is returned. Is that right? |
| >> Well, what happens if somebody drops the |
| book in the book drop, but doesn't pay the, |
| if it's overdue and doesn't pay the fine? |
| Will that get rid of the information about what |
| they owe? |
| >> Oh, I see. So you can have the item being available, but you still |
| want to know whether there is any pending fines on the book. |
| >> Uh-huh, and how much those fines are. |
| >> And how do you compute how much it is? |
| >> It's how many days it was, from the time it was |
| due, to when they returned it. I see. OK. |
| So you know what we can do? I think |
| we can put an additional attribute in the checked out |
| class and I'm going to call it when returned and |
| that item will have either a special value or it |
| will contain the date in which the book was |
| returned. So in this way you should be able to |
| keep this in the system until it's paid, and also to compute |
| how much the fine is. Is that working? |
| >> So the special value is for a normal situation when they |
| haven't, they don't owe anything and haven't returned it yet. |
| >> Exactly so that will tell us that, |
| that the loan is still active basically. |
| >> Great. |
| >> Does that work for you? |
| >> Yes. And you know, I like this. I mean, I feel pretty good |
| about it. I think we have a nice class diagram. So what I'd like to |
| do is just go off and clean it up a little bit, and put it |
| in an IDE so I can pretty print it and rearrange things a little bit. |
| And then I'd like to sit down again and |
| just go through it for a last time. And |
| for some final considerations. So if you don't mind |
| we will take a ten minute break and reconvene here. |
| >> That's fine. |
| >> Alright. |

## 199 - Final Considerations

| Okay. So this is what I've done as you see, |
| it looks a little nicer than it was before. And I didn't |
| really change that much. I just made a few changes, so |
| I just wanted to point them out to you, so that you |
| know what they are. And the main thing, one of the |
| main things I did is really to introduce these derived attributes. So |
| these are attributes that are basically |
| computed. Based on some other attributes. |
| Okay, they don't have a value themselves, but their value is computed. |
| And I used two. The first one is age. So |
| basically we know the age of the patron based on |
| the birthday, of the patron. So you guys, I don't |
| know if you have that information currently in the system. |
| >> No, we'll have to add that to the |
| form patrons fill out, when they get their card. |
| >> Is that, that an issue? Can you do it? |
| >> No yes, we, we can easily do that. |
| >> Okay, so then, perfect. So we'll do it that way. I think it's |
| a, in a little cleaner. And similarly, since you told me that the fine |
| was computed based on the amount of days that an |
| item was late. The patron was late returning the item, then I |
| also added this as a derived attribute that is computed based on |
| the due date and when the item is actually returned. |
| >> Makes sense. |
| >> Makes sense? Okay. And the rest |
| is kind of really minor things. So the, the only one I |
| want to point out is I didn't, you know, discuss that with |
| you before, but I added this, which is called cardinality |
| for some of these relationships. And what they say is basically |
| is how many elements are involved in the relationship. |
| >> So, you mean the stars? |
| >> Yeah, like the stars and the one... |
| >> Okay. |
| >> Here for example, this is telling you that for each item there |
| is only one title. And that for each title, there are multiple items. |
| >> So, star means many. |
| >> Stars mean many, yeah. |
| >> Okay, go you. |
| >> Sorry that's kind of computer science lingo - we use the star |
| for that kind of stuff. And, similarly, for the patron, it's |
| telling me that, you know, each patron can have multiple, can |
| request multiple titles, and that the same title can be requested |
| by multiple patrons, which I think is the way the system works. |
| >> Right. So except for these minor changes, |
| we already had a pretty good model in our hands, so |
| I think is a, we can finalize this and then just |
| move to the low level design and then implementation, and be |
| done with the system. |
| >> Sounds good. |

## 200 - Debriefing

| >> So Spencer, now that we went through |
| this process and, I'd just like to hear |
| whether you enjoyed it, whether you think it |
| was useful. What are your thoughts? |
| >> Well, ti was very interesting. I not only |
| learned something about computers and about how you design information systems |
| in UML, but I, it was interesting. I also learned something |
| interesting about the library. And things that, that I knew but |
| I never really, explicitly written down. |
| >> Uh-huh. |
| >> Came up during the course of doing this. And I think I now |
| much better understand what this information system that you're |
| going to build for us, is really all about. |
| >> Okay, well, I mean, I'm very happy that you say |
| that, because I really believe that, you know, doing this kind |
| of analysis and design exercises really helps you figuring out whether |
| there's any issues with the requirements. So for example, you can find |
| out whether there's any missing information, or maybe conflicting |
| information. And I think that's exactly what happened today. |
| So I'm very glad to hear that it worked for you. That you enjoyed it. I hope you |
| enjoyed it as well. And I strongly encourage you |
| to do this kind of exercises for different kinds |
| of systems. So as you can become more familiar |
| with analysis and design techniques. So, any final thoughts? |
| >> I look forward to receiving your delivered software. |
| >> All right. Will do. |

## 201 - Lesson Overview

| In the last lesson, we talked about design, and we saw how difficult it can |
| be to come up with a good and effective design for a given software system. To |
| help address these difficulties, we will discuss |
| design patterns, which can support design activities by |
| providing general, reusable solutions to commonly occurring design |
| problems. Similar to architectural styles, design patterns can |
| help developers build better designed systems by reusing design solutions that |
| worked well in the past and by building on those solutions. |

## 202 - History of Design Patterns

| Let's start our decision of design patterns by looking |
| at the history of patterns. As you know, I like |
| to give this sort of historical perspective on how and |
| when concepts were defined. In this case, we have to |
| go back to 1977, when Christopher Alexander, an American professor |
| of architecture at UC Berkeley, introduces the idea of patterns, |
| successful solutions to problems, in his book called a Pattern |
| Language. The book contains about 250 patterns. And the idea |
| is that occupants of a building should be able |
| to design it. And the patterns in the book provide |
| a way to do that. And this idea of design |
| patterns, so, a formal way of documenting successful solutions to |
| problems, inspired several other disciplines. In particular, in 1987, |
| Ward Cunningham and Kent Beck leveraged this idea of Alexander's |
| patterns in the context of an object oriented language. |
| And in this specific the language was Smalltalk. |
| Some of you might know the language. So what Cunningham |
| and Beck did, was to create a 5 pattern |
| language for guiding novice Smalltalk programmers. So they did |
| an experiment and had several developers using their patterns, and |
| the experiment was extremely successful. The users were able to |
| create elegant designs using the provided patterns. And in case |
| you are interested in reading about it, Cunningham and Beck |
| reported the results in the article, Using Pattern Languages for |
| Object Oriented Programs, which was published at the |
| International Conference on Object Oriented Programming, Systems, Languages, and |
| Applications, also called OOPSLA, in 1987. At the |
| same time, Eric Gamma was working on his dissertation, |
| whose topic was the importance of patterns and |
| how to capture them. Between 1987 and 1992, there |
| were several workshops related to design patterns. And |
| in 1992, Jim Coplien compiled a catalog of C++ |
| items, which are some sort of patterns, and |
| he listed this catalog of patterns in his |
| book, which was titled Advanced C++ Programming Styles |
| and Idioms. Finally, in 1993 and 1994, there were |
| several additional workshops focused on patterns. And this |
| workshop brought together many patterns folks, including these |
| 4 guys, Erich Gamma, Richard Helm, Ralph Johnson, |
| and John Vlissides. These guys are also known as |
| the gang of 4. And the result of this collaboration was the |
| famous book Design Patterns: Elements of |
| Reusable Object Oriented Software. So this |
| is basically The Book on design patterns. If you want to buy |
| a book on design pattern, this is the one you should get. |

## 203 - Patterns Catalogue

| This book contains a patterns catalog which is |
| a number of design patterns classified by purpose. And |
| there are five main classes of patterns. There are |
| fundamental patterns which are the basic patterns. There are |
| creational patterns which are the patterns that support object |
| creation. Then there are structural patterns and these are |
| patterns that help compose objects, put objects together. The |
| next class of patterns are behavioral patterns and these |
| are patterns that are mostly focused on realizing interactions |
| among different objects. Finally, there are concurrency patterns and these |
| are patterns that support, as the name says, concurrency, so |
| they're more related to concurrency aspects. And for each of |
| these classes there are a number of specific patterns, and |
| here I'm just listing some of them. Clearly we cannot |
| cover in one lesson all of these patterns, but what |
| I want to do is to cover at least a few |
| of those to give an idea of what patterns are and |
| how they can be used. In particular, we will see in |
| detail the Factory Method Pattern and the Strategy Pattern. And we |
| will also discuss a few more patterns at a higher level. |

## 204 - Pattern Format

| So let's start by seeing how patterns are defined. So |
| what is the format of the pattern definitions. If we look |
| at the Gang of Four's book we can see that these |
| definitions contain a lot of information. In fact, what I'm listing |
| here is just a subset of this information. In this lesson, |
| what I want to do is to focus on four essential |
| elements of a design pattern. It's name, the intent which is |
| the goal of the pattern. The pattern's applicability which is the |
| list of situations or context in which the |
| pattern is applicable. I also want to cover the structure |
| and participants. Which is the static model that describes |
| the elements, so normally the classes or the object |
| involved in the pattern. In addition to that |
| the structure also describes |
| the relationships, responsibilities and collaborations |
| among these classes or objects. Finally what I want |
| to cover is sample code. So examples that illustrate |
| the use of patterns. |

## 205 - Factory Method Pattern

| Let's now look at the first design pattern that we |
| will discuss, the factory method pattern. And I'm going to start |
| by discussing the intent of the pattern and its applicability. |
| As far as the intent is concerned, the factory method pattern |
| allows for creating objects without specifying their class, by invoking |
| what we call a factory method. And what that is, is |
| a method whose main goal is to create class instances. |
| So when is this pattern useful? So when is it applicable? |
| For example, it is applicable in cases in which a class |
| cannot anticipate the type of object it must create. That is, |
| the type of an object is not known at compile time, |
| is not known until the code runs. A typical example of |
| this, are frameworks. So if you ever used a framework, you |
| will know that, normally, frameworks only know about interfaces and abstract |
| classes. So the exact type of the objects of these classes |
| is only known at runtime. The second case in which the factory |
| method pattern is applicable, is when a class wants its |
| subclasses to specify the type of objects it creates. And we'll |
| see an example of this in a minute. Finally, factory |
| method patterns are applicable when a class needs control over the |
| creation of its objects. And in this case, one possible |
| example is when there is a limit on the number of |
| objects that can be created. Special example, it's a singleton. If |
| you're familiar with a singleton, a singleton is a class for |
| which only one instance can be created. The factory method pattern |
| is perfect in these cases, because it allows to control how many |
| objects get created. So in this case, it would allow the creation |
| only of a single object. And from the second time that it |
| is invoked, it will just return the object that was previously |
| created. Now let's go ahead and see how this pattern actually works, |
| and let's do that by discussing the structure and the participants for |
| the pattern. The structure that is represented here, using the UML notation, |
| includes three classes, the Creator, the ConcreteCreator, |
| and the Product. The Creator provides the |
| interface for the factory method. So this |
| here, is the interface for the factory method |
| that, when invoked, returns an object of |
| type Product. The ConcreteCreator provides the actual |
| method for creating the Product. So this |
| method is a concrete implementation of this interface. |
| Finally, the Product is the object created by the factory method. So |
| summarizing, we have the interface for |
| the factory method, the actual implementation of |
| the summary method, and the object that is created by the factory method, |
| when it is invoked. So let's look at an example of this pattern. |

## 206 - Factory Method Pattern Example

| The example I'm going to use consists of a class called |
| ImageReaderFactory which provides the factory method which is this one; |
| createImageReader. As you can see the method takes an InputStream |
| as input and returns an object of type ImageReader, and it's |
| static so that we can invoke it even if we |
| don't have an instance of the ImageReaderFactory. So what does the |
| method do? Well the method first invokes, getImageType, passing the |
| InputStream as a parameter and this method figures out the type |
| of the image that is stored in this Inputstream and it's |
| an integer. Then, based on the value of this integer, the |
| method does one of several things. If the image type is |
| a GIF, it will invoke the constructor for GifReader passing the |
| stream as a parameter. And what will happen is that the |
| GIF reader will read a GIF from the stream, create a |
| corresponding object and return it. So in this case, the ImageReader |
| object return will be the object representing a GIF as appropriate. |
| Similarly, if the image type is JPEG, then the method will |
| invoke the constructor for JPEG Reader and in this case, this constructor |
| will read from the stream a JPEG, create a corresponding object |
| and return it. And so on for different types of images. So |
| why is this a situation in which it is appropriate to |
| use the factory method pattern? One, because it corresponds exactly to the |
| cases that we saw before, of applicability. This is a case |
| in which we don't know the type of the object that we |
| need to create until we run the code, because it depends |
| on the value of the InputStream. It depends on the content |
| of the InputStream. So, until we read the InputStream, we cannot |
| figure out whether we need to create a GIF, a JPEG or |
| some other type of image. So in this case, we want to |
| do, we want to simply delegate to this classes the creation of |
| the object, once we know what type of object needs to |
| be created. So perfect example of application of a factory method pattern. |

## 207 - Strategy Pattern

| The second pattern I want to discuss is the |
| strategy pattern, which provides a way to configure a |
| class with one of many behaviors. What does that |
| mean? Well, more precisely, this pattern allows for defining |
| a family of algorithms, encapsulating them into separate classes, |
| so each algorithm in one class, and making these |
| classes interchangeable, but providing a common interface for all |
| the encapsulated algorithms. So in essence, the intent of |
| a strategy pattern is to allow for switching between |
| different algorithms for accomplishing a given task. For example, imagine |
| having different sorting algorithms with different space or time |
| tradeoffs. You might want to be able to have them |
| all available and use different ones in different situations. |
| And this pattern is applicable not only when we have |
| different variants of an algorithm, but also when we |
| have many related classes that differ only in their behavior. |
| So let's get more concrete and see how this is |
| done. And I'm going to do it as before, by |
| discussing the structure and the participants for this strategy pattern. |
| In this case, we have 3 types of participants for this |
| pattern, the context, the algorithm, and the concrete strategies. There |
| can be as many as the number of behaviors that |
| I need to implement. So, let's see what those are. |
| The context is the interface to the outside world. It maintains |
| a reference to the current algorithm and allows for |
| updating this reference at run time. So, basically the outside |
| world will invoke the functionality provided by the different algorithms, |
| by using this interface. And depending on which algorithm is |
| currently selected, that's the one that will be executed when |
| the functionality is involved. The algorithm, also called the strategy, |
| so that's where the pattern gets its name, Is the |
| common interface for the different algorithims. So all the algorithms |
| implement this interface. Finally, the concrete strategies are the |
| actual implementations of the algorithms. So if I have 10 |
| different variants of my algorithm, I will implement 10 different |
| concrete strategies. They will all be implementations of this interface. |

## 208 - Strategy Pattern Example & Demo

| Now let's see how this whole thing works in practice by |
| using an example. We're going to consider a program that takes as |
| input a text file and produce it as output, a filtered |
| file. So basically it outputs a subset of the content of |
| this text file based on some filter. And we're going to have |
| four different types of filters. So the first one is |
| not filtering which means that the whole content of the text |
| file will be produced on the output. The second filter will output |
| only words that starts with t. So you'll take the text file |
| and simply ignore all of the words that do not start with |
| t. So in the output we'll have only those words that starts |
| with letter t. The third filter will produce in the output only |
| words that are longer than five characters. So all the other words |
| will be simply disregarded. And finally, the four filter will produce as |
| output only words in the text file that are palindromes, and in |
| case you don't know what a palindrome is, a palindrome is a word |
| that is the same whether you read it from left |
| to right or from right to left. For example, the |
| word kayak, you can read it in this direction, or |
| in this direction, and it's exactly the same word. So |
| let's see how this program could be implemented using a |
| strategy pattern. And let's do it for real as a |
| demo. What we're looking at here is the editor page |
| for Eclipse, open with the strategy pattern implementation for our example. |
| So what I'm going to do is that, I'm going to look at a |
| different part of implementation. And you will see that, you know, despite |
| the fact that it's slightly longer, it's really fairly simple, it's kind |
| of a straightforward implementation of what we just saw. As I just |
| said, what we are doing is basically building the strategy patterns that |
| allows for changing the strategies with which we're filtering an input file. |
| And we have different strategies, we'll look at those in detail, and |
| we said that the three participants for this pattern are the context, |
| the algorithm, which is the general interface and then the concrete |
| strategies, which are the concrete implementations of this algorithm. So let's |
| start by looking at the context. Which is this class here. |
| And as you can see it contains a reference at the current |
| strategy. We call this the check strategy, which is basically our |
| filter, and when the context is created by default it sets a |
| strategy to the old strategy. The old strategy is the one |
| that accepts all the input, so basically it doesn't filter out anything. |
| And we said that the context is the interface to the |
| outside world, right? So it has to provide the outside world |
| with a way of selecting the strategy, the specific algorithm to |
| be used, and it does that in this case by providing |
| this change strategy method. This method takes a strategy as input, |
| and simply replaces the current strategy with the one specified as |
| a parameter. And at this point, the context also will perform |
| the filtering. The filtering is pretty straightforward, so what it does is |
| that it opens a file that is passed as a parameter |
| so that this the file, the input file to be filtered. And |
| then it reads the file line by line and then splits |
| the lines into its composing words and then for each word in |
| each line, what it will do, it will basically invoke the |
| check method in the current strategy, which is basically the filtering method |
| and if the check method returns true, which basically means that |
| the word should be printed, it prints the word. Otherwise, it'll just |
| skip it. So basically the filter will return false for all the |
| words that have to be filtered out. Okay? This is the basic |
| way in which context works. Let's see how this is used in |
| our main method. The main method simply creates the context, reads the input file |
| from the arguments, and then what he does is simply as a |
| demonstration, it will perform the filtering using all the different filters. So |
| starting from the default one, which is the one that basically doesn't |
| do any filtering that reports all words, then it will switch to the |
| algorithm, that only considers the words that start with t, and |
| it will do that by invoking a change strategy and passing this |
| strategy as the argument, and then |
| performing the actual filtering through context. |
| And it will do exactly the same for the strategy that only |
| prints words that are longer than five and the one that |
| only prints words that are palindromes. So now let's look at the |
| actual algorithm. This is the interface, the algorithm interface. And you can |
| see that the only thing that the interface provides is this method, |
| which is the check method, that takes a string as input and will |
| return a boolean. So, basically, it's the boolean that we were seeing before. |
| The one that is true for the words that have to be printed |
| and false for the ones that have to be filtered out. Now, we have |
| all the different implementations of the algorithm, the simplest one is the all |
| algorithm, the simple return is always true, so all the words will be printed. |
| The second one starts with t, and again, without looking at the details |
| of implementations that don't really matter, what |
| it does is basically check that |
| the first character is t, and returns true in that case and |
| false otherwise. Similarly, for the LongerThan5 |
| algorithm, also in this case, this |
| will implement the check strategy interface, and the check will be performed |
| by checking that the word is longer than five characters and returning |
| true in that case and false otherwise. And finally the Palindrome check |
| is a little more complicated, but basically it just checks whether the |
| word is a Palindrome and returns true in that case. Okay, so |
| as I said, it doesn't really matter too much what is the specific |
| implementations of these matters. What matters is that we have |
| a general interface for the algorithm and then any different concrete |
| implementations of the algorithm that implement different strategies. So again, |
| this allows you to change the behavior of your class without |
| changing class. So we have this context class that does |
| different things when the filter method in invoked, depending on what |
| is the current strategy. So the behavior of the class can |
| change dynamically, and it changes dynamically every time that we change |
| the strategy. At this point, the way this whole thing works should |
| be clear, so what we're going to do is that we're going to go to |
| our console, and we're actually going to run the strategy pattern and see |
| what happens. So here I have a file, it's called foo.txt. And if |
| we look at the content of foo, you can see that it |
| says that this is just a test to assess how well this program |
| performs when used on files of text. And since it checks for |
| palindromes, we will also insert one such word, level. Level is a palindrome, |
| because you can read it from both sides. Okay, so let's |
| see what happens when we run our code. So we're going to |
| run java pattern.strategy.StrategyPattern which is |
| our class, and we going to fetch |
| foo.txt as an input, and let's go back to the beginning |
| of the output to see what happened exactly. You can see |
| here that for the default strategy, which was the old strategy, |
| the whole file is printed, so every word is printed. This |
| is just a test to assess and so on and so forth, |
| as expected. For the filter that only prints words that |
| start with t, only words that start with t are printed, |
| again, as expected. Similarly, for the filter that only prints words |
| that are longer than 5, and finally for the one that prints |
| palindromes. And here you can see that we actually have two |
| because the way in which this is implemented we'll also consider |
| single letter words as palindromes because you can read them from |
| both sides. But you definitely will also have level in the output. |
| And in case you want to play with this code yourself, I |
| have made this code and also the implementation for examples of other |
| design partners available as a compressed archive. And the archive is accessible |
| through a URL that is provided in the notes for the cost. |

## 209 - Other Common Patterns

| Before concluding this lesson, let's look at a few more patterns. And |
| although it will take too long to cover them in detail, I |
| would like to at least mention and quickly discuss a few more |
| of these more commonly-used patterns. In fact, some of the patterns that |
| I will discuss, you might have used yourself. Maybe without knowing their |
| name or the fact that they were design patterns. So let's start |
| with a Visitor pattern, which is a way of separating an algorithm |
| from an object structure on which it operates. And a practical result |
| of this separation is the ability to add the new operation |
| to exist in object structures, without modifying the structures. So, basically |
| what this pattern does, is to allow for defining and easily |
| modifying set of operations to perform on the objects of the collection. |
| And the typical usage of this is, for example, when you're |
| visiting a graph, or a set of objects, and you want |
| to perform some operations on these objects. By using a visitor |
| pattern, you can decouple the operation |
| from the objects. Although not straightforward, |
| this pattern is very, very useful. So, I really encourage you |
| to look at it in more detail and get familiar with it. |
| The second pattern I want to mention is the decorator pattern. |
| The decorator pattern is basically a wrapper that adds functionality to a |
| class. So the way in which it works, is that you |
| will take a class, you will build a class that basically wraps |
| this class. So it reproduces the functionality of the original class, but |
| it also adds some functionality. And for all the functionality that was |
| already in the original class, it will simply invoke this |
| functionality and for the new one, you will implement it |
| using the services of the class. And a nice property |
| of the decorator pattern is that it's stackable. So you can |
| add decorators on decorators on decorators, and further increase the |
| functionality provided by your class. The iterator is another very |
| commonly-used pattern. And, you probably use this one yourself because, |
| it's also part of many standard libraries. What the iterator allows |
| you to do, is basically to access elements of a collection |
| without knowing the underlying representation. So the iterator will allow you |
| to just go through a set of objects without worrying about |
| how the objects are stored. So you basically just ask the |
| iterator to give you the first object, the next object and |
| so on. Another very commonly-used pattern is the observer pattern. And |
| this pattern is very useful when you have an object of |
| interest and a set of other objects that are interested in |
| the changes that might occur in this first object. So |
| what the observer pattern allows you to do is to register |
| these objects, so that they let the system know that |
| they're interested in changes in this first object. And then, every |
| time that there is a change, these other objects will |
| be automatically notified. So basically, |
| the observer pattern allows for notifying |
| dependents when an object of interest changes. If you want |
| an example of this, just think about the file system and |
| imagine having a folder. All the views of this folder will |
| want to be notified every time that there's a change in |
| the folder because they need to refresh. So instead of continuously |
| checking the state of the folder, they will just register and basically |
| say, hey, we're interested in knowing when something changes in this |
| folder. And when something changes in the folder, they will be automatically |
| notified. So it will be some sort of a push notification |
| instead of a pull notification, if you are familiar with that terminology. |
| Finally the proxy pattern is a pattern in which a surrogate |
| controls access to an object. In other words, we have our object, |
| and we have our proxy here. So all the requests to the |
| object will go through the proxy that will then forward them. And |
| all the responses from the object will also go through the |
| proxy. They will then forward them to the original requester. So what |
| the proxy allows you to do is to control how this object, |
| that is behind the proxy, is actually accessed, for example, by filtering |
| some calls. So in a sense, the proxy allows use |
| for masking some of the functionality of the object that |
| is behind the proxy. And there's many, many, many more |
| useful patterns. That can help you when designing and implementing |
| the system. So once more, I really encourage you to |
| have a look at the book, to look at the |
| resources online, and to really get more familiar with these |
| patterns, and to try to use them in your everyday work. |

## 210 - Choosing a Pattern

| But with so many patterns, how do we choose a pattern? So |
| this is a possible approach that you can follow. First of all, you |
| want to make sure that you understand your design context. You understand |
| what you're designing and what are the issues involved with this design. What |
| are the problems that you need to solve. At this point, you |
| can examine the patterns catalog, or,if |
| you're already familiar with the catalog, just |
| think about the possible patterns that you could use. Once you identify |
| the patterns that you can use, you also want to study them and |
| study the related patterns. So normally if you look at any pattern catalog, |
| for each pattern there will also be a list of related patterns. So |
| you can also look at those to see whether maybe some of those |
| might be more applicable. And finally, once you identify the pattern that you |
| think is appropriate, you will apply that pattern. When you do that, just |
| be mindful that there are pitfalls in the use of patterns. One obvious |
| one is the fact that you might select the wrong pattern and make |
| your design worse instead of better. The second one is that if you |
| get too excited about patterns, then you |
| might be abusing patterns, so just using too |
| many patterns, and end up with a design |
| that is more complicated rather than less complicated. |
| So always be careful, spend the time to figure out which one is the right |
| pattern to apply, and make sure that you |
| don't use patterns that you don't actually need. |

## 211 - Choosing a Pattern Quiz Question

| Now that we've discussed how to choose a pattern. Imagine that |
| you have to write a class that can have only one |
| instance. So to satisfy this requirement, I would like for you |
| to pick one of the design patterns that we discussed in |
| this lesson, and write the code here that satisfies that requirement. |
| And when you write the code, please make sure that your |
| class has only one method, without counting possible constructors, and that |
| the class is called Singleton. And write your class right here. |

## 212 - Choosing a Pattern Quiz Solution

| As we discussed in the class the right thing to |
| do here was to use the factory pattern. So here is |
| a possible code to solve the problem. Of course that there |
| are different possible solutions. So what we did for this code |
| was to first create a private, static, Singleton object called |
| instance, which is the one that will keep track of the |
| only instance that can be created on the class. Then we |
| define the default constructor, the constructor that doesn't take any parameter |
| as private. In this way other classes cannot create instances |
| of Singleton without calling our factory method, and finally we |
| create the factory method. And the factory method is very |
| simple. The method will first check whether an instance of |
| the class was already created. If it was created, it |
| would just return that instance. Otherwise, it will create a |
| new instance and assign it to that instance member variable |
| and then return the newly created instance. So with this code |
| you're guaranteed that other classes cannot bypass the factory |
| method, because the default constructor is private. And the that |
| the factory method will create one and only one instance |
| of the class, which is exactly what our requirements were. |

## 213 - Negative Design Patterns

| To conclude this lesson, I want to discuss the |
| concept of negative design patterns, that is, patterns that should |
| be avoided. Interestingly, negative patterns were also mentioned in |
| Christopher Alexander's book, so in the first formulation of patterns. |
| So negative design pattern are basically guidelines on how |
| not to do things. In consoles with patterns, the guidelines |
| on how to do things. So basically, what the negative |
| design patterns do is, they enable recurring design defects to |
| be avoided. And as we will see in this class extensively, |
| in mini-course four, negative patterns are |
| also called anti-patterns or bad smells, |
| or bad code smells. So in mini-course four we will see several |
| examples of bad smells and what we can do to eliminate them. |

## 214 - Lesson Overview

| In the previous lessons of this mini-course, |
| we discussed high level design, or architecture, |
| low level design, and design patterns. Now, we're going to see how we can put |
| this and also others software engineering activities |
| together in the context of a UML-based |
| process model, the unified software process, or |
| USP. We will discuss how USP was defined, |
| its main characteristics, its phases, and how we can apply it in practice. |

## 215 - History of RUP

| As I just said, today we're going to talk about the |
| Rational Unified Process. And you know that I like to provide |
| the historical perspective of the topics that we cover in class |
| and this lesson is no exception. So let's see a little bit |
| of history of RUP. To do that we have to go |
| back to 1997 when Rational defined six best practices for modern software |
| engineering. So let's look at what these practices were. The first |
| practice involved developing in an iterative way with risk as the primary |
| iteration driver. The second practice had to do |
| with managing requirements, including updating them and keeping |
| traceability information between requirements and other software |
| artifacts. Practice number three was to employ a |
| component-based architecture. What that means is to have |
| a high level design that focuses on cooperating |
| components that are nevertheless very cohesive and highly |
| decoupled. Modeling software visually is another key aspect |
| of the rational unified process. And the key concept |
| here is to use visual diagrams, and in particular UML |
| visual diagrams, in a very extensive way so as |
| to make artifacts easier to understand and agree upon among |
| stakeholders. And the fact that the process is defined |
| in an iterative way, allows for performing quality assurance activities |
| in a continuous way. So it allows for continuously |
| verifying quality throughout the development |
| process. Finally, change management and |
| control were also at the center of the rational |
| approach These six practices, that I just mentioned were |
| the starting point for the development of the Rational |
| Unified Process, which is what we're going to discuss next. |

## 216 - Key Features of RUP

| So let's start by seeing how these activities and principles |
| are reflected in the key features of the Rational Unified |
| Process. First of all, the Rational Unified Process is a |
| software process model. So if you recall our introductory lessons, |
| that means two main things. The first one is that |
| it defines an order of phases that have to be |
| followed in the software process. And the second thing is |
| that it also prescribes transition criteria, so when to go |
| from one phase to the next. The second key |
| feature of RUP is that it is component based. And |
| also in this case, this implies two main things. |
| The first one is that a software system is defined |
| and built as a set of software components. So |
| software components are the building blocks of our software system. |
| And the second one is that there must be well-defined |
| interfaces between these components, interfaces |
| through which these components communicate. |
| In addition, the Rational Unified Process is |
| tightly related to UML. And in particular, it |
| relies extensively on UML for its notation, and |
| with respect to its basic principles. Finally, the |
| three main distinguishing aspects of the Rational Unified |
| Process are that it is use-case driven, architecture-centric |
| and iterative and incremental. So let's now look |
| in more detail at these three distinguishing aspects, |
| and we're going to look at each one of them individually. |

## 217 - UML Quiz Question

| Before doing that though, let's have a quiz to check whether you remember |
| the basics of UML. Since we're going to talk about use cases, I want |
| to ask you, what is the difference between a use case and a |
| use case model. So here are the possible answers, and you can mark |
| more than one. First one is that only use case models include actors. |
| The second is that they are the same thing. The third one is |
| that a use case model is a set of use cases. The fourth |
| one says that a use case is a set of use case models. |
| Finally, the last one says that use cases |
| are a dynamic representation, whereas use case models |
| are a static representation of a system. So |
| mark all the answers that you think are correct. |

## 218 - UML Quiz Solution

| And the correct answer, in this case it's only one, |
| is that a use case model is a set of use |
| cases. So a use case model is simply a collection of |
| use cases that represent different pieces of functionality for the system. |

## 219 - UML Quiz Question

| So, since we are talking about use case diagrams, I also want |
| to ask you, what are use case diagrams used for? So, what |
| are they good for? Why are they useful within a software process? |
| Also in this case, I'm providing several possible answers. They are not really |
| used for anything. Or, they can be used to prioritize requirements. Or, |
| maybe they can be used for user interface design. They can be |
| used during requirements elicitation. They can |
| be used for code optimization. And |
| finally, they can be used for test case design. Also, in this case, |
| I would like you to mark all the answers that you think are correct. |

## 220 - UML Quiz Solution

| In this case, there are multiple correct answers. |
| So, you should have marked several of those. |
| So, let's go through the list. |
| Well, this is definitely not true. |
| They are used for something. |
| The second answer is a correct one, |
| because you can order the used cases that you plan to |
| realize according to your prioritization criteria. |
| So basically, what you're doing you're prioritizing either in terms of functionality, |
| so you can decide which piece of functionality you want to realize first in your system. |
| Or you can also prioritize based on the actors involved. |
| Maybe there are some actors, |
| maybe there are some user roles that you want to |
| support before others and we'll see some examples of that. |
| The next correct question is that they can be used for requirements elicitation. |
| Why? Well, because use cases express what the system is supposed to do for each user. |
| They are an ideal way to collect, |
| represent and check functional requirements. |
| We'll also get back to this. |
| Finally, use cases can definitely be used for test case design. So, why is that? |
| Because each use case it presents a scenario of interaction between users and the system. |
| So, testers can very naturally construct test case is based on use cases. |
| In addition, and most importantly, |
| they can do that even in the absence of code that realize they use case. |
| So, they can do it as soon as they have the requirements. |
| They don't have to wait until the code is ready. |
| So, this is another very important point. |
| So, you can have your test cases ready even before writing the code. |
| Now, for completeness, even though this is not listed in the quiz, |
| I also want to mention two additional uses for use cases. |
| The first one is that use cases can be used to estimate effort, |
| as we will discuss in more detail in mini course four, |
| where we talk about Agile software development. |
| They can also be used by customers to assess requirements, |
| which is another fundamentally important role of the use cases. |
| They provide a common language between the customers and the developers, |
| which makes it easier to collect the right requirements. |

## 221 - Use Case Driven

| Now let's go back to the distinguishing aspects of |
| RUP, starting from the first one. That is, that the |
| rational unified process is use-case driven. So let's see what |
| that means. Generally speaking, we can see a system as |
| something that performs a sequence of actions in response to |
| user inputs. So the user submits some requests, or requests |
| some functionality, and the system responds to those requests. Use |
| cases, as we just said, capture exactly this interaction and |
| answer the question, what is the system supposed to do |
| for each user? So, this is a very important point. |
| So they can represent what a system can do for |
| each of the different types of users of the system. |
| For this reason, and as we will see in more |
| detail, in the rational unified process, use cases are a |
| central element of the whole development life cycle. From requirements |
| engineering, all the way through the process until testing and maintenance. |
| So, once more, use cases are used to support and |
| help each one of these phases in the rational unified process. |

## 222 - Architecture Centric

| The second distinguishing aspect of RUP is that it |
| is architecture-centric. As we saw in the first lesson |
| of this mini-course, a software architecture is a view |
| of the entire system that represents all high level |
| principal design decisions. Another way to see this is |
| by saying that use cases define the function of |
| the system, where as architecture defines the form of |
| the system. Use cases give the functionality, architecture tells |
| you how the system should be structured to provide the functionality. |
| So how do we define a software architecture in the rational |
| unified process. Also in this case this happens through |
| a sort of a iterative process. We start by creating a rough |
| outline of the system. And in this case we do it |
| independently from the functionality. So this is just the general structure |
| of the system. For example, we model aspects such as the |
| platform on which the system will run, the overall style. For example, |
| whether it's a client server or a peer to peer |
| system and so on. We then use the key use cases |
| in our use case diagram to define the main subsystems of |
| my architecture. For example, in the case of a banking IT |
| system, one of these subsystems might be the withdrawal system. So |
| what will happen in that case is that we will have |
| some use case that refers to the withdrawal activity, and by |
| analyzing that use case, we'll realize that we need a subsystem |
| that implements that piece of functionality. So again, we use |
| the key use cases to identify and define the key |
| subsystems for my architecture. So once we have that we |
| keep refining the architecture by using additional use cases. So |
| considering more and more pieces of functionality that will help |
| us to refine the architecture of the system and also |
| leveraging our increasing understanding of the system that we're modeling. |
| And this will continue until we are happy with the |
| architecture that we define. |

## 223 - Iterative and Incremental

| We just saw two of the three distinguishing aspects of |
| the rational unified process. The fact that it is used |
| case driven and the fact that it is architecture centric. |
| The third and final distinguished aspect of R.U.P. is that |
| it is iterative and incremental. So let's see what that |
| means by considering the lifetime of a software project. Basically, |
| the lifetime of a rational unified process consists of a |
| series of cycles, such as the ones that are represented here. |
| Cycle one, cycle two, through cycle n. And as |
| you can see, these cycles can also be called increments. |
| And each one of the cycles involves all of |
| the main phases of software development. In addition, each cycle |
| results in a product release which can be internal |
| or external. More precisely, each cycle terminates with a product |
| release that includes a complete set of artifacts for |
| the project. That means code, manuals, use cases, non-functional |
| specification, test cases, and so on. So, I've just |
| said, that each cycle involves all of the main phases |
| of software development. Specifically, each cycle is further divided |
| in four phases. Inception, elaboration, construction and transition. In a |
| minute, we will look at each one of these |
| phases in detail and see how they relate to the |
| traditional activities of software development. Before that, I want |
| to mention the last level of these iterations, which happens |
| within these individual phases More precisely, inside each of these |
| phases, there might be multiple iterations. So what are these |
| iterations? Well, basically, each iteration corresponds to a group of |
| use cases that are selected so as to deal with |
| the most important risks first. So if you have a |
| set of use cases that you're considering, which means that |
| you have a set of features that you need to |
| implement, you will select for each iteration the most risky |
| ones that you still haven't realized, and realize them in that |
| iteration. And then continue in the following iterations with less and |
| less risky ones. So basically what happens in the end is |
| that essentially each iteration extends |
| the functionality beyond the previous iteration. |

## 224 - Cycle Example

| To make this a little more concrete, let's look at |
| an example involving cycles, phases, and iterations. Let's assume that we |
| have to develop a banking IT system. The first possible |
| cycle for such a system could be one in which we |
| implement the basic withdrawal facilities. What this means is that, |
| at the end of this cycle, there will be the release |
| of the product that implements this piece of functionality. But notice |
| that this will not be the only product release because within |
| the cycle, we will perform also the four phases that |
| we mentioned before, inception, elaboration, |
| construction, and transition. And within each |
| of these phases, we might have multiple iterations. And at the |
| end of each iteration, we will also have a product release. |
| Which in this case, will be an internal one. As |
| you can see, the iterative nature is really inherent in the |
| unified rational process. So, now let's clean up here, and let's |
| see what some other possible cycles could be for our banking |
| IT system. Here, I'm showing two possible additional ones. The first |
| one, cycle two, which will develop the account and system management. And |
| the third one, cycle three, which will develop the full account |
| management and cross selling. Similarly to cycle one, also these cycles will |
| produce a product, both at the end of the cycle, and |
| within the cycle in the different phases. And there's a few more |
| things to note. So the first one, is that each cycle |
| focuses on a different part of the system. So what you will |
| do, when you use the rational unified process, you will select a |
| subset of use cases that you want to realize within your cycle. |
| And the final product for that cycle, will be a product that |
| realizes those use cases. This is the first aspect. The second one, |
| is that these cycles, as you can see, are slightly overlapping. So |
| it is not the case that you finish a cycle, and then |
| you start the next one. So there is a little bit of |
| overlap among cycles, and we'll talk about that more. And finally, |
| I want to stress one more that each cycle |
| contains four phases, and each one of these phases might |
| be further splayed in iterations. So that's kind of a |
| high level view of how the whole process will work. |

## 225 - Phases within a Cycle

| Now let's go back to the phases within a cycle. |
| because I want to show you how they relate to traditional |
| activities of software development. Because this is the first time that |
| we talk about inception, elaboration, construction and transition. So we will |
| know what they mean, in terms of the traditional software |
| development. So I'm going to first discuss these relations and then |
| I'm going to talk about each individual phase in further detail. |
| So I'm going to start by representing the four RUP phases here |
| with possible internal iterations. I1, E1 and E2, C1, |
| C2, and so on. And just as a reference, this |
| is the way in which time will progress. So we |
| will start with inception and we will finish with transition. |
| So what I'm want to do now is to show the |
| actual, traditional, software development activities here on the left. And |
| I also want to show you, using this diagram, how these |
| activities are actually performed in each of the RUP phases. |
| So, let's see what this representation means. Basically, what |
| I'm showing here, is that requirements engineering actually starts in |
| the inception phase. So, you can see the height |
| of this bar as the amount of effort devoted to |
| this activity in this specific phase. So you can |
| see that requirements engineering starts in inception phase, is mostly |
| performed in the elaboration phase, and then it continues, |
| although to a lesser extent, throughout all phases up until |
| the end of the transition. But the bulk is really |
| performed here in the elaboration phase. Similarly, if we consider analysis |
| and design, we can see that analysis and design are |
| mainly performed in the elaboration phase. But a considerable amount of |
| it also continues in the construction phase, and then it |
| kind of phases out. So there's very little of that done |
| in the transition phase. Looking now at implementation, you can see |
| that the implementation happens mostly in the construction phase, which is, |
| unsurprisingly, the phase that is mostly concerned with actual code development, |
| as we will see in a minute. Testing, on the other |
| hand, is performed throughout most phases, with, peaks in some specific |
| point, for example, at the end of some iterations, like here |
| and here. To conclude, we have the business modeling activity that |
| happens mainly in the inception and a little bit in the |
| elaboration phase and the deployment activity which happens a little bit |
| throughout, but the bulk of it is really in the transition |
| phase, which is actually the phase that has to do |
| with deployment and then maintenance. So I hope this kind |
| of high level view gives you a better understanding of |
| what is the mapping between these new phases and, the |
| typical software development activities that we are more familiar with. |
| So to further this understanding, later in the lesson, I'm |
| also going to talk about these specific phases individually. First, however, |
| I want to spend a little more time discussing what happens |
| inside each one of these iterations, just to make sure |
| that we are all understand what an iteration is exactly. |

## 226 - Iterations

| So what happens, exactly, within an iteration? In |
| almost every iteration, developers perform the following activities. |
| So they identify which pieces of functionality this |
| iteration will develop, will implement. After doing that, they |
| will create a design, for the considered use |
| cases, and they will do that guided by the |
| chosen architecture. So the set of use cases |
| plus the architectural guidelines will result in a design |
| for the selected use cases. Once the design is defined, |
| then the developers will implement the design, which will result |
| in a set of software components. They will then verify |
| the components against the use cases to make sure that the |
| components satisfy the use cases, they suitably realize the use |
| cases. And they will do that through testing or some |
| other verification and validation activity. Finally, after verifying that the |
| code actually implements the use cases, they will release a product, |
| which also represent the end of the iteration. And notice that |
| what I put here is an icon for the world, |
| in double quotes. Because in many cases the release will be |
| just an internal release or maybe a release that will just |
| go to some of the stakeholders so that they can provide |
| feedback on that. Okay. So it doesn't have to be an |
| external release. It doesn't have to be a release to the |
| world. But it is, nevertheless, a release of a software product. . |

## 227 - Iterative Approach Quiz Question

| So now, since we're talking about the incremental and iterative |
| nature of the Rational Unified Process, let's have a quiz on |
| the benefits of iterative approaches. So I'd like for you to tell |
| me what are these benefits. Is one benefit the fact that |
| iterative approaches keep developers busy or maybe that they give developers |
| early feedback, that they allow for doing the same thing over |
| and over in an iterative way. Maybe they also minimize the |
| risk of developing the wrong system. Can they be used to |
| improve planning, or is it the benefit |
| that they accommodate evolving requirements. Also, in this |
| case, I would like for you to check all the answers that you think are correct. |

## 228 - Iterative Approach Quiz Solution

| Okay so let's look at the first one. Well I |
| don't think that the fact of keeping developers busy is really |
| one of the highlights or the main benefits of iterative |
| approaches. Developers are really busy without any need for additional help. |
| So I will just not mark this one. The second |
| one conversely is definitely one of the advantages of iterative approaches. |
| So the fact that iterative approaches give the developers a early |
| feedback, is a great advantage which has in turn additional advantages. |
| For example, it increases the project tempo, so it gives the developers |
| not busy but more focused. It's easier to be focused when you |
| have a short term deadline, or a short term goal |
| rather than a release that is planned in six months or even |
| later. Another advantage of this early feedback is the fact that developers |
| are rewarded for their efforts so, there is sort of an immediate |
| rewards because you can see the results of your effort instead of |
| having to wait a long time to see such results. And last, |
| but not least the fact of getting early feedback also minimizes |
| the risks of developing the wrong system. So why is that? |
| Well because getting early feedback will also allow us to find |
| out whether we're going in the wrong direction early in the development process |
| rather than at the end. And therefore, will minimize this risk. |
| Going back to the previous question, yeah, I don't think that, you |
| know, doing the same thing over and over is a great |
| advantage. And in fact, iterative approaches do not do the same thing |
| over and over. So they keep iterating, but they keep |
| augmenting the amount of functionality in the system. They don't |
| just repeat the same thing. As for improving planning, actually |
| improving planning is not really a strength of these approaches, |
| because sometimes the number of iterations is hard to predict, |
| so it's hard to do a natural planning when you |
| are using an iterative approach. So finally, are iterative approaches |
| good for accomodating evolving requirements? |
| Most definitely. First, iterative approaches, and |
| in particular, the one that we're discussing consider requirements |
| incrementally, so they can better incorporate your requirements. So if |
| there are new requirements, it's easier to accommodate them using |
| an iterative approach. Second, these approaches realize a few requirements |
| at a time. Something from the most risky ones, as |
| we said. So any problem with those risky requirements will |
| be discovered early, and suitable course corrections could be taken. |
| So in case you still have doubts about iterative approaches, |
| it might be worth it to go back to |
| mini course number one, lesson number two to discuss the |
| life cycle models. Because we talk about iterative approaches |
| and their advantages and their characteristics there in some detail. |

## 229 - Inception Phase

| Let's talk a little bit more about phases. The rational unified |
| process phases are fundamental aspects of this process and which just touched |
| on them so we just give a quick overview. And I want to |
| look at these phases in a little more detail. So, what I'm |
| going to do is, for each phase, I'm going to discuss what it is, |
| what it produces and how is the result of the phase suppose |
| to be,. Assessed, and what are the consequences of this assessment. So |
| let's start with the first phase, the inception phase. The first phase |
| goes from the idea of the product to the |
| vision of the end product. What this involves is basically |
| to delimiting the project scope. And making the business case |
| for the product presented. Why is it worth doing? What |
| are the success criteria? What are the main risks? What |
| resources will be needed? And so on, specifically these phases |
| answer three main questions. The first one is, what are |
| the major users or actors, to use the UML terminology. |
| And what will the system do for them? To |
| answer this, these phases produce a simplified use-case model where |
| only a few use-cases are represented and described. So this |
| is a sort of initial use-case model. The second question |
| is about the architecture, what could be an architecture |
| for the system? So in this phase we will normally |
| also develop a tentative architecture. So an initial architecture that |
| describes the most crucial subsystems. Finally this phase also answers |
| the question, what is the plan and how much |
| will it cost? To answer this question. This phase will |
| identify the main risks for the project and also produce |
| a rough plan with estimates for resources, initial planning for |
| the phases and dates and milestones. Specifically, the inception phase |
| generates several deliverables. It is very important that you pay |
| attention so that you understand what this deliberate approach are. |
| Starting from the first one, which is the vision document. |
| And this is a document that provides a general |
| vision of the core projects requirements, key features and main |
| constraints. Together with this, the inception phase also produces an |
| initial use case model, as I just mentioned. So this |
| is a use case model that includes an initial set |
| of use cases, and then will be later refined. Two |
| additional variables are the initial project glossary, which describes the |
| main terms, using the project and their meaning, and the |
| initial business case which includes business context. And |
| success criteria. Yet another deliverable for the inception phase |
| is the initial project plan, which shows the |
| phases, iterations, roles of the participants, schedule and initial |
| estimates. In addition, the inception phase also produces |
| a risk assessment document, which describes the main risks |
| and counters measures for this risk. Finally, and this |
| is an optional deliverable, in the sense that it, |
| it might or might not be produced, depending on the specific |
| project. As part of the inception phase we might also generate |
| 1 or more prototypes. For example, we might develop prototypes to |
| address some specific risks that we have identified or to show some |
| specific aspect of the system of which we are unsure to |
| the stakeholders. So basically all the typical users of prototypes that |
| we discussed before. So when we're done with the inception phase |
| we hit the first milestone for the cycle we are currently performing. |
| And so there are some evaluation criteria that will tell |
| us whether we can consider the inception phase concluded or not. |
| And the first of this criteria is stakeholder concurrence, which |
| means that all the stakeholders must agree on the scope, definition, |
| and cost schedule estimates for the projects. The second criteria |
| needs requirements understanding, out of the initial primary use cases that |
| we have identified so far, the right one for our system. |
| And other criteria is the credibility of the cost schedule estimates, |
| the priorities, defined the risks identifies and the countermeasures for |
| those risks, and the development process that we're following. Finally, in |
| the case we produce prototypes as part of the inceptional |
| phase, this will also be evaluated and assessed to judge the |
| overall outcome of the phase. So what happens if the |
| project fails to pass this milestone? So if the outcome of |
| the inception phase is considered to be inadequate with respect |
| to one or more of these criteria. Well at this point, |
| since we're kind of an initial phase of the cycle |
| the project may be cancelled or considerably re-thought. So to |
| summarize all of these in one sentence the Inception Phase |
| is the phase in which we produce. Then you shall vision, |
| used case model, project plan, risk assessment and possibly, prototypes |
| for the project. And we have to make sure, that |
| all of this deliverables satisfy a set of criteria, so |
| that we can continue on the project. And otherwise, we'll either |
| cancel the project or rethink its scope, or other aspects of it. |

## 230 - Elaboration Phase

| Now that we've discussed the inception phase, let's move |
| on to the second phase of RUP, which is |
| the elaboration phase. And there are four main goals |
| and activities for the elaboration phase. Analyzing the problem domain |
| to get a better understanding of the domain. Establishing |
| a solid architectural foundation for the project. Eliminating the highest |
| risk elements which basically means addressing the most critical |
| use cases. And finally, refine the plan of activities and estimates |
| of resources to complete the project. The outcome |
| of the elaboration phase reflects these activities and also |
| in this case produces several artifacts. The first one |
| is an almost complete use case model with all use cases |
| and actors identified and most use case descriptions developed. |
| As part of this phase we also identify a |
| set of what we called supplementary requirements. So these |
| are basically all the requirements that are not associated |
| with a use case. And these sets includes in particular all |
| non-functional requirements such as security, |
| reliability, maintainability and so on. So |
| all the ones that are relevant for the system that |
| you're developing. We mentioned before |
| that the software architecture is developed |
| in an incremental way, so it's not created at once. |
| And this is exactly what happens in the elaboration phase, that |
| we take the initial architecture that was defined in the inception |
| phase and we refine it until we get to a software |
| architecture which is complete. And that is part of the |
| deliverables for this phase. And the list continues, so let |
| me make some room. In addition to producing a complete |
| architecture for our system, in the elaboration phase we also |
| define the lower-level design for the system. And, therefore, as |
| part of this phase, we produce as deliverables a design |
| model, and together with that, a complete set of test |
| cases, and an executable prototype. We also produce a revised |
| project plan. Now that we have more information about the |
| project we can refine the various estimates and the various |
| pieces of information in the project plan. And also an |
| updated risk assessment document. Finally, in this phase we also generate |
| a preliminary user manual that describes to the users how |
| the system can be used and should be used. So now |
| let's see what are the evaluation criteria for the elaboration |
| phase which is our second milestone. So I'm just going to list |
| them here. The first one is whether the vision |
| and the architecture are stable or they're still changing so |
| did we converge into a final complete vision for the |
| system? Does the prototype show that the major risks that |
| we have identified have been resolved or at least addressed |
| in this phase? Is the project plan sufficiently detailed and |
| accurate? Do all stakeholders agree that the vision can be |
| achieved with the current plan? Is the actual resource expenditure |
| versus the planned expenditure acceptable? So now we study consumer |
| resources and therefore we can check whether our estimates were |
| correct. And also in this case the project might be |
| cancelled or considerably reshaped if it fails to pass this milestone. |

## 231 - Construction Phase

| So if the elaboration phase is successful, we then move |
| to the construction phase, which is our third phase. And |
| the construction phase is basically the phase in which most |
| of the actual development occurs. In short, all the features considered |
| are developed. So we'll continue with our car metaphor that |
| we used for the prototype. And in this case we |
| will have our complete car ready. Not only the features |
| are developed but they're also thoroughly tested. So we have performed |
| quality assurance. We have verified and validated the software, |
| the system and we know that it works correctly. Or |
| at least that it works correctly as far as |
| we can tell. So, in general, the construction phase is |
| the phase in which there is a shift in |
| emphasis from intellectual property development |
| to product development. From ideas |
| to products. So, what is the outcome of the |
| construction phase? Well, basically the construction phrase produces a product |
| that is ready to be deployed to the users. Specifically, |
| the phase generates the following outcomes. First of all, at the |
| end of this phase, all the use cases have been |
| realized with traceability information. What does that mean? It means that |
| not only all the functionality expressed by the use cases |
| have been implemented, but also that we have traceability information from |
| the use cases, to the different artifacts. So for example, |
| we know which part of the design realizes which use case. |
| We know which part of the implementation is related to a |
| given use case. Which use cases were derived from a use |
| case, and so on and so forth. And in this way |
| we can trace our requirements throughout the system. Throughout the different |
| artifacts that were developed during the software process. As we were |
| saying, we also have complete software product here, which is integrated |
| on all the needed platforms. Since the system, the software product, |
| has to be thoroughly tested, we will also have a complete |
| set of results for our tests. As part of this |
| phase, we will also finalize the user manual, so you'll have |
| a user manual ready to be provided to the users, and |
| ready to be used. And finally, we will have a complete |
| set of artifacts that include design documents, code, test cases, and |
| so on and so forth, so basically all of the artifacts |
| that have been produced during the development process. So roughly speaking, |
| we can consider the product that is produced at the end |
| of this phase as a typical beta release. So in case |
| you're not familiar with that, a beta release is an initial |
| release normally meant for a selected subset of users. So it |
| is something that is not quite yet ready for primetime, but |
| almost. So let's see also in this case, what are the evaluation |
| criteria for the construction phase. So how do we assess, that |
| this third milestone has been accomplished, successfully? We pretty much have |
| a complete product ready to be shipped right? So the first question |
| we want to ask is, whether the product is stable and mature |
| enough to be deployed to users. At the end of this |
| phase it has to be. Are the stakeholders ready for the |
| transition into the user community? Are we ready to go from development |
| to production? Are the actual |
| resource expenditures versus the planned expenditures |
| still acceptable? So what this means is that at this point we |
| can really assess whether our estimates were accurate enough with respect |
| to what we actually spent for the project up to this point. |
| So unless we can answer in a positive way to |
| all these questions, the transition might be postponed by one release. |
| Because that means that we're still not ready to go |
| to the market. We're still not ready to deploy our product. |

## 232 - Transition Phase

| But if we are ready to go to the market, |
| if we are ready to deploy our product, then we can |
| move to the transition phase, which has mainly to do |
| with deployment and maintainence of a system. So what are the |
| main activities in the transition phase? As we discussed in |
| our initial lessons, in most real world cases, there are issues |
| that manifest themselves after deployment, when we release our software and |
| actual users interact with the |
| software. Specifically, users might report failures |
| that they experienced while using the system. So, what we call |
| bug reports. Or they might report improvements they might want to see |
| in the software. So typically these will be new feature requests. And |
| in addition, there might be issues that don't come necessarily from the |
| users but that are related to the fact that our system |
| has to operate, has to work in a new execution environment. For |
| example, the new version of an operating system, or the new version |
| of a set of libraries. When this happens, we have to address |
| these issues by performing maintenance. Specifically, corrective maintenance |
| for bug reports, perfective maintenance, for feature requests, and |
| adaptive maintenance, for environment changes. And the result of |
| this is that we will have a new release |
| of the software. Other activities that are performed in |
| this phase include training, customer service, and providing help-line |
| assistance. Finally, if you remember what we saw when |
| we were looking at the banking IT system example, |
| the cycles within a development are not necessarily completely dis-joined, but |
| they might overlap a little bit. So something else that might |
| happen in the transition phase is that a new cycle may |
| start. So there might be some activities that are related to |
| the fact that we're starting to think about the new cycle. |
| So now let's see what kind of outcome these activities will |
| produce. The first one is a complete project with all the |
| artifacts that we mentioned before. Another outcome is that the product will |
| be actually in use. So the product will be in the |
| hands of the users and the users will start using it, will |
| start interacting with it, for real, not just in a beta testing |
| setting. Another outcome will be a lesson learnt. What worked. What didn't |
| work. What should we do different in the next cycle or in |
| the next development? And this is a very important part of the |
| whole process, because it;s what provides |
| feedback between cycles, and between projects. |
| And as we said before, in case we have a next released |
| planned or a next cycle coming up, we might want to |
| start planning for the next release. So another outcome will be |
| the plan for the next release. So similar to the other |
| phases, also for the transition phase, we have a milestone, which |
| is the fourth milestone in this case. And therefore we |
| have evaluation criteria for the transition phase that will define whether |
| we've reached the milestone or not. And in this case, one |
| important assessment is whether the user is satisfied. So users are |
| actually using our product now, so we can get feedback |
| from them, we can see whether the product makes them |
| happy or not. And we continue assessing whether our expenditures |
| are fine with respect to our estimates. And in this case, |
| problems with this milestone might lead to further maintenance of |
| the system. So for example, we might need to produce |
| a new release to address some of the issues that |
| the users identified, as we discussed a couple of minutes ago. |

## 233 - Phases and Iterations

| So now I would like to wrap up this lesson |
| by going back to our discussion of rational unified process |
| phases and iterations. So to do that I'm going to bring |
| back the presentation that I used before, the summary representation |
| about phases and traditional software engineering activities. And I want to |
| use this representation to stress and discuss a couple of |
| things. Mainly I want to recap it because I think |
| it is very important. What is the relation between the rational |
| unified process, and the traditional software engineering phases, and software |
| engineering activities? And I like to do it now that |
| we have discussed the phases in a little more detail. |
| So I want to make sure that it is clear by now |
| how and when the traditional software engineering activities, the ones |
| listed here, take place in the context of the RUP |
| phases, the four listed up here. For instance, it should |
| be clear why implementation takes place mainly in the construction phase. |
| Why requirements engineering is prominent in the elaboration phase |
| and why deployment activities occur mostly in the transition phase, |
| and so on. So it should be clear now |
| why the activities are so distributed in the four phases. |
| It should also be clear that although there is |
| normally one main phase for each activity, the activities really |
| span multiple phases. Which is actually one of the interesting |
| aspect of RUP. So the fact that you're not really |
| done with an activity even in later phases. Why? Well, because that allows |
| you, in subsequent iterations, to address |
| problems that came up in previous iterations. |

## 234 - Lesson Overview

| Hello, and welcome back. In the previous |
| mini course we covered software design, discussed the |
| UML and the unified software process, and worked |
| on a complex project in which we developed |
| a distributed software system. In this mini course, |
| which is the last one for this class, |
| we will cover my very favorite topic, software |
| testing or more generally, software verification and validation. |
| So why do I love software testing? Well, |
| I love it because it is extremely important. It |
| is very challenging and it is fun but only if you do it in the right way. |
| In the upcoming lessons we will discuss why |
| software verification is important, why software testing, which is |
| a specific type of verification, is important, and |
| what are the main techniques for performing software testing. |
| We will also discuss test-driven development and agile methods, |
| in which we'll lose some of the rigidity of |
| the earlier processes and turn things around by writing |
| tests before we write the code and then writing |
| code that makes the test pass. Finally, we will |
| perform a project, in which you get to apply |
| most of the principles and practices of agile development |
| in a realistic scenario. So let's jump right in. |

## 235 - Introduction

| So let me start with some examples that motivate the |
| need for very fine software. The first example I want to |
| use is the famous Arian five. And if you remember |
| that's a rocket that exploded not too long after departure. |
| Because of a software error. And even without going to |
| such dramatic examples. I'm sure you're all familiar with this |
| kind of situation. Or this one, or again in this |
| one. And here I'm not really picking on any specific organization, |
| operating system or software. The point I want to make is that software is |
| buggy. In fact, a federal report from |
| a few years ago assessed that software bugs |
| are costing the US economy, $60 billion |
| every year. In addition, studies have shown that |
| software contains on average one to five |
| bugs every 1000 lines of code. Building 100% |
| correct mass-market software is just impossible. And if |
| this is the case, what can we do? |
| What we need to do is to verify software as much as possible. In this part of |
| the course, we will discuss how we can |
| do this. We will discuss different alternative ways |
| of very fine software systems. With particular attention |
| to the most common type of verification. Which is |
| software testing. Before doing that however, let |
| me go over some basic terms that are |
| commonly used. And I have to say, |
| often misused in the context of software verification. |

## 236 - Failure -  Fault -  and Error

| The first term I want to define, is failure. |
| A failure is an observable incorrect behavior of the software. |
| It is conceptually related to the behavior of the |
| program, rather than its code. The second term I want |
| to introduce is fault, which is also called bug. |
| And the fault or bug, is an incorrect piece of |
| code. In other words, a fault is related to |
| the code. And is a necessary, but not sufficient condition |
| for the occurrence of a failure. The final |
| term I want to introduce is, error. Where an |
| error is the cause of a fault. It is |
| usually a human error, which can be conceptual. A |
| typo or something along those lines. And know that |
| this terminology, failure, fault and error, is the official |
| [UNKNOWN] terminology. So you cannot go wrong if you |
| use it. Now, let me illustrate the difference between |
| failure, fault and error. Using a small example. What I'm showing here is |
| a small function that, as you can see from its name, takes an |
| integer parameter i. And is supposed to double the value of i, and |
| return it. As we can clearly see, this is not what the function does. |

## 237 - Failure -  Fault -  and Error Quiz Question

| So now I have a few questions for you. And so we use, as |
| usual, our developer Janet to introduce a quiz. And the first question I want to |
| ask you is the following. A call to double passing three as a parameter returns |
| the value nine. What is this? Is that a failure, a fault, or an error? |

## 238 - Failure -  Fault -  and Error Quiz Solution

| The fact that the call to double three returns nine instead of six is clearly |
| a failure because it is an observable incorrect behavior of the program. |
| So let me remind you that the failure is conceptually related to the |
| behavior of the program, to the way the program acts and not its code. |

## 239 - Failure -  Fault -  and Error Quiz Question

| So now, let me ask you a second question. We just saw that we |
| can, reveal a failure in the program |
| by calling double with parameter three. Where |
| is the fault that causes such failure in the program? So I want you |
| to write the number of the line of code that, that contains the fault. |

## 240 - Failure -  Fault -  and Error Quiz Solution

| Before telling you what the right answer is, let |
| me remind you that the fault is related to |
| the code, and is a necessary, but not sufficient |
| condition for the occurrence of a failure. So in this |
| case, a single faulty line is responsible for the |
| failure, which is line three. So the correct answer, is |
| three. At line three, the program computes i times |
| i, instead of i times 2, as it should do. |

## 241 - Failure -  Fault -  and Error Quiz Question

| So, I want to ask you one last question about |
| this problem. What is the error that cause the fault |
| at line three? Remember that an error is the |
| cause of a fault and it's usually a human error. |

## 242 - Failure -  Fault -  and Error Quiz Solution

| And I apologize, but this was a tricky question that |
| we cannot really answer. We really have no way to |
| know what the error was. It could have been a |
| typo, an erroneous copy and paste operation, or even worse |
| a conceptual error. In case a developer did not know |
| what it means to double a number. Unfortunately though, the |
| developer is the only one who could actually answer this |
| question. So even though we cannot really answer this question, |
| having it help us think about how the |
| error is in fact related to human behavior. |

## 243 - Verification Approaches

| Now that we got out of the way this |
| initial set of basic definitions. Let's go back to our |
| main concept, which is software verification. We said that software |
| is buggy, and because software is buggy, we need to |
| verify the software as much as we can. But how |
| can we verify software? There are several ways to verify |
| a software system. Among those, we will discuss four mainstream |
| approaches. The first one is testing, also called dynamic verification. |
| The second approach is static verification. The third approach is |
| inspections. And finally, we're going to consider a fourth approach which is |
| formal proofs of correctness. So what I'm going to do |
| next, I'm going to first provide an overview of these approaches and |
| then discuss some of them in more depth and please |
| note that although we will discuss all four approaches we will |
| spend most of our time on software testing. As software |
| testing is the most popular and most used approach in industry. |
| So let's start with our overview and in particular |
| with testing. Testing a software system means exercising the system |
| to try to make it fail. More precisely, let's consider |
| a program. Its input domain, which is the set of |
| all the possible inputs for the program and, its output |
| domain, which is a set of all the possible corresponding |
| outputs. Given this context, we can define what a test |
| case is. A test case is a pair that consists |
| of a, an input from the input domain D, |
| and then, expected output O from the output domain. |
| And O is the element in the output domain |
| that a correct software would produce when ran against I. |
| We can also define the concept of test suite, |
| which is a set of test cases, and we're going to |
| use these two concepts of test case and test |
| suite quite a bit in the rest of the lessons. |
| Subject verification, tries to identify specific classes of problems |
| in the program. Such as null pointer dereferences. And |
| unlike testing, what it does is that it does |
| not just consider individual inputs, it instead considers all |
| possible inputs for the program. So it consider in |
| a sense all possible executions of the program and |
| all possible behaviors of the program, that's why we |
| save the verification unlike testing it's complete. The 3rd technique |
| we are going to consider is inspections, |
| and inspections are also called reviews or walkthroughs. |
| And unlike the previous techniques, inspections are a |
| human intensive activity, more precisely, they are a |
| manual and group activity in which several |
| people from the organization that developed the software, |
| look at the code or other artifacts developed |
| during the software production and try to identify |
| defects in these artifacts. And interestingly inspections |
| have been shown to be quite effective in |
| practice and that's the reason why they're used |
| quite widely in the industry. Finally, the last |
| technique I want to mention is Formal |
| Proof (of correctness). Given a software specification, and |
| actually a formal specification, so a document that |
| formally defines and specifies the behavior, the expected |
| behavior of the program. A form of proof of |
| correctness proves that the program being verified, actually implements |
| the program specification and it does that through a |
| sophisticated mathematical analysis of the specifications and of the code. |

## 244 - Pros and Cons of Approaches

| The four different techniques that we just discussed have |
| a number of pros and cons. So next we |
| are going to discuss the main pros and cons |
| for these techniques, so as to be able to compare |
| them. When testing is concerned the main positive about |
| this technique is that it does not generate false |
| alarms. In other words, it doesn't generate false positives. |
| What that means, is that when testing generates a failure, |
| that means that there is an actual problem in the |
| code. The main limitation of testing, however, is that it |
| is highly incomplete. Consider again the picture that we drew |
| a little earlier. The one representing the input domain of |
| the program being tested. Even in the best scenario, testing |
| can consider only a tiny fraction of the problem domain, |
| and therefor a tiny fraction of the program's behavior, and |
| we'll say a lot more about that in the following lessons. |
| Static verification, unlike testing, has the main advantage |
| that it considers all program behaviors. If we |
| look back at our diagram, whereas testing will |
| select only a few of those inputs, static verification |
| will consider them all. Unfortunately, however, this comes |
| with a price. Due to limitation of this |
| kind of analysis and due to infeasibility issues, |
| static verifiation considers not only all the possible behaviours, |
| but also some impossible behaviors. And what that means is |
| that static gratificaition can generate false positives. And this is, |
| in fact, the main issue with static verification techniques. As |
| we will further discuss later in the class, static verification can |
| generate results that are not true. For example, it might |
| report a possible no point of the refernce that cannot |
| actually occur in practice. The strongest point about inspections is |
| that, when they're done in a rigorous way, they're systematic and |
| they result in a thorough analysis of the code. |
| They are nevertheless a manual process, a human process. |
| So they're not formal and their effectiveness may depend |
| on the specific people performing the inspection. So its results |
| can be subjective. Finally, the main pro about formal |
| proofs of correctness is that they provide strong guarantees. |
| They can guarantee that the program is correct, which |
| is not something that any of the other approaches can |
| do, including study verification. But the main limitation of |
| formal proofs is that they need a form of specification, |
| a complete mathematical description of the expected behavior of |
| the whole program, and unfortunately such a specification is rarely |
| available, and it is very complex to build one. |
| In addition, it is also very complex, and possibly expensive, |
| to prove that the program corresponds to a specification. |
| That is a process that requires strong mathematical skills and, |
| therefore, a very specialized personnel. |

## 245 - Verification Approaches Quiz Question

| So let's have another simple quiz, and we're going to |
| have our developer Brett introducing the quiz. And the |
| starting point for this quiz is the fact that |
| today, quality assurance, or verification, if you wish, is mostly |
| testing. That is, testing is the most commonly used |
| activity to perform software verification. So now, I'm going to show |
| you a quote, 50% of my company employees are |
| testers and the rest spends 50% of their time testing, |
| so I want to ask you, who said |
| that? I'm going to give you some possibilities. Was |
| that Yogi Berra, Steve Jobs, Henry Ford, Bill |
| Gates or Frank Gehry? Take your best guess. |

## 246 - Verification Approaches Quiz Solution

| And the correct answer is Bill Gates. So this gives you an idea of how |
| important testing is in Microsoft in particular, |
| but in many other software companies in general. |

## 247 - Testing Introduction

| So let's talk more about testing, as we said a |
| little earlier in the lesson, testing means executing the program on |
| a sample of the input domain, that is of all |
| the possible input data and I really want to stress that |
| this sample is tiny sample of the input domain. There |
| are two important aspects of testing that I'm want to mention here, |
| there first one is that testing is a dynamic technique. And |
| what that means is that the program must be executed in |
| order to perform testing. The second important point is that |
| testing is an optimistic approximation. And what does it mean |
| to be optimistic? Well, it means that the program under |
| test is exercised with a very small subset of all the |
| possible inputs as we just said. And this is done |
| under the assumption that the behavior with any other input |
| is consistent with the behavior shown for the selected subset |
| of input data, that is why it is an optimistic approach. |
| Another concept that I want to mention explicitly, is the |
| concept of successful test. And I'm going to do that, |
| using another quote. This one from Goodenough and Gerhart |
| in their paper Towards a Theory of Test Data Selection, |
| and what the quote says is that a test |
| is successful if the program fails. And this might sound |
| counterintuitive, but the point here is that testing cannot |
| prove the absence of errors, but only reveal their presence. |
| If a set of tests does not produce any failure, we are either in the extremely |
| unlikely case of a correct program, or in |
| the very likely situation of a bad set of |
| tests that are not able to reveal failures of the program. And that is why we |
| say that the test is successful if you |
| can show that there are problems in the program. |

## 248 - Testing Granularity Levels

| And before I start talking about specific testing techniques, there's |
| something else that I want to discuss, which is Testing |
| Granularity Levels. So let's consider a software system, a system |
| made out of components that interact with one another. So the |
| first level that we consider in testing is called Unit |
| Testing, which is the testing of the individual units or modules |
| in isolation. The next step, is to see there are |
| multiple modules and their interactions. And this is called Integration Testing. |
| So, integration testing is the testing of the interactions among |
| different modules. And it can be performed according to different |
| strategies. Depending on the order in which the modules are |
| integrated and on whether we integrate one module at a time |
| or multiple modules together, all at once. And in this |
| latter case, we call this kind of integration testing, the one that |
| integrates all the modules at once, Big Bang integration testing. |
| And after performing integration testing, the next step is to test |
| the complete system as a whole. And this level of |
| testing is normally called, System Testing. So system testing in the |
| testing of the complete system and it includes both functional and |
| non functional testing. We will discuss functional and non functional testing |
| in details in the next two lessons. But I just |
| want to give you an idea of what they are intuitively. Functional |
| tests are the test that aim to verify the functionality provided |
| by the system. For example if you consider the function double |
| value that we saw earlier in the lesson, a |
| functional test will try to assess that that function |
| is producing the right value given a specific input. |
| Conversely, no functional test are the one that target, as |
| surprisingly, no functional properties of the system. For example, |
| no functional test will include performance tests, load tests, |
| robustness tests. In general, no functional tests will try |
| to assess different qualities of the system, such as reliability, |
| maintainability, usability, so basically, all the ilities that you can |
| think about. In addition to these three basic testing levels, there |
| are two more levels that I want to consider and that |
| I want to discuss. And they both involve the whole system. |
| And the first one is Acceptance Testing which is the |
| validation of the software against the Customer requirements. So this is |
| the testing that makes sure that the system does what the |
| customer wants it to do. And the last type of testing |
| that I want to mention is Regression Testing. And regression testing |
| is the type of testing or retesting, that we perform every time |
| that we change our system. And we need to make sure |
| that the changes behave as intended and that the unchanged code is |
| not negatively affected by the modification, by these changes. In fact, |
| what can happen when you modify the code is that parts of |
| the code that are related to the changes, are actually affected |
| by the changes, and start misbehaving. And we call those regression errors. |
| And regression errors, are very common. For example, you're probably |
| familiar with the situation in which, one software update is |
| released, and just a few days later, another software update |
| is released. In many cases that happens because the first update |
| was containing regression errors. So the changes in the code |
| that broke some functionality, that resulted in failures on the user's |
| machine and in bug reports and therefore that caused further |
| maintenance, further bug fixes, and a release on a new version. |
| Something else I'd like to mention about regression testing, is that |
| regression testing is one of the main causes why software maintenance is |
| so expensive. And that's also why researchers have invested a great |
| deal of effort into refining regression |
| testing techniques that can make regression |
| testing more effective and more efficient. So let me leave you, |
| with a little piece of advice which is try to automate as |
| much as possible regression testing. For example use scripts, use tools, make |
| sure to save your harness, make sure to save your input, and |
| outputs for the test, because you want to be able |
| to rerun your test, at a push of a button as |
| much as possible every time you change your code, to |
| avoid the presence of regression errors in the code you release. |

## 249 - Alpha and Beta Testing

| All the testing levels that we've seen so far is what |
| we can call developer's testing. So that's testing that is performed |
| either within the testing organization, or by somebody who's doing like |
| third-party testers on behalf of the testing organization. But there are two |
| other kinds of testing that are worth mentioning that are also |
| related to testing phases and these are alpha and beta testing. |
| Alpha testing is the testing performed by distributing a software system |
| ready to be released to a set of users that are internal |
| to the organization that developed the software. So you can consider these |
| users as, if you pass me the term, guinea pigs that will |
| use an early version of the code and will likely discover errors |
| that escaped testing and will have made it to the field if |
| not caught. Beta testing is the next step after alpha testing, in |
| which the software is released to a selected subset of users, in |
| this case, outside your organization. And also in this case, the users |
| are likely to discover latent errors in the code before it is officially |
| released to the broader user population, so before we have an |
| actual product release. So you may wonder why do we need |
| to do both alpha and beta testing. Why not just one |
| of the two? The reason is that alpha testing is performed |
| to iron out the very obvious issues that still escape testing, |
| but we want to do that before involving people outside your |
| organization. And the rationale is that alpha testers have a higher |
| tolerance for problems than beta testers, who expect a mostly working system. |

## 250 - Black and White Box Testing Introduction

| We're almost at the end of this lesson. In the |
| next two lessons we're going to talk about two main families |
| of testing techniques, black-box testing |
| techniques, and white-box testing techniques. So, |
| what I want to do before getting into the discussion of the |
| specific techniques in this families. I want to give you an |
| overview of what black-box testing and white-box testing are. Black box |
| testing is the kind of testing in which we consider the |
| software as a closed box. That's why it's called black box. |
| So we don't look inside the software, we don't want to |
| look at the code. We just going to look at the description |
| of the software. So this is the testing that is based |
| on a description of the software, which is what we normally |
| call the specification for the software. And what black box testing |
| tries to do is to cover as much specified behavior as |
| possible, and the main limitation black box testing and the reason |
| why this is complimentary to white-box testing is that it cannot reveal |
| errors due to implementation details. Conversely, white-box testing |
| is the kind of testing that looks inside the |
| box. So looks at the code and how |
| the code is written and uses this information to |
| perform the testing. So white-box testing is based |
| on the code, its goal is to cover as |
| much coded behavior in this case, as possible, and |
| its limitation is that unlike black-box testing, it can't |
| reveal errors due to missing paths. Where missing paths are |
| a part of a software specification that are not implemented and |
| the reason why you can not reveal them is because |
| it is focused on the code and not on the specification. |

## 251 - Black Box Testing Example

| To give you a slightly better understanding of the differences |
| between black-box testing and white-box testing, I am going to provide you |
| a couple of simple examples that illustrate the, the strengths and |
| limitations of these two techniques. So, in this case, let's start |
| with black-box testing, so we're only working with this specification. |
| So, let's say that our specification says that this is a |
| program that inputs an integer value and prints it. And implementation, |
| we don't know because we're working at the black box level. |
| If we wanted to test this function according to its |
| specification, what we will probably do is to select a positive |
| integer, a negative integer, and the zero as test inputs |
| and see how the program behaves for these inputs. So let |
| me now show you a possible implementation for this specification. |
| What I'm showing here is this function that we called print |
| NumBytes, which takes the parameter and prints it. And one thing |
| that we notice right away is that, although in the specification, |
| numbers that are less than 1024 and numbers that |
| are greater or equal to 1024 are exactly equivalent from |
| the specification standpoint. They're however treated differently in the |
| code, so the developer decided that the program was just |
| going to print the value of the parameter if it's |
| less than 1024. But it was actually divided by 1024 |
| and printing it with a kilobyte mark after it |
| if you are greater than 1024. And notice that here, |
| there is a problem. The developer, just a number 124, instead |
| of 1024. So there's probably a typo in this point in the |
| code. So this is a case in which by simply doing black-box |
| testing, so by simply looking at the specific issue, we might miss |
| this problem. Because we have no reason to consider numbers that are |
| less than 1024 or greater than 1024. However if we were to |
| look at the code, so operating at white-box manner, we will right |
| away see that we need to have a test case that checks |
| the program when the parameter is greater than 1024. And we will find |
| the problem right away. So now let me show you a dual example. |

## 252 - White Box Testing Example

| In this case we focus on white box testing. So consider now this |
| other function, called fun. And let's assume that we want to test this function |
| without having a specification. So without knowing exactly what it needs to do. |
| But just by looking at the code. So we will try to do the |
| problem in this case is to try to just execute all the statements. |
| In the function. And notice I will talk extensively of what does it |
| means to do white box testing later on in the next, two classes. |
| So if that's our goal, if our goal is to cover all the statements, |
| any input will really do. So any test case |
| will excecute all statements in the code. And we'll a |
| complete, you know, white-box testing coverage for the program. |
| Imagine that I now give you a specification for this |
| function. And what the specification says is that this |
| function inputs an integer parameter, param, and returns half of |
| its value, if param is even, and its value |
| unchanged otherwise. That means if param is odd. So looking |
| at this specification, we can clearly see that the function fun |
| works correctly only for even integers, and it doesn't work for |
| odd integers. Because it computes. Half of the value of the |
| parameter and returns it every time, no matter what param is. So |
| this is a case in which white box testing could easily |
| miss the problem, because as we said any input will exercise |
| the code. It's just by chance that we could reveal one |
| that revealed the problem in the code. Conversely if we were to |
| work, in a black box manner. Typically looking at the specification, we |
| will select at least one odd, and one even input number to |
| exercise all of the specified behavior. And we will find the problem |
| right away. So these two examples are just very small examples, and |
| they're kind of, you know, stretched. But these kind of issues occur |
| on a much bigger scale and in much more subtle ways in |
| real world software. And so what this examples do is to show |
| you, how black box and white box tests are really complimentary techniques. |
| So in the next two lessions we will explore |
| these two types of techniques in detail. We will |
| see different kinds of white box and black box |
| testing. And we'll talk about their strengths and the mutations |

## 253 - Lesson Overview

| In the previous lesson, we discussed the fundamental |
| concepts behind software verification in general, and software testing |
| in particular. In this lesson, we will discuss |
| one of the two main testing approaches. Black box |
| testing, also called functional testing. We will cover |
| the main characteristic of black box testing, its pros |
| and cons, and discuss some commonly used black |
| box testing techniques. We will conclude the lesson with |
| a practical exercise in which we will apply a specific black |
| box testing technique to a real program. We will derive test |
| cases for the program and assess how the use of a |
| systematic approach, in contrast to a brute force approach, can help. |

## 254 - Overview

| As we said at the end of the previous lesson, black-box testing is |
| the testing of the software when we look at it as a black box, |
| as a closed box, without looking at it inside, without looking at the |
| code. And there are several advantages in |
| using black-box testing. So let me recap |
| those advantages, some of which we already mentioned, and let me also expand |
| on that a little bit. The first advantage of when I mentioned is that |
| black box focuses on the domain, on the input domain of the software. And |
| as such, we can use it to make sure that we are actually covering |
| this domain, that we are actually covering the important behaviors of |
| the software. A second advantage is that black box testing does not |
| need the code. What that means is that you can perform early |
| test design. So you can start designing and writing your test cases, |
| even before writing your code, so that when the code is |
| ready, we can test it right away. And that helps prevent a |
| problem that is very typical in real life software development, which is |
| getting an idea of the project and having no time to create |
| the tests. In this way, we already have the tests, so |
| we just have to run them. Another advantage is that black-box testing |
| can catch logic defects, because it focuses on the description of what |
| the software should do, and therefore on its logic. If we derive |
| test cases from such description, then we can catch these kind of |
| problems. And finally, black-box testing is |
| applicable at all granularity levels, which |
| means that we can use black-box testing in unit testing, integration testing, |
| system testing, and so on. We can use it at all levels. |

## 255 - Systematic Functional Testing Approach

| So what is the starting point of black box testing? Black |
| box testing start from a description of the software or as we |
| call it, a functional specification. And the final result of black |
| box testing is a set of test cases, a set of actual |
| inputs and corresponding outputs that we can use to exercise our |
| code and to try to find defects in our code. So the |
| question is, how do we get from functional specification to test |
| cases? Doing these derivations, so going from this description to a concrete |
| set of tests, is a very complex analytical process. |
| And normally brute force generation is not a good |
| idea because it's inefficient and ineffective. What we want |
| to do instead is to have a systematic approach to |
| derive test cases from a functional specification. What a |
| systematic approach does is to simplify the overall problem by |
| dividing the process into elementary steps. In particular, in |
| this case, we will perform three main steps. The first |
| step is to identify independently testable features. Individual features in |
| the soft hood that we can test. And we're going to |
| expand on each one of these steps in the next |
| part of the lesson. The following step is once we have |
| these independently testable features to identify what are the relevant |
| inputs. So what are the inputs or the behavior that is |
| worth testing for these features. Next once we have these |
| inputs, we're going to derive test |
| specifications. And test case specifications are |
| description of the test cases that we can then use |
| to generate actual test cases. And proceeding in this way, |
| by this steps, has many advantages. It allows for the |
| coupling different activities. It allows for dividing brain intensive steps from |
| steps that can be automated, which is a great advantage. |
| And also we will see, it allows you for monitoring |
| the testing process. So to figure out whether your testing |
| process is going as expected, for example, if you're generating too |
| many test cases. Or you're generating the number of test cases that your |
| amount of resources available allows you to run. So let's start by looking |
| at the first step of this process in which our goal is to |
| go from a Functional Specification to a set of features that we can |
| test in the software. So what we want to do is to identify all |
| of the feature of the software. And why do we want to do this? |
| Well you know, in the spirit of breaking down the complexity of the |
| problem, it does not make sense to just try to devise test cases for |
| all the features of the software at once. For any non-trivial |
| software, that's a humongous problem, and something that we cannot really |
| handle effectively. A much better way is to identify independently testable |
| features and consider one of them at a time when generating tests. |

## 256 - Overview Quiz Question

| So, now I want to do a little quiz about |
| identifying testable features. Let's consider |
| this simple problem called printSum. |
| We won't see the implementation because we are doing black-box |
| testing. And all we need to know is that printSum takes |
| two integers, a and b, and prints the sum of |
| these two numbers. So what I want to ask, is |
| how many independently testable features do we have here? Do |
| we have one, two, three features? Or more than three features? |

## 257 - Overview Quiz Solution

| Sum is a very simple program, that only does one thing, |
| summing two number, adding two numbers. So the answer in this |
| case, it's one. There's only one feature that we can test |
| in PrintSum. So let's look at the slightly more interesting example. |

## 258 - Overview Quiz Question

| Let's look at this spreadsheet. I'm pretty sure most of you |
| are familiar with what a spreadsheet is and have used them before. |
| So now I'm going to ask the same question, which is I'd |
| like you to identify three possible |
| independently testable features for a spreadsheet. |

## 259 - Overview Quiz Solution

| In this case there's not really a right answer because there's |
| many, many features that you could identify in a piece of |
| software as complex as a, a spreadsheet. So I'm just going |
| to give you three examples. So one could be the cell merging |
| operation. So the operation in which we merge two cells in |
| the spreadsheet. Another example could be chart creation, so I might want |
| to test the feature that allows you to create charts in |
| your spreadsheets. Yet another example could |
| be the test of statistical functions, |
| so the function that allows you to do various statistical calculations on |
| the numbers in your cells. And as I said there's many, many |
| more example that we could use. But the key thing I want |
| to convey here is the fact that there is no way you |
| can look at a spreadsheet with all the functionality that it provides |
| and just go and test it. The first step, what you need |
| to do first, is to identify which ones are the pieces of |
| functionality that I can test individually. So that's why this is the |
| first step in black-box testing. |

## 260 - Test Data Selection

| Once we have identified Independently Testable Features, the next step is to |
| identify the Relevant Inputs for each one of these features. And there are |
| many ways to do that. So, what we're going to do, instead of |
| looking at them all, is that we're just going to focus on two different |
| ways of doing it. And they are fairly general ways. So, they |
| are applicable to a number of situations. And in addition, what I will |
| do, I will point you to other sources in which you can |
| look at different ways of doing this in the class notes. The problem |
| of identifying relevant inputs for some Software or some feature |
| of it is called Test Data Selection and can be expressed |
| as followed. Let's consider our software as usual we have |
| our Input Domain, which is the set of inputs for all |
| the software. And again as usual, we have our Output |
| Domain, which is the set of corresponding outlets for these inputs. |
| So the question here is, how can we select a meaningful |
| set of inputs in my domain? And of course corresponding outputs |
| because we know that test cases are an input, plus an |
| expected output. So how can we select interesting inputs for our |
| software? So a set of inputs that, after we run them |
| on the software, if the software behaves correctly, we'll have enough |
| confidence that the software is correctly implemented. So one possible idea |
| is, hey, why don't we just test them all? We just |
| do exhaustive testing. We do all the inputs, nowadays we have |
| powerful machines, we have a lot of computational power in the cloud. |
| Why not just doing it? So to answer that |
| question, what I'm going to do? I'm going to use another quiz. |

## 261 - Test Data Selection Quiz Question

| So I'm going to ask you something. Which is if |
| we consider again our function print sum, the one |
| that takes two integers and prints the sum. How |
| long would it take to exhaustively test this function? And |
| this is a very simple one. There's just two |
| inputs, right? So we can just enumerate them all. |
| And put them throw them at the computer form, |
| and wait for the results. How long would that take? |

## 262 - Test Data Selection Quiz Solution

| Okay, so now we're going to answer the question. So if we want |
| to consider all these inputs, and run them all on the software, |
| let's see how it will work. Let's assume that these are, 32 |
| bit integers. So at this point what we will have is, a |
| number of combination, which is 2 to the 32, times 2 to |
| the 32. They're two integers. This is equal to 2 to the |
| 64, which in turn, is more or less equal, to 10 to |
| the 19. So 10 to the 19 is the number of tests that |
| we need to run to cover the whole domain. Now let's assume |
| that we can run one test per nanosecond. So what that means |
| is that we can run 10 to the 9 tests per second, |
| and that's a lot. If we do the math, that results in 10 |
| to the 10 seconds over all, because we have 10 to the |
| 19 tests, we could run 10 to the 9 tests per second |
| so, we do the math, and we can run all these tests |
| in 10 to the 10 seconds. And what that corresponds to, it's about |
| 600 years, so a lot of time. So even for such |
| a simple problem, a problem that takes two integers and adds them, |
| it will take more than 500 years to test it exhaustively. So |
| the bottom line here is that we just can't do exhaustive testing. |

## 263 - Why Not Random Testing

| So then maybe what we can do is just to |
| pick our test inputs randomly so to do what is called |
| random testing. And what that means is that we pick the |
| inputs to test just as we pick a number by rolling |
| a set of dice randomly. And this will have several advantages. |
| First, we will pick inputs uniformly. So if we use a |
| uniform distribution as the basis for our random testing, we will |
| make no preferences. In other words, all inputs will be considered |
| equal, of equal value. And what that means in turn, is |
| that random testing eliminates designer bias. So what does designer bias |
| mean? Designer bias is the problem of making the same assumption, |
| when we read the specification and we interpret it and when we |
| develop test cases. Which means that the developer might develop code, |
| assuming a given behavior of the user. And we may write |
| tests, making the same assumptions. And the problem, of course, is |
| even worse if it's the same person that develops the code and |
| writes the test cases. With random testing, the problem is gone, |
| because we just pick randomly what our inputs will be. So |
| why not do in random? The problem is that when testing, |
| we are looking for a needle in a haystack. Actually, multiple |
| needles in multiple haystacks, if we want to be precise. So, |
| random approaches are not necessarily the best way to go about |
| it, because we might just be looking in all the wrong |
| places. So let me show you this, using a different representation |
| for the haystack. What I'm showing here is a grid, and |
| imagine this grid just expanding indefinitely outside the screen, and this grid |
| represents the domain for the program, so each box in the grid, |
| each square in the grid, it's a possible input. So what happens |
| with bugs is that bugs are very scarce in this grid. Maybe |
| there is a bug here, so that means that there is a |
| bug, than an input, in this point we'll reveal. And maybe there |
| is another bug that will be triggered by an input over here. |
| So imagine this spread out over this infinite grid. Its very unlikely |
| that just by picking randomly that we will be able to get to |
| these two points. Fortunately not all is lost, there is a silver lining. |
| So we need to look a little more in depth into this grid. |

## 264 - Partition Testing

| So let me use a slightly expanded version of this |
| grid. Although we're indeed looking at a needle in a haystack. |
| And failing inputs are generally sparse, very sparse, in the input |
| domain. However, they tend to be dense in some parts of |
| the domain. Like here or here. So how can we leverage |
| this? The fact that the failures are dense in some subdomains? |
| As it turns out, the domain is naturally split into partitions. |
| Where partitions are areas of the domain that are treated homogeneously |
| by the software. And this is what happens, that normally, |
| failures tend to be dense in this partitions. So the way |
| to leverage this characteristic of failures, is that we don't know |
| want to pick inputs randomly, in the input domain. Just here |
| and there. Rather we want to do two things. First we |
| want to identify partitions of our domain. And second we want |
| to select inputs from each partition. And by doing so, we |
| can dramatically increase our chances to reveal faults in the code. |
| So the name that is normally used for this process, is partition testing. |

## 265 - Partition Testing Example

| So let's look at how this will work with an example. |
| I'm going to use this simple program that takes two inputs. The |
| first input is a string, str, and the second one is |
| an integer, size. And the problem is called split. And as |
| the name says what it does is to take this string, |
| str, and split it into sub string, into chunks of size |
| characters each. So how do we identify some possible partitions for |
| this program? If we consider the input size, we can identify |
| three neutral partitions which are size less than 0. For example, |
| we want to test how the program behaves. But if we pass an |
| incorrect size, size equal to 0, which is also a partition. In |
| this case, a partition with a single element. And the third case |
| is size greater than 0, which I will consider to be |
| kind of the standard case. And actually let me do a, you |
| know, slight aggression so when I was talking about designer bias. So |
| this is a case in which designer bias might not make you |
| think of using size less than 0 because you read the |
| spec. And you sort of assume that the size will be positive. |
| Whereas the right thing to do when we test is to consider |
| the complete domain rather than just parts of it. So now let's |
| look at string, str, and let's see what kind of sub |
| domains we could identify for this |
| parameter. And notice another important aspect |
| here is that we treat each different part of the input independently, |
| which also helps breaking down the problem. One interesting sub domain is |
| the domain that includes all the strings whose length is less than |
| size. So all the strings that will not be displayed. Another subdomain |
| is all the strings with length which is between the value of |
| size and twice the value of size. A third subdomain is the one |
| including all the strings whose length is greater than twice the value |
| of size. And we can continue and identify more and more subdomain. |
| The key thing here is that we have to do that based |
| on the domain. So we need to adapt what we just did here |
| based on, on the specific domain involved and on the type |
| of data in this domain. So at this point we said that |
| there were two steps. One was to identify the subdomains and |
| the second one was to pick values in this subdomain. The values |
| that we'll actually use for the testing. In this case, we |
| do not want to just pick any value. Rather we want to |
| pick values that are particularly |
| interesting, particularly representative. So what does |
| that mean? Well, we're going to do that based on an intuitive idea. |

## 266 - Boundary Values

| So let's go back again to our domain, with |
| all the sub-domains identified. And the basic idea, or the |
| intuitive idea I was talking about, is that errors tend |
| to occur at the boundary of a domain, or a |
| sub-domain. Like in this case. And why? Because these |
| are the cases that are less understood by the developers. |
| Like for example, the last iteration of a loop, or |
| a special value like zero for integers. So if this |
| is true, what we want to do is to select inputs at these |
| boundaries. And this is complementary to partition |
| testing, in the sense that partition testing |
| will identify the partitions in which we want to select inputs, and boundary |
| testing. So the selection of boundary values |
| will help select inputs in these partitions. |

## 267 - Boundary Values Example

| So now let's go back to our split example. Let me |
| rearrange things a little bit to make more room. So now I'm |
| going to put the domains for size and for strength one next to |
| the other. So let's look at what some possible inputs will be |
| for the sub domains that we identified when we use the idea |
| of selecting input of the boundary. If we look at the first |
| subdomain, size less than zero, one reasonable input is, size equals to |
| minus 1, because minus 1 is the boundary value for the domain |
| of the integers less than zero. If we look at the third |
| subdomain, possibly interesting case is the one of size of equal to |
| 1, for the same reasoning that we used for the previous subdomain, |
| for size less than zero. And, let's try to select another one |
| for this subdomain, for the integers greater than zero. If there is |
| a concept of maximal integer, we can select that one as our |
| boundary value. And of course we could select much more, but this |
| is just to give you an idea. Other possible inputs. One interesting |
| example for the first one, string with length less than |
| size will be a string with length size minus one. Again |
| this is the boundary value for this domain. And we could |
| continue in this way like for example selecting a string who's |
| length is exactly size as a boundary value for this |
| other domain. Instant one, and we look back actually to this |
| example and look at it in a more extensive way when |
| we actually talk about a specific method for doing this kind |
| of process. |

## 268 - Deriving Test Case Specifications

| Now, let's go back to our systematic functional testing |
| approach and all the steps in this process. So |
| far we've seen the first step and the second |
| step. Now we're going to look at this step in which, |
| once we have identified the values of interest, we |
| derive test case specifications for these values, or using these |
| values. And the test case specification defines how the |
| values should be put together when actually testing the system. |
| And test case specification describe how these values should be put |
| together when testing the system. So let me go back one more |
| time to our split program, so that we can use the |
| information that we already computed. At this point what we have is |
| some possible inputs for "string," our first parameter, and for "size," |
| our second parameter. And we want to put them together, to generate |
| the description of what the test case should be. So let |
| me once more rearrange this a little bit. I first remove the |
| description of the subdomains, because we won't use them in this step. |
| And I moved out the set of all our possible inputs, that we're |
| going to combine to create the test case specification. And one possible way |
| of doing that is simply to combine the values for the first parameter, |
| and the values for the second parameter. So the Cartesian product. So |
| if we do that, what we will obtain is, for example, if we |
| consider the first possible input, size is equal to minus 1, we can |
| combine it with these two possible inputs for string, and we will get |
| size is equal to minus 1 string with length minus 2, or |
| size is equal to minus 1 string with length minus 1. And we'll |
| go back in a second to see what this means. Now if we |
| consider the second possible value for size, size is equal to one, we |
| also have two cases so the first one in this case that will |
| be considered a string with length zero. So the antistring. And we can |
| continue combining this value, but one thing I want to point out is |
| that if we just go in this straight forward and brute force sort |
| of way, we will obtain many combinations that don't make any sense, |
| like for example, this combination which doesn't make any sense because we can |
| not create the string with length minus 2. Similar for this combination, because |
| then by the same token, we cannot raise things with length minus 1. |
| And so there's a lot of cases that we will have to eliminate |
| afterwards. So what we're going to see in a few minutes is a possible |
| way in which we can avoid producing these meaningless cases. And at the |
| same time, keep under control, the number of test cases that we generate. |
| So let's go back for the last time to our steps |
| for systematic functional testing. What we just did was to derive |
| test case specification from a set of relevant inputs. The following |
| step is to use these test case specifications to generate actual test |
| cases. And this is normally a fairly mechanical step in the |
| sense that we just have to instantiate what is in the test |
| case specification as actual test cases. And it's really dependent on |
| the specific type of partitions and values identified on the specific context. |
| So instead of looking at that here in the, in the abstract, |
| I'm going to show you with an example later on, in the lesson. |

## 269 - Category Partition Method

| What we will discuss next is a specific black-box testing |
| approach. So a specific instance of the general approach that |
| we just saw. And this approach is the category-partition method, |
| and was defined by Ostrand & Balcer in 1988 in |
| an article to the peer [UNKNOWN] communication of the ACM. |
| So this is a method for going from a specification, |
| a description of the system, to a set of test |
| cases like any other black-box testing approach by following six steps. |
| So let's look at what these steps are. The first |
| step is to identify independently testable features and this is |
| a step that we are familiar with because its exactly |
| the same step that we performed in the generic black box |
| testing approach that we just discussed. The second step is |
| to identify categories. Then the next step is to partition |
| categories into choices. Identify constraints |
| among choices. Produce and evaluate |
| test case specifications. And finally, the sixth step is to generate |
| test cases from test case specifications. So two of |
| the key elements in these six steps are the two |
| that give the name to the technique so the identification |
| of the categories and the partition of these categories into |
| choices. What we're going to do next is to go |
| and look at each one of the steps independently, except |
| for the first one. Because we're already familiar with that |
| step, and this method doesn't really add much to it. |

## 270 - Identify Categories

| In the second step of the category partition technique, the goal is |
| to Identify Categories. Where categories are |
| characteristics of each input element. So |
| let me illustrate what that means using an example. And to do |
| that I'm going to use again the example of the split program, as |
| we are already familiar with it and we kind of already played |
| with it. When we were talking about the generic black box approach. |
| So let me bring back the program, and let me remind you |
| that what the program does is to take two inputs, a string and |
| the size, and it breaks down the string into chunks, |
| whose length is size. If we look at the split program |
| there are two input elements, str and size so we going to |
| identify categories for these two. So starting from str, what are |
| the interesting characteristics of the string? In, in this step |
| you're going to use your domain knowledge, your understanding of what a |
| string is, and for example we might identify the length of |
| the string and the content of the string as the two |
| main characteristics that we want to focus on. If we now |
| move our focus to size, the only characteristic I can really |
| think of for an integer is its value. So that's what |
| I'm going to mark here. So at the end of the step |
| what we have is that we have two categories. So two |
| interesting characteristics for the string input str, which are the length |
| and the content. And one category for the integer input size |
| which is its value. And notice that there's not only one solution. |
| So there's not only one possibility. |
| So that the specific characteristics that you |
| will identify are somehow subjective. But the |
| important point is that you identify characteristics |
| that are meaningful and they sort of cover the main aspects of the |
| inputs, which is the case for the |
| categories that we've identified in this example. |

## 271 - Partition Categories into Choices

| Now we move to the next step, which involves partitioning the |
| categories that we just identified into choices. And these choices are the |
| interesting cases for each category. So the interesting subdomains for each one |
| of these categories. So once more, let's look at that using our |
| example, the split program. So let's start by considering length. What are |
| the interesting cases when we think about the length of a string? |
| Some of those we already saw, one interesting case is the case |
| of the length of size zero, so a string with no characters. |
| Another interesting case is the one in which the length of the |
| string is size minus one, so the string is just one character |
| short of the size at which it will be cut by the |
| split program. And we can continue along these lines, so we will select |
| size, size plus one, size twice the value of size minus one, |
| and so on and so forth. But even without listing all of |
| those, I'm sure you get the idea of what it means to |
| identify this interesting cases. Let's see |
| the movements that are considering the content. |
| So without the interesting cases when we think about the content |
| of the string. So possible interesting case is the string that |
| contains only spaces. Why? Well maybe because a split is written |
| spaces in a special way. Similarly a string that contains special |
| characters, like non printable characters, |
| like tabulation characters, new line might |
| also be an interesting case, something that we want to test. Also |
| in this case we could continue and go on and on. |
| So basically here you just want to put all the interesting cases |
| that you can think of when you consider the content |
| of a string. Now let's move to the value as the |
| next category. So the value of the input size. And |
| here we might want to consider a size zero, special case, a |
| normal situation, like size greater than zero, another special case, |
| size less than zero or maxint. And these are, if you |
| remember, I accepted the cases that we consider when we look |
| at this example, before. And also here we can continue and |
| go on and on. So, at the end of the |
| step, what we have is a set of interesting cases |
| for each one of the categories, and now we can |
| start to think about how we want to combine them. |

## 272 - Identify Constraints Among Choices

| Something that we saw when we were looking at the split |
| program before is that if we just combine the interesting values that |
| we identify, we might end up with a lot of cases. |
| And I mentioned that we, we're going to look at some way of |
| addressing that problem. And this is exactly what happens in the |
| next step of the category partition method, in which we identify constraints |
| among choices. And why do we identify these constraints? We do |
| that to eliminate meaningless combinations of |
| inputs. If you remember, for example, |
| we had the case in which we were trying to |
| create a string with a size less than 0, which |
| doesn't make any sense. And very importantly, we also do |
| that to reduce the number of test cases. Because every time |
| we constrain one of the possible choices, we eliminate possible |
| test cases, so we can use it to keep under |
| control the number of tests that we generate. There are |
| three types of properties. The |
| pair property...if, error properties, and properties |
| of type single. So we're going to look at what these |
| properties mean, using, once more, our example of the split program. |
| In particular, we're going to use some of the choices that we |
| identified earlier. So let's look, for example, at choice 0, for |
| category length of the string. All we can say is that, |
| if the length is 0, this define a special property of |
| the string. And that was specified in this way by saying |
| that this identifies property zerovalue. So every time that we use |
| this choice, zerovalue is defined. At this point, we can use |
| this to exclude some meaningless |
| combinations. For instance, consider special characters. |
| If we have a string of length 0, which means a |
| string with no characters. Obviously, there |
| cannot be special characters. So, considering |
| this combination will just be a waste of time. So what |
| we do is that we specify next to this choice, that we |
| will only consider this if length is not 0. And we |
| do this by saying that we consider this only if not zerovalue. |
| So, if zerovalue is not defined. So this pair is an |
| example of a property...if case. Define a property and use that |
| property. Now let's look at a case in which we might |
| want to use an error property. For instance, when we look at |
| the category value for the input size, the choice value less |
| than 0 is an erroneous choice. So it's a choice that |
| we selected to test a possibly erroneous situation, so we can |
| mark this as an error property. And what that means is that |
| when generating a combination of choices, we will consider this only |
| once because we assume that we just want to test this error condition |
| once. Finally, the single property is a property that we use |
| when we want to limit the number of test cases. And it's |
| similar as an effect to error. It just has a different |
| meaning. So what we do when we use the single property is |
| that we're saying that this choice, we want to use in only |
| one combination. So don't combine it multiple times. And that, of course, |
| given the combinatorial nature of the problem, cuts down dramatically |
| the number of test cases. And we might use, for |
| instance, the single property for maxint, which means that we |
| will only have one test case in which the size is |
| equal to maxint. We're actually going to see a demo |
| on this topic so we'll have more chances of seeing how |
| properties work in practice and how good they are at |
| eliminating meaningless combinations and at reducing the number of test cases. |

## 273 - Produce and Evaluate Test Case Specifications

| Before getting to our demo, we still have two steps to consider. |
| The first step corresponds to the identification of the test case specifications |
| in our general systematic approach. And in fact, it's called produce and |
| evaluate test case specifications. This is a step than can be completely |
| automated given the results of the previous steps. And the final result |
| of this step is the production of a set of test frames. |
| Where a test frame is the specification of a test. Let me |
| show you an example of this. What we are looking at here |
| is a test frame for the program split. Test frames are normally |
| identified by a sequence number. But in this case we are looking at |
| the 30th six test frame. And what they do is simply to |
| specify the characteristic of the inputs for that test. In this case, since |
| we have two inputs, we have two entries, the first one for |
| string str tells us that the length of the string has to be |
| size minus 1, and that the string has to contain special characters. And |
| for size, it tells us that the value of size has to be |
| greater than zero. As the title says, this step is meant |
| to produce but also evaluate the case specification. What does it mean |
| to evaluate? One of the advantages of this approach is that we |
| can easily use it to assess how many test frames and therefore |
| how many test cases we will generate with the current least |
| of categories, choices and constraints. And the beauty of this is that |
| if the number is too large we can just add additional constraints |
| and reduce it. And given then the step is automated we just |
| add constraints push a button and we get our new set of |
| test frames. And again we can have a wait it either go |
| hat or add more constraints if we need to further reduce it |
| and this is something else that we will see in our demo. |

## 274 - Generate Test Cases from Test Case Specifications

| So we get to the last step of the technique in |
| which once we have generated test case specifications. We create test |
| cases starting from this specifications. This step mainly consists in a |
| simple instantiation of frames and it's final result is a set of |
| concrete tests. For our example, test frame number 36 that we |
| just saw, this will be the resulting test case, which has |
| the same ID, so that we can track it and will |
| specify to concrete values, not just the specification for the input elements. |
| So string STR will have this value. And the integer size |
| will have this value. And these two values satisfy what this |
| test case specification was. Which was, having a string contain special |
| characters. Here, we have two special characters, like the new line |
| and the tab. And, we have a size which is greater |
| than zero, in particular, okay? And this is a test case |
| that we can actually run on our code. That we can |
| run on the split program. So, to summarize, we perform six steps |
| in which we went from a high level description of what the program does, to a |
| set of concrete test cases. And this is |
| one of those test cases. So what, what we're |
| going to do next, we're going to do a mini-demo, |
| in which we do this for real. We take |
| the program, we identify categories, choices, constraints, and |
| we actually generate test frames and then test cases. |

## 275 - Category Partition Demo

| In this demo, we're going to do exactly what we |
| did just now in the lesson. We're going to use |
| the category partition method to go from a high-level |
| description of a piece of software of a program to |
| a set of test cases for that program. To |
| do that, we're going to use a simple tool. So |
| I'm going to show you here the tool that is |
| called a tsl generator right here. This tool is available |
| to you, so you can look in the class notes to |
| see information on how to download it. And together with the tool, |
| we are also going to provide a manual for the tool, and |
| a set of files that I'm going to use in this demo. So |
| you should be able to do exactly what I'm doing. So |
| again, all of those are available from the class notes. So specifically, |
| today we're going to write test cases for the grep program. So in |
| case you're familiar with the grep utility, this is a simplified version |
| of that utility. So basically the grep utility allows you |
| to search a file for the occurrences of a given |
| pattern. So you can invoke it, as it's shown here |
| in the synopsis, by executing grep, the pattern that you're |
| looking for, and the filename in which you want to |
| look for the pattern. And let me read the description |
| of the grep utility. The grep utility searches files for |
| a pattern and brings all lines that contain that pattern |
| on the standard output. A line that contains multiple occurrences of |
| the pattern is printed only once. The pattern is any sequence |
| of characters. To include a blank in the pattern, the entire |
| pattern must be enclosed in single quotes. To include a quote |
| sign in the pattern, the quote sign must be escaped, which |
| means that we have to put a slash in front of |
| the quotes sign. And in general, it is safest to enclose |
| the entire pattern in single quotes. So this is our high |
| level description for the program, for the softer system, that |
| we need to test. So now let me show you |
| what a possible set of categories and partitions could be |
| for this program. So what I have here is a |
| file, a textual file, which contains all the categories and |
| partitions for the elements that are relevant for my program. |
| In particular, when we look at the file, we can |
| see that the file can be characterized by its size. |
| And in this case, I've got two choices. The file can |
| be empty or not empty. The second characteristic of the file |
| that I'm considering is the number of occurrences of the pattern |
| in the file. And I'm considering that the pattern might not occur |
| in the file or it might occur once, or multiple times. |
| I'm not going to go through the rest of the file because we |
| already covered how to apply the category partition method in the |
| lesson. So if you had doubts about that, about the method and |
| how to apply, you might want to go back and watch again the |
| lesson. What I want to show you here is how you can go |
| from this information that you have here, that we have derived by |
| applying the, the first steps of the method, to a set of |
| test frames, and then, a set of test packs. So to do |
| that we're going to use the tool that I just mentioned. So let |
| me bring back my terminal. So first of all, let's see how |
| we can run the tool. So you have a manual that will explain |
| all the details on how to build the file that we're |
| going to feed the tool. So what is the format and so |
| on. Here I'm just going to see how I can run the |
| tool. So first of all, let me point out that this was |
| developed together by professors from the University of California Irvine and |
| Oregon State University. And as you can see, we can run |
| TSL generator and specify that we want to see the main |
| page. So in this case if we run it this, this way, |
| you'll have some basic information on how to run |
| the tool. And from the main page you can see |
| that you can specify the minus c flag and in |
| this case the TSL generator will report the number of |
| test frames generated without writing them to output. For |
| example, you might want to use this as we will do |
| to see how many tests that you will generate with |
| a current set of category partitions and choices. The minus |
| s option will bring the result of the TSL |
| generator on the standard output. And finally, you can |
| use minus o to specify an output file, where |
| to put the output of the program. So let's |
| at first run our TSL generator by specifying the |
| minus c option and by bypassing our current set |
| of category partitions and choices. Okay, so let me |
| remind you that what the, the tool will do |
| is what we will do manually. Otherwise, which is |
| to combine all these choices so as to have one |
| test case for each combination. So if we do |
| that, you can see that the tool tells us that |
| we will generate 7776 test frames in this case. |
| And this seems to be a little too much for |
| a program as small as the one that we are |
| testing. And assume for instance that we don't have the |
| resources to run this many test cases for, for |
| the grep program. In addition, consider that in this case, |
| we're computing all possible combinations of choices. And there's going to |
| be some combination that do not make sense as we |
| discussed in the lesson. So what we might want to |
| do in this case is to go back to our |
| spec and start adding constraints to eliminate this meaningless combination. |
| So I'm going to show you the result of doing that. |
| And I'm going to show you a few examples. |
| For example here, when the file is empty, I'm going to |
| define this property empty file. And how am I |
| going to use this property? Well for example here, it |
| doesn't make sense to consider the case in which |
| we have one or many occurrences of the pattern in |
| the file if the file is empty. Therefore I'm |
| going to tell the tool that it should consider this specific |
| choice only if the file is not empty, only if |
| empty file is not defined. And that will skip, for |
| example, all of the combinations in which the file is |
| empty. And I'm trying to generate the test case that has |
| one occurrence of the pattern in the file, which is |
| simply not possible. For another example, in case I have |
| an empty pattern, I define the property empty pattern. And |
| then I avoid the choices that involve the pattern in case |
| the pattern is empty. because, for example, I cannot |
| have quotes in a pattern that is empty. For example, |
| it doesn't make sense to have blanks. So, one or |
| more blanks if the pattern is empty. So I'm going to |
| specify again that this choice should be considered only if |
| we don't have an empty pattern. And so on and |
| so forth. So now after I edit these constraints, I |
| can go back and compute again the number of test |
| frames and therefore the test cases that will be |
| generated with these constraints. So let me go again |
| to my terminal. Okay, so now I'm going to run |
| my TSL generator again, and I'm going to run it on |
| the second version of this file. And you can |
| see that I reduced the, the number of test frames |
| from about 7800 to about 1700. So it's quite |
| a, quite a big reduction by eliminating all these combinations |
| that do not make sense. But let's assume again that |
| we want to reduce this further so that we don't want to |
| generate those many test frames and therefore test cases. So |
| what can we do? We go back to our spec. And |
| in this case, we start adding error constraints. So if |
| you remember what we said in the lesson, error constraints are |
| constraints that indicate a choice that has to do with an |
| erroneous behaviour. For example, an erroneous input provided to the problem. |
| So here for instance, we're indicating the presence |
| of incorrectly enclosing quotes as an error choice. Same |
| thing if there's no file corresponding to the |
| name that we provide to the tool, we say |
| that this corresponds to an error. So how |
| is the tool going to use this information? It uses |
| this information by producing only one combination that involves |
| error choices, instead of combining them with other choices. |
| So let's see what happens after we added this |
| error constraints. So we go back to our console |
| once more. And in this case, we want to run |
| the TSL generator with the version of the, of my |
| file that contains the area of constraints. And again, |
| I reduce quite a bit the number of test frames. |
| So now I have only 562 test frames that |
| will be generated by using the file that I provided. |
| So for the last time, let's assume that we really want |
| to cut down the number of test frames or the number of |
| test cases. So once more, we go back to our file, and |
| at this point what we can add is the final type of |
| constraints that we have, which are |
| single constraints. And single constraints are |
| basically indicated choices that we don't want to combine with other choices. |
| So they have the same effect of the error constraints, but they |
| have a different meaning, so they do not indicate choices that corresponds |
| to an error. In other words, I can use a |
| single constraints to identify choices that I want to test only once. |
| So for example in this case, I might decide that I |
| want to have only one test frame that tests my program |
| with a file being empty and I can do the |
| same for other choices. So basically I can continue adding this |
| single constraint until I get down to the number of test |
| frames and therefore the number of test cases that I want. |
| So now let's go back once more to our console. And so now if we run |
| using this file as input, you can see that we have 35 test frames generated. So |
| this is a fairly low number of test cases, so we might decide that we want to |
| go ahead and write these test frames to a file. So now let's open this file |
| that we just generated. And as you can see here, I have exactly 35 test frames, |
| as expected. Some of those correspond to the single and error cases. So in this |
| case, the only choice that I have indicated |
| is the one that corresponds to the single |
| or error constraint. What is for the other |
| ones? I actually have the whole test spec. |
| So let's pick one just to give you an example. |
| In this case, that's frame number 15 that will correspond to |
| test case number 15. And here you can see that |
| we have all the information. So this is a test specification. |
| All the information that we need to generate the corresponding |
| test. We know that we need a file that is not |
| empty. That we need to have one occurrence of the pattern |
| in the file. One occurrence of the pattern in one line. |
| The position of the pattern in the file can |
| be any position. The length of the pattern must |
| be more than one character. The pattern should not |
| be enclosed in quotes. There should be one white |
| space, one quote within the pattern, and finally the |
| file that would pass through the program should exist. |
| So the file should be present. So I can |
| easily transform all of this into an actual test case. |
| And notice that even though we're not, we're not |
| going to do it here. In cases like this, it might |
| even be possible to automatically generate the test cases |
| from the test specifications because, here for example, here it |
| should be relatively straight forward to parse these test |
| specifications and generate test cases accordingly. So, just to summarize, |
| what we have done is to go from one high-level |
| description of a program to a set of categories, partitions, |
| and choices for that program. Then we have combined them |
| in different ways, adding more and more constraints to reduce the |
| number of combinations until we ended up with the right number |
| of test cases, so the number of test cases that we |
| were fine generating. We generated the corresponding test specifications. And at |
| that point, we could just go ahead, generate the test case, |
| and test our application. So, and you can see how this |
| can result in a much more thorough testing of your application. |
| Because instead of reading this description and just trying to come up with test |
| cases for it, we can break down the process in steps that are easy to perform |
| individually. They can be automated as much |
| as possible. And they will end up with |
| a set of test cases that will test |
| all the interests and aspects of your application. |

## 276 - Model Based Testing

| What we just saw with the category-partition method, is a |
| specific instance of this systematic |
| functional testing approach. So specific instance |
| of the steps that we represented here. And, as I |
| mentioned earlier on, this is not the only way in which |
| you can generate test cases, starting from a functional specification. |
| In particular, this step, in which we identified relevant inputs and |
| then we combine them to generate test case specifications, can also |
| be done in different ways. And, we're going to look at one |
| of these ways. Which is through the construction of a |
| model. And, the reason why I want to talk about models. |
| Is because, model based testing is also, fairly popular in |
| industry. And fairly used in practice. In model based testing, the |
| way in which we go from specifications, to test cases, |
| is through the construction of a model. Where a model is |
| an abstract representation of the software under test. Also in |
| this case there are many possible models, that we can use. |
| And what we're going to do, we're going to focus |
| on a specific kind of model. And I'll |
| just point you to additional sources of information, |
| in case you're interested in seeing other examples. |

## 277 - Finite State Machines

| The model that we will consider, is a very well |
| known one. Which is finite state machines. And you might have |
| seen them before. At a high level, a state machine is |
| a graph in which nodes represent states of the system. For |
| example, in this case, state 1, state 2, and state 3. |
| Edges represent transitions between states. For instance, in this case we |
| have one edge from state 1, to state 2. That means |
| that the system can go from state 1, to state 2. |
| And finally, the labels on the edges represent events |
| and actions. For example, what this label means is that |
| the system goes from state three to state two |
| when event five occurs. And when going from state three |
| to state two, it generates action four. And does |
| reacher model, sir reacher's kind of state machines, but we're |
| just going to stick to this ones which are enough. For |
| our purpose. So how do we build such a final |
| state machine starting from a specification? The first thing |
| we need to do is to identify the system's boundaries |
| and the input and output to the system. Once we |
| have done that, we can identify, within the boundaries of |
| the system, the relevant states and transitions. So we split |
| this single state We'll refine it into several states. And |
| we also identify how the system can go from one |
| state to another. Including which inputs cause which transition, and |
| which result in outputs we can obtain. To |
| better illustrate that, let's look at a concrete example. |

## 278 - Finite State Machines Example

| In this example, we're going to start from an informal specification, and the |
| specification is the one shown here in file spec.txt. This is the |
| specification for the maintenance function in a specific system. So what we're |
| doing is that we're taking the description of the functionality of a system, |
| and we're building a model, in this case a final state machine |
| for it. And there is no need to look at all the details |
| for this specification, but I want to point out that if you |
| look at the way the specification is written, we can identify specific cases |
| that we need to take into account. Like here if something |
| happens, something else will follow. Again, if something happens something else |
| will follow. So we have multiple choices here. Here will determine |
| the next steps and so on. So all we have to |
| do is to go through this process, identify these cases and |
| then build a machine that represents these cases. For the spec |
| that we just consider this is the state machine that will |
| result. Again there is no need to go through all the details, |
| but what I want to point out is that we have |
| a set of states. So for instance, we have state zero, |
| which is no maintenance, and if a request comes in, the |
| system will move, and the system wait for pickup. Then if |
| the pickup actually occurs, the system will move to the repair |
| state, and so on and so forth. So this is just |
| a more systematic representation of what was in the former specification. |
| And I will argue that this is much easier to understand at |
| least for somebody who has to develop tests for this system. In |
| fact what we're going to see next is how we can go from that |
| representation to a set of test cases. And the way which we do |
| it is by covering the behaviors represented by defining state machine. And we |
| can decide how we want to cover them. For example we might want |
| to cover all the states. So we might want to identify paths in |
| the state machine that go through all the states in the machine. Like |
| the one I just draw or this one, this one and this one. |
| So if we consider these four test cases, we can see that all the |
| states in my system or at least all the states that I have identified |
| are covered. I might want to go a little further, and decide that I |
| don't only want to cover all of the states, but I want to cover, all |
| of the transitions, because, it makes sense to visit a state, when coming from |
| different states. And, if I want to do that, and I look at the |
| test cases that I generated so far, I can see that there is one |
| transition, the one here, that is not covered. And, the same can be said for |
| the two transitions here. So what I can decide to do is |
| to generate another test case, that covers those or extend an existing one. |
| For instance, I could extend this test case by adding a visit to |
| the state, before going back to these two. Alternatively, I could also generate |
| new test cases, such as this one. To cover the missing transitions. |
| And once I have these test cases, I can express them in a |
| clearer way by simply specifying what are the states that they cover. I'm |
| just going to give you a couple of examples. Say, if we look |
| at the last one that I added, which will be test case |
| number five, I just need to specify that it will go through state |
| zero, which is this one, five, which is this one, six, and |
| then back to zero. And I can do the same for the other |
| test cases. So this will be my complete set of test cases. |
| So the bottom line here is that it is much harder to build |
| a set of test cases that will cover the behavior of an informal |
| description. But by going through a model, so by building in this case, |
| a finite state machine for that description, we can, in a much easier way, see |
| what the behaviors of interest of the system |
| are, and try to cover them. And there |
| is again in the spirit of breaking |
| down a complex problem into smaller steps that |
| we can better manage, which in the end, |
| results in a more efficient and effective testing. |

## 279 - Finite State Machines Considerations

| There are some important considerations I want to make on final state |
| machines. And more in general, on model based testing. The first one |
| is about applicability. Testing based on final state machines is a very |
| general approach, that we can apply in a number of contexts. And in |
| particular, if you are working with UML, you have state machines for |
| free. Because state charts are nothing else but a special kind of |
| state machine. So you can apply the technique that we just saw |
| directly on state charts, and try to cover their states and their transitions. |
| Another important point is that abstraction is key. You have to find the |
| right level of abstraction. The bigger the system, the more you have to |
| abstract if you want to represent it with a model, and in particular, with |
| the final state machine. So it's like having a slider, and you have |
| to decide where you want to move on that slider. The more you represent, |
| the more complex your system is going to be and the more thorough your |
| testing is going to be but also more expensive. The less you represent the |
| less expensive testing is going to be, but also testing might not be as |
| thorough as it would be otherwise. So you have to find |
| the right balance between abstracting the weight too much and abstracting |
| the weight too little. And finally there are many other approaches. |
| So we just scratched the surface, and we just saw one possible |
| approach. But for instance, other models that you can use are |
| decision tables, flow graphs and even historical models. Models that can |
| guide your testing based on problems that occurred in your system |
| in the past. And also, in this case, I'm going to put pointers |
| to additional materials in the class notes. |

## 280 - Summary

| Now we are at the end of this lesson, and I |
| just want to wrap it up by summarizing what we've seen. We talked |
| about black-box testing, the testing of |
| software based on a functional specification, |
| a description of the software rather than its code. We saw a |
| systematic way of doing that, that allows for breaking down the problem |
| of testing software, so the problem of going from this functional specification |
| to a set of test cases into smaller steps, more manageable steps. |
| And we saw two main ways of doing this. One by identifying |
| relevant inputs for the main features in the system |
| and then deriving test case specifications and test cases from |
| this set of inputs. And the second way by |
| building a model for the main features of the system |
| and then using this model to decide how to |
| test the system. In the next lesson, we are going |
| to discuss, how to do testing by looking inside the |
| box? So, how to do testing in a white-box fashion. |

## 281 - Lesson Overview

| In the previous lesson we discussed black box |
| testing, which is the testing performed based on a |
| description of the software, but without considering any of |
| software's internal details. In this lesson, we will discuss |
| the counterpart of black box testing, which is called |
| unsurprisingly white box testing or structural testing. And just |
| like we did for black box testing, we will |
| cover the main characteristics of white box testing and |
| this casts the most commonly used white box testing techniques. We |
| will conclude the lesson with the discussion of the main strengths and |
| limitations of white box testing. So that you will know, when to |
| use it? How to use it? And what to expect from it? |

## 282 - Overview

| In the last lesson, we talked about black-box testing or functional testing, |
| which is the kind of testing that you perform when you just |
| look at the description of the software. Today we're going to cover white-box |
| testing, which is the kind of testing that we perform when we |
| open up the box. We look inside the program, and we actually |
| test it based on its code. And there is one basic assumption |
| behind the idea of white-box testing, which is a very intuitive one, |
| and the assumption is that executing the faulty statement is a necessary |
| condition for revealing a fault. In other words, if there is |
| a bug in the program there is no way were going to be |
| able to find this bug or this fault, if we don't execute |
| the statement that contains it. Which makes a lot of sense. As |
| we did for black-box testing, we're going to start by summarizing what |
| are the main advantages of white-box testing. The main advantage is that |
| it's based on the code, and as such, the quality of white-box |
| testing can be measured objectively. And what I mean here by objectively |
| is that if you think about black-box testing In many |
| cases, there were subjective decisions, there were had to be made |
| in order to define tests in a black-box fashion. In the |
| case of white-box testing, because everything is based on the quota, |
| we don't have to make such subjective decisions. And similarly, because |
| white-box testing is based on the code, it can be measured |
| automatically. So we can build tools and actually there are tools, |
| and there's plenty of tools, that can be measured, the level |
| of white-box testing can be achieved in a fully automated way. |
| And we're going to see some of them in the course of the |
| class. Another advantage of white-box testing is that it can be |
| used to compare test suites. So if you have two alternative sets |
| of tests that you can use to assess the quality of |
| your software, white-box testing techniques can tell you which one of these |
| two test suites is likely to be more effective in testing |
| your code. And finally, white-box testing allows for covering the coded behavior |
| of the software. What that means is that if there is |
| some mistake in the code and is not obvious by looking at |
| the specification of the code, white box testing might be able |
| to catch it, because it tries to exercise the code. There's many |
| different kinds of white box testing, there are control flow based |
| techniques, data flow based techniques, and fault based techniques. And for each |
| one of these family of techniques there are many variations. So |
| this field is very, very broad. In this lesson we will talk |
| about white-box testing by focusing |
| mainly on control-flow based testing techniques. |

## 283 - Coverage Criteria Intro

| So let's start our lesson on white docs testing by considering again the |
| program PrintSum. If you remember, this is the same program that we used when |
| we were talking about black box testing. It's the program that takes two |
| integers, A and B, and produces, as a result, the sum of the two. |
| And when we were looking at this problem in the context of black |
| box testing, we did not look at |
| implementation. But that's exactly what we're going to |
| do now. So we're going to open the box and look at how the |
| code is implemented. And as you can see, the programmer was kind of creative. |
| Because instead of just adding the two numbers and printing them, he |
| or she also decided to print them in a specific color depending |
| on whether they were positive numbers or negative numbers. So positive results |
| are printed in red and negative results are printed in blue. And as |
| you can see by looking at the code we can see some |
| interesting cases that we might want to test. For instance you can |
| see that there are two decisions made here. So we might decide |
| that this is an interesting case and therefore we want to test it. |
| Similarly we might look at this other case and we might |
| also decide that this is another interesting case and therefore we |
| want to test this one as well. So let's discuss this |
| in a slightly more formal way by introducing the concept of |
| coverage criteria which are really the essence of why box testing. |
| First of all coverage criteria are defined in terms of test |
| requirements where test requirements are the elements, the entities in the |
| code that we need to exercise. That we need to execute |
| in order to satisfy the criteria. And we'll see plenty |
| of examples of that. And normally, when I apply a coverage |
| criterion, my result is a set of test specifications. And we |
| already saw test specifications. Those |
| are basically descriptions, specifications, of how |
| the tests should be in order to satisfy the requirements. And |
| they also result in actual test cases, which are instantiations of |
| the test specifications. And again this is exactly analogous to what |
| we saw when we were talking about the black box testing. |
| So let's see what this means by going back to our |
| example. A minute ago, we looked at the print sum code |
| and we identified two interesting cases for our code. And those |
| are exactly our test requirements. So we have a first test |
| requirement here, which is the execution of this particular statement and |
| a second requirement here and this one corresponds to the execution |
| of this other statement. So for this example there are two |
| things that we need to do in order to satisfy our |
| coverage requirements. Execute this statement and execute this statement. |

## 284 - Coverage Criteria Intro Quiz Question

| Now let's see if we are all on the same page |
| on the concept of testing specifications, and we're going to do that through |
| a quiz. What I would like for you to do is to |
| tell me, what are some possible test specifications that will satisfy the |
| requirements that we just saw? And I want you to express this |
| specification in terms of constraints on |
| the inputs. Which means, what constraints |
| should the input satisfy in order for this statement to be executed, |
| and this statement to be executed, and you can write your answer |
| here in these two slots. |

## 285 - Coverage Criteria Intro Quiz Solution

| To satisfy our first requirements, we need to find an |
| input that causes the execution of this statement. Because this statement |
| is executed only when result is greater than zero, our |
| test requirement is that a plus b must be greater than |
| 0. When this is satisfied, this statement is executed therefore |
| any test case that implements this specification will cause the execution |
| of this statement. Similarly if we want to cover this statement |
| which is our second requirement we need to have a result |
| that is less than 0. Again, the result is equal |
| to a plus b, so all we need to do |
| is find the test case such that a plus b |
| is less than 0. So this is pretty straight forward. |

## 286 - Coverage Criteria Intro Quiz Question

| So, now that we have our test specifications. Test specification number one that |
| says that a plus b must be greater than zero. And test specification |
| number two, for which a plus b must be less than zero. I'd |
| like to do another small quiz and ask you to write some test |
| cases that will implement these specifications. And I want you to write the |
| test cases in this format. I want you to specify for each one |
| of the test cases, what is the value of a that you need |
| to use. What is the value of b that you need to use. |
| And since a test case, I like to remind you, is |
| not just a set of inputs. But is the set of |
| inputs plus expected output? I also want you to specify, what |
| is the expected output for these test cases? And in particular, |
| since we have two characteristics of the output, one is the |
| color of the output and the other one is the actual |
| value. I want you to specify for each test case, what |
| is the expected output color and what is the expected value? |

## 287 - Coverage Criteria Intro Quiz Solution

| In this case like in many other cases, there's not just a |
| single right answer because you can build many test cases that will |
| satisfy this test specification. So for example, we could pick value 3 |
| for a and value 9 for b. Those satisfy the specification because a |
| plus b is equal to 12 and therefore is greater than 0, |
| and therefore this is a test case that implements this test specification. |
| And in terms of results, what we expect to see is in |
| the case of a result greater than 0, the caller should be red, |
| and the upper value should be 12. And obviously for this test |
| specification, we just need to pick two inputs such that the sum |
| of the two inputs is less than 0. So for example, we |
| could pick minus 5 and minus 8. The output color in this |
| case is going to be blue, and the output value is going to be |
| minus 13. So, what we just saw is basically how we can |
| go from a piece of code to a set of requirements, which |
| are the interesting aspects of the code that we want to exercise. How we |
| can satisfy the requirements by finding |
| the right test specifications, and then how |
| we can initiate the test specifications into actual test cases. And this is |
| what we will do in general when doing white books testing. And we'll |
| do things likely different way, depending on |
| the specific criteria that we are considering. |

## 288 - Statement Coverage

| Now that we saw this overview of white-box testing, I'd like |
| to start talking about specific coverage criterion. And I'm going to start |
| with the first one, which is Statement Coverage. This criterion is |
| going to be characterized by two aspects, the first one is which |
| are the Test requirements for the criteria and the second one |
| is how we measure Coverage for that criteria. In the case |
| of statement coverage, these test requirements are all the statements in |
| the program. So this is the basic, the first the, the simplest |
| coverage criteria in the white-box arena. Let me remind you the assumption |
| that we made at the beginning. White-box testing is based on the assumption |
| that if there isn't a faulty element in the code, we need |
| to exercise it. We need to execute it, in order to find the |
| fault. And that's exactly what statement coverage does. If there is a |
| statement that is faulty in the code, we need to exercise it, in |
| order to find the fault. And therefore, a good measure of how well |
| we exercise the code, is the ratio of the number of executed statements. |
| So all the statements that my test cases executed, to the total |
| number of statements in the program. The higher this number, the better |
| I exercise my code. And we can also look at coverage criterion |
| in terms of questions. So what is the questions they were trying |
| to answer when we look at a specific set of test cases |
| and we assess the statement coverage that they achieved. And the question |
| is whether each statement in the program has been executed. So, statement |
| coverage is satisfied when all the statements in the program have been executed. |
| And we can satisfy to different degrees and the degrees to which it's |
| satisfied is measured by this value. So now let's go ahead and measure |
| statement coverage on our printSum example. What I'm going to show down here is |
| this progress bar in which we show the amount of coverage, the percentage of |
| coverage achieved. So what this means is that the, if I get to |
| this point I've covered 25% of the statements in the code. And my goal |
| is to get up here to cover all the statements in the code. |
| We have two test cases for this code. The first one that we just |
| saw, consists of the inputs a equal to 3 and b equal |
| to 9, and the second one has the inputs a is equal to |
| minus 5 and b is equal to minus 8. So now let's see |
| what happens when we run this test case. When we run this test |
| case, I'm going to show you by highlighting in the code the parts that |
| we cover when we start executing the code. We cover the first statement, |
| then we always execute the second |
| statement, which computes the result, we continue |
| the execution, we get to the if statement. If the result is greater |
| than zero, in this case our result is 12 because we |
| are working with the inputs 3 and 9, and therefore we |
| execute the true part of the if, we execute the statement. |
| And at this point, we just jump to the end. Because we |
| do not execute the else part of the statement, since we |
| have executed a true one, and therefore, we cover this final |
| statement. So at the end of the execution of this test |
| case, we cover one, two, three, four, five statement out of seven |
| which is roughly speaking 71%. So we can mark in here |
| that we more or less got to 71% of coverage for |
| this code. Now let's look at what happens when we execute |
| test case number two. In this case again, we execute the |
| first statement, the second statement, the third statement. In this case |
| though, the first statement, when it evaluates the value of result, |
| it sees that the result is not greater than zero because |
| our inputs are minus five and minus eight. Therefore, you will execute |
| line number five. And because the result is less than |
| zero, you will also execute line number six. So, at |
| this point, all of the statements in our code are |
| executed and therefore, we achieved a 100% statement coverage, which |
| was our goal. Before looking at other kinds of coverage, |
| let's see how our statement coverage is used in practice. |
| First of all, statement coverage is the most used kind |
| of coverage criterion in industry. Normally for company that uses |
| statement coverage, the typical coverage target is 80-90%, which |
| mean the outcome of the test should be such |
| that 80-90% of the statements are exercised at the |
| end of testing. So at this point, you might |
| be wondering, why don't we just shoot for 100%? |
| Why don't we try to cover all of the |
| code? We just saw that we could do it. |
| And so I'm going to ask you the same question. |

## 289 - Statement Coverage Quiz Question

| so, I would like to hear from you. Why |
| do you think that we don't aim normally at |
| 100 % college but, slightly less than that and |
| I want you to put your answer right here. |

## 290 - Statement Coverage Quiz Solution

| To get the answer to this question, I'm |
| going to ask you to be a little patient, and |
| to wait until the end of the lesson. |
| Because there are a couple of more topics that |
| I want to cover, before I actually get in |
| to this. Nevertheless, I wanted to ask you right |
| away, because I wanted you to think about |
| this, before you see the rest of the lesson. |

## 291 - Control Flow Graphs

| Let's look at the code for PrintSum in a slightly different way |
| by making something explicit. If we go through the code, we can |
| see that the, the code does something in that case, if the |
| result greater then zero, does something else if the result is not |
| greater than zero but is less than zero, and otherwise in the |
| case in which neither of these two conditions is true. Nothing really |
| happens. So we're going to make that |
| explicit, we're going to say here, otherwise |
| do nothing, which is exactly our problem, the code does nothing, in this |
| case where it should do something. So now, let's look again in |
| our test cases, let's consider the first one, and I'm going to go a |
| little faster in this case, because we already saw what happens If |
| we execute the first test case, we get to this point, we execute |
| this statement, and then we just jump to the end, as we |
| saw. Now we, if we execute the second test case, we do the |
| same, we get to the else statement, the condition for the if is |
| true, and therefore we execute this statement. And we never reached this point |
| for either of the test cases. So how can we express |
| this? In order to do that, I'm going to introduce a very useful |
| concept. The concept of control flow graphs. The control flow graphs |
| is just a representation for the code that is very convenient when |
| we run our reason about the code and its structure. And |
| it's a fairly simple one that represents statement with notes and the |
| flow of control within the code with edges. So here's an |
| example of control flow graph for this code. There is the entry |
| point of the code right here, then our statement in which we |
| assign the result of A plus B to variable result. Our if |
| statement and as you can see the if statement it's got two |
| branches coming out of it, because based on the outcome of this |
| predicate we will go one way or the other. In fact normally |
| what we do, we will label this edges accordingly. So for example, |
| here we will say that this is the label to be executed |
| when the predicate is true. And this is the label that is executed |
| when the predicate is false. Now, at this point, similar |
| thing, statement five which corresponds with this one, we have another |
| if statement and if that statement is true, then we get |
| to this point and if it's false, we get to this |
| point. So as you can see, this graph represents my |
| code, in a much more intuitive way, because I can see |
| right away where the control flows, while I execute the code. |
| So we're going to use this |
| representation to introduce further coverage criteria. |

## 292 - Branch Coverage

| So now that we know what the CFG is, let's see how we can get into a count, |
| that else part, that is missing in our example code by introducing a new |
| kind of coverage. Branch coverage. As usual, |
| I'm going to describe branch coverage in terms of test requirements and |
| coverage measure. So starting from test requirements. The test requirement for |
| branch coverage are the branches in the program. In other words, |
| the goal of branch coverage is to execute all of the branches in the program. |
| The coverage measure is defined accordingly as the number of branches |
| executed by my test cases over the total number of branches in the program. And |
| let me remind you that branches are the outgoing edges from a decision point. |
| Therefore, an if statement, a switch statement, a while statement. |
| Any note in the c of g that has got more than one outgoing edge. |
| Those edges are called branches. So let's look at that using our example. So |
| now we're looking back at our printSum example. And in addition to the code, |
| I also want to represent the CFG for the program. So |
| let's start by looking at how many branches we have in our code. Which means how |
| many test requirements we have. And in this case there are two decision points. |
| The first one that corresponds to the first if, and the second one that |
| corresponds to the second if. So we have one, two, three, and four branches. So |
| now, let's bring back our current set of test cases. We had two test cases. |
| The one's that, with which we achieved a 100% statement coverage. And |
| let's see what happens in terms of branch coverage when we run these test cases. |
| I start from the first one, when we execute it, we follow the code, |
| we get to this decision point because the predicate in the if statement is true. |
| We follow the true branch, therefore we get here and then, |
| we exit from the program. So, in this case, we covered one of the branches, |
| which means that we got to 25% coverage. Now when we run the second test case, |
| again we follow this path. We get to this, the first if and |
| in this case the predicate of the if is false. Therefore, we go this way. |
| We reach the second predicate, the second if. The result is true, so |
| we follow the true branch and therefore, we cover these additional two branches. |
| So at this point, we are at 75% branch coverage. So what |
| happens is that we're missing this branch. For now, the inputs that we consider, |
| this branch is executed. Therefore, we need to add an additional test case. And |
| that this case that we need, is one for which this predicate is false and this |
| predicate is false. The simplest possibility in this case is the test case for |
| which A is equal to 0 and B is equal to 0. If we execute this test case, |
| our execution again followed this path, follows the fourth branch here. |
| And in this case, because result is not less than zero either, will follow |
| this branch as well. And therefore, we will reach our 100% branch coverage. And |
| this covered the problem. Something that I would like to clarify before we |
| move to the next topic, is that 100% coverage does not provide any guarantee of |
| finding the problems in the code. All we saw so far is the fact that by |
| testing more thoroughly we have more chances of finding a problem in the code. |
| But it doesn't matter which kind of coverage we utilize, and how much |
| coverage we achieve. There's always a chance that we might miss something. And |
| I will get back to this later on in the lesson. I just mentioned the fact that |
| we tested more fully when we went from statement coverage to branch coverage. |
| What does that mean exactly? To explain that, I'm going to introduce the concept |
| of test criteria subsumption. One test criteria subsumes another criteria when |
| all the tests widths that satisfy that criteria will also satisfy the other one. |
| So let me show you that with statement and |
| branch coverage. If we identify a test width that achieves 100% branch coverage, |
| the same test width will also achieve, necessarily, 100% statement coverage. |
| That's what happened for our example, and also what happens in general, |
| because branch coverage is a stronger criteria than statement coverage. |
| There is no way to cover all the branches without covering all the statements. |
| It is not true that any test results satisfies statement coverage will also |
| satisfy branch coverage. And, in fact, we just saw a counter example. |
| When we look at the printSum code. We had a test where there was achieving 100% |
| statement coverage and was not achieving 100% branch coverage. Therefore, |
| in this case we have a substantial relation in this direction. Branch coverage, |
| subsumes statement coverage. What it also means is that normally, or in general, |
| it is more expensive to achieve branch coverage than achieve statement coverage, |
| because achieving branch coverage requires the generation of |
| a larger number of test cases. So what this relation means is that |
| branch coverage is stronger than statement coverage but also more expensive. |

## 293 - Condition Coverage

| What I'm going to do next is to introduce a few additional |
| coverage criteria using a slightly more complex example, but still a |
| pretty simple one. What I'm showing here is a program that |
| reads two real numbers, x and y. And then, if x |
| is equal to 0 or y is greater than 0, it |
| computes y as y divided by x. Otherwise, it computes x |
| as y plus 2, then it writes the value of x, |
| the value of y, and it terminates. Let's also introduce a CFG |
| for the program. As you can see, the CFG represents the statements |
| in the code and their control flow. And in this case, I made |
| explicit over the branches what are the conditions under which those branches |
| are taken to make it simpler to look at the example. Let's assume |
| that we have two tests for this code that are shown here. |
| For the first one, the inputs are 5 and 5. For the second |
| one, 5 and minus 5. If we consider branch coverage for this code |
| and we consider the two test cases, for the first one this condition |
| is true. Because x is not equal to 0 but y |
| is greater than 0. And therefore, we will follow this tree branch. |
| For the second one, the condition is false. Because x is not |
| equal to 0 and y is not greater than 0. Therefore, the |
| negation of it is true and we will follow this branch. In |
| other words, these two test cases achieve 100% branch coverage on this |
| code. If we look at the code though, we can see that |
| there is the possibility of making this code fail. Consider this statement, |
| if x is equal to 0, we could have a division |
| by 0. However, these two test cases, despite the fact that |
| they achieved 100% branch coverage, will not rebuild this problem. So |
| how can we be more thorough? I'll let you think about it |
| for a second, so think about how can we test more |
| thoroughly, in a more complete way, this code. So, in a way |
| that goes beyond branch coverage. And the answer is that we |
| can make each condition true and false. Instead of just considering the |
| whole predicate here. And that's exactly what is required by |
| the next criteria that we're going to consider which is condition |
| coverage. We're going to define it as usual in terms of |
| test requirements and coverage measure. In this case, the test |
| requirements for condition coverage are the individual conditions in the |
| program. So we want each condition in the program to |
| be both true and false first time execution. So the |
| way in which we can measure that is by measuring the |
| number of conditions that were both true and false |
| when we executed our tests over the total number |
| of conditions. And that gives us the percentage of |
| coverage that we achieved for condition coverage. Again, if you |
| want to look at this criteria in the form |
| of a question. The question would be, has each boolean |
| sub-expression, which means every condition in every predicate, evaluated |
| both to true and false when we run our tests. |

## 294 - Subsumption Quiz Question

| So now that we introduced an additional criterion, |
| let's have a quiz to see whether everybody |
| understood the concept of subsumption. We know that |
| branch coverage subsumes statement coverage, but what about condition |
| coverage? Does it subsume branch coverage? Is it |
| the case that all of the test which |
| satisfy condition coverage will also satisfy branch coverage? |
| Think about it, and answer either yes or no. |

## 295 - Subsumption Quiz Solution

| In this case, the answer is no, and I'm |
| going to show you an example of this in a minute. |

## 296 - Branch and Condition Coverage

| Let's go back to our test criteria subsumption representation, where |
| we already had branch coverage and statement coverage. In this case, |
| if we want to add condition coverage to this page, we |
| have to put it here on this side, with no relationship |
| of subsumption with either branch coverage or statement coverage, which |
| means that the criteria are not comparable. So now let's consider |
| again our last example, and let's use a different test |
| with this time. We still have two tests, but the first |
| one has x is equal to 0 and y is equal to minus |
| 5. And the second one, x is equal to 5 and y is |
| equal to 5 as well. Let's see what happens in terms of condition |
| coverage, when we run these tests. If we look at the first condition, x |
| is equal to 0. It is both true, for the first test case, |
| and false for the second one. As for the second condition, y greater |
| than 0, it is false for the first test case and true for |
| the second one. Therefore we've achieved a |
| 100% condition coverage with these two tests. |
| But what about branch coverage? If we consider the whole predicate, |
| instead of just the individual conditions, let's see what happens for the |
| two test cases. If we look at the first one, because |
| x is equal to 0, the overall predicate is true. As for |
| the second one, because the second condition is true, the overall |
| predicate is true. In other words, despite the fact that we're exercising |
| all the possible values for the two conditions, the overall predicate is |
| always true. And therefore, we're covering only one of the two branches. |
| So our coverage will be 50%. This is the reason |
| why normally the two criteria that we just saw, decision |
| coverage, and condition coverage are considered together. And the resulting |
| criterion is called branch and condition coverage, or also decision |
| and condition coverage. At this point the test requirements and |
| the coverage measure should be pretty straight forward, because they're |
| just considering the two criteria together. As far as the |
| requirements are concerned, they include |
| all the branches and individual conditions |
| in the program. Where as the coverage measure is computed |
| considering both coverage measures, both branch coverage and condition coverage. |

## 297 - Subsumption Quiz Question

| Let's have another quick quiz about Subsumption. If we |
| consider Branch and Condition Coverage, does it subsume Branch Coverage, |
| and therefore Statement Coverage? Or in other words, does branch |
| and condition coverage imply branch coverage? Answer yes, or no. |

## 298 - Subsumption Quiz Solution

| In this case it should be clear that the |
| answer is yes, because branch and condition coverage actually includes |
| branch coverage. Therefore, by definition, any test rate that |
| satisfies branch and condition coverage |
| will necessarily satisfy branch coverage. |

## 299 - Test Criteria Subsumption

| So we can now update our test criteria subsumption. We start |
| from this situation in which there are no relationship between condition |
| coverage, branch coverage and statement coverage. And when we add branch |
| and condition coverage, we can mark the fact that branch and |
| condition coverage subsumes branch coverage |
| and also subsumes condition coverage, for |
| the same reason. Therefore, this is a stronger criterion than both |
| branch coverage and condition coverage, and of course indirectly also soft |
| statement coverage. So once more, to make sure we are all |
| on the same page, if I develop a test rate that satisfies branch and condition |
| coverage, the same test will satisfy also |
| branch coverage, statement coverage and condition coverage, necessarily. |

## 300 - B&C Coverage Quiz Question

| So let's have another quiz using the example that we just |
| used. This one is about achieving 100% branch and condition coverage. So |
| let me bring back the two tests cases that we just saw, |
| and as we saw a few minutes ago, these tests cases do |
| not achieve 100% branch and condition coverage despite the fact that they |
| achieve 100% condition coverage. So both conditions are both true and false, |
| for these test cases. So what I want you to do is |
| to add a test case, to achieve 100% branch and condition coverages. |
| So specify the test case by writing here the value for x, and the value for y. |

## 301 - B&C Coverage Quiz Solution

| Obviously there are many possible tests that we can use to |
| reach 100% branch and condition coverage. So I'm just going to show a |
| possible one, which is x equal to 3 and y is |
| equal to negative 2. If we specify this as case, you can |
| see that the overall condition is false, because neither x is |
| equal to 0 nor y is greater than 0. Therefore we will |
| follow the false, false branch, and achieve 100% branch and condition coverage |
| for this code. And we might require to be even more thorough, |
| that all the combinations of our conditions inside each |
| decision, inside each predicate, are tested. Which is what is |
| called, multiple condition coverage. But because of the way |
| this criterion is defined, it is combinatorial, becuse you have |
| to consider all the possible combinations of conditions. And |
| therefore it's extremely expensive, to the point of being impractical. |
| So instead of defining that criterion, we're going to find |
| another one which finds a good trade off between thoroughness |
| of the tests and their cost. |

## 302 - MCDC Coverage

| And this criterion is called Modified Condition/Decision Coverage, |
| also called MC/DC. This criterion is very important because |
| it is often required for safety critical applications. |
| For example, the FAA, the Federal Aviation Administration, requires |
| for all the software that runs on commercial |
| airplanes to be tested according to the Modified Condition/Decision |
| Coverage. So what is the key idea behind the |
| MC/DC criterion? It is to test only the important |
| combinations of conditions instead of all of them, and limit |
| the testing cost by excluding the other combinations. And the way |
| in which it works is by extending branch and decision |
| coverage with the requirement that each condition should affect the decision |
| outcome independently. So let's see what this means with an |
| example that will also show you how you can reduce the |
| number of combinations in this way. I am going to |
| show you an example of how MC/DC works using this predicate |
| which consists of three conditions. a, b, and c, which are all |
| in and, so the overall predicate is a and b and c. |
| The first thing I'm going to do is to show you how |
| many test cases we will need to satisfy the multiple condition coverage |
| for this simple predicate. Which means, how many test cases we will |
| need to test all the possible combinations of true and false values |
| for these conditions. So I'm going to populate this table. And as you |
| can see, at the end we have eight test cases. Each test case |
| tests a different combination of values for a, b, and c. |
| I'm also showing, for each test case, the outcome of the overall |
| predicate. So, for example, if we look at the first one, the |
| first test case, will be such that a is true, b is |
| true, and c is true. And therefore, the overall outcome of |
| the predicate is true. Now let's consider the first condition, a. As |
| I said a minute ago, what we want to test are the |
| important combination. Which are the comibatinos |
| in which a single condition independently |
| effects the outcome of the overall predicate. So if we consider a |
| and we look at this possible set of this cases. Let's try to |
| find two test cases such that the only difference between the two |
| test cases is the value of a, and the overall outcome of the |
| predicate is different. If we look at the table, we can see |
| that this is true for test cases one and five. If we look |
| at these two cases, we can see that the overall of the predicate |
| in the two cases is true and false, and that the only difference |
| between the value of the conditions in the value of a. So |
| these test cases satisfy exactly what we wanted. There are two test |
| cases in which the value of a independently decides the overall value |
| of the predicate. What we do, therefore, is to add these first |
| two test cases to our set of tests down here. Now let's |
| focus on b and let's try to find two test cases such |
| that the value of b is the only value that changes between |
| the two test cases, but the overall value of the predicate is |
| different, the same thing we did for a. And in this case, |
| we can see that if we select test case number one, and test |
| case number three, we have exactly that situation. b is true in the |
| first case, false in the second one, a and c don't change, but |
| the overall value of the predicate changes. And now you can notice |
| something else. That even though we selected two test cases, tested two values, |
| one we already had. So, we only need three test cases overall to |
| test a and b according to MC/DC. Now, let's look at our last |
| condition, c. At this point, we know the game, so we |
| just have to look for two test cases that satisfy our |
| requirements. And in this case, one and two are suitable candidates. |
| And once more, because we already have one, we just have to |
| add two to our list. So as you can see from |
| this example, we went from having eight test cases needed to cover |
| all the possible combinations of conditions to only four test cases |
| to satisfy the MC/DC criteria. So let's see where MC/DC stands in |
| our substantion hierarchy. This is what we had so far |
| in the hierarchy and this is where the MC/DC criterion will |
| stand. MC/DC criterion is stronger than branch and condition coverage. |
| Why? Because it requires every single condition to be true and |
| false. And therefore, this section was a condition coverage criteria. |
| And it also requires every predicate to be true and false |
| and therefore, this section is branch coverage. And in addition, |
| it's got the additional requirements that the true and false values, |
| all the conditions have to also decide the overall |
| value of the predicate. So it's stronger. Which is more |
| thorough than branch and condition coverage and, as usual, |
| also stronger than branch coverage, statement coverage, and condition coverage. |

## 303 - Other Criteria

| As I mentioned at the beginning of the class, there are many, many, |
| many, white box criteria. And we're not going to have time to cover them |
| all. So what I like to do now is just to give you |
| the flavor, of some other criteria by just mentioning them, and saying a |
| couple of things, about the way they work. And the first one I |
| want to mention is path coverage. And |
| in path coverage, the test requirements are |
| all the paths in the program. So what that means is that to |
| satisfy this criteria, we need to generate enough test cases such that all |
| the paths in my program are covered. As you can |
| imagine this is incredibly expensive because any nontrivial program has got |
| a virtual infinite number of paths and therefore we will |
| need a virtual infinite number of test cases to satisfy the |
| path coverage criteria. Another family of criteria I want to mention |
| are data-flow coverage criteria and in data-flow coverage criteria, the focus |
| shifts from the coverage of individual elements in the code to |
| the coverage of pairs of elements. And in particular the coverage |
| of Statements, in which the content of some memory locations |
| modified, and statements in which the content of the same |
| memory location is used. So in this way, our test |
| will exercise the assignments of values to memory, and the |
| usage of those assignments,. Finally, I want to mention mutation |
| coverage. And this is a fairly different and new idea, |
| so the key concept in mutation coverage is that we |
| want to evaluate the goodness of our test by modifying the code. |
| For example here in this small I'm, I'm showing that I might |
| change it. An if statement from K greater than 9, to K |
| greater than or equal to 9. And the reason why I want to |
| do that, is that if I generate enough mutants, enough variation of |
| my program, then I can use them to assess how good are |
| my tests at distinguishing the original program and the mutants. And because |
| I'm changing the code based on the way I expect to introduce |
| errors in the code, the more my test can identify mutants, the better |
| they are at identifying real faults. This is a very high |
| level [UNKNOWN], but just to give you the intuition and the idea |
| behind these criteria, and I'm going to provide as usual, additional pointers |
| to go in more depth on these topics in the notes of |
| the class. So now, let's go back to our test criteria |
| subsumption hierarchy, and see how all of these criteria fit together in |
| this context. Let me start with multiple condition coverage. As we saw, |
| MC/DC is sort of as [UNKNOWN] way of doing multiple condition coverage |
| in the sense that it doesn't consider all the combinations, |
| but only the ones that are more likely to matter. |
| And as such, MC/DC exercises a subset of the elements |
| of the multiple condition coverage |
| exercises. And therefore, multiple condition coverage |
| is more thorough than MC/DC and subsumption, and it's also |
| as we saw incredibly more expensive. Path coverage subsumes branch coverage, |
| because if I cover all of the paths in the |
| code, I necessarily cover all the branches. However, it doesn't subsume |
| multiple condition coverage, MC/CD, or |
| branch and condition coverage. Because this |
| criteria, have additional requirements involving |
| the conditions of the predicate that |
| path coverage does not have. As for data-flow coverage criteria and |
| mutation coverage criteria, there really no |
| relation with the other criteria, because |
| they look at different aspects, of the code. So they're not |
| really comparable, and therefore we're just going to put them on the |
| side, without any relationship with the other ones. The reason why |
| I want to represent them all anyways is because I want to make |
| an important distinction between these different criteria. And |
| that's the distinction between practical criteria, which are |
| criteria that are actually not too expansive to |
| be used in real scenarios. And theoretical criteria, which |
| are criteria that are useful in theory from |
| the conceptual standpoint, but they're not really applicable |
| in practice because they're too expansive, because they |
| require basically too many test cases to be satisfied. |

## 304 - Review Quiz Question

| White box testing, in general, and coverage criteria in particular, involve some |
| subtle concepts, so before I conclude this lesson, I want to have a |
| few more quizzes to make sure that we all understand these concepts. |
| The first one involves a very simple piece of code, a straight line |
| of code, three statements, in which we simply read an integer and |
| then prints 10 divided by the value of that integer minus 3. Now, |
| let's imagine that we have a test where there consists of three |
| test cases for this code, and what I'm showing in the test cases |
| is the input and the expected output. So for the first one, |
| the input is 1, and I expect the output to be minus 5. |
| For the second one, the input is minus 1, I'm expecting to |
| have 2.5. And for the third one, the input is 0, and I'm |
| expecting to have minus 3.3333 as the result. Now the first question |
| I want to ask, is if we considered this test suite, and we |
| run it on the code, does it achieve path coverage? And remember |
| that path coverage is one of the strongest coverage criteria that we saw. |

## 305 - Review Quiz Solution

| And the answer in this case is clearly yes. In fact, any input will really |
| achieve path coverage for this code because there is only one path in the code. |

## 306 - Review Quiz Question

| But now want to ask a different question which is, does this test reveal |
| the fault at line three? Clearly, here there is a possible problem, because |
| if we pass the right input, we can have a division by zero. |
| Is that revealed if we run this test within the code? Yes or no? |

## 307 - Review Quiz Solution

| And the answer is no. So even path coverage's stronger criteria |
| that we saw is not enough to reveal this problem. And why |
| is that? So let me go back to a concept that |
| I mentioned in a previous lesson, the cost of exhaustive testing. Exhaustive |
| testing is really the only way in which we can exercise |
| all of the possible behaviors of a program. So we can say |
| even though it might sound like topology, that only exhaustive testing is |
| exhausted. All the coverage criteria that we saw are just process and |
| just approximation of a complete test. So test is a best effort kind |
| of activity. Coverage criteria help you assess |
| how well you tested but once more, |
| test can only reveal issues, can only reveal problems. You can never show the |
| absence of problems. And that's something is |
| important to remember when we do testing. |

## 308 - Review Quiz Question

| Now let's do another quiz considering a slightly different piece |
| of code. In this case we have five layers of |
| code. We have a variable i, a variable j. Variable |
| j is read from the input. And then based on |
| this predicate, we either print the value of i or |
| simply exit. And what I want to know from you is |
| whether you can create a test suite to achieve statement |
| coverage for this simple piece of code. Yes or no? |

## 309 - Review Quiz Solution

| And the answer in this case is no. And |
| the reason for this is because this code is |
| unreachable. This is dead code because no matter the |
| value of j, this condition will always be false because |
| i will always be 0. And notice that this |
| is a small example, but another important truth is |
| that any non-trivial program contains dead or unreachable code, |
| code that no matter how well we test our system, |
| we will never be able to exercise. Why is that? Various |
| reasons. For example, defensive programming or, |
| for example, developing for future releases. |
| So there might be pieces of code that are added, but they're |
| still not activated. They're still not invoked by any other part of |
| the code because of modifications to the code. There are some |
| parts that were executed before and in the new version of the |
| program, they are no longer exercised. They are no longer executable. But |
| they still remain in the code base. And this is a very, |
| very normal situation for this reason and many more. And this is |
| an important concept because this affects |
| the very meaning of coverage measures. If |
| there is some unreachable code, we will never be able to reach |
| 100% code coverage. And in fact, if you remember, at the beginning of |
| the lesson, we discussed this concept and asked you why you think |
| that, in the industry, the target for coverage is not 100% but less |
| that that. And that's the answer, to account for the fact that there |
| are infeasibility problems that I have to take into account when I test |
| the code, infeasible paths, unexecutable statements, conditions that can never |
| be true, and so on. So most criteria, if not |
| all, are affected, and we need to take that into |
| account when we try to achieve a given coverage target. |

## 310 - Summary

| Now let me conclude the lesson by summarizing a few important |
| aspects of white-box testing. The first important aspect is that white-box |
| testing works on a formal model. The code itself are models |
| derived from the code. So when we do white-box testing, we |
| don't need to make subjective decision, for example, on the level |
| of obstruction of our models. Normally, we simply represent what's there. |
| And so what we will obtain are objective, results and objective |
| measures. As I also said at the beginning, coverage criteria allows |
| us to compare different test suites, different sets of tests, |
| because I can measure the coverage achieved by one test suite |
| and by the other, and then decide which one to use |
| based on this measure. And again, remember, these measures aren't perfect, |
| but they at least give you an objective number, an objective |
| measure of the likely effectiveness of your tests. So even though |
| achieving 100% coverage does not mean that you identify all the |
| problems in the code for sure. If your level of coverage |
| is 10%, for example, for stemen coverage. That means that |
| you haven't exercised 90% of your code, and therefore the trouble |
| is in a piece of software that is inadequately tested |
| and likely to be of inadequate quality. We also saw that |
| there are two broad classes of coverage criteria, practical criteria |
| that we can actually use, and theoretical criteria that are interesting |
| from a conceptual standpoint, but that they are totally impractical. |
| They are too expensive to be used on real world software. |
| And finally, as we also said at the beginning, |
| one of the great things about white box testing and |
| coverage criteria, is that they are fully automatable. There are |
| tools that can take your code, instrument it automatically. And |
| when you run your test cases, they will tell |
| you, what is the level of coverage that you achieve |
| with your test at no cost for you. So there's |
| really no reason not to measure coverage of your code. |

## 311 - Lesson Overview

| In previous lessons, we covered testing principles and |
| techniques. In this lesson, we will discuss a |
| type of software process that is heavily based |
| on the use of testing. The agile development |
| process. Also called test-driven development. To do that, |
| we will revisit some of the assumptions that |
| led to the definition of the more traditional |
| software processes. The ones that we discussed so far. |
| We will see how, when some of these assumptions are |
| no longer valid, we can change the way in which we |
| look at software processes. And we can change the way |
| in which we look at software development in general. We will |
| discuss how this changing perspective, let's us rethink software processes |
| and make them more agile and better suited for context in |
| which changes are the norm and we need to adapt |
| fast. In particular, we will discuss two processes that apply the |
| principles of agile software development and that are commonly |
| used in industry. Extreme programming, also called XP, and Scrum. |
| [BLANK_AUDIO] |

## 312 - Cost of Change

| We will start our discussion about test written and development by going |
| back to a softer life cycle to examine a little bit ago |
| which is the waterfall life cycle. And if you remember, that was |
| a totally rigid process in which we were preparing documents and we |
| were not studying any phase before the previous one was finished. And |
| once a phase was finished, we were really going back to it. |
| So today we are going to examine how it is possible to go |
| from such a rigid process to an agile one, in which we can |
| better deal with changes. So remember what we saw in the |
| first lesson when Barry Boehm stated that the cost of change |
| grows exponentially with time. So if we imagine to have time |
| over here on the x-axis and cost on the y-axis, we |
| can see the cost that will go up more or less |
| this way. And what that means is finding a problem while |
| collecting requirements will cost you much less than finding a problem |
| in the analysis phase, which in turn, will cost you less |
| than finding a problem during design, and so on for |
| the subsequent phases. So if this is the case, and cost |
| is really growing this fast as we proceed in our process, |
| what should we do? The key thing is to discover errors |
| early before they become expensive, which in turn means doing a |
| lot of upfront planning. And because models are cheaper to modify |
| in code, we're willing to make large investments in upfront analysis |
| and design models. And only after we have built and checked |
| these models, we're going to go ahead and build the code. In |
| other words, we are following |
| a waterfall mentality. However, something definitely |
| changed in the last 30 years. For example, 30 years ago, |
| we needed to walk down the hall, submit a deck of |
| cards to an operator, and wait a day for our program |
| to run and produce some results. Today we can leverage the |
| computational power of the cloud. Computers used to be very slow |
| and very expensive. Today, computer are a thousand times faster and |
| a thousand times cheaper than what they used to be. In |
| particular, if you think about the compile and test cycle, that has |
| gone from days to seconds. Now we can change our code, compile |
| it, run it our tests, all in a matter of instants, something |
| that was unthinkable before. Finally, developers in the past had to |
| do a lot of tasks manually in a very time-consuming way and |
| often in a very painful way. Today, on the contrary, we can |
| now automate a lot of these tasks. We have high level programming |
| languages, version control systems, smart ideas. Basically a whole set of tools |
| that can help developers. And they can make them more efficient. In |
| general, what that means is, it's easy to change, much easier than |
| what it was before. So maybe if we take all that into account, |
| the cost of change can be flat. So if we go back |
| to our diagram, the one in which we showed the cost with |
| respect to the project time, maybe instead of having this kind of |
| curve, we might have a different kind of curve. Maybe the curve is |
| more like this one. So maybe we can make all of this happen, as long as |
| we use tools, practices and principles in the |
| right way. And we're going to see what that means. |

## 313 - Agile Software Development

| And assuming that cost is flat that we can really lower that |
| curve then teher are a few interesting consequences. First of all upfront |
| work becomes a liability, we pay for speculative work some of which |
| is likely to be wrong. Some of which we are likely to undo |
| and the reason for ambiguity and volability for example in requirements then |
| it's good to delay We don't want to plan for something that |
| might never happen, to invest resources in something that we might have |
| to throw away later on. In general, if cost is flat it is |
| cost effective to delay all decisions until the last possible |
| moment and only pay for what we use, so to |
| speak. In other words, there is value in waiting, time |
| answers questions and removes uncertainty. And we want to take advantage |
| of that. This and other considerations led to the birth |
| of Agile Softer Development. Specifically for those of you who are |
| interested in a little bit of history. In February 2001 |
| a group of software developers, 17 of them, met to discuss |
| lightweight development methods and published Manifesto for Agile |
| Software Developement. Which introduces and defines the concept of |
| agile software development, or agile methods. In a |
| nutshell, agile methods aim at flat cost and a |
| decrease in traditional overhead by following a set |
| of important principles. Our first principle is to focus |
| on the code, rather than the design, to avoid |
| unnecessary changes. Another principle is to focus on people, |
| value people over process, and make sure to reward people. |
| In addition agile methods are all based on iterative approaches to |
| software development, to deliver working software quickly, and to be |
| evolve it Just as quickly based on feedback. And feedback can |
| come from many sources, in particular, it'll come from the |
| customer, it'll be customer feedback. And to be able to do |
| so, agile methods need to involve the customer throughout the development |
| process. Finally, there are two more principles I want to mention. |
| Which are cornerstones of agile methods. The first |
| one is the expectation that requirements will change, and |
| therefore, we need to be able to handle some |
| changes. We can't count on the requirements to be |
| still and unmutable. And the last principle is |
| the mentality of simplicity. Simple design and simple code |
| and so on. But be careful, because simple does |
| not mean inadequate, but rather, as simple as possible. |

## 314 - Extreme Programming (XP)

| So now let's talk about a specific agile method, which |
| is also one of the first ones, extreme programming, also called |
| XP. And to introduce XP, I'm going to start with |
| a quote. The quote says XP is a lightweight methodology for |
| small to medium sized teams developing software in the face |
| of vague or rapidly-changing requirements. And this is a quote from |
| Kent Beck the American Software Engineer that created extreme programming. |
| And by the way Beck was one of the original 17 |
| developers who signed the manifesto in 2001. And as you can see |
| we are still talking about the methodology. So we are not just |
| talking about going out and just start writing software. There are principles. |
| And there are practices that we need to follow, but we're going |
| to do it in a much more agile, and a much more |
| flexible ways than we did for our software processes. And also note |
| that the vague and rapidly changing |
| requirements are explicitly mentioned, because this |
| is really one of the important parts about all of this agile methodologies. |
| so what is XP? XP is a. Lightweight. Humanistic. |
| Discipline. Of software development. It is lightweight because it doesn't |
| overburden the developers with an invasive process. So process |
| is kept to a minimum. It's humanistic because as we |
| said, it's centered on people. People, developers, customers, are |
| at the center of the process. It's a discipline, as |
| we said, it includes practices that we to Follow. |
| And finally, is of course about software development. Software development |
| is a key point of the whole method. In XP, developing |
| is like driving, imagine having a road, a wind road, we need |
| to able to drive our car down the road, take the |
| abrupt turns, react promptly to changes, for example obstacles on the road. |
| So, in a nutshell, change is the only constant. Eyes always |
| have to be on the road and it's about steering and not |
| pointing, and XP is trying to do the same thing, while creating |
| softer systems. In XP we need to adopt a mentality of sufficiency, |
| what does that mean? How would you program if you had all |
| the time in the world? No time constraints at all, you will probably |
| write tests instead of skipping them, because there's no more resources. You |
| will probably restructure your code often, |
| because you see opportunities to improve it, |
| and you will take them. And you will probably talk to fellow |
| programmers and with the customer, interact with them, and this is actually the |
| kind of mentality that XP is trying to promote and agile processes |
| in general. And we will see that the following some of the practices |
| that XP is advocating, you can actually achieve these goals and you can |
| actually behave in this way. And the |
| development process is going to benefit overall. |

## 315 - XPs Values -  Principles -  and Practices

| Next I'm going to go over some of the XP's values |
| and principles that I just hinted on earlier in the lesson. |
| The first one, the first important value is communication. There |
| is no good project without good communication. And XP tries to |
| keep the right communication flowing and it uses several practices |
| to do that. It's got practices based on and require information |
| and in general share the information. For example, pair programming. |
| And we're going to say more about that. User stories, customer involvement, |
| all activities that help communication, |
| that faster communication. Another important |
| principle that we already saw, is simplicity. And the motto here |
| is live for today without worrying too much about the |
| future. When you have to do something, look for the simplest |
| thing that works. And the emphasis here is on, that |
| works. We want to build something simple, but not something stupid. |
| Feedback. That's extremely important in XP, and it occurs at |
| different levels, and it is used to drive changes. For example, |
| developers write test cases. And that's immediate feedback. If your test cases |
| fail, there's something wrong with the code. Or there's something that you |
| still haven't developed. Developers also estimate new stories right away as soon |
| as they get them from the customers and that's immediate feedback to |
| the customer. And finally, on a slightly longer time frame, customers and |
| tester develop together functional system test |
| cases to assess the overall system. |
| And also in this case, that's a great way to provide feedback |
| and by the way, also to help communication. And finally, courage, the courage |
| to throw away code if it doesn't work. To change it if you |
| find a way to improve it. To fix it if you find a problem. |
| To try out new things if you think that they might work better |
| than what you have right now. Now, that we can build and test systems |
| very quickly, we can be much braver than what we were before. So |
| how do we accomplish all that? And what are XP's practices that are going to |
| help us follow these principles and adhere to those values? These are some |
| of XP practices. There are more, but those are the ones that I'd like |
| to discuss in a little more depth, individually. Incremental planning, |
| small releases, simple design, test first, refactoring. We will actually |
| have a whole lesson next on refactoring. Pair programming, continuous |
| integration, and on-site customer. So let's start with incremental planning. |

## 316 - Incremental Planning

| Incremental planning is based on the idea that requirements are recorded |
| on story cards, sort of use cases or scenarios that the customer |
| provides. So the first step in incremental planning is to select |
| user stories for a given release, and which stories exactly to include |
| depends on the time available and on the priority. For example, |
| scenarios that we might want to realize right away because they are |
| particular important for the customer. After we select user stories for |
| the release, we break stories i to tasks. So what we do, |
| we take the user stories and we identify specific development tasks |
| that we need to perform in order to realize these stories. Once |
| we know our tasks, we can plan our release. And at |
| that point, we can develop, integrate and test our code. And of |
| course, this is more kind of an iterative process right here, |
| so we do this many times. When we're ready, when we accomplish |
| all of our tasks, all of our tests pass and we're happy, |
| we release this software. At the point, the released software is evaluated |
| by us, by the customer, and we can reiterate. We can |
| continue the process, select more stories and continue it this way. |

## 317 - Small Releases

| The first practice that we just saw goes together with |
| small releases practice. This idea that instead of having a big |
| release at the end of a long development cycle, we try |
| to release very often. And there are many advantages to small |
| releases and to releasing often. The first one is that |
| we deliver real business value on a very short cycle. And |
| what that means is that we get business value sooner, and |
| that in turn increase our customer confidence and makes the customer |
| more happy. So more releases also mean rapid feedback. We |
| release the software soon, we get feedback from the customer soon, |
| and we can in this way do exactly what we |
| were saying before, steer instead of driving, adapt weekly to possible |
| changes in the requirements. We avoid working for six months |
| on a project and find out six months later that the |
| customer wanted something else and we got the wrong requirements. In |
| addition having small releases, so seeing your product deployed and released |
| soon produces a sense of accomplishment for the developers. |
| And in addition, it also reduces risk because again, |
| if we're going down the wrong path, we will |
| know right away. If we're late, we will know right |
| away. So these are just additional advantages of having |
| this quick cycle and more releases. And finally, as we |
| also said before, we can quickly adapt in the |
| case our requirements change our code to the new requirements. |

## 318 - Simple Design

| The next practice is simple design. We want to avoid |
| creating a huge complicated possibly cumbersome design at the beginning of |
| the project. What we want to have instead is just |
| enough design to meet the requirements, so no duplicated functionality, fewest |
| possible classes and methods in general, just the amount of |
| design that we need to get our system to work. So |
| one might object that to for designing that way we |
| will have to change the code a lot, we will need |
| to adapt the design as the code evolves, |
| and that's exactly the point. That's what we will |
| do. XP is all about changing and adapting, |
| changing your design, changing your code, refactoring. And with |
| the fact that we have test cases throughout |
| the development process, we can do that with confidence. |
| Because if we break something we will know |
| right away, which leads us to the next practice. |

## 319 - Test First Development

| Which is test-first development. The key idea is that any program |
| feature that doesn't have an automatic test simply does not exist. If |
| there is a feature, you need to write a test for the |
| feature before. So, what developers do is to create unit tests for |
| each such piece of functionality even before the functionality is implemented. |
| And of course, when you run this test, they will fail. But |
| the beauty of it is that, as you write your code and |
| you add more and more fractionality to the feature that you're developing, |
| these test cases are going to start to pass. |
| And that's extremely rewarding because it gives you immediate |
| feedback, again feedback on the fact that you're |
| developing the code in the right way. As soon |
| as you write it, you will know. And if you write a piece of code and the |
| test says still fail, that means that the |
| code is not doing what it's supposed to do. |

## 320 - Refactoring

| A couple of minutes ago we talked about the fact that well, we |
| might need to change our design a lot, so how we going to do |
| that, that's going to be expensive. Well it's not very expensive, if we can |
| do efficient refactoring. Which is another |
| one of the important xp practices. And |
| what does it mean to refactor? It means to take a piece of |
| code who's design might be suboptimal, because for example, we evolved it, we |
| didn't take into account that from the beginning some of the features that |
| had to be added later, probably because we didn't even know about this |
| feature, because the requirements evolved. So we're going to take this piece |
| of code and we're going to restructure it, so that it becomes simple |
| and maintainable. Developers are expected to |
| refactor as soon as opportunities for |
| improvement, are found. And that happens for example, before adding some code. |
| You might look at the code that you're about to modify, or |
| to which you are about to add parts, and say can we |
| change the program to make the addition simple, that has maintainability or |
| we can do it after adding some code to our code base. |
| We might look at the code, the resulting code, and say well |
| can we make the program simpler? Was the running all the tests |
| and the key point here is that we don't want to refactor on |
| speculation, but we want to refactor on demand, on the system, and the |
| process needed. Again the goal is just to keep the code simple |
| and maintainable, not to over do it. And as I mentioned before |
| we're going to have a whole lesson, the next lesson on refactoring. So |
| we're going to go in more depth in the discussion of this topic. |

## 321 - Pair Programming

| The next practice I want to discuss is a very important one |
| in XP, and also one of the scandal, controversial, and it's |
| the practice of pair programming. What does it mean? It means |
| that all production code is written with two people looking at one |
| machine. And not that they're, they're working with one keyboard and |
| one mouse or they're not just interfering and writing on each other's |
| code. And the way in which that happens is by playing |
| different roles at different times. So the two developers alternate between the |
| role of programming and strategizing, where strategizing means, for example, |
| looking at the code that has been written and thinking whether |
| that would work. Or what other tests that are not there |
| might not work, given the way the code is being written. |
| Or maybe looking at the code from a, you know, slightly |
| detached perspective and trying to figure out whether the code can |
| be made simpler, more maintainable, more efficient. And interestingly, there are |
| measurements, there are studies that |
| suggest that development productivity with pair |
| programming is similar to that of two people |
| working independently. And that answers one of the |
| main objections against pair programming, which is why |
| should I put two developers together, which is |
| going to cut their productivity in half. It is |
| not. Studies shows that that does not happen. |
| And that the resulting code can actually benefit |
| from the fact that two developers are working together. |

## 322 - Continuous Integration

| An important practice to get all of this to work is |
| continuous integration, which means integrating and |
| testing every few hours, or a |
| day at most, because we don't want problems to pile up and |
| to be discovered too late when there are too many of them |
| to fix. So what goes on here is a cycle. And the |
| cycle starts with the developer's programming, as soon as the developers are |
| done modifying the code and they have a stable version they will |
| run the local tests. If the local tests fail, the developers will |
| go back to programming to fix their code and possibly add |
| new code as needed, and this cycle, mini cycle will continue |
| until all the local tests pass. At that point the developers |
| can integrate their code with the code of other developers. And they |
| can run test for the integrated system, and when they run |
| this test again there are two possibilities. The test might fail, and |
| if the test fails you broke it, and therefore you'll have |
| to fix it. So developers will have to go back and modify |
| the system and again going through the cycle of running the local |
| tests, integrating, and running the systems |
| tests. Conversely, if all the systems |
| tests pass, then at that point the code is good to go |
| and it is integrated into the system. And it will be the problem |
| of some other developers if something breaks because at the time you |
| integrated your code, the code was compiling, running and passing the tests |
| successfully. So again, if we do this every few hours or every |
| day, we can find problems very early, and we can avoid the situations |
| in which we have many different changes coming from |
| many different developers in a integration nightmare as a result. |

## 323 - On Site Customer

| The last practice I want to mention is on-site customer, and what |
| that means is that literally the customer is an actual member of |
| the team. So the customer will sit with the team and will |
| bring requirements to the team and discuss the requirements with them. So |
| the typical objection to this practice is the fact that it's just |
| impossible in the real world. There is no way that the customer |
| can have one person staying with the team all the time, and |
| the answer to that objection is that if the system is not |
| worth the time of one customer then maybe the system is not worth building. In |
| other words, if you're investing tons of |
| dollars, tons of money in building a system, |
| you might just as well invest a little more and have one of the people |
| in the customer's organization stay with the |
| team and be involved in the whole process. |

## 324 - Requirements Engineering

| Now that we saw what the main values and practices |
| of XP are, I want to go back for a minute |
| to discussion of requirements engineering in XP. In XP, user |
| requirements are expressed as scenarios or user stories, as we already |
| discussed. These are written by customers on cards, and what |
| the development team does is to take these cards, take these |
| users stories and break them down into implementation tasks. And |
| those implementation tasks are then used as a basis for scheduling |
| cost estimates. So given these estimates, and based on their priorities, |
| the customer will choose the stories that will be included in |
| the next release, in the next iteration. And at this point, |
| the corresponding cards will be taken by the developers and the, |
| the task will be performed, and the relative, and the corresponding |
| card will be developed. And just to give an idea of |
| the order of magnitude, if you consider a few months project, |
| there might be 50 to 100 user stories for a project of |
| that duration. So, now let me give you an example of what |
| the story card might look like, and I'm going to do it using |
| a story card for document downloading and you can really do all of |
| this, basically as seeing what the |
| scenario is, downloading and printing an article. |
| And it describes basically what happens when you do that, what is |
| the scenario. First, you select the article that you want from a displayed |
| list. You then have to tell the system how you will pay for |
| it. This can either be through a subscription, through a company account or |
| by credit card, and so on. So what developers do, they take |
| this story card, and they break it down in to development tasks. |
| So, here I'm showing you some examples of task cards for the |
| user story that we just saw. In particular I'm showing three task cards |
| and if we look at the third one, there is a name |
| for the task, which is implement payment collection. So this is the development |
| task that we have the perform and here, there's a description of |
| what that developed code should do. And notice that, you know, the task |
| card can even be more. explicit than this, more |
| specific than this, and talk about actual development tasks. |

## 325 - Testing Strategy

| As you probably realized by now, at job development, it's a |
| lot about testing. So there is a lot of emphasis on |
| testing. Testing first, te, testing early. So that's the reason why |
| I also want to discuss what is the testing strategy in XP. |
| So first of all what is the basic principle? The basic |
| principle is that testing is Coded confidence. You write your test |
| cases and then you can run them anytime you want. And |
| if they pass, they'll give you confidence that your code is behaving |
| the way it's expected. If they don't pass on the other |
| hand, you'll know that there's something to fix. Another important concept is |
| that test might be isolated and automated. So both the running and |
| the checking of the tests has to be automated for all of |
| this to work. And there are two types of tests. The first |
| type of test is unit tests, that are created by the programmers, |
| and they're created by looking at the task cards. The task cards |
| describe what they implemented, functionality should |
| do, and therefore allows the developers. |
| The right test that can test this functionality. That can |
| check that the code's correctly implemented functionality. And as we |
| said, you should really test every meaninful feature. So, for |
| example, you should test every meaningful method in your classes. |
| You should put specific attention to possibly complex implementations, special |
| cases or specific problems that you might think of. while |
| reading the task cards. In some cases, when you do |
| refactoring, you might also want to write test cases specific |
| to that refactoring. But we'll say more about that. So this |
| was for the first kind of tests that are involved in |
| the, in the XP process. The second kind of tests are |
| the system tests, also called acceptance tests. And those tests involve |
| the customer. So basically what happens is that the customer provides |
| the test cases for their stores and then the development team |
| transforms those into actual automated tests. So these are tests created |
| by the developers. They run very quickly and they run very frequently. |
| These are tests developed with the help, with the |
| involvement of the customer they run longer. And run less |
| frequently, they run every time the system is integrated. |
| According to the cycle we saw a few minutes ago. |

## 326 - Testing Strategy Quiz Question

| Now that we are done discussing XP Extreme Programming, I |
| would like to have a quiz, in which I make |
| sure that some of the concepts behind XP are well |
| understood. So, I'm going to ask you which of the following statements |
| about Extreme Programming are true, and here are the statements. |
| Because of pair programming, XP requires twice the number of developers. |
| In XP, code is rarely changed after being written. XP |
| follows the test driven development, or TDD, paradigm. The customer does |
| not need to provide any requirements in XP. |
| XP is an iterative software development process. So I |
| would like for you to mark all of |
| the statements that you think are true about XP. |

## 327 - Testing Strategy Quiz Solution

| The first statement is false. It is not true |
| that because of pair programming, we need twice as many |
| developers. In fact that there is some evidence that even |
| though in pair programming we have two developers working together, |
| that the overall efficiency of the programmers is not really |
| affected by use of this practice. In XP, code is |
| rarely changed after being written. This is also definitely false. |
| In fact in XP there is a lot of emphasis |
| on change on the fact that the code can be changed, |
| it can be resigned, because of the fact when we do |
| that, we have a set of these cases that we can |
| use to check right away that the code still works as |
| expected. So again in XP, it's all about steering rather than |
| just driving down one fixed direction. And therefore, the code can |
| be changed. So this statement is false. It is definitely true |
| that XP follows the test driven development paradigm. In XP we first |
| write tests, and then we write the code, which is |
| exactly what TDD is about. It is not true that |
| the customer does not need to provide requirements in XP. |
| The customer does provide requirements in the form of user |
| stories, and the user stories are the starting point of |
| the development process. Finally, XP is definitely an iterative software |
| development process. In fact, we saw that XP is based |
| on subsequent iterations of the same cycle, in which we |
| select from a set of story cards, or user |
| stories, the stories that we want to implement in the |
| next iteration. Based on that we develop task cards, |
| and then we use the task cards to write this |
| case and then to write code. And we continue |
| this cycle in an iterative way until we are done |
| with all the story cards, and all the user |
| stories, so definitely XP is an iterative software development process. |

## 328 - Scrum Intro

| Before concluding this class on java development, I want to |
| talk about another process that is very popular these days, and |
| it's used in many companies, which is called Scrum. Which similar |
| to XP is another agile development process, and I'm going to |
| start by discussing what the Scrum actors are. There's three |
| main kinds of actors. The first one is the product owner, |
| which means the customer. The product owner is mainly responsible for |
| the product back log, where the product back log is basically |
| the list of things that have to be done, the |
| back log in fact for the project. And that is |
| analogous to the user stories to be realized in XP, |
| that we just saw. So what the product owner does is |
| to clearly express these back log items, and to also |
| order them by value, so they can be prioritized. The second |
| actor is the team. The team is responsible for delivering |
| shippable increments to estimate the |
| back log items. It's normally self-organized, |
| consists of four to nine people, and it's what you |
| would consider normally as the main development team in a |
| project. And finally we have the Scrum master. The Scrum |
| master is the person who's responsible for the overall Scrum process, |
| so he or she has to remove obstacles, facilitate events, |
| helps communications, and so on. So you you can see |
| the Scrum master as sort of a manager or the |
| person who's got oversight, or the supervisor of the Scrum process. |

## 329 - High Level Scrum Process

| So I want to conclude this lesson by providing a high |
| level view of this scrum process. The process is represented here, |
| and as you can see it has several components. We're going to |
| go through all of them one at a time. We're going to |
| start with a product backlog. Product backlog is the single source |
| of requirements, for the process. They're order by value raised priority |
| necessity, so that all of this characteristics can be taken into |
| account when selecting which backlog items to consider for the next iteration. |
| It's a living list in the sense that backlog items |
| can be added or removed. And it's not really defined |
| as we just said, by the product owner. In the |
| sprint planning, what happens is that the next increment or |
| the next sprint is defined. So basically, the backlog items |
| of interest are selected based on the characteristics we just |
| mentioned: value, [UNKNOWN], priority, and necessity. And the items are |
| converted into tasks and estimated. So the result is this sprint |
| backlog, which is the set of backlog items that will |
| be completed during the next sprint. The sprint is an actual |
| iteration of this scrum process. It's got a main part |
| that lasts two to four weeks, and within this main part, |
| there are many daily scrums that last 24 hours. So |
| let's see how this work. A daily scrum is typically characterized |
| by a 50-minute meeting at the beginning of the day |
| for the team to sync, and what happens during the meeting |
| is that there is a discussion of the accomplishments since |
| the last meeting. A to do list for the next |
| meeting is produced, and there is also an obstacle analysis. |
| So if some problem appear, they're discussing the daily scrum, and |
| possible solutions are proposed. At the end of the two |
| four-week cycle, there is a sprint review and retrospective. The sprint |
| review normally consists of a four hour meeting. In the |
| meeting, the product owner assesses the accomplishment for the specific sprint, |
| and the team discusses issues that were encountered and solved. |
| There is typically a demo of the deliverable for that |
| sprint. And at that point, the product owner will also |
| discuss the backlogs. And together with the team they will decide |
| what to do next. In the retrospective conversely what happens |
| is there is more focus on the process. So the |
| goal of that part of the meeting is discussing possible |
| process improvements. To identify them |
| and if promising improvements are identified |
| try to plan how to implement those improvements and use them |
| in the next iterations. And something else that might happen at |
| the end of a sprint is that if the product increment |
| is good enough as it reach the state in which it |
| can be actually shipped that will result in a release that |
| is not just internal. To show the product owner the progress |
| that can also be deployed and actually used in production. So |
| one final consideration is that as you can see, XP and scrum |
| are fairly similar, and that's because they're both agile development |
| processes. So the main thing to keep in mind is that |
| they both implement and enforce |
| those ideas, values, practices, and characteristics |
| that we saw when we discussed agile development process in general. |

## 330 - Lesson Overview

| In the previous lesson, we discussed agile |
| software development. Its principles and practices. And two |
| specific agile processes. XP and Scrub. In |
| this lesson, we will introduce a practice that |
| is of fundamental importance in the context |
| of agile software development. Software refactoring. Software refactoring |
| is the process of taking a program and |
| transforming it to make it better. That is, |
| to make it easier to understand, make it |
| more maintainable, and in general to improve its |
| design. Specifically, we will discuss what the refactoring |
| is and why it is important? When to perform |
| refactoring, and when not to perform refactoring? And |
| how to perform refactoring in a fully automated way, |
| using tools. We will also introduce the concept |
| of bad smells, where a bad smell, in software, |
| is the indication that there might be something wrong with |
| the code that might call for the application of refactoring. |

## 331 - Introduction

| Let me start this lesson by discussing what is refactoring. |
| Refactoring is the process of applying transformation or refactoring to a |
| program. So as to obtain a refactor program. With an |
| improved design but with same functionality as the original program. So |
| key aspect of refactoring is the fact that refactoring should |
| be somatic to perserving So what is the main goal of |
| refactoring? The goal is to keep the program readable, understandable, and |
| maintainable as we evolve it. And to do this by eliminating |
| small problems soon, so that you can avoid big trouble later. And |
| I want to stress once more a key feature of refactoring, which |
| is the fact that it is behavior per serving. But how can |
| we ensure that the refactoring is behavior per serving? In other words, |
| how can we ensure that the program does the same thing before |
| and after applying a refactoring. So what we would like to do |
| is to have some guarantee that, that happens. And unfortunately in general, |
| there are no guarantees. But something we can do is to test |
| the code. For example, we can write tests that exercise the |
| parts of the program affected by the refactoring, and if we're in |
| a [INAUDIBLE] context, we might already have plenty of test cases |
| that exercise that part of the code. So we might just have |
| to rerun the test cases after the refactoring. And in fact, |
| that's a very advantageous situation, and that's a very good use of |
| existing test cases. And I want to make sure that you remember, |
| and that you beware that tests provide no guarantees. Testing can only |
| show the presence of defects, but cannot demonstrate their absence. |
| So we can use testing to get confidence in our |
| refactorings, but we can't really guarantee that the refactorings are |
| behavior preserving. I'd also like to point out that for some |
| simple refactoring, we can use a static analysis to actually |
| provide these guarantees. And in fact we will see examples of |
| such refactorings that are incorporated into IDs and that leverage |
| these kinds of analysis to perform refactoring in a safe way. |

## 332 - Introduction Question

| So let's have a small quiz and see whether you can remember why can testing |
| guarantee that that a refactoring is behavior is |
| preserving. So why testing can only show the |
| absence of defects and not their presence? |
| Is that because testing and refactoring are different |
| activities? Because testing is inherently incomplete? Or, just |
| because testers are often inexperienced? Make your choice. |

## 333 - Introduction Solution

| And the reason for this is because testing is inherently |
| incomplete. So let me re-size this a little bit, so that |
| I can make room for an illustration. And what I'm |
| going to show you here is just a reminder, that when we |
| test, we have a huge virtually infinite input domain, and |
| we have to derive from this input domain a few test |
| cases. By picking specific inputs in the domain, and of |
| course, corresponding outputs. And so what happens normally is that these |
| test cases represent the teeny tiny fraction of |
| the domain, and therefore testing is always incomplete. |

## 334 - Reasons to Refactor

| We saw at the beginning of the lesson, what are the |
| goals of refactoring? Or what are the reasons ,why we need to |
| refactor in the first place? The first reason is that requirements |
| change, and when the requirements change, we often need to change our |
| design accordingly. In other cases if any of the requirements unchange, |
| we might need to improve our design. And this happens for many |
| reasons. For example, we need to add a new feature, we |
| want to make the code more maintainable, and also in general programmers |
| don't come up with the best design the first time. So they might |
| need to adapt it after the fact. And the final reason I want to |
| mention is sloppiness, and to some |
| extent laziness, of programmers. And a typical |
| example of this is something that we all have done, which is copy |
| and paste programming. So instead of rewriting a new piece of code, because |
| we know that there is some code in some other parts for the |
| program that does a similar thing, we'll just copy the code over. And |
| before we know, we end up with tons of copies of the same functionality. |
| And when that happens, a good way of consolidating that code and |
| extracting that functionality is to use refactoring, for example, by creating a |
| method or a class that provides the functionality. And we'll see specific |
| examples of that. A question I would like to ask at this |
| point of the class is whether you have used refactoring before? So |
| I want you to take a second and think about it. And |
| no matter what you're history is, if you ever coded I bet |
| you any money that the answer is yes, you have done refactoring. |
| What do I mean? I'm going to give you an |
| example. I'm sure you renamed the class or a |
| method or change the name of some variables in |
| the code before. That's refactoring. Even something as simple as |
| renaming a class is refactoring, because, for example, it |
| might help you making your code more understandable. And of |
| course I'll admit that in this case, this is |
| a trivial refactoring, and there are much more interesting ones. |

## 335 - History of Refactoring

| So if you follow my class so far, you know that |
| I like to give a little bit of history when I talk |
| about a specific topic. So I'm going to do the same also |
| in this case for refactoring. I'm going to start by mentioning, the fact |
| that refactoring is something that programmers have always done. I gave |
| you a trivial example just a minute ago of what refactoring is. |
| So even more complicated refactorings are |
| something that are commonplace for developers. |
| Somehow refactoring is especially important in |
| the context of object-oriented languages and |
| probably it's because the object-oriented features are well suited to |
| make designs flexible and reusable. Because of the fact that help |
| encapsulation, information hiding, and so they make it easier to |
| modify something without changing the functionality that it provides to the |
| outside world. However, you should keep in mind that refactoring |
| is really not specific to object oriented languages, you can also |
| refactor other languages, it's just more common to see it in |
| that context. So one of the first examples of a specific |
| discussion of what the refactorings are is Opdyke's PhD |
| thesis in 1990. Which discusses refactorings for small talk. |
| And some of you might be familiar with small |
| talk, which is a specific objectory language. And in |
| more recent times, refactoring's becoming increasing popular due to |
| lightweight development methodoogies, due to agile development, which is |
| something that we just discussed in this class. For |
| example, when we talked about extreme programming, we mentioned refactoring |
| a few times. And the reason why its so popular |
| is because re-factoring is one of the practices that help. |
| Making changes less expensive. And therefore adapt to changing requirements |
| and changing environments more quickly. |
| And continuing with historical perspective, one |
| of the milestones in the history of re-factoring [INAUDIBLE] is |
| a book by Martin Fowler. This is a book entitled |
| Improving the Design of Existing [INAUDIBLE]. And it contains a |
| catalog of refactorings, a list of bad smells, in code, and |
| we're going to see what that mean exactly. Nothing to |
| do with other kinds of bad smells. It talks about |
| guidelines on when to apply refactoring. And finally, which is |
| very useful, it provides example of code, before and after. |
| Applying the refactoring and we're going to use more of the |
| same style when discussing refactoring in the rest of this |
| lesson. More specifically what we're discussing next, are some examples |
| of refactoring and also some examples of code bad smells. |

## 336 - Types of Refactorings

| There are many refactorings in Fowler's book, and what I'm |
| showing here is just a partial list. And we're not going to |
| have time to go through the complete list of refactorings, |
| so what I'm going to do instead, I'm just going to pick a |
| few of those, but I'm going to explain in more depth, |
| and for which I'm going to provide some examples. In particular, we're |
| going to talk about the collapse |
| hierarchy refactoring, the consolidate conditional |
| expressions, the decompose conditionals, extract |
| method, extract class, and inline class. |
| And we're going to see each of those individually in the rest of the lesson. |

## 337 - Collapse Hierarchy

| The first refactoring we're going to see is the collapse hierarchy |
| refactoring. When a software system undergoes a number of changes, over |
| time the collapse hierarchy may become, let's say, sub-optimal. There are |
| several refactorings that address this |
| issue for example, refactorings that allow |
| you to move methods and fields up and down the class |
| hierarchy. So what happens when you apply a number of these |
| refactorings, is that a subclass might become too similar to its |
| superclass and might not be adding much value to the system. |
| In this case, it is a good idea to merge |
| the classes together. That's exactly what the Collapse Hierarchy refactoring |
| does. Imagine, for instance, that we have two classes: employee |
| and salesman. And that salesman is just so similar to |
| employee that it does not make sense to keep them |
| separated. In this case, you could merge the two classes, |
| so that at the end of the refactoring, only employee |
| is left. And the resulting structure of the system is improved. |

## 338 - Consolidate Conditional Expression Question

| We're now going to talk about |
| the consolidate conditional expression refactoring. |
| A common situation in code is that you have a set |
| of conditionals with the same result. What that means that |
| sometimes the code contains a series of conditional checks in which |
| each check is different, yet the resulting action is the |
| same. In these cases, the code could be improved by combining |
| the conditionals using, for example, and, and or, as connectors. So |
| as to have a single conditional check, with a single result. |
| At that point you can also extract those conditional into a |
| method. And replace the conditional with a call, to debt matter consolidating |
| the conditional code in this way can make the checks clearer |
| by showing that you're really making a single check rather than multiple |
| checks, and extracted that condition and having that matter instead of |
| a condition can clarify your code by explaining why you're doing a |
| given check, rather than how you're doing it. You can see an |
| example of that situation in this code, which is the disabilityAmount method. |
| As the name of the method says, the purpose of this code |
| is to compute the disability amount for a given, for example, employee. |
| And there is a set of initial checks in the methods whose |
| goal is to decide whether there's this disabilityAmount should be instead zero. |
| And as you can see, there's multiple conditions. For example, there's a |
| check about the seniority level, and about the number of months that |
| the employee's been disabled. So far, whether the employee is part time |
| and the outcome of all these check is always the same. If they're |
| true, if the check is satisfied then there is no disability |
| amount. So the disabilityAmount is zero. So what I will do |
| if I apply the consolidate conditional expression to this matter, is |
| that I will take these three conditionals. I will put them together |
| by saying basically that if seniority is less than 2 or |
| monthsDisabled is greater than 12 or isPartTime is true then the |
| return should be zero. And once I have this combined conditional, |
| as I see here, I will just extract that into a method. |

## 339 - Consolidate Conditional Expression Solution

| So the resulting code will be like this. As you can see here, |
| now I don't have the conditionals any longer, but I just have a call to |
| this notEligibleForDisability method. And this makes the code so |
| much clearer, because if I just need to understand how disabilityAmount works, |
| I can clearly see there is an initial check that is actually checking whether |
| an employee's eligible for disabilities or not. And if the check is false, so |
| if the employee's eligible, then I'll just perform the rest of the computation. |
| Otherwise I'll simply return zero. |
| So if I don't need to understand the details of this check, |
| I can simply look at this method and understand it all. And if I need to look at |
| the details I can just go, and look at the implementation of this method, |
| and I will get exactly the same information that I have here. But I'm sort of |
| separating the concerns, and making the code overall more understandable, and |
| therefore more maintainable, which is the main goal of refactoring. |

## 340 - Decompose Conditionals

| Let's now see a related refactoring, which is the |
| decompose conditional refactoring. What happens here is that in some |
| cases, the complexity of the conditional logic in a program |
| can make a method hard to read and understand. Specifically |
| we might have one or more particularly complex conditional |
| statements. And similar to what we discussed for the previous |
| refactoring, the conditional, if it's too complex, might tell you |
| what happens, but obscure why it happens. To address this |
| issue, you can do a similar thing to what we did in |
| the previous refactoring. You can transform the condition into a method and then |
| replace the condition with a call to that method. And if you give |
| the right name to the method, as we saw in the last example, |
| that can make the code much clearer and much easier to understand. In |
| addition here you can also do something else. Let's assume that those are |
| the then and else part of the conditional are complex. We can do |
| the same thing with them. So what we can do, we can modify |
| the then and else part of the conditional by extracting the corresponding |
| code, making also that one into a method, suitably naming the method, |
| and then having the call to the method only in the then |
| and else part of the conditional statement. So let's see how that works |
| with an example. Here we have the matter that computes some charge. |
| And it computes the charge based on some corrective uses of the date |
| that is provided as input, or it's imagined or is just, you |
| know, one of the fields in the class. So as you can see, |
| there is a conditional here that checks that if the |
| dates is before the beginning of the summer, so before summer |
| start. Or it's after the summer end. Then it compute |
| the charge using some winterRate. Otherwise, if we are in the |
| summer, it will compute the quantity, the charge using a |
| summerRate. And this is just a small example, so it might |
| not look that complex. But, you know, just project this on |
| more realistic code, on larger code. You can end up with |
| the conditions that are hard to understand. And even in this case, even |
| such a small piece of code, you have to kind of look at |
| the conditionals, figure out what does it mean for the date to be |
| before the summer start and after the summer end. We can make this much |
| clearer. So, how can we do it? By applying this refactoring as we |
| described. Let's see what happens when |
| I apply the decompose conditionals refactoring to |
| this method. The first thing I will do is to take this condition, |
| create a method that perform exactly the same check, give it a meaningful name. |
| In this case I called it notSummer, which is pretty self-explanatory, and then |
| replacing the condition with a call to that matter. As you can see |
| here, there's a clear improvement in the code, because here I just need |
| to look at this statement and I see right away that the check. What |
| the check is doing is just checking whether the date is in the |
| summer or not. So, much easier than having to interpret this condition. And |
| the second thing I do is to take the code that computes the |
| charge and also in this case, creating |
| suitable methods that compute the winterCharge and |
| the summerCharge. And I called them exactly winterCharge and summerCharge which |
| again is self explanatory. And then I replace this computation with |
| a call to that method. So again, when I look at |
| this code, I can clearly see that the charge is computed |
| using some sort of winterCharge calculation and then using some sort |
| of summerCharge calculation. And if I don't want to know how |
| this is exactly computed, that's all I need to know to |
| understand what this method does. Easier and faster than looking at |
| this method and figuring out what it does. And if |
| I need to look at the details, exactly like in the |
| previous case, I can just go and look at the |
| implementation of winterCharge and summerCharge. But I will be looking at |
| that in its specific context. So, without having to understand |
| everything at once. So in this way, you make it clear |
| both why you're doing something, because it is notSummer, and |
| what exactly you're doing. You're computing a winterCharge, or a summerCharge. |

## 341 - Extract Class

| We are now going to talk about the extract class refactoring. When a |
| softer system evolves, we might end up with classes that really do the |
| work of more than one class because we keep adding functionality to |
| the class. Therefore also they're too |
| big, too complicated. In particular, we might |
| end up with a class that is doing the work of two |
| classes. Typical examples are classes with many methods and quite a lot of |
| data, quite a lot of fields. In this case, it's normally good idea |
| to split the class into two, so what you will do, you will |
| create a new class and move there the relevant fields and methods from |
| the original class. So as to have two classes, each one implementing a |
| piece of the functionality. Let's look at an example. In this case we're |
| going to use a UML like representation for the class. We have this class Person |
| that ends up representing also a phone number. And imagine that we add |
| up these pieces, you know, a little bit at the time so we end |
| up with something that really is doing the job of the person and |
| of the phone number. So what we can do, we can actually do exactly |
| what we described here. We split this class |
| into a Person class, and the Phone Number class. |
| And then we establish a use relation, so we |
| have a reference of the phone number class into |
| this class. And by separating the telephone number behavior |
| into its own class, I once more improved the |
| structure of the code, because now I have classes |
| that are more cohesive, and do exactly one thing. |

## 342 - Inline Class

| This new refactoring called inline class is the reverse of the extract class |
| refactoring. And know that this is kind of a general situation in the |
| sense that it is often the case that the refactoring also has a |
| reverse refactoring that does exactly the |
| opposite. So basically, un-dos, in a sense, |
| the operation of the other refactoring. In this case, the motivation for the |
| refactoring is that during system evolution, we might end up with one or |
| more classes that do not do much. In this case what you want |
| to do is to take the class that is not doing that much and |
| move its features into another class. And then delete the original class. |
| So let's use an example similar to the one we've used for |
| the previous refactoring to illustrate how this works. Here we have in |
| this case, two classes, person and office. And the person class is |
| using the office class, but this latter class, the office class, only |
| contains a phone number. So it doesn't really do that much. What |
| we can do is therefore to fold the office class into the |
| person class, by simply moving its only field into the class. And so |
| the result will be this person class that also contains the information |
| about the office number, and overall a simpler design for the code. |

## 343 - Extract Method

| The next re-factoring which is also the last one that we'll |
| see, extract method is one of the most commonly used re-factoring. As |
| it is applicable in many, many situations. The starting point is |
| a method that is too long and contains cohesive code fragments, that |
| really serve a single very specific purpose. So we start from |
| a cohesive code fragment in a large method. What we can do |
| in this case, is to create a method using that code fragment. |
| And then replacing the code fragment with a call to that method. |
| Let's look at this with an example. Here over this method called |
| print owing, and what it does, imagine that it does a lot |
| of operations here that I'm just not listing, and then it's got |
| a set of print statements. That are just printing a lot of details |
| about the owing information. And then again, a lot of code after |
| that. So what I could do in this case to simplify. The |
| method is to transform this set of statements. They are cohesive in |
| the sense that they do just one thing, they just print these details |
| into a method, and then I had, replace the statements with a |
| call to that method. Which is actually something similar to what we did |
| as part of some the previous re-factoring's. Here I'm showing the result. |
| So here is the method that I extracted. As you can see. It |
| contains the code that was previously here. I give you the meaningful |
| name, I called it printDetails so it's clear what it does. And now |
| the print owning method is simpler. Because I still have the remaining code |
| the one I didn't touch. But now this potentially long list of details. |
| Of prints, of details is not replaced by a single method code. |
| So a gain similar to the previous refactorings that we saw. If |
| we just look at the printing method, it's very easy to figure |
| out what this part does. Oh, print some details. And once more I |
| really want to stress this. If you don't care about how, this |
| is implemented and knowing that this print some details is enough. Then |
| you're done. You don't need to understand anything more. It's clear, it's |
| self explanatory. And if you'll need to look at what print details does, |
| you just go and look at print details. And you look at |
| it in isolation. So it's easier to understand what this does without having |
| to think the rest of the code. So once more the color we |
| factor in is just to improve your design, made the code more readable |
| Make the code more maintainable. And also keep in mind all of these, |
| are kind of small examples. You also always have to think about the |
| effect that this can have on larger codebases. It can really improve a |
| lot. The understandabililty, and maintainability of |
| your code. So in general, it's design. |

## 344 - Refactoring Demo

| So now we saw, this set of re-factoring's. They're nice, but |
| how can we actually perform re-factoring's? In some cases you'll have to |
| do it by hand. And you'll do it in that case in |
| small steps, so that you can check at every step that you |
| didn't introduce any area. But there's also many cases in which at |
| least for the more standard re-factoring's, you can just apply, you can |
| just use a tool that actually supports re-factoring. I'm going to show |
| you how that works, into a specific ID, Eclipse through a demo. |
| To show you how Eclipse, can help in performing |
| re-factoring, in an automated way, I just opened the Eclipse |
| editor and I maximized it. So that we can look |
| at the code more clearly. And as you can see |
| here, I have this class. It's called Re-factorable, it's a |
| pretty indicative name. And what we're going to do, we're going to |
| try to apply the extract method re-factoring to this class. |
| And in particular, to parts of this print owing method. |
| So this is a matter than will print owing's, |
| as the name says. And it will do several things |
| such as, for example, printing a banner first, then |
| calculating the outstanding debts, and then printing some details. So |
| the starting point for an extract method re-fractoring, is |
| the identification of some cohesive code fragment. And here, for |
| instance, we can see that, if we can see there, |
| these three print statements. They are basically printing some banner, |
| for the method. And I also put a comment here |
| just to make that even more explicit. So this is a |
| perfect case in which we might want to just extract |
| this part, create an independent method, so that we can make |
| the code more readable and maintainable. So I select, the |
| part of the code, that I want to put in my |
| method. I invoke the contextual menu, and as you can see |
| there is a re-factor entry here. Here are some re-factoring's [UNKNOWN], |
| re-factoring's that I can apply, and I'm going to select extract |
| method. When I do that, Eclipse is going to ask me to |
| specify a method name. I'll just call this one print |
| banner. And as you can see, as soon as I do |
| that, Eclipse will show me the preview, for the method |
| that will be generated. I'm going to leave the access modifier. To |
| public and I'm not going to change anything else. So, |
| now when I click Ok. As you can see Eclipse modified |
| my code so that now I have the Print Banner method |
| down here that does exactly what that piece of code was doing |
| before. And I just have an invocation of the Print Banner |
| method, up here, where the code was before. And of course, this |
| is something that we could have done by hand. It's pretty |
| easy to do, but it's even easier, to do it using Eclipse's |
| capabilities. And this will become even more apparent, when we consider slightly |
| more complex case. So here, if we look at this piece of |
| code for instance, we can that see this code |
| prints some details, about the always. And the reason |
| why this case is likely more complicated, is because |
| this code needs to know about the value of outstanding. |
| And whereas that underscore name, is a member of |
| the class, and therefore will be available to the |
| method. Outstanding is a locker variable, so a method |
| different from print, oh it wouldn't know anything about outstanding. |
| So let's see what happens when we try to apply |
| a re-factoring for this code. So we go again here |
| to the re-factor menu, we select extract method, we will |
| pick a name again. So let's call it [SOUND] print details, |
| since this is what the code does. And as you |
| can see here, Eclipse was able to figure out, that outstanding |
| has to be a parameter, of this method. So if |
| you look at the signature here, this will be very clear. |
| So outstanding has to be passed to the matter because |
| it's a locker variable of the print owing method. so |
| it will not be visible to the other methods otherwise. |
| So since eclipse figured it out, all I have to do, |
| is to press Ok. And at this point what I |
| will have here is my new method, for in details |
| that takes outstanding as a parameter. And does exactly what |
| the code was doing before. And here, where the code was, |
| I will have my print details invocation, with outstanding |
| as a parameter. So now, let's continue to extract methods. |
| And let's look at a even more complex case. which |
| is, the one involving this piece of code. So this |
| piece of code, as you can see, will calculate |
| the value of the outstanding debt. Will calculate the owing's, |
| and the way in which it does that, is by |
| considering all the orders, that are part of this enumeration. |
| That is the declared here, and it will |
| compute for each one, of these orders, the amount, |
| and then added to outstanding. So what is the |
| additional complication here? Well, the additional complication here is |
| that this code needs to know, not only |
| about outstanding. It also needs to know, about this |
| enumeration, because this one is also a local variable. |
| And in addition to that, this code also has |
| some side effects. So outstanding, is modified as a |
| consequence of the execution of this code. So how can |
| we do that in the extracted method? Well let's |
| see what the clips will do and what the clips |
| will suggest. It will try to again re-factor this |
| code and extract the method. In this case as you |
| can see. The clips does two things. First of all, |
| it figures out as before, that there are some parameters, |
| that are needed for this method to operate correctly. The |
| enumeration e, as we said, and the outstanding variable. In |
| addition, if you look at the method signature Eclipse will |
| also figure out that this method has to return, a |
| double value. So what does this value correspond to? This |
| value corresponds to a new value of outstanding. So if |
| we, give a name to this method, so we just |
| use the name, [SOUND] that I put in the comment |
| over there. We click Ok, and this will create |
| a method by extracting the code. And here, where the |
| method used to be, we will have that the |
| value of outstanding is updated. Based on the return value |
| of calculate outstanding. So in the end if we |
| look at this code, you can see that if we |
| just focus, on this code it's very easy to |
| understand what it does. It prints the banner, it calculates |
| an outstanding value, and then it prints some details. And |
| in case we don't care, as I said before, about the |
| details of what these methods do, we're done. And if we |
| care about the details we can look at each matter individually. |
| And get exactly the same information that we got before, |
| in a sort of a separation of concerns kind of way, |
| by focusing on one problem at a time. So now let |
| me do one last thing. So let me modify the code, |
| slightly. So i'm going to go back, to the version of |
| the code before re-factoring. So this is what we had. |
| And I'm going to add, an additional variable here, [SOUND] called count, |
| which I initialize to zero. Here I'm going to increase, [SOUND] |
| the value of count at every iteration. And |
| finally, here I'm going to print out the value |
| of count. Okay, now that I have this code up. So let's imagine that I |
| want to, again as I did before, extract this matter. So, I'm going to |
| give you a second. Have a look at this and see, if you see |
| any problem with that. Feel free to stop the video, if you need more time. |
| So the problem here is that I have two side effects. |
| Both outstanding and count are modified. And therefore it's not really |
| possible to extract this method, and preserve the semantics of this |
| code. Let's see if Eclipse will be able to figure that out. |
| And it does. If we try to extract the matter here, |
| you'll tell us that's an ambiguous return value. The selected block |
| contains more than one assignment to look at variables. And the |
| affected variables are outstanding, just a Double and Count which is |
| an integer. So it will refuse to extract the method. So |
| at this point if we wanted to do that we have |
| we'll have to do the re-factoring a different way, but I |
| don't really want to get there. I want to conclude here, |
| and I hope this this little demo helped you |
| realize how useful it can be to use an |
| id that supports re-factoring that can automate this important |
| task. And I also encourage you to try to play |
| with this, and try to use different re-factoring's, on |
| your code. So as to get familiar with the kind |
| of re-factoring's that are supported by the ID. And |
| also with the re-factoring's themselves and how should be used. |

## 345 - Extract Method Refactoring Quiz Question

| After the demo I would like to have a little quiz |
| about the extract method refactoring. And I would like to ask you |
| when is it appropriate to apply the extract method refactoring. Here I |
| have a set of possible scenarios. First one is when there is |
| duplicated code in two or more methods. When a class is too |
| large. When the names of two classes are too similar. Or when |
| a method is highly coupled with a class other than the one |
| where it is defined. So as usual, please mark all that apply. |

## 346 - Extract Method Refactoring Quiz Solution

| The first scenario is the typical case in which it is |
| recommended to use the extract method refactoring, when there is duplicated code |
| in two or more methods and we want to take this |
| code and factor is out, and basically have the two methods called |
| a third method, which is the one we create using the |
| refactoring. When a class is too large, normally we don't want to |
| apply the extract. Extract method. Instead, in this cases, it is |
| usually more appropriate to use the |
| extract class or extract subclass refactorings. |
| Analogously, when the names of two classes are too similar, extracting a |
| method will normally not help much. And all we need to do |
| in case having too similar names is actually a problem. Is to |
| rename one of the two classes, or both, if we wish. Finally, |
| it is definitely appropriate to apply the extract method of refactoring in |
| cases in which a method is highly coupled with a class other |
| than the one where it is defined. In this case, which we |
| will discuss also later in the lesson, the extract method of refactoring |
| allows us to extract part of the metal to With the other class. |
| Then we can take the matter that we just extracted and move it |
| to the class where it actually belongs. So the extract method is one |
| of the two refactorings that it is appropriate to apply in these cases. |

## 347 - Refactoring Risks

| Now that we saw a number of refactorings, we also saw |
| how refactorings can be performed automatically within an ID, I'd like |
| to make you aware of some risks involved with the user |
| refactorings. Refactorings are a very powerful tool, but you also have to |
| be careful, first of all when you do more complex refactorings, |
| you may also introduce subtle faults. What, we don't really call |
| regression errors. You might change something in the class. You might |
| think that that's a behavior preserving |
| transformation when considering the whole code, |
| and instead your change is affecting the behavior of some of the |
| other parts of the code. So, it's introducing a regression that will cause |
| some other functionality, some other piece |
| of functionality some other feature, to |
| work incorrectly. So you always have to be careful, and as we saw |
| at the beginning one way to avoid that is to run tests. |
| Every time you make a refactoring every time you change your code and |
| refactor your code. So is to get the least some confidence in |
| the fact that your refactoring is |
| indeed behavior preserving. Also consider the refactoring |
| should not. Be abused. Refactoring should be performed when it's needed. It's |
| useful to improve the design of your code when you see problems |
| with the design of the code. Shouldn't just be applied for the |
| final code because you can apply, for example, easily within a tool. |
| So be careful not over doing it when you refactor. And for |
| the same reason that we mentioned at the beginning, you should be |
| particularly careful when you're using refactoring |
| for systems that are in production. |
| Because if you introduce a problem, before the system goes in production, |
| then you might be able to catch it earlier, |
| with testing. Or before it's released. But, if you introduce |
| a problem for a system in production, then you have |
| to issue a new version of the code. You'll be |
| affecting, you might be affecting some users, because the code |
| fails on their machine. So, you have to be twice |
| as careful, when you are doing refactoring, when you're changing |
| your code for a system that is already in production. |

## 348 - Cost of Refactoring

| Let's also talk about the cost of refactoring. Refactoring might be |
| free or almost free if you're using a tool to do refactoring |
| as we did in our demo. But that's not always the |
| case. In many cases, refactoring involves quite a bit of manual work |
| if you're doing some manual refactoring. And how much that costs |
| depends on how well the operations on the source code are supported. |
| You might have partial support from an ID. You might have complete |
| support, in which case it's greater. Or you might have no support, |
| in which case you have to be very careful about |
| how you change your code and how you check that you |
| didn't change the behavior of the code. There's also an additional |
| cost associated with refactoring. Remember |
| that refactoring relies heavily on testing |
| after each small step of refactoring. So you might have |
| to develop test cases, specifically to check your refactoring. And even |
| if you have an existing test because, for example, you're working |
| some agile context and therefore you develop a lot of UNIX |
| test cases before writing your code. And therefore you have a good |
| regression test with it you can use every time you modify your code. |
| Nevertheless, when you refactor and you change your code, you might need |
| to update your test so it's not only the development of the test |
| cases but also it's maintaining the test cases. And if you have |
| a lot of test cases, you have to maintain more test cases. So |
| that's a cost that is not directly visible but can affect quite |
| a bit the overall cost of refactoring and the overall cost of system |
| development therefore. And finally, you should not |
| under estimate the cost of documentation maintenance. |
| Applying refactoring may involve changes in interfaces, |
| names, for example, names of classes. And |
| when you make this kind of changes, you might need to update the documentation, |
| and that's also cost. It's something that |
| takes effort and therefore should be considered. |

## 349 - When Not To Refactor

| Now I want to conclude this discussion on refactoring by telling you |
| when you should not refactor. One first clear case is when |
| your code is broken. I want to make it very clear, refactoring |
| is not a way to fix your code in terms of its |
| functionality. It's a way to improve the design of your code. |
| So if your code does not compile or does not run |
| in a stable way, it's probably better to throw it away |
| and rewrite it rather then trying to refactor it. By definition refactoring |
| should maintain the functionality of the |
| system. It should be behavior preserving. |
| So if the code was broken before, it, it's probably going to be broken |
| afterwards as well. You may also want to avoid refactoring when a |
| deadline is close. Well, first of all, because refactoring might take a long |
| time and therefore might introduce risks of being late for the deadline. |
| And also, because of what we said before about introducing problems, you don't |
| want to introduce problems that might take you time to fix right before a |
| deadline. So if the deadline is too close, you might want to avoid |
| refactoring the code at that point. And finally, do not refactor if there |
| is no reason to. As we said before, you should refactor on demand. You |
| see a problem with the design of your code, with the structure of your |
| code, it's okay to refactor. If the code is fine, there is no reason |
| to refactor. I know that refactoring is fine, but you don't want to do |
| it all the time. The next thing I want to discuss, after discussing when |
| not to refactor, is when to refactor without an indication that will tell us |
| that it's time to refactor the code. And that leads us to the discussion |
| of a very interesting concept. |

## 350 - Bad Smells

| The concept of bad smells. What are bad smells? Well, we |
| mentioned earlier that refactoring is typically applied when there is something |
| that does not look right, does not feel right in the |
| code. And that's exactly what bad smells are. Bad smells, or |
| code smells if you wish, are symptoms in the code of |
| a program that might indicate deeper problems. So there might be |
| parts of my system, classes in my systems, that just don't |
| smell right, and it feels like there's, there might be something wrong |
| with them. And if you are an experienced developer just like Brad, |
| you'll be able to figure out there is something wrong with the |
| classes. You'll be able to smell that there's something wrong and you'll |
| do something about it. And I want to mention one more, just to make |
| sure that we're all on the same page here. That these bad |
| smells are usually not bugs and don't prevent the program from functioning. They |
| however indicate weaknesses in the design of the system that might cause |
| problems during maintenance. In other words, |
| they might make the code less maintainable, |
| harder to understand, and so on. Just like refactorings, |
| there's also many possible different bad smells. So what |
| I'm providing here is just a possible list of |
| some very common bad smells. And you can find plenty |
| of information on this online. So what I want |
| to do next is just to cover before finishing the |
| lesson a few of those to show you some |
| examples of smells and what you can do about them. |

## 351 - Bad Smell Examples

| The first example I want to mention is this called duplicated |
| code. So what happens here what the symptom is, is that you |
| have the same piece of code. The same fragment of code or |
| code structure replicated in more than one place. And that's pretty common |
| when we do for example copy and paste programming. Is something |
| that we mention at the beginning of the lessons. So for example |
| we are just instead reimplementing a piece of functionality we know we |
| already have. We simply copy from a different part of the code. |
| So what do you do if you have duplicated code? This can |
| be a problem over time because we might end up with a lot |
| of duplication in your system. You can use the extract method. Refactoring that |
| we just saw, and basically create a method that has exactly the same |
| function as this fragment of code and then replace the fragment of code |
| with an invocation to run and you will do it in all the |
| places where the code is duplicated. That simply finds the code and favors |
| reuse, because there can be more |
| places that benefit from that additional method. |
| Especially if it implements some popular piece of functionality. Another example |
| of best mal a typical one is the long method. So you |
| have a very long method with a lot of statements. And we |
| know that the longer procedure, the more difficult it is to understand |
| it and maintain it. So what I'm going to do in this |
| case is to factor in such as an extract method or a |
| decompose conditional to make the code simpler, shorten it. And extract some |
| of the functionality into other methods. So basically break down the method |
| in smaller methods that are more cohesive. Another typical example |
| of best mail which is something that can happen very |
| commonly during maintenance, is that you keep adding functionality to |
| a class and you end up with a large class. So |
| class is clearly to big. It contains too many fields |
| too many methods, and is just too complex to understand. This |
| case the obvious solution is to use the extract class |
| or subclass and basically break down the class in multiple classes. |
| Each one with a more cohesive piece of functionality. So, the |
| classes are more cohesive, are more |
| understandable, and the overall structure The |
| structure of the system is improved. Shotgun surgery is an interesting smell |
| and the case here is we are in a situation and you, |
| probably will happen to you, it definitely happened to me, in |
| which every time you make some kind of change to the system |
| you have to make many little changes. All over the place to |
| many different classes. And this can be a symptom of the fact |
| that the functionality is spread among these different classes. So |
| there's too much coupling between the classes and too little |
| cohesion within the classes. Also in this case you can |
| use refactoring, for example by using the move method or move |
| field or inline class to bring the pieces of related |
| functionality together. So that your resulting classes are more cohesive, you |
| reduce the dependencies between the different classes, and you address |
| this problem. Because at this point, each class is much more |
| self-contained and therefore it can be |
| modified by itself without having to affect |
| the rest of the system. The last smell I want to mention is |
| one I really like, is the feature envy, and it refers to a |
| method that seems more interested In a class other than the one it |
| belongs to. So for example this method is using a lot of public |
| fields of another class, is calling a lot of methods of the other |
| class. And so in this case the solution is really clear. What you |
| want to do it to perform the extract method refactoring and then the move |
| method refactoring so as to take the jealous |
| method out of the class where it doesn't |
| belong and get it home. To the class where it really belongs and once more the |
| effect of this is that you decrease the |
| coupling between the two classes and therefore you |
| have a better system and also you eliminate |
| the envy. Which is always a good thing. |

## 352 - Bad Smell Quiz Question

| So now, I would like for you to tell me |
| which of the following can be considered bad smells in |
| the context of refactoring. The fact that the program takes |
| too long to execute? The fact that method M in class |
| C is very long? Or the, the fact that Class |
| Cat and Dog are subclasses of class Animal? Or finally the |
| fact that every time we modify method M1 we also |
| need to modify method M2? So please mark all that apply. |

## 353 - Bad Smell Quiz Solution

| So let's look at this one by one. The fact the program takes |
| too long to execute is not really a bad smell. It probably indicates |
| some problem with the code and the fact that we might need to |
| modify the code to make it more efficient, but it's not something that |
| we will normally classify it as a bad smell, so we're not going to |
| mark it. The second one, conversely, is definitely a bad smell. The fact |
| that the method is too long is a typical example of bad smell |
| and one in which we might want to apply some refactoring, for example, |
| the extract method or the |
| decomposed conditional refactorings. There's definitely |
| nothing wrong with the fact that the classes cat and dog |
| are subclasses of class animal. Actually, that sounds pretty appropriate, so |
| this is not a problem and definitely not a bad smell. |
| Whereas the fact that every time we modify method M1, |
| we also need to modify method some other method M2 as |
| a typical example of bad smell. So this can actually be |
| considered a specific example of what we just called "shotgun surgery." |
| So it is a case in which we might want to |
| use, for instance, the move method refactoring to fix the issue. |

