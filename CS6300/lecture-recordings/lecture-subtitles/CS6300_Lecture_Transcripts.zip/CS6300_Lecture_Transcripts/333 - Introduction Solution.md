# CS6300 333 - Introduction Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,220 --> 00:00:03,180 | And the reason for this is because testing is inherently |
| 00:00:03,180 --> 00:00:06,080 | incomplete. So let me re-size this a little bit, so that |
| 00:00:06,080 --> 00:00:08,340 | I can make room for an illustration. And what I'm |
| 00:00:08,340 --> 00:00:11,170 | going to show you here is just a reminder, that when we |
| 00:00:11,170 --> 00:00:15,380 | test, we have a huge virtually infinite input domain, and |
| 00:00:15,380 --> 00:00:17,956 | we have to derive from this input domain a few test |
| 00:00:17,956 --> 00:00:21,330 | cases. By picking specific inputs in the domain, and of |
| 00:00:21,330 --> 00:00:25,260 | course, corresponding outputs. And so what happens normally is that these |
| 00:00:25,260 --> 00:00:28,280 | test cases represent the teeny tiny fraction of |
| 00:00:28,280 --> 00:00:28,280 | the domain, and therefore testing is always incomplete. |