# CS6300 175 - More Examples

| Timestamp | Content |
|-----------|---------|
| 00:00:00,180 --> 00:00:03,090 | As another example, I want to show you the architecture of the |
| 00:00:03,090 --> 00:00:06,290 | iRods system. This is a data grid system that was built by |
| 00:00:06,290 --> 00:00:09,720 | a biologist. And it's a system for storing and accessing big |
| 00:00:09,720 --> 00:00:11,910 | data. So what I'm going to do, I'm going to do the same thing |
| 00:00:11,910 --> 00:00:14,010 | that I did for the Linux system. I'm going to show you |
| 00:00:14,010 --> 00:00:18,080 | here, on the left hand side, this clean prescriptive architecture for the |
| 00:00:18,080 --> 00:00:21,000 | iRODS system. And I'm going to show you here on the right the |
| 00:00:21,000 --> 00:00:22,660 | actual architecture of the system. The |
| 00:00:22,660 --> 00:00:25,780 | descriptive architecture of iRODS. So here, |
| 00:00:25,780 --> 00:00:27,640 | even if we don't go in and look at the details, you |
| 00:00:27,640 --> 00:00:31,800 | can see very easily that the system is badly drifted and eroded |
| 00:00:31,800 --> 00:00:34,500 | with respect to the way it was supposed to be. Continuing |
| 00:00:34,500 --> 00:00:36,500 | with the examples. What I want to show you now is the |
| 00:00:36,500 --> 00:00:39,980 | view of the complete architecture of HADOOP. As many of you probably |
| 00:00:39,980 --> 00:00:44,210 | already know, HADOOP is an open source software framework for storage and |
| 00:00:44,210 --> 00:00:47,990 | large scale processing of data sets. It's very broadly used. And here |
| 00:00:47,990 --> 00:00:50,820 | is a picture of the architecture, and I hope you can see it |
| 00:00:50,820 --> 00:00:54,290 | because the architecture is so complex and so broad and so |
| 00:00:54,290 --> 00:00:57,050 | intertwined, and in order to be able to represent it here |
| 00:00:57,050 --> 00:00:59,690 | in one page, I had to zoom out quite a bit. |
| 00:00:59,690 --> 00:01:02,120 | But also in this case, you don't really have to look |
| 00:01:02,120 --> 00:01:05,640 | at details. The important point here is that in this software architecture |
| 00:01:05,640 --> 00:01:09,540 | 61 out of the 67 components in the system have circular |
| 00:01:09,540 --> 00:01:12,570 | dependencies. Which means that they depend on each other in a |
| 00:01:12,570 --> 00:01:15,820 | circular way and this is normally not a good thing and also |
| 00:01:15,820 --> 00:01:18,790 | in this case a few developers when shown the diagram had no |
| 00:01:18,790 --> 00:01:18,790 | idea that the structure of the system was so complex and messy. |