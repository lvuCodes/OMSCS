# CS6300 86 - Pertinence Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:03,530 | Now that we talked about completeness and pertinence, let's consider an |
| 00:00:03,530 --> 00:00:06,200 | information system for a gym. I'm going to give you a |
| 00:00:06,200 --> 00:00:09,580 | list of possible requirements and I want you to mark in |
| 00:00:09,580 --> 00:00:13,530 | that list all the requirements that you believe are pertinent. So let |
| 00:00:13,530 --> 00:00:16,030 | me read the list. Members of the gym shall be able |
| 00:00:16,030 --> 00:00:18,770 | to access their training programs. The system shall be able to |
| 00:00:18,770 --> 00:00:21,894 | read member cards. The system shall be able to store members' |
| 00:00:21,894 --> 00:00:25,150 | commute time. Personal trainers shall be able to add clients. And the |
| 00:00:25,150 --> 00:00:25,150 | list of members shall be stored as a linked list. |