# CS6300 144 - State Transition Diagram Example

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:02,850 | As usual were going to illustrate these kind of diagrams by |
| 00:00:02,850 --> 00:00:06,050 | using an example. In particular we are going to describe the state |
| 00:00:06,050 --> 00:00:09,330 | transition diagram for part of our example, for part of |
| 00:00:09,330 --> 00:00:12,640 | our course management system. And we're going to focus on the course |
| 00:00:12,640 --> 00:00:15,540 | offering class. When the class is created, it enters the |
| 00:00:15,540 --> 00:00:19,490 | initialization state, in which the activity performed is to initialize the |
| 00:00:19,490 --> 00:00:22,580 | course. At this point, a simple case is the case in |
| 00:00:22,580 --> 00:00:25,550 | which the class is cancelled, so there is a cancelled event. |
| 00:00:25,550 --> 00:00:28,700 | And if that happens, the class is simply cancelled. So it |
| 00:00:28,700 --> 00:00:31,720 | gets into this final state, which is the state cancelled. And |
| 00:00:31,720 --> 00:00:35,500 | the activity in this case is to notify the registered students. |
| 00:00:35,500 --> 00:00:38,580 | Obviously if this is the flow there will be no registered students. |
| 00:00:38,580 --> 00:00:41,110 | However something else can happen when we are in this initial |
| 00:00:41,110 --> 00:00:43,930 | state. So what can happen is that a student can register, so |
| 00:00:43,930 --> 00:00:47,260 | in this case the add student event is triggered. And the |
| 00:00:47,260 --> 00:00:50,620 | corresponding action is to set the count, in this case it would |
| 00:00:50,620 --> 00:00:53,270 | be the count of students for the course offering, to one. And |
| 00:00:53,270 --> 00:00:55,570 | there will be a change of state and the course offering will |
| 00:00:55,570 --> 00:00:58,870 | get into this open state. And the action that will be performed |
| 00:00:58,870 --> 00:01:02,260 | on entry will be to register the student. At this point more |
| 00:01:02,260 --> 00:01:06,920 | students may register. So other student events might occur and notice that we |
| 00:01:06,920 --> 00:01:10,630 | have a curve here that tells us this event will trigger this |
| 00:01:10,630 --> 00:01:13,790 | transition only if the count is less than 10. So we're assuming |
| 00:01:13,790 --> 00:01:16,120 | that we're not going to have more than 10 students just for lack |
| 00:01:16,120 --> 00:01:19,010 | of a better number in our course offering. So if that |
| 00:01:19,010 --> 00:01:21,960 | happens, if the count is less than ten so then the count |
| 00:01:21,960 --> 00:01:25,880 | is incremented so the increment count action takes place. And the |
| 00:01:25,880 --> 00:01:28,910 | system goes back into the open state, and the new student |
| 00:01:28,910 --> 00:01:32,100 | is registered. Now here we have an interesting transition, because there's |
| 00:01:32,100 --> 00:01:35,380 | no event triggering the transition, but simply the fact that the |
| 00:01:35,380 --> 00:01:37,780 | count is equal to 10. So you can imagine this as |
| 00:01:37,780 --> 00:01:40,930 | being a transition that is always enabled so can always be triggered, |
| 00:01:40,930 --> 00:01:43,410 | but will be guarded. By the fact that the count has |
| 00:01:43,410 --> 00:01:46,750 | to be exactly ten. So basically this transition will take place |
| 00:01:46,750 --> 00:01:49,800 | only when enough students are added, such we get to count |
| 00:01:49,800 --> 00:01:52,900 | them. Being incremented and being equal to ten and then the transition |
| 00:01:52,900 --> 00:01:55,590 | will occur. And we will get into the closed state, in |
| 00:01:55,590 --> 00:01:59,025 | which the class is no longer open because there are enough students |
| 00:01:59,025 --> 00:02:01,730 | registered. And at this point, what will happen is that the |
| 00:02:01,730 --> 00:02:06,320 | course will be finalized. So there will be this activity which performs |
| 00:02:06,320 --> 00:02:09,699 | some operation that is needed to finalize the course. Another possibility |
| 00:02:09,699 --> 00:02:12,150 | is that when we are in the open state, the course |
| 00:02:12,150 --> 00:02:14,680 | is cancelled. And if the course is cancelled, in this case, |
| 00:02:14,680 --> 00:02:18,320 | we go again to the cancel state. But here, the activity |
| 00:02:18,320 --> 00:02:21,850 | of notifying registered students makes more sense. Because we will have |
| 00:02:21,850 --> 00:02:24,960 | at least one registered student in this state, and therefore we'll |
| 00:02:24,960 --> 00:02:28,190 | need to notify such student that the course offering has been |
| 00:02:28,190 --> 00:02:31,470 | cancelled. Finally, is it also possible also to cancel a course |
| 00:02:31,470 --> 00:02:34,050 | after it has been closed? And in this case again, the |
| 00:02:34,050 --> 00:02:38,040 | same thing will happen. The class will reach the cancelled state and |
| 00:02:38,040 --> 00:02:40,850 | all the students, in this case ten students, that are registered |
| 00:02:40,850 --> 00:02:43,730 | for the course will be notified that the course has been cancelled. |
| 00:02:43,730 --> 00:02:46,100 | So, if we look at this state transition diagram, you can |
| 00:02:46,100 --> 00:02:49,860 | see that it's pretty easy to see what the evolution of objects |
| 00:02:49,860 --> 00:02:52,590 | of this class can be. How they can go from their initial |
| 00:02:52,590 --> 00:02:56,660 | state to various final states depending on what are the external events |
| 00:02:56,660 --> 00:02:56,660 | that reach the system. |