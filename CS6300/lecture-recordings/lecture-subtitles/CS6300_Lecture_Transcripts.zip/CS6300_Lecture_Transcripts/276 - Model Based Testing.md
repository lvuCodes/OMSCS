# CS6300 276 - Model Based Testing

| Timestamp | Content |
|-----------|---------|
| 00:00:00,370 --> 00:00:02,950 | What we just saw with the category-partition method, is a |
| 00:00:02,950 --> 00:00:05,530 | specific instance of this systematic |
| 00:00:05,530 --> 00:00:08,230 | functional testing approach. So specific instance |
| 00:00:08,230 --> 00:00:10,900 | of the steps that we represented here. And, as I |
| 00:00:10,900 --> 00:00:13,100 | mentioned earlier on, this is not the only way in which |
| 00:00:13,100 --> 00:00:16,700 | you can generate test cases, starting from a functional specification. |
| 00:00:16,700 --> 00:00:20,190 | In particular, this step, in which we identified relevant inputs and |
| 00:00:20,190 --> 00:00:23,390 | then we combine them to generate test case specifications, can also |
| 00:00:23,390 --> 00:00:25,490 | be done in different ways. And, we're going to look at one |
| 00:00:25,490 --> 00:00:28,170 | of these ways. Which is through the construction of a |
| 00:00:28,170 --> 00:00:31,040 | model. And, the reason why I want to talk about models. |
| 00:00:31,040 --> 00:00:34,090 | Is because, model based testing is also, fairly popular in |
| 00:00:34,090 --> 00:00:37,680 | industry. And fairly used in practice. In model based testing, the |
| 00:00:37,680 --> 00:00:41,150 | way in which we go from specifications, to test cases, |
| 00:00:41,150 --> 00:00:44,220 | is through the construction of a model. Where a model is |
| 00:00:44,220 --> 00:00:47,670 | an abstract representation of the software under test. Also in |
| 00:00:47,670 --> 00:00:50,860 | this case there are many possible models, that we can use. |
| 00:00:50,860 --> 00:00:52,180 | And what we're going to do, we're going to focus |
| 00:00:52,180 --> 00:00:54,370 | on a specific kind of model. And I'll |
| 00:00:54,370 --> 00:00:57,010 | just point you to additional sources of information, |
| 00:00:57,010 --> 00:00:57,010 | in case you're interested in seeing other examples. |