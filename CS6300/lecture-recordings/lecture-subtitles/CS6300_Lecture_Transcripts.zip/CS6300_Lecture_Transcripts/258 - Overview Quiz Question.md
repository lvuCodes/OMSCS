# CS6300 258 - Overview Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:02,469 | Let's look at this spreadsheet. I'm pretty sure most of you |
| 00:00:02,469 --> 00:00:05,990 | are familiar with what a spreadsheet is and have used them before. |
| 00:00:05,990 --> 00:00:08,119 | So now I'm going to ask the same question, which is I'd |
| 00:00:08,119 --> 00:00:10,480 | like you to identify three possible |
| 00:00:10,480 --> 00:00:10,480 | independently testable features for a spreadsheet. |