# CS6300 186 - Architectural Styles Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:02,680 | Okay, let's start with the Android Operating System. The Android |
| 00:00:02,680 --> 00:00:07,170 | system, heavily based on the generation and handling of events, |
| 00:00:07,170 --> 00:00:10,640 | so it is mostly an event driven system. However, it |
| 00:00:10,640 --> 00:00:13,870 | also has some elements of publish, subscribe, in the way |
| 00:00:13,870 --> 00:00:17,480 | elements in the system can register for elements of interest. |
| 00:00:17,480 --> 00:00:20,570 | So we can mark both styles here. So what about |
| 00:00:20,570 --> 00:00:23,449 | Skype? We haven't discussed Skype yet. So here we probably |
| 00:00:23,449 --> 00:00:25,019 | had to take a little bit of a wild guess. |
| 00:00:25,019 --> 00:00:27,068 | But as we will see in more detail in the |
| 00:00:27,068 --> 00:00:29,736 | rest of the lesson. Skype is mainly a peer to |
| 00:00:29,736 --> 00:00:34,035 | peer architecture, with some minimal elements of a client server |
| 00:00:34,035 --> 00:00:37,770 | architecture. For example, when you start Skype and sign in |
| 00:00:37,770 --> 00:00:40,420 | to a conceptually centralized server. So let's move to the |
| 00:00:40,420 --> 00:00:42,930 | World Wide Web. As we just discussed, the Word Wide |
| 00:00:42,930 --> 00:00:46,255 | Web is based on a rest architecture. And because rest |
| 00:00:46,255 --> 00:00:50,170 | style, is a hybrid derived from other architectural styles, including the |
| 00:00:50,170 --> 00:00:53,960 | client server architectural styles. Both of those styles apply here. |
| 00:00:53,960 --> 00:00:57,465 | And finally Dropbox is by and large, a client server |
| 00:00:57,465 --> 00:01:01,904 | architecture. As conceptually, we upload our documents to a Dropbox |
| 00:01:01,904 --> 00:01:01,904 | central server, and get the files from the same server. |