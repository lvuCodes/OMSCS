# CS6300 24 - Software Phases Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,070 --> 00:00:02,590 | Okay. Now before we jump into the next |
| 00:00:02,590 --> 00:00:04,780 | topic, I just want to take a very quick and |
| 00:00:04,780 --> 00:00:06,630 | simple quiz just to make sure that you |
| 00:00:06,630 --> 00:00:09,236 | guys paid attention to what I just discussed. So |
| 00:00:09,236 --> 00:00:10,820 | I want to ask you what are the traditional |
| 00:00:10,820 --> 00:00:13,200 | software phases. Requirements engineering, |
| 00:00:13,200 --> 00:00:16,079 | design, abstraction, implementation, verification and |
| 00:00:16,079 --> 00:00:18,020 | validation. Or maybe design, |
| 00:00:18,020 --> 00:00:20,830 | optimization, implementation verification and validation |
| 00:00:20,830 --> 00:00:22,448 | and maintenance. Or requirements |
| 00:00:22,448 --> 00:00:24,892 | engineering, design, implementation, verification and |
| 00:00:24,892 --> 00:00:24,892 | validation, and maintenance. |