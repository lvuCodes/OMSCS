# CS6300 115 - Benefits of OO

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:02,110 | So in more general terms, why do we want to |
| 00:00:02,110 --> 00:00:05,330 | use object orientation? The first reason is that object |
| 00:00:05,330 --> 00:00:10,530 | orientation can help reduce long-term maintenance costs by limiting |
| 00:00:10,530 --> 00:00:12,700 | the effects of changes. As we saw, the effect |
| 00:00:12,700 --> 00:00:15,990 | of using encapsulation and information hiding makes it easier |
| 00:00:15,990 --> 00:00:18,700 | to modify parts of the system without affecting the |
| 00:00:18,700 --> 00:00:21,590 | rest of the system. Object orientation can also improve |
| 00:00:21,590 --> 00:00:25,870 | the developing process by favoring code and design reuse. |
| 00:00:25,870 --> 00:00:27,840 | In general, object orientation helps |
| 00:00:27,840 --> 00:00:31,750 | enforcing good design principles. Principles such |
| 00:00:31,750 --> 00:00:34,880 | as the ones that we saw in encapuslation, information hiding, high |
| 00:00:34,880 --> 00:00:39,470 | cohesion, low coupling and we will discuss these aspects more extensively |
| 00:00:39,470 --> 00:00:39,470 | in the next mini course which is centered around design concepts. |