# CS6300 174 - Real World Example

| Timestamp | Content |
|-----------|---------|
| 00:00:00,210 --> 00:00:02,770 | Now to drive home some of the points that I just |
| 00:00:02,770 --> 00:00:05,920 | made, I would like to show you a few real world examples |
| 00:00:05,920 --> 00:00:09,150 | of architectures that kind of went astray. The first example I |
| 00:00:09,150 --> 00:00:11,970 | want to use is an example from the Linux kernel. Actually, from |
| 00:00:11,970 --> 00:00:15,260 | an earlier version of the Linux kernel. A research group studied |
| 00:00:15,260 --> 00:00:17,020 | the documentation of Linux, and also |
| 00:00:17,020 --> 00:00:19,440 | interviewed several Linux developers. And by |
| 00:00:19,440 --> 00:00:21,710 | doing that, they were able to come up with a software |
| 00:00:21,710 --> 00:00:25,260 | architecture of Linux at different levels of obstruction. So the one that |
| 00:00:25,260 --> 00:00:27,365 | I'm showing you here on the left, is the |
| 00:00:27,365 --> 00:00:31,120 | software architecture at the level of Linux's main subsystems. So |
| 00:00:31,120 --> 00:00:34,540 | this is the prescriptive architecture of Linux at the level |
| 00:00:34,540 --> 00:00:38,060 | of Linux's main subsystems. So the researchers, after identifying this |
| 00:00:38,060 --> 00:00:40,420 | architecture, they showed it to the developers, and the |
| 00:00:40,420 --> 00:00:43,180 | developers agreed that, that was indeed the architecture of the |
| 00:00:43,180 --> 00:00:46,540 | system. The researchers then studied the source code of Linux |
| 00:00:46,540 --> 00:00:50,380 | and reverse engineered its actual architecture. So the architecture as |
| 00:00:50,380 --> 00:00:54,020 | implemented, it's descriptive architecture. And this one here, on the |
| 00:00:54,020 --> 00:00:56,610 | right, is the result. And as you can see, they found |
| 00:00:56,610 --> 00:01:00,940 | a number of differences or violations between the prescriptive architecture and |
| 00:01:00,940 --> 00:01:04,080 | the descriptive architecture. In particular, if we look at this architecture, |
| 00:01:04,080 --> 00:01:06,820 | we can see that pretty much everything talks to everything else, |
| 00:01:06,820 --> 00:01:09,010 | which is, in general, not a good thing. And in addition |
| 00:01:09,010 --> 00:01:11,890 | to that, there are also several things that don't really make |
| 00:01:11,890 --> 00:01:15,630 | much sense. For example the library calls the file system and |
| 00:01:15,630 --> 00:01:19,290 | also the network interface which doesn't make much sense. Another thing |
| 00:01:19,290 --> 00:01:21,850 | that is kind of weird is the fact that file system |
| 00:01:21,850 --> 00:01:25,250 | calls the kernel initialization code. Which is also a little bit |
| 00:01:25,250 --> 00:01:28,100 | weird. So basically, the bottom line here is that not even |
| 00:01:28,100 --> 00:01:32,020 | the developers realized how the actual architecture of the system was, |
| 00:01:32,020 --> 00:01:35,170 | and how it was different from the architecture they have conceived. |
| 00:01:35,170 --> 00:01:37,870 | And in fact another interesting thing here is the reaction of |
| 00:01:37,870 --> 00:01:41,020 | the developers when they were shown the actual architecture. So basically |
| 00:01:41,020 --> 00:01:44,110 | they justified the differences by saying things such as, well you |
| 00:01:44,110 --> 00:01:47,120 | know it had to be done fast, and therefore I changed it |
| 00:01:47,120 --> 00:01:50,110 | and then I didn't have time to go back and update the documentation |
| 00:01:50,110 --> 00:01:52,800 | and things of this sort. And by the way these are exactly some |
| 00:01:52,800 --> 00:01:55,640 | of the reasons that we mentioned early on in the lesson for the |
| 00:01:55,640 --> 00:01:58,410 | discrepancy between prescriptive and descriptive software |
| 00:01:58,410 --> 00:01:59,990 | architecture. So one last thing that I |
| 00:01:59,990 --> 00:02:02,840 | want to mention here as an aside and we can get back to |
| 00:02:02,840 --> 00:02:06,495 | that later is the fact that you can probably clearly show how representing |
| 00:02:06,495 --> 00:02:10,880 | software architectures graphically can be extremely useful, because it allows |
| 00:02:10,880 --> 00:02:14,140 | for easily seeing the structure of the system. Look at different |
| 00:02:14,140 --> 00:02:17,140 | views identify problematic points and so on. And we will see |
| 00:02:17,140 --> 00:02:17,140 | how that can be useful in many cases also later on. |