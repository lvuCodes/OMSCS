# CS6300 326 - Testing Strategy Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,130 --> 00:00:02,776 | Now that we are done discussing XP Extreme Programming, I |
| 00:00:02,776 --> 00:00:04,612 | would like to have a quiz, in which I make |
| 00:00:04,612 --> 00:00:06,772 | sure that some of the concepts behind XP are well |
| 00:00:06,772 --> 00:00:10,040 | understood. So, I'm going to ask you which of the following statements |
| 00:00:10,040 --> 00:00:13,390 | about Extreme Programming are true, and here are the statements. |
| 00:00:13,390 --> 00:00:17,700 | Because of pair programming, XP requires twice the number of developers. |
| 00:00:17,700 --> 00:00:21,260 | In XP, code is rarely changed after being written. XP |
| 00:00:21,260 --> 00:00:25,200 | follows the test driven development, or TDD, paradigm. The customer does |
| 00:00:25,200 --> 00:00:27,560 | not need to provide any requirements in XP. |
| 00:00:27,560 --> 00:00:31,120 | XP is an iterative software development process. So I |
| 00:00:31,120 --> 00:00:32,700 | would like for you to mark all of |
| 00:00:32,700 --> 00:00:32,700 | the statements that you think are true about XP. |