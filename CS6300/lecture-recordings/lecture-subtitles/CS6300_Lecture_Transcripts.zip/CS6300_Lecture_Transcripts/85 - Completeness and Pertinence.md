# CS6300 85 - Completeness and Pertinence

| Timestamp | Content |
|-----------|---------|
| 00:00:00,350 --> 00:00:03,610 | These issues and difficulties can result in requirements |
| 00:00:03,610 --> 00:00:06,780 | that show various problems. Two particularly relevant and |
| 00:00:06,780 --> 00:00:10,880 | common problems are completeness and pertinence. Or better, |
| 00:00:10,880 --> 00:00:14,750 | the lack of completeness and pertinence. Completeness refers to |
| 00:00:14,750 --> 00:00:17,560 | the fact that it is often extremely difficult |
| 00:00:17,560 --> 00:00:20,370 | to identify all of the requirements. That is it |
| 00:00:20,370 --> 00:00:22,890 | is very difficult to have a complete picture |
| 00:00:22,890 --> 00:00:25,780 | of the purpose of the software. So what happens |
| 00:00:25,780 --> 00:00:28,540 | is that incomplete requirements are collected and the software |
| 00:00:28,540 --> 00:00:32,500 | is missing functionality that is important for the user. Pertinence |
| 00:00:32,500 --> 00:00:34,720 | conversely has to do with the relevance of the |
| 00:00:34,720 --> 00:00:38,770 | requirements. To avoid completeness problems developers often end up collecting |
| 00:00:38,770 --> 00:00:42,640 | a lot of irrelevant when not conflicting requirements. In |
| 00:00:42,640 --> 00:00:45,060 | these cases what can happen is that the software could |
| 00:00:45,060 --> 00:00:47,120 | either end up being bloated that is it might |
| 00:00:47,120 --> 00:00:51,290 | contain a needed functionality. The functionality represented by these extra |
| 00:00:51,290 --> 00:00:54,120 | requirements or it might even be impossible to build the |
| 00:00:54,120 --> 00:00:57,480 | software due to the conflicting additional requirements. And to make |
| 00:00:57,480 --> 00:01:00,920 | things even worse collecting all of these requirements sometimes doesn't |
| 00:01:00,920 --> 00:01:03,390 | even solve the completeness issue. So you might end up |
| 00:01:03,390 --> 00:01:05,800 | with a set of requirements that is not only incomplete |
| 00:01:05,800 --> 00:01:08,740 | but it also contains extra information that can be harmful |
| 00:01:08,740 --> 00:01:11,450 | to the system. So again the bottom line is that |
| 00:01:11,450 --> 00:01:14,310 | gathering an adequate, accurate, complete, |
| 00:01:14,310 --> 00:01:16,500 | and pertinent set of requirements that |
| 00:01:16,500 --> 00:01:16,500 | identify the purpose of a software system is an arduous task. |