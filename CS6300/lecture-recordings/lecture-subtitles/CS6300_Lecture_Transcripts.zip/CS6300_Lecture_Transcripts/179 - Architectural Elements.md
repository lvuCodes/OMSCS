# CS6300 179 - Architectural Elements

| Timestamp | Content |
|-----------|---------|
| 00:00:00,170 --> 00:00:02,770 | Now that we have discussed a few foundational aspects |
| 00:00:02,770 --> 00:00:05,410 | of software architectures, and we have looked at some real |
| 00:00:05,410 --> 00:00:07,900 | world examples that help us to illustrate some of these |
| 00:00:07,900 --> 00:00:10,560 | points, to discuss some of these aspects. I want to |
| 00:00:10,560 --> 00:00:13,730 | introduce and define the different elements that compose a software |
| 00:00:13,730 --> 00:00:17,700 | architecture and also talk about architectural styles. So let's start |
| 00:00:17,700 --> 00:00:20,190 | by discussing a software architecture's |
| 00:00:20,190 --> 00:00:22,880 | elements. A software system's architecture |
| 00:00:22,880 --> 00:00:26,690 | typically is not, and should not be, a uniform monolith. |
| 00:00:26,690 --> 00:00:28,770 | On the contrary, an architecture should be a |
| 00:00:28,770 --> 00:00:32,910 | composition and interplay of different elements. In particular, |
| 00:00:32,910 --> 00:00:34,510 | as we quickly mentioned at the beginning of |
| 00:00:34,510 --> 00:00:36,970 | the lesson, there are three main types of elements |
| 00:00:36,970 --> 00:00:40,160 | in an architecture. Processing elements, data elements, and |
| 00:00:40,160 --> 00:00:44,580 | interaction elements. Processing elements are those elements that implement |
| 00:00:44,580 --> 00:00:48,260 | the business logic and perform transformations on data. |
| 00:00:48,260 --> 00:00:51,760 | Data elements, also called information or state, are those |
| 00:00:51,760 --> 00:00:54,180 | elements that contain the information that is used |
| 00:00:54,180 --> 00:00:57,440 | and transformed by the processing elements. And finally, |
| 00:00:57,440 --> 00:01:00,030 | the interaction elements are the glue that holds |
| 00:01:00,030 --> 00:01:02,760 | the different pieces of the architecture together. Now, |
| 00:01:02,760 --> 00:01:06,030 | the processing elements and the data are contained |
| 00:01:06,030 --> 00:01:10,350 | into the system components, whereas the interaction elements |
| 00:01:10,350 --> 00:01:13,900 | are maintained and controlled by the system connectors. |
| 00:01:13,900 --> 00:01:17,100 | And components and connectors get all cooked together |
| 00:01:17,100 --> 00:01:19,980 | into a systems configuration, which models |
| 00:01:19,980 --> 00:01:22,940 | components, connectors and their relationships. So |
| 00:01:22,940 --> 00:01:24,850 | now, let's look at components, connectors |
| 00:01:24,850 --> 00:01:24,850 | and configurations in a little more detail. |