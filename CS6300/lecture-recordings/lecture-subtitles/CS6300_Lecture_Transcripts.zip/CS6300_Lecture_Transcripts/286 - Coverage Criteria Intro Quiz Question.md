# CS6300 286 - Coverage Criteria Intro Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,220 --> 00:00:03,780 | So, now that we have our test specifications. Test specification number one that |
| 00:00:03,780 --> 00:00:06,740 | says that a plus b must be greater than zero. And test specification |
| 00:00:06,740 --> 00:00:09,990 | number two, for which a plus b must be less than zero. I'd |
| 00:00:09,990 --> 00:00:12,580 | like to do another small quiz and ask you to write some test |
| 00:00:12,580 --> 00:00:16,440 | cases that will implement these specifications. And I want you to write the |
| 00:00:16,440 --> 00:00:19,780 | test cases in this format. I want you to specify for each one |
| 00:00:19,780 --> 00:00:22,300 | of the test cases, what is the value of a that you need |
| 00:00:22,300 --> 00:00:25,160 | to use. What is the value of b that you need to use. |
| 00:00:25,160 --> 00:00:28,200 | And since a test case, I like to remind you, is |
| 00:00:28,200 --> 00:00:30,960 | not just a set of inputs. But is the set of |
| 00:00:30,960 --> 00:00:34,050 | inputs plus expected output? I also want you to specify, what |
| 00:00:34,050 --> 00:00:37,040 | is the expected output for these test cases? And in particular, |
| 00:00:37,040 --> 00:00:39,540 | since we have two characteristics of the output, one is the |
| 00:00:39,540 --> 00:00:41,630 | color of the output and the other one is the actual |
| 00:00:41,630 --> 00:00:44,040 | value. I want you to specify for each test case, what |
| 00:00:44,040 --> 00:00:44,040 | is the expected output color and what is the expected value? |