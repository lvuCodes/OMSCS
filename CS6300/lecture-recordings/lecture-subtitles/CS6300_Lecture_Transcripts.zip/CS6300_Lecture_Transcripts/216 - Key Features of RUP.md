# CS6300 216 - Key Features of RUP

| Timestamp | Content |
|-----------|---------|
| 00:00:00,300 --> 00:00:03,450 | So let's start by seeing how these activities and principles |
| 00:00:03,450 --> 00:00:06,640 | are reflected in the key features of the Rational Unified |
| 00:00:06,640 --> 00:00:10,010 | Process. First of all, the Rational Unified Process is a |
| 00:00:10,010 --> 00:00:13,700 | software process model. So if you recall our introductory lessons, |
| 00:00:13,700 --> 00:00:16,670 | that means two main things. The first one is that |
| 00:00:16,670 --> 00:00:19,200 | it defines an order of phases that have to be |
| 00:00:19,200 --> 00:00:21,970 | followed in the software process. And the second thing is |
| 00:00:21,970 --> 00:00:25,420 | that it also prescribes transition criteria, so when to go |
| 00:00:25,420 --> 00:00:28,030 | from one phase to the next. The second key |
| 00:00:28,030 --> 00:00:31,290 | feature of RUP is that it is component based. And |
| 00:00:31,290 --> 00:00:33,810 | also in this case, this implies two main things. |
| 00:00:33,810 --> 00:00:36,410 | The first one is that a software system is defined |
| 00:00:36,410 --> 00:00:39,420 | and built as a set of software components. So |
| 00:00:39,420 --> 00:00:43,110 | software components are the building blocks of our software system. |
| 00:00:43,110 --> 00:00:45,550 | And the second one is that there must be well-defined |
| 00:00:45,550 --> 00:00:48,440 | interfaces between these components, interfaces |
| 00:00:48,440 --> 00:00:50,750 | through which these components communicate. |
| 00:00:50,750 --> 00:00:53,020 | In addition, the Rational Unified Process is |
| 00:00:53,020 --> 00:00:56,080 | tightly related to UML. And in particular, it |
| 00:00:56,080 --> 00:00:58,820 | relies extensively on UML for its notation, and |
| 00:00:58,820 --> 00:01:02,120 | with respect to its basic principles. Finally, the |
| 00:01:02,120 --> 00:01:05,140 | three main distinguishing aspects of the Rational Unified |
| 00:01:05,140 --> 00:01:09,830 | Process are that it is use-case driven, architecture-centric |
| 00:01:09,830 --> 00:01:12,680 | and iterative and incremental. So let's now look |
| 00:01:12,680 --> 00:01:15,565 | in more detail at these three distinguishing aspects, |
| 00:01:15,565 --> 00:01:15,565 | and we're going to look at each one of them individually. |