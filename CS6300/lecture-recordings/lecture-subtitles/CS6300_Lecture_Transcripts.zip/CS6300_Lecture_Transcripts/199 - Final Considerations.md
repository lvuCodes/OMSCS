# CS6300 199 - Final Considerations

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:03,202 | Okay. So this is what I've done as you see, |
| 00:00:03,202 --> 00:00:06,130 | it looks a little nicer than it was before. And I didn't |
| 00:00:06,130 --> 00:00:08,530 | really change that much. I just made a few changes, so |
| 00:00:08,530 --> 00:00:11,560 | I just wanted to point them out to you, so that you |
| 00:00:11,560 --> 00:00:13,690 | know what they are. And the main thing, one of the |
| 00:00:13,690 --> 00:00:18,210 | main things I did is really to introduce these derived attributes. So |
| 00:00:18,210 --> 00:00:19,860 | these are attributes that are basically |
| 00:00:19,860 --> 00:00:22,520 | computed. Based on some other attributes. |
| 00:00:22,520 --> 00:00:26,010 | Okay, they don't have a value themselves, but their value is computed. |
| 00:00:26,010 --> 00:00:28,900 | And I used two. The first one is age. So |
| 00:00:28,900 --> 00:00:31,930 | basically we know the age of the patron based on |
| 00:00:31,930 --> 00:00:34,920 | the birthday, of the patron. So you guys, I don't |
| 00:00:34,920 --> 00:00:37,150 | know if you have that information currently in the system. |
| 00:00:37,150 --> 00:00:38,480 | >> No, we'll have to add that to the |
| 00:00:38,480 --> 00:00:40,280 | form patrons fill out, when they get their card. |
| 00:00:40,280 --> 00:00:42,255 | >> Is that, that an issue? Can you do it? |
| 00:00:42,255 --> 00:00:44,130 | >> No yes, we, we can easily do that. |
| 00:00:44,130 --> 00:00:46,670 | >> Okay, so then, perfect. So we'll do it that way. I think it's |
| 00:00:46,670 --> 00:00:51,310 | a, in a little cleaner. And similarly, since you told me that the fine |
| 00:00:51,310 --> 00:00:54,480 | was computed based on the amount of days that an |
| 00:00:54,480 --> 00:00:58,310 | item was late. The patron was late returning the item, then I |
| 00:00:58,310 --> 00:01:02,010 | also added this as a derived attribute that is computed based on |
| 00:01:02,010 --> 00:01:05,140 | the due date and when the item is actually returned. |
| 00:01:05,140 --> 00:01:05,780 | >> Makes sense. |
| 00:01:05,780 --> 00:01:08,389 | >> Makes sense? Okay. And the rest |
| 00:01:08,389 --> 00:01:10,590 | is kind of really minor things. So the, the only one I |
| 00:01:10,590 --> 00:01:14,340 | want to point out is I didn't, you know, discuss that with |
| 00:01:14,340 --> 00:01:17,260 | you before, but I added this, which is called cardinality |
| 00:01:17,260 --> 00:01:20,700 | for some of these relationships. And what they say is basically |
| 00:01:20,700 --> 00:01:25,360 | is how many elements are involved in the relationship. |
| 00:01:25,360 --> 00:01:26,580 | >> So, you mean the stars? |
| 00:01:26,580 --> 00:01:27,960 | >> Yeah, like the stars and the one... |
| 00:01:27,960 --> 00:01:28,290 | >> Okay. |
| 00:01:28,290 --> 00:01:31,380 | >> Here for example, this is telling you that for each item there |
| 00:01:31,380 --> 00:01:35,490 | is only one title. And that for each title, there are multiple items. |
| 00:01:35,490 --> 00:01:36,490 | >> So, star means many. |
| 00:01:36,490 --> 00:01:37,716 | >> Stars mean many, yeah. |
| 00:01:37,716 --> 00:01:39,045 | >> Okay, go you. |
| 00:01:39,045 --> 00:01:42,321 | >> Sorry that's kind of computer science lingo - we use the star |
| 00:01:42,321 --> 00:01:45,500 | for that kind of stuff. And, similarly, for the patron, it's |
| 00:01:45,500 --> 00:01:48,510 | telling me that, you know, each patron can have multiple, can |
| 00:01:48,510 --> 00:01:52,550 | request multiple titles, and that the same title can be requested |
| 00:01:52,550 --> 00:01:55,650 | by multiple patrons, which I think is the way the system works. |
| 00:01:55,650 --> 00:01:59,080 | >> Right. So except for these minor changes, |
| 00:01:59,080 --> 00:02:01,850 | we already had a pretty good model in our hands, so |
| 00:02:01,850 --> 00:02:04,620 | I think is a, we can finalize this and then just |
| 00:02:04,620 --> 00:02:07,350 | move to the low level design and then implementation, and be |
| 00:02:07,350 --> 00:02:07,970 | done with the system. |
| 00:02:07,970 --> 00:02:07,970 | >> Sounds good. |