# CS6300 50 - Eclipse Demo_ Run Configuration

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,660 | So now that we have run our program, let's see what |
| 00:00:02,660 --> 00:00:05,660 | happens exactly when you run a program within Eclipse. And to |
| 00:00:05,660 --> 00:00:08,410 | do that I'm going to use the menu over here which is |
| 00:00:08,410 --> 00:00:12,500 | the Run menu and I'm going to select Run Configurations, and this |
| 00:00:12,500 --> 00:00:15,190 | brings up a window where you can change or run configurations. |
| 00:00:15,190 --> 00:00:17,200 | Well first of all, you can see that here on the |
| 00:00:17,200 --> 00:00:22,260 | left under Java application. Eclipse automatically created a Hello World run |
| 00:00:22,260 --> 00:00:25,300 | configuration for our program. And this is where you can configure |
| 00:00:25,300 --> 00:00:28,370 | the different parameters for your execution. For example, |
| 00:00:28,370 --> 00:00:30,520 | you can select the main class. So here |
| 00:00:30,520 --> 00:00:34,745 | it's, obviously, edu.gatech.HelloWorld. You can define different program |
| 00:00:34,745 --> 00:00:36,920 | arguments. We don't have any for now. You can |
| 00:00:36,920 --> 00:00:39,480 | also pass arguments to the virtual machine. You |
| 00:00:39,480 --> 00:00:41,960 | can define which Java runtime environment you want to |
| 00:00:41,960 --> 00:00:47,720 | use, Classpath and other environmental options. So let's |
| 00:00:47,720 --> 00:00:50,650 | now try to pass some arguments to our program. |
| 00:00:50,650 --> 00:00:54,390 | So for example here, I am just going to write George as |
| 00:00:54,390 --> 00:00:58,450 | a possible parameter. I say Apply so that modify the configuration and |
| 00:00:58,450 --> 00:01:01,510 | if i run the program of course, the output is not changing |
| 00:01:01,510 --> 00:01:04,440 | because my program does not use the argument. But, let's see if |
| 00:01:04,440 --> 00:01:07,060 | we do use the argument, what happens. So I'm going to slightly |
| 00:01:07,060 --> 00:01:10,030 | modify the final program so that now, instead of printing hello |
| 00:01:10,030 --> 00:01:13,420 | world, it will print hello followed by the first argument that I |
| 00:01:13,420 --> 00:01:15,700 | will pass to the program. And if I do that, and I |
| 00:01:15,700 --> 00:01:19,420 | go and I run the program, what I get is exactly what I |
| 00:01:19,420 --> 00:01:23,420 | was expecting, which is Hello George. So this is the way in which you |
| 00:01:23,420 --> 00:01:26,120 | can pass arguments to your execution, which |
| 00:01:26,120 --> 00:01:27,640 | is something that might come in handy |
| 00:01:27,640 --> 00:01:27,640 | for some other projects. When you need to run some code with an argument. |