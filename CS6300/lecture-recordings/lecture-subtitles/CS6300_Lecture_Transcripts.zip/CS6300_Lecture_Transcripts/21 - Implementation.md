# CS6300 21 - Implementation

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:02,719 | After we have designed our system we can implement |
| 00:00:02,719 --> 00:00:05,900 | it. In the implementation phase what we do is basically |
| 00:00:05,900 --> 00:00:08,410 | taking care of realizing the design of the system |
| 00:00:08,410 --> 00:00:11,920 | that we just created and create an actual software system. |
| 00:00:11,920 --> 00:00:15,530 | There are four fundamental principles, four pillars that can |
| 00:00:15,530 --> 00:00:18,470 | affect the way in which software is constructed. The first |
| 00:00:18,470 --> 00:00:21,900 | one is the reduction of complexity. This aims to build |
| 00:00:21,900 --> 00:00:25,160 | software that is easier to understand and use. The second |
| 00:00:25,160 --> 00:00:28,400 | pillar is the anticipation of diversity. Which takes into |
| 00:00:28,400 --> 00:00:31,720 | account that software construction might change in various way over |
| 00:00:31,720 --> 00:00:35,220 | time. That is that software evolves. In many cases, |
| 00:00:35,220 --> 00:00:38,270 | it evolves in unexpected ways. And therefore, we have to |
| 00:00:38,270 --> 00:00:41,680 | be able to anticipate some of these changes. The |
| 00:00:41,680 --> 00:00:45,390 | third pillar is the structuring for validation. Also called design |
| 00:00:45,390 --> 00:00:47,550 | for testability. And what this means is that we |
| 00:00:47,550 --> 00:00:50,760 | want to build software so that it is easily testable |
| 00:00:50,760 --> 00:00:54,890 | during the subsequent validation and verification activities. Finally, and |
| 00:00:54,890 --> 00:00:58,040 | this is especially true within specific organizations and or |
| 00:00:58,040 --> 00:01:00,770 | domains. It is important that the software conforms to |
| 00:01:00,770 --> 00:01:04,330 | a set of internal or external standards. And some examples |
| 00:01:04,330 --> 00:01:06,730 | of this might be, for example, for internal standards, |
| 00:01:06,730 --> 00:01:10,680 | coding standards within an organization, or naming standards within an |
| 00:01:10,680 --> 00:01:13,320 | organization. As for external standards, if for example you |
| 00:01:13,320 --> 00:01:15,780 | are developing some medical software. There are some regulations and |
| 00:01:15,780 --> 00:01:17,930 | some standards that you have to adhere to in |
| 00:01:17,930 --> 00:01:17,930 | order for your software to be valid in that domain. |