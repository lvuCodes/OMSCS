# CS6300 244 - Pros and Cons of Approaches

| Timestamp | Content |
|-----------|---------|
| 00:00:00,230 --> 00:00:02,870 | The four different techniques that we just discussed have |
| 00:00:02,870 --> 00:00:06,120 | a number of pros and cons. So next we |
| 00:00:06,120 --> 00:00:08,780 | are going to discuss the main pros and cons |
| 00:00:08,780 --> 00:00:11,140 | for these techniques, so as to be able to compare |
| 00:00:11,140 --> 00:00:14,330 | them. When testing is concerned the main positive about |
| 00:00:14,330 --> 00:00:17,600 | this technique is that it does not generate false |
| 00:00:17,600 --> 00:00:21,740 | alarms. In other words, it doesn't generate false positives. |
| 00:00:21,740 --> 00:00:25,180 | What that means, is that when testing generates a failure, |
| 00:00:25,180 --> 00:00:27,230 | that means that there is an actual problem in the |
| 00:00:27,230 --> 00:00:30,060 | code. The main limitation of testing, however, is that it |
| 00:00:30,060 --> 00:00:33,680 | is highly incomplete. Consider again the picture that we drew |
| 00:00:33,680 --> 00:00:36,430 | a little earlier. The one representing the input domain of |
| 00:00:36,430 --> 00:00:39,430 | the program being tested. Even in the best scenario, testing |
| 00:00:39,430 --> 00:00:44,050 | can consider only a tiny fraction of the problem domain, |
| 00:00:44,050 --> 00:00:47,430 | and therefor a tiny fraction of the program's behavior, and |
| 00:00:47,430 --> 00:00:50,308 | we'll say a lot more about that in the following lessons. |
| 00:00:50,308 --> 00:00:53,780 | Static verification, unlike testing, has the main advantage |
| 00:00:53,780 --> 00:00:57,320 | that it considers all program behaviors. If we |
| 00:00:57,320 --> 00:01:00,370 | look back at our diagram, whereas testing will |
| 00:01:00,370 --> 00:01:04,010 | select only a few of those inputs, static verification |
| 00:01:04,010 --> 00:01:07,120 | will consider them all. Unfortunately, however, this comes |
| 00:01:07,120 --> 00:01:08,990 | with a price. Due to limitation of this |
| 00:01:08,990 --> 00:01:11,490 | kind of analysis and due to infeasibility issues, |
| 00:01:11,490 --> 00:01:15,260 | static verifiation considers not only all the possible behaviours, |
| 00:01:15,260 --> 00:01:18,870 | but also some impossible behaviors. And what that means is |
| 00:01:18,870 --> 00:01:22,472 | that static gratificaition can generate false positives. And this is, |
| 00:01:22,472 --> 00:01:24,590 | in fact, the main issue with static verification techniques. As |
| 00:01:24,590 --> 00:01:28,550 | we will further discuss later in the class, static verification can |
| 00:01:28,550 --> 00:01:31,280 | generate results that are not true. For example, it might |
| 00:01:31,280 --> 00:01:33,970 | report a possible no point of the refernce that cannot |
| 00:01:33,970 --> 00:01:37,590 | actually occur in practice. The strongest point about inspections is |
| 00:01:37,590 --> 00:01:40,950 | that, when they're done in a rigorous way, they're systematic and |
| 00:01:40,950 --> 00:01:43,420 | they result in a thorough analysis of the code. |
| 00:01:43,420 --> 00:01:46,840 | They are nevertheless a manual process, a human process. |
| 00:01:46,840 --> 00:01:49,890 | So they're not formal and their effectiveness may depend |
| 00:01:49,890 --> 00:01:53,560 | on the specific people performing the inspection. So its results |
| 00:01:53,560 --> 00:01:57,150 | can be subjective. Finally, the main pro about formal |
| 00:01:57,150 --> 00:02:01,090 | proofs of correctness is that they provide strong guarantees. |
| 00:02:01,090 --> 00:02:03,740 | They can guarantee that the program is correct, which |
| 00:02:03,740 --> 00:02:06,280 | is not something that any of the other approaches can |
| 00:02:06,280 --> 00:02:09,505 | do, including study verification. But the main limitation of |
| 00:02:09,505 --> 00:02:12,680 | formal proofs is that they need a form of specification, |
| 00:02:12,680 --> 00:02:15,750 | a complete mathematical description of the expected behavior of |
| 00:02:15,750 --> 00:02:19,060 | the whole program, and unfortunately such a specification is rarely |
| 00:02:19,060 --> 00:02:21,920 | available, and it is very complex to build one. |
| 00:02:21,920 --> 00:02:25,170 | In addition, it is also very complex, and possibly expensive, |
| 00:02:25,170 --> 00:02:27,720 | to prove that the program corresponds to a specification. |
| 00:02:27,720 --> 00:02:30,990 | That is a process that requires strong mathematical skills and, |
| 00:02:30,990 --> 00:02:30,990 | therefore, a very specialized personnel. |