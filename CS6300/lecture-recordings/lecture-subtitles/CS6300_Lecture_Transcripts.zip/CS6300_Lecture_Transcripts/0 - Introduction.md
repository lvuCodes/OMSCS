# CS6300 0 - Introduction

| Timestamp | Content |
|-----------|---------|
| 00:00:00,350 --> 00:00:03,570 | Hi, everybody, and welcome to the first lesson |
| 00:00:03,570 --> 00:00:07,970 | of the Software Engineering Course. In this introductory lesson |
| 00:00:07,970 --> 00:00:09,820 | I will first provide an overview of the |
| 00:00:09,820 --> 00:00:13,100 | whole course and then try to answer two important |
| 00:00:13,100 --> 00:00:16,630 | questions about software engineering, which are, what is |
| 00:00:16,630 --> 00:00:20,310 | software engineering and why do we need it? And |
| 00:00:20,310 --> 00:00:22,370 | to spice up the content a bit I |
| 00:00:22,370 --> 00:00:25,480 | will also interview several experts in the software engineering |
| 00:00:25,480 --> 00:00:30,080 | field from both academia and industry and ask them these |
| 00:00:30,080 --> 00:00:30,080 | very questions. So without any further ado, let's begin the lesson. |