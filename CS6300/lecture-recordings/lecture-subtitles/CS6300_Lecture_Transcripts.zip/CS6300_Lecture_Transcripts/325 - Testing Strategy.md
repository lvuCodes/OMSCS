# CS6300 325 - Testing Strategy

| Timestamp | Content |
|-----------|---------|
| 00:00:00,360 --> 00:00:03,320 | As you probably realized by now, at job development, it's a |
| 00:00:03,320 --> 00:00:06,280 | lot about testing. So there is a lot of emphasis on |
| 00:00:06,280 --> 00:00:09,420 | testing. Testing first, te, testing early. So that's the reason why |
| 00:00:09,420 --> 00:00:12,710 | I also want to discuss what is the testing strategy in XP. |
| 00:00:12,710 --> 00:00:14,820 | So first of all what is the basic principle? The basic |
| 00:00:14,820 --> 00:00:18,770 | principle is that testing is Coded confidence. You write your test |
| 00:00:18,770 --> 00:00:22,150 | cases and then you can run them anytime you want. And |
| 00:00:22,150 --> 00:00:25,540 | if they pass, they'll give you confidence that your code is behaving |
| 00:00:25,540 --> 00:00:27,920 | the way it's expected. If they don't pass on the other |
| 00:00:27,920 --> 00:00:30,870 | hand, you'll know that there's something to fix. Another important concept is |
| 00:00:30,870 --> 00:00:34,600 | that test might be isolated and automated. So both the running and |
| 00:00:34,600 --> 00:00:37,400 | the checking of the tests has to be automated for all of |
| 00:00:37,400 --> 00:00:39,830 | this to work. And there are two types of tests. The first |
| 00:00:39,830 --> 00:00:43,170 | type of test is unit tests, that are created by the programmers, |
| 00:00:43,170 --> 00:00:45,830 | and they're created by looking at the task cards. The task cards |
| 00:00:45,830 --> 00:00:48,410 | describe what they implemented, functionality should |
| 00:00:48,410 --> 00:00:50,740 | do, and therefore allows the developers. |
| 00:00:50,740 --> 00:00:53,970 | The right test that can test this functionality. That can |
| 00:00:53,970 --> 00:00:57,000 | check that the code's correctly implemented functionality. And as we |
| 00:00:57,000 --> 00:01:00,670 | said, you should really test every meaninful feature. So, for |
| 00:01:00,670 --> 00:01:04,250 | example, you should test every meaningful method in your classes. |
| 00:01:04,250 --> 00:01:08,490 | You should put specific attention to possibly complex implementations, special |
| 00:01:08,490 --> 00:01:11,100 | cases or specific problems that you might think of. while |
| 00:01:11,100 --> 00:01:13,110 | reading the task cards. In some cases, when you do |
| 00:01:13,110 --> 00:01:15,800 | refactoring, you might also want to write test cases specific |
| 00:01:15,800 --> 00:01:18,300 | to that refactoring. But we'll say more about that. So this |
| 00:01:18,300 --> 00:01:20,610 | was for the first kind of tests that are involved in |
| 00:01:20,610 --> 00:01:23,650 | the, in the XP process. The second kind of tests are |
| 00:01:23,650 --> 00:01:27,710 | the system tests, also called acceptance tests. And those tests involve |
| 00:01:27,710 --> 00:01:30,920 | the customer. So basically what happens is that the customer provides |
| 00:01:30,920 --> 00:01:33,760 | the test cases for their stores and then the development team |
| 00:01:33,760 --> 00:01:37,630 | transforms those into actual automated tests. So these are tests created |
| 00:01:37,630 --> 00:01:40,700 | by the developers. They run very quickly and they run very frequently. |
| 00:01:40,700 --> 00:01:43,120 | These are tests developed with the help, with the |
| 00:01:43,120 --> 00:01:46,170 | involvement of the customer they run longer. And run less |
| 00:01:46,170 --> 00:01:48,710 | frequently, they run every time the system is integrated. |
| 00:01:48,710 --> 00:01:48,710 | According to the cycle we saw a few minutes ago. |