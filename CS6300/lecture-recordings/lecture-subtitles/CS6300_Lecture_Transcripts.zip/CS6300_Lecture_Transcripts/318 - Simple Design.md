# CS6300 318 - Simple Design

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:02,790 | The next practice is simple design. We want to avoid |
| 00:00:02,790 --> 00:00:07,330 | creating a huge complicated possibly cumbersome design at the beginning of |
| 00:00:07,330 --> 00:00:09,730 | the project. What we want to have instead is just |
| 00:00:09,730 --> 00:00:14,580 | enough design to meet the requirements, so no duplicated functionality, fewest |
| 00:00:14,580 --> 00:00:17,910 | possible classes and methods in general, just the amount of |
| 00:00:17,910 --> 00:00:20,860 | design that we need to get our system to work. So |
| 00:00:20,860 --> 00:00:23,012 | one might object that to for designing that way we |
| 00:00:23,012 --> 00:00:25,210 | will have to change the code a lot, we will need |
| 00:00:25,210 --> 00:00:27,300 | to adapt the design as the code evolves, |
| 00:00:27,300 --> 00:00:29,180 | and that's exactly the point. That's what we will |
| 00:00:29,180 --> 00:00:31,670 | do. XP is all about changing and adapting, |
| 00:00:31,670 --> 00:00:34,850 | changing your design, changing your code, refactoring. And with |
| 00:00:34,850 --> 00:00:37,420 | the fact that we have test cases throughout |
| 00:00:37,420 --> 00:00:39,770 | the development process, we can do that with confidence. |
| 00:00:39,770 --> 00:00:41,220 | Because if we break something we will know |
| 00:00:41,220 --> 00:00:41,220 | right away, which leads us to the next practice. |