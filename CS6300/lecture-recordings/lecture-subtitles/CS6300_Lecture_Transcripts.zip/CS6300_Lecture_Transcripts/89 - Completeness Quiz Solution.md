# CS6300 89 - Completeness Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:02,060 | And the answer is clearly no. |
| 00:00:02,060 --> 00:00:05,060 | Obviously, there are many missing requirements here. |
| 00:00:05,060 --> 00:00:07,910 | For example, requirements about registration for the |
| 00:00:07,910 --> 00:00:11,560 | customers, requirements about fitness program creation, membership |
| 00:00:11,560 --> 00:00:15,481 | types, and so on. Plus, we are also missing all of the nonfunctional |
| 00:00:15,481 --> 00:00:15,481 | requirements, which we haven't seen yet, but that we will discuss in a bit. |