# CS6300 130 - Class Diagram_ Dependency Relationship

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:03,040 | So let's start with the dependency example. A dependency, |
| 00:00:03,040 --> 00:00:06,720 | as we said, expresses the relationship between a supplier |
| 00:00:06,720 --> 00:00:09,290 | and a client that relies on it. There is |
| 00:00:09,290 --> 00:00:12,490 | a dependency because changes in the supplier can affect the |
| 00:00:12,490 --> 00:00:14,770 | client. Here in this example I am showing that |
| 00:00:14,770 --> 00:00:18,510 | a dependency example involving the registration manager and the |
| 00:00:18,510 --> 00:00:21,590 | scheduling algorithm. As you can see the, the dependency |
| 00:00:21,590 --> 00:00:25,710 | is indicated with a dashed line pointing from the client |
| 00:00:25,710 --> 00:00:28,520 | to the supplier. And here it's pretty clear why |
| 00:00:28,520 --> 00:00:31,820 | the RegistrationManager is dependent on the Scheduling Algorithm. It's |
| 00:00:31,820 --> 00:00:35,710 | because the RegistrationManager uses this Scheduling Algorithm. And therefore, |
| 00:00:35,710 --> 00:00:39,130 | if the Scheduling Algorithm changes, the RegistrationManager might be |
| 00:00:39,130 --> 00:00:42,210 | affected by that change. Another less obvious example is |
| 00:00:42,210 --> 00:00:45,600 | the dependency between the Registration Manager and the Student. |
| 00:00:45,600 --> 00:00:48,040 | In this case, because the Registration Manager gets a |
| 00:00:48,040 --> 00:00:51,620 | Student object as a parameter here there is a dependency |
| 00:00:51,620 --> 00:00:55,740 | between the two. Again, if the Student class were to change the Registration |
| 00:00:55,740 --> 00:00:55,740 | Manager might be affected because it's relying on the Student for it's behavior. |
![[lvu 2026-02-15 at 03.21PM.png]]