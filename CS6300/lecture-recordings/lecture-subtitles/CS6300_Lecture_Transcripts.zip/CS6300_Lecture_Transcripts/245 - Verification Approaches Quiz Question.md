# CS6300 245 - Verification Approaches Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,240 --> 00:00:02,570 | So let's have another simple quiz, and we're going to |
| 00:00:02,570 --> 00:00:05,490 | have our developer Brett introducing the quiz. And the |
| 00:00:05,490 --> 00:00:07,900 | starting point for this quiz is the fact that |
| 00:00:07,900 --> 00:00:11,970 | today, quality assurance, or verification, if you wish, is mostly |
| 00:00:11,970 --> 00:00:15,730 | testing. That is, testing is the most commonly used |
| 00:00:15,730 --> 00:00:19,550 | activity to perform software verification. So now, I'm going to show |
| 00:00:19,550 --> 00:00:22,310 | you a quote, 50% of my company employees are |
| 00:00:22,310 --> 00:00:25,691 | testers and the rest spends 50% of their time testing, |
| 00:00:25,691 --> 00:00:27,347 | so I want to ask you, who said |
| 00:00:27,347 --> 00:00:29,664 | that? I'm going to give you some possibilities. Was |
| 00:00:29,664 --> 00:00:34,215 | that Yogi Berra, Steve Jobs, Henry Ford, Bill |
| 00:00:34,215 --> 00:00:34,215 | Gates or Frank Gehry? Take your best guess. |