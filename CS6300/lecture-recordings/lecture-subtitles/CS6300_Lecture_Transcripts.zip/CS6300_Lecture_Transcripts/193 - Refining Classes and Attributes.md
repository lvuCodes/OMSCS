# CS6300 193 - Refining Classes and Attributes

| Timestamp | Content |
|-----------|---------|
| 00:00:00,880 --> 00:00:03,920 | Okay, so this is our first, class diagram. |
| 00:00:03,920 --> 00:00:06,260 | >> So, let me ask you something about. |
| 00:00:06,260 --> 00:00:06,520 | >> Okay. |
| 00:00:06,520 --> 00:00:08,930 | >> What we've done so far. I also sent, in what |
| 00:00:08,930 --> 00:00:14,490 | I sent you, I also had some stories about how the actual |
| 00:00:14,490 --> 00:00:16,400 | >> Library is used. You asked me to do |
| 00:00:16,400 --> 00:00:20,160 | that and are we going to take, use that here? |
| 00:00:20,160 --> 00:00:23,300 | >> Glad you asked actually. yeah. Those are, you know, what we call use |
| 00:00:23,300 --> 00:00:25,940 | cases, or what we will use as scenarios kind of things that we will |
| 00:00:25,940 --> 00:00:28,340 | use to derive use cases. And they're also a very good |
| 00:00:28,340 --> 00:00:31,450 | way of extracting requirements. We're not going to look at them right |
| 00:00:31,450 --> 00:00:33,890 | now because now, because we're more working on kind of the static |
| 00:00:33,890 --> 00:00:37,860 | structure of the system. But after we're done with the class diagram, |
| 00:00:37,860 --> 00:00:40,700 | you know, we will do it at a different time. But |
| 00:00:40,700 --> 00:00:43,410 | we're going to use those to see how the |
| 00:00:43,410 --> 00:00:45,850 | libraries actually use them, and see whether we can get more |
| 00:00:45,850 --> 00:00:49,000 | information that we can use to refine our requirements based on that. |
| 00:00:49,000 --> 00:00:49,770 | >> Okay. |
| 00:00:49,770 --> 00:00:51,020 | >> Okay, |
| 00:00:51,020 --> 00:00:52,940 | So, for now, we'll just focus in on the, |
| 00:00:52,940 --> 00:00:54,630 | structure, but, just so you know, I'm, |
| 00:00:54,630 --> 00:00:55,870 | I'm glad you sent them, because they were going |
| 00:00:55,870 --> 00:00:59,410 | very useful as well. |
| 00:00:59,410 --> 00:01:00,840 | Okay. So let's see. Well, first of all, let |
| 00:01:00,840 --> 00:01:03,030 | me, seems like that this is already pretty crowded, |
| 00:01:03,030 --> 00:01:06,770 | right? We have a number of, classes. So let's |
| 00:01:06,770 --> 00:01:10,580 | see if there's, some class that may be superfluous and |
| 00:01:10,580 --> 00:01:13,310 | we can model in a different way. So, for |
| 00:01:13,310 --> 00:01:16,360 | example, you, while, while thinking of this I was thinking, |
| 00:01:16,360 --> 00:01:19,450 | the library card, it doesn't really contain much |
| 00:01:19,450 --> 00:01:23,948 | information, right? So is it basically just the number? |
| 00:01:23,948 --> 00:01:30,760 | The card has a number on it. We have a separate vendor that does that for us so. |
| 00:01:30,760 --> 00:01:30,810 | >> Oh. |
| 00:01:30,810 --> 00:01:33,270 | >> We don't need, it doesn't need to be part of this system, |
| 00:01:33,270 --> 00:01:35,450 | we just have to make sure that every patron has a library card. |
| 00:01:35,450 --> 00:01:37,670 | >> Okay, so basically for you, in a sense, the library |
| 00:01:37,670 --> 00:01:41,560 | card is just an ID that gets associated with a patron. |
| 00:01:41,560 --> 00:01:42,120 | >> That's right. |
| 00:01:42,120 --> 00:01:45,380 | >> So I think that the best way to represent this, I mean, unless you |
| 00:01:45,380 --> 00:01:47,000 | need an entity because you are creating it |
| 00:01:47,000 --> 00:01:49,160 | yourself, but it seems like you are not. |
| 00:01:49,160 --> 00:01:52,710 | I would just remove this one and I would like to put this, |
| 00:01:52,710 --> 00:01:56,020 | basically to take the library card number and add it to the pattern. |
| 00:01:56,020 --> 00:01:57,100 | >> Okay, makes sense. |
| 00:01:57,100 --> 00:02:03,000 | >> Okay, so I'll add it here. And as |
| 00:02:03,000 --> 00:02:06,160 | an additional attribute. Okay, and it will eliminate this class. |
| 00:02:06,160 --> 00:02:06,410 | >> Okay. |
| 00:02:06,410 --> 00:02:09,690 | >> Okay. |
| 00:02:09,690 --> 00:02:11,700 | Oh, and, wait a second, so I guess |
| 00:02:11,700 --> 00:02:13,940 | also the child needs a library card number, right? |
| 00:02:13,940 --> 00:02:18,320 | >> Child needs a library card number, but let me ask you about that. Is, |
| 00:02:18,320 --> 00:02:22,050 | is child a separate class, or is it just another kind of patron? |
| 00:02:22,050 --> 00:02:24,920 | >> Oh, I see, I see. Because, yeah, it |
| 00:02:24,920 --> 00:02:28,490 | is sort of a special patron, right? And, so |
| 00:02:28,490 --> 00:02:31,730 | maybe we should, maybe we should represent it as |
| 00:02:31,730 --> 00:02:35,640 | a kind of a refinement of the patron. |
| 00:02:35,640 --> 00:02:38,730 | Hm, but then that made me think. So what is |
| 00:02:38,730 --> 00:02:42,510 | the only thing that characterizes children? Is it just the age? |
| 00:02:42,510 --> 00:02:47,440 | >> Well, if they're, that they can't check out more than five books. |
| 00:02:47,440 --> 00:02:48,890 | >> Okay. And the, and the only difference is the |
| 00:02:48,890 --> 00:02:52,010 | fact that they are less than, you know, twelve years old. |
| 00:02:52,010 --> 00:02:52,710 | >> Twelve or less, right. |
| 00:02:52,710 --> 00:02:56,090 | >> Twelve or less. So, I guess, you know, I would probably |
| 00:02:56,090 --> 00:03:01,120 | like to represent this by making the age explicit in the patron rather |
| 00:03:01,120 --> 00:03:04,730 | than to represent it as a class. And I'll tell you why, |
| 00:03:04,730 --> 00:03:08,300 | because one, one of the issues, and you know, that might happen |
| 00:03:08,300 --> 00:03:13,070 | again, is that, basically, there are patrons that are children. And they're |
| 00:03:13,070 --> 00:03:17,130 | no longer children, when they come you know 13 or older right. |
| 00:03:17,130 --> 00:03:18,100 | >> Right. |
| 00:03:18,100 --> 00:03:21,990 | >> And if we represent them with a separate class in a sense, then we |
| 00:03:21,990 --> 00:03:26,620 | cannot really change the type of an instance of these classes. |
| 00:03:26,620 --> 00:03:28,920 | So we're left to kind of destroy the patron, create |
| 00:03:28,920 --> 00:03:31,190 | a new one, so that means we also have to transfer |
| 00:03:31,190 --> 00:03:33,510 | any history we want to keep history and so on. |
| 00:03:33,510 --> 00:03:35,680 | So I, I think I kind of like better the idea |
| 00:03:35,680 --> 00:03:39,560 | that I represent the age exclusively in |
| 00:03:39,560 --> 00:03:42,700 | the patron, and then I'll behave differently, based on whether the |
| 00:03:42,700 --> 00:03:45,910 | patron is 12 years old, or younger, or 13 or, |
| 00:03:45,910 --> 00:03:49,600 | 13 or older. This, do you see any problem with that? |
| 00:03:49,600 --> 00:03:51,210 | >> It makes things a little simpler. |
| 00:03:51,210 --> 00:03:51,490 | >> Okay, |
| 00:03:51,490 --> 00:03:53,550 | and we actually, it allows us also to eliminate |
| 00:03:53,550 --> 00:03:56,450 | one class here. So I'm going to proceed this way. |
| 00:03:56,450 --> 00:03:59,450 | I'm going to eliminate the children class, and I'm going to |
| 00:03:59,450 --> 00:04:03,600 | put the age in the patron. Okay, and let me |
| 00:04:03,600 --> 00:04:07,020 | see. But in this spirit, actually, something else that jumps |
| 00:04:07,020 --> 00:04:09,740 | at me is this idea of the bestseller, because I |
| 00:04:09,740 --> 00:04:11,850 | kind of feel like, we might have the same |
| 00:04:11,850 --> 00:04:15,085 | problem. So, what is the story? What is a bestseller. |
| 00:04:15,085 --> 00:04:16,850 | >> Well it's |
| 00:04:16,850 --> 00:04:20,750 | an item that we want to restrict how |
| 00:04:20,750 --> 00:04:23,896 | long people can keep, because there is such demand for it. |
| 00:04:23,896 --> 00:04:26,880 | >> I see, and so basically a book that's a |
| 00:04:26,880 --> 00:04:30,450 | bestseller, like the New York Times bestseller, is a bestseller forever? |
| 00:04:30,450 --> 00:04:32,683 | >> No, no, no it's hot for |
| 00:04:32,683 --> 00:04:35,940 | awhile, and then it becomes just a regular item. |
| 00:04:35,940 --> 00:04:38,318 | >> I see. Hm. Then I guess it's a |
| 00:04:38,318 --> 00:04:40,349 | similar situation to the one I was mentioning before, right? |
| 00:04:40,349 --> 00:04:40,980 | >> Okay. |
| 00:04:40,980 --> 00:04:41,800 | >> That if we have a book, |
| 00:04:41,800 --> 00:04:44,530 | it will kind of have to change its type if it becomes a best seller. |
| 00:04:44,530 --> 00:04:47,218 | Then we have to change its type again, if it's no longer a best seller. |
| 00:04:47,218 --> 00:04:47,790 | >> Right. |
| 00:04:47,790 --> 00:04:48,920 | >> So it seems to me that a better |
| 00:04:48,920 --> 00:04:52,150 | way to represent this, is just to eliminate this BestSeller |
| 00:04:52,150 --> 00:04:55,060 | class and instead, I'm going to put the best seller |
| 00:04:55,060 --> 00:04:58,190 | attribute, which would just be a Boolean in the book. |
| 00:04:58,190 --> 00:05:00,190 | >> Okay, what do you mean by Boolean? |
| 00:05:00,190 --> 00:05:02,280 | >> Right. We don't know what Boolean is, right? The Boolean is |
| 00:05:02,280 --> 00:05:04,940 | basically just a number. It can have two values, right? True or false. |
| 00:05:04,940 --> 00:05:05,380 | >> Okay. |
| 00:05:05,380 --> 00:05:06,830 | >> So we usually, normally use it |
| 00:05:06,830 --> 00:05:09,510 | in this in this case. Imagine one, zero, |
| 00:05:09,510 --> 00:05:10,970 | right? Then it's just kind of the basic. |
| 00:05:10,970 --> 00:05:11,120 | >> Okay. |
| 00:05:11,120 --> 00:05:12,250 | >> You know, the bits, right? |
| 00:05:12,250 --> 00:05:12,590 | >> Okay. |
| 00:05:12,590 --> 00:05:14,730 | >> So, this is just telling us, it's like a flag |
| 00:05:14,730 --> 00:05:16,672 | that is telling this book is a best seller, or not. |
| 00:05:16,672 --> 00:05:17,053 | >> Okay. |
| 00:05:17,053 --> 00:05:20,920 | >> It's very easy to change this value and make a book a best |
| 00:05:20,920 --> 00:05:22,880 | seller or not a best seller, than |
| 00:05:22,880 --> 00:05:26,210 | just creating and destroying instances of these classes. |
| 00:05:26,210 --> 00:05:27,135 | >> Okay, makes sense. |
| 00:05:27,135 --> 00:05:32,630 | >> Okay, so at this point, this already looks better, right? Because we have, |
| 00:05:32,630 --> 00:05:35,590 | less classes, and I think we did, yeah, we |
| 00:05:35,590 --> 00:05:38,775 | did some serious cleanup. That's good. Okay, so now that |
| 00:05:38,775 --> 00:05:40,975 | we eliminated some of this, what I would like to |
| 00:05:40,975 --> 00:05:42,845 | do, as I said, we are going to both clean |
| 00:05:42,845 --> 00:05:45,222 | up, but also refine. I would like to go |
| 00:05:45,222 --> 00:05:48,826 | back to our, requirements and see whether we can identify |
| 00:05:48,826 --> 00:05:52,566 | additional attributes for this, class that maybe are not as |
| 00:05:52,566 --> 00:05:52,566 | obvious as the one that we saw so far, okay? |