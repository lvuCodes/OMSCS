# CS6300 224 - Cycle Example

| Timestamp | Content |
|-----------|---------|
| 00:00:00,230 --> 00:00:02,590 | To make this a little more concrete, let's look at |
| 00:00:02,590 --> 00:00:07,466 | an example involving cycles, phases, and iterations. Let's assume that we |
| 00:00:07,466 --> 00:00:10,250 | have to develop a banking IT system. The first possible |
| 00:00:10,250 --> 00:00:12,730 | cycle for such a system could be one in which we |
| 00:00:12,730 --> 00:00:16,280 | implement the basic withdrawal facilities. What this means is that, |
| 00:00:16,280 --> 00:00:18,400 | at the end of this cycle, there will be the release |
| 00:00:18,400 --> 00:00:22,130 | of the product that implements this piece of functionality. But notice |
| 00:00:22,130 --> 00:00:25,500 | that this will not be the only product release because within |
| 00:00:25,500 --> 00:00:28,580 | the cycle, we will perform also the four phases that |
| 00:00:28,580 --> 00:00:31,020 | we mentioned before, inception, elaboration, |
| 00:00:31,020 --> 00:00:33,550 | construction, and transition. And within each |
| 00:00:33,550 --> 00:00:36,980 | of these phases, we might have multiple iterations. And at the |
| 00:00:36,980 --> 00:00:39,710 | end of each iteration, we will also have a product release. |
| 00:00:39,710 --> 00:00:41,790 | Which in this case, will be an internal one. As |
| 00:00:41,790 --> 00:00:44,690 | you can see, the iterative nature is really inherent in the |
| 00:00:44,690 --> 00:00:48,030 | unified rational process. So, now let's clean up here, and let's |
| 00:00:48,030 --> 00:00:50,814 | see what some other possible cycles could be for our banking |
| 00:00:50,814 --> 00:00:54,070 | IT system. Here, I'm showing two possible additional ones. The first |
| 00:00:54,070 --> 00:00:57,800 | one, cycle two, which will develop the account and system management. And |
| 00:00:57,800 --> 00:01:00,230 | the third one, cycle three, which will develop the full account |
| 00:01:00,230 --> 00:01:04,620 | management and cross selling. Similarly to cycle one, also these cycles will |
| 00:01:04,620 --> 00:01:07,570 | produce a product, both at the end of the cycle, and |
| 00:01:07,570 --> 00:01:10,740 | within the cycle in the different phases. And there's a few more |
| 00:01:10,740 --> 00:01:13,150 | things to note. So the first one, is that each cycle |
| 00:01:13,150 --> 00:01:15,900 | focuses on a different part of the system. So what you will |
| 00:01:15,900 --> 00:01:19,350 | do, when you use the rational unified process, you will select a |
| 00:01:19,350 --> 00:01:23,320 | subset of use cases that you want to realize within your cycle. |
| 00:01:23,320 --> 00:01:26,640 | And the final product for that cycle, will be a product that |
| 00:01:26,640 --> 00:01:30,190 | realizes those use cases. This is the first aspect. The second one, |
| 00:01:30,190 --> 00:01:33,290 | is that these cycles, as you can see, are slightly overlapping. So |
| 00:01:33,290 --> 00:01:35,880 | it is not the case that you finish a cycle, and then |
| 00:01:35,880 --> 00:01:37,580 | you start the next one. So there is a little bit of |
| 00:01:37,580 --> 00:01:41,250 | overlap among cycles, and we'll talk about that more. And finally, |
| 00:01:41,250 --> 00:01:43,600 | I want to stress one more that each cycle |
| 00:01:43,600 --> 00:01:46,960 | contains four phases, and each one of these phases might |
| 00:01:46,960 --> 00:01:49,890 | be further splayed in iterations. So that's kind of a |
| 00:01:49,890 --> 00:01:49,890 | high level view of how the whole process will work. |