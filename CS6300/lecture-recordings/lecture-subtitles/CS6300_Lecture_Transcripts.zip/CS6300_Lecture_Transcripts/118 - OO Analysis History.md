# CS6300 118 - OO Analysis History

| Timestamp | Content |
|-----------|---------|
| 00:00:00,060 --> 00:00:02,160 | The use of object orientation and object oriented |
| 00:00:02,160 --> 00:00:06,430 | concepts led to what we call OOAD, object oriented |
| 00:00:06,430 --> 00:00:10,650 | analysis and design. OOAD is a software engineering approach |
| 00:00:10,650 --> 00:00:13,790 | whose main characteristics is to model a software system |
| 00:00:13,790 --> 00:00:16,600 | as a group of interacting objects, and we'll |
| 00:00:16,600 --> 00:00:19,160 | see what that means. In particular, in this lesson |
| 00:00:19,160 --> 00:00:21,590 | we will specifically focus on the first part of |
| 00:00:21,590 --> 00:00:25,360 | this, object oriented analysis, which is a requirements analysis |
| 00:00:25,360 --> 00:00:29,650 | technique that concentrates on modeling real world objects. And |
| 00:00:29,650 --> 00:00:31,340 | as I usually like to do, I would like |
| 00:00:31,340 --> 00:00:34,812 | to start by providing some historical perspective on object |
| 00:00:34,812 --> 00:00:37,472 | oriented analysis to better understand how we went from a |
| 00:00:37,472 --> 00:00:40,990 | function-centric world to a data-centric world. And several people |
| 00:00:40,990 --> 00:00:43,800 | contributed to this shift in perspective, but I'd like |
| 00:00:43,800 --> 00:00:46,960 | to mention a few that were particularly influential. Starting |
| 00:00:46,960 --> 00:00:50,540 | from James Rumbaugh, which in the 90s developed an integrated |
| 00:00:50,540 --> 00:00:53,900 | approach to object oriented modelling with three main aspects. |
| 00:00:53,900 --> 00:00:56,680 | A data aspect, so the modelling was based on |
| 00:00:56,680 --> 00:01:00,390 | using an extended version of entity relationship diagrams to |
| 00:01:00,390 --> 00:01:03,680 | describe classes and inheritance. So that's what was called |
| 00:01:03,680 --> 00:01:06,770 | the object model. And the second aspect has to |
| 00:01:06,770 --> 00:01:09,770 | do with functions. So data flow diagrams were used |
| 00:01:09,770 --> 00:01:12,850 | to represent the functional aspects of the system, where |
| 00:01:12,850 --> 00:01:16,070 | each function was then becoming a method in a class. |
| 00:01:16,070 --> 00:01:18,500 | So this is what is called the functional model. |
| 00:01:18,500 --> 00:01:22,120 | So object model and functional model. The third model |
| 00:01:22,120 --> 00:01:25,120 | in Rumbaugh's methodology had to do with control. So |
| 00:01:25,120 --> 00:01:29,301 | it was representing the dynamic aspects of a system. And |
| 00:01:29,301 --> 00:01:31,880 | it uses state machines, which we'll cover in more |
| 00:01:31,880 --> 00:01:35,730 | detail, to represent how a system would evolve going from |
| 00:01:35,730 --> 00:01:37,650 | one state to the other based on what happened |
| 00:01:37,650 --> 00:01:41,260 | to the system. These three models together represented what was |
| 00:01:41,260 --> 00:01:44,950 | called the Object Modeling Technique, or OMT. And |
| 00:01:44,950 --> 00:01:47,860 | OMT combined with contributions from several people, and in |
| 00:01:47,860 --> 00:01:51,290 | particular Jacobson and Booch, evolved into what we call |
| 00:01:51,290 --> 00:01:54,910 | the Unified Modeling Language, which is UML, which is |
| 00:01:54,910 --> 00:01:56,910 | probably the modeling language that most of you |
| 00:01:56,910 --> 00:02:00,480 | are familiar with. UML extends OMT by providing more |
| 00:02:00,480 --> 00:02:03,460 | diagrams and a broader view of a system from |
| 00:02:03,460 --> 00:02:06,270 | multiple perspectives. So, in the second part of the |
| 00:02:06,270 --> 00:02:07,850 | lesson, we will cover some of these |
| 00:02:07,850 --> 00:02:10,530 | diagrams in details, but before that, I'd like |
| 00:02:10,530 --> 00:02:12,215 | to talk a little bit more about object |
| 00:02:12,215 --> 00:02:12,215 | oriented analysis, and how we can perform it. |