# CS6300 107 - Requirements Prioritization

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:04,010 | Why collecting, modeling, and analyzing requirements? We might realize |
| 00:00:04,010 --> 00:00:07,310 | that the resources available for the project are not enough |
| 00:00:07,310 --> 00:00:10,000 | to satisfy all of them. For example, there's not |
| 00:00:10,000 --> 00:00:13,450 | enough time, not enough money, not enough manpower. And therefore, |
| 00:00:13,450 --> 00:00:15,590 | there are some requirements that we won't be able |
| 00:00:15,590 --> 00:00:19,760 | to satisfy. In these cases, we must prioritize our requirements, |
| 00:00:19,760 --> 00:00:22,310 | by classifying them in one of three classes. The |
| 00:00:22,310 --> 00:00:25,270 | first class is mandatory requirements, and these are the requirements |
| 00:00:25,270 --> 00:00:29,770 | we must satisfy. Then there are the nice to have requirements that are the |
| 00:00:29,770 --> 00:00:32,170 | ones that we will satisfy if resources |
| 00:00:32,170 --> 00:00:34,740 | allow. And finally, there are the superfluous |
| 00:00:34,740 --> 00:00:36,440 | requirements, and those are the requirements that |
| 00:00:36,440 --> 00:00:37,770 | we're going to keep around, but that we're |
| 00:00:37,770 --> 00:00:40,010 | going to postpone. For example, we might decide |
| 00:00:40,010 --> 00:00:40,010 | to satisfy them in the next release. |