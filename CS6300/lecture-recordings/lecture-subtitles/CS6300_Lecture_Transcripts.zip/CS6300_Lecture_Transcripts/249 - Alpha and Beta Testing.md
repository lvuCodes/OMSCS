# CS6300 249 - Alpha and Beta Testing

| Timestamp | Content |
|-----------|---------|
| 00:00:00,510 --> 00:00:02,754 | All the testing levels that we've seen so far is what |
| 00:00:02,754 --> 00:00:06,058 | we can call developer's testing. So that's testing that is performed |
| 00:00:06,058 --> 00:00:09,649 | either within the testing organization, or by somebody who's doing like |
| 00:00:09,649 --> 00:00:13,520 | third-party testers on behalf of the testing organization. But there are two |
| 00:00:13,520 --> 00:00:16,280 | other kinds of testing that are worth mentioning that are also |
| 00:00:16,280 --> 00:00:19,600 | related to testing phases and these are alpha and beta testing. |
| 00:00:19,600 --> 00:00:23,050 | Alpha testing is the testing performed by distributing a software system |
| 00:00:23,050 --> 00:00:26,000 | ready to be released to a set of users that are internal |
| 00:00:26,000 --> 00:00:29,480 | to the organization that developed the software. So you can consider these |
| 00:00:29,480 --> 00:00:32,460 | users as, if you pass me the term, guinea pigs that will |
| 00:00:32,460 --> 00:00:35,170 | use an early version of the code and will likely discover errors |
| 00:00:35,170 --> 00:00:37,850 | that escaped testing and will have made it to the field if |
| 00:00:37,850 --> 00:00:41,390 | not caught. Beta testing is the next step after alpha testing, in |
| 00:00:41,390 --> 00:00:44,530 | which the software is released to a selected subset of users, in |
| 00:00:44,530 --> 00:00:47,770 | this case, outside your organization. And also in this case, the users |
| 00:00:47,770 --> 00:00:51,110 | are likely to discover latent errors in the code before it is officially |
| 00:00:51,110 --> 00:00:54,240 | released to the broader user population, so before we have an |
| 00:00:54,240 --> 00:00:56,850 | actual product release. So you may wonder why do we need |
| 00:00:56,850 --> 00:00:59,360 | to do both alpha and beta testing. Why not just one |
| 00:00:59,360 --> 00:01:02,980 | of the two? The reason is that alpha testing is performed |
| 00:01:02,980 --> 00:01:06,730 | to iron out the very obvious issues that still escape testing, |
| 00:01:06,730 --> 00:01:09,610 | but we want to do that before involving people outside your |
| 00:01:09,610 --> 00:01:12,730 | organization. And the rationale is that alpha testers have a higher |
| 00:01:12,730 --> 00:01:12,730 | tolerance for problems than beta testers, who expect a mostly working system. |