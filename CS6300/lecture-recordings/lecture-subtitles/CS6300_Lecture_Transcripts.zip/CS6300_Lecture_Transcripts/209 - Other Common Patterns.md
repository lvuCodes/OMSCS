# CS6300 209 - Other Common Patterns

| Timestamp | Content |
|-----------|---------|
| 00:00:00,060 --> 00:00:03,460 | Before concluding this lesson, let's look at a few more patterns. And |
| 00:00:03,460 --> 00:00:05,880 | although it will take too long to cover them in detail, I |
| 00:00:05,880 --> 00:00:08,986 | would like to at least mention and quickly discuss a few more |
| 00:00:08,986 --> 00:00:12,080 | of these more commonly-used patterns. In fact, some of the patterns that |
| 00:00:12,080 --> 00:00:15,400 | I will discuss, you might have used yourself. Maybe without knowing their |
| 00:00:15,400 --> 00:00:18,300 | name or the fact that they were design patterns. So let's start |
| 00:00:18,300 --> 00:00:21,660 | with a Visitor pattern, which is a way of separating an algorithm |
| 00:00:21,660 --> 00:00:25,150 | from an object structure on which it operates. And a practical result |
| 00:00:25,150 --> 00:00:28,010 | of this separation is the ability to add the new operation |
| 00:00:28,010 --> 00:00:31,680 | to exist in object structures, without modifying the structures. So, basically |
| 00:00:31,680 --> 00:00:34,540 | what this pattern does, is to allow for defining and easily |
| 00:00:34,540 --> 00:00:37,870 | modifying set of operations to perform on the objects of the collection. |
| 00:00:37,870 --> 00:00:40,570 | And the typical usage of this is, for example, when you're |
| 00:00:40,570 --> 00:00:43,140 | visiting a graph, or a set of objects, and you want |
| 00:00:43,140 --> 00:00:46,090 | to perform some operations on these objects. By using a visitor |
| 00:00:46,090 --> 00:00:48,410 | pattern, you can decouple the operation |
| 00:00:48,410 --> 00:00:50,830 | from the objects. Although not straightforward, |
| 00:00:50,830 --> 00:00:53,360 | this pattern is very, very useful. So, I really encourage you |
| 00:00:53,360 --> 00:00:56,060 | to look at it in more detail and get familiar with it. |
| 00:00:56,060 --> 00:00:59,040 | The second pattern I want to mention is the decorator pattern. |
| 00:00:59,040 --> 00:01:02,820 | The decorator pattern is basically a wrapper that adds functionality to a |
| 00:01:02,820 --> 00:01:05,030 | class. So the way in which it works, is that you |
| 00:01:05,030 --> 00:01:08,230 | will take a class, you will build a class that basically wraps |
| 00:01:08,230 --> 00:01:12,250 | this class. So it reproduces the functionality of the original class, but |
| 00:01:12,250 --> 00:01:15,900 | it also adds some functionality. And for all the functionality that was |
| 00:01:15,900 --> 00:01:18,750 | already in the original class, it will simply invoke this |
| 00:01:18,750 --> 00:01:21,080 | functionality and for the new one, you will implement it |
| 00:01:21,080 --> 00:01:24,510 | using the services of the class. And a nice property |
| 00:01:24,510 --> 00:01:26,760 | of the decorator pattern is that it's stackable. So you can |
| 00:01:26,760 --> 00:01:30,210 | add decorators on decorators on decorators, and further increase the |
| 00:01:30,210 --> 00:01:34,052 | functionality provided by your class. The iterator is another very |
| 00:01:34,052 --> 00:01:37,810 | commonly-used pattern. And, you probably use this one yourself because, |
| 00:01:37,810 --> 00:01:41,090 | it's also part of many standard libraries. What the iterator allows |
| 00:01:41,090 --> 00:01:44,220 | you to do, is basically to access elements of a collection |
| 00:01:44,220 --> 00:01:47,490 | without knowing the underlying representation. So the iterator will allow you |
| 00:01:47,490 --> 00:01:50,630 | to just go through a set of objects without worrying about |
| 00:01:50,630 --> 00:01:53,200 | how the objects are stored. So you basically just ask the |
| 00:01:53,200 --> 00:01:55,810 | iterator to give you the first object, the next object and |
| 00:01:55,810 --> 00:02:00,130 | so on. Another very commonly-used pattern is the observer pattern. And |
| 00:02:00,130 --> 00:02:02,650 | this pattern is very useful when you have an object of |
| 00:02:02,650 --> 00:02:06,190 | interest and a set of other objects that are interested in |
| 00:02:06,190 --> 00:02:09,240 | the changes that might occur in this first object. So |
| 00:02:09,240 --> 00:02:12,690 | what the observer pattern allows you to do is to register |
| 00:02:12,690 --> 00:02:15,460 | these objects, so that they let the system know that |
| 00:02:15,460 --> 00:02:18,690 | they're interested in changes in this first object. And then, every |
| 00:02:18,690 --> 00:02:20,840 | time that there is a change, these other objects will |
| 00:02:20,840 --> 00:02:23,030 | be automatically notified. So basically, |
| 00:02:23,030 --> 00:02:25,290 | the observer pattern allows for notifying |
| 00:02:25,290 --> 00:02:29,310 | dependents when an object of interest changes. If you want |
| 00:02:29,310 --> 00:02:32,020 | an example of this, just think about the file system and |
| 00:02:32,020 --> 00:02:35,870 | imagine having a folder. All the views of this folder will |
| 00:02:35,870 --> 00:02:37,970 | want to be notified every time that there's a change in |
| 00:02:37,970 --> 00:02:40,720 | the folder because they need to refresh. So instead of continuously |
| 00:02:40,720 --> 00:02:44,390 | checking the state of the folder, they will just register and basically |
| 00:02:44,390 --> 00:02:47,430 | say, hey, we're interested in knowing when something changes in this |
| 00:02:47,430 --> 00:02:50,320 | folder. And when something changes in the folder, they will be automatically |
| 00:02:50,320 --> 00:02:53,300 | notified. So it will be some sort of a push notification |
| 00:02:53,300 --> 00:02:56,590 | instead of a pull notification, if you are familiar with that terminology. |
| 00:02:56,590 --> 00:03:00,020 | Finally the proxy pattern is a pattern in which a surrogate |
| 00:03:00,020 --> 00:03:04,370 | controls access to an object. In other words, we have our object, |
| 00:03:04,370 --> 00:03:07,220 | and we have our proxy here. So all the requests to the |
| 00:03:07,220 --> 00:03:09,950 | object will go through the proxy that will then forward them. And |
| 00:03:09,950 --> 00:03:12,020 | all the responses from the object will also go through the |
| 00:03:12,020 --> 00:03:15,580 | proxy. They will then forward them to the original requester. So what |
| 00:03:15,580 --> 00:03:18,710 | the proxy allows you to do is to control how this object, |
| 00:03:18,710 --> 00:03:22,180 | that is behind the proxy, is actually accessed, for example, by filtering |
| 00:03:22,180 --> 00:03:24,500 | some calls. So in a sense, the proxy allows use |
| 00:03:24,500 --> 00:03:27,470 | for masking some of the functionality of the object that |
| 00:03:27,470 --> 00:03:31,070 | is behind the proxy. And there's many, many, many more |
| 00:03:31,070 --> 00:03:34,424 | useful patterns. That can help you when designing and implementing |
| 00:03:34,424 --> 00:03:37,220 | the system. So once more, I really encourage you to |
| 00:03:37,220 --> 00:03:38,740 | have a look at the book, to look at the |
| 00:03:38,740 --> 00:03:41,570 | resources online, and to really get more familiar with these |
| 00:03:41,570 --> 00:03:41,570 | patterns, and to try to use them in your everyday work. |