# CS6300 213 - Negative Design Patterns

| Timestamp | Content |
|-----------|---------|
| 00:00:00,100 --> 00:00:02,210 | To conclude this lesson, I want to discuss the |
| 00:00:02,210 --> 00:00:06,170 | concept of negative design patterns, that is, patterns that should |
| 00:00:06,170 --> 00:00:09,600 | be avoided. Interestingly, negative patterns were also mentioned in |
| 00:00:09,600 --> 00:00:12,950 | Christopher Alexander's book, so in the first formulation of patterns. |
| 00:00:12,950 --> 00:00:16,219 | So negative design pattern are basically guidelines on how |
| 00:00:16,219 --> 00:00:19,689 | not to do things. In consoles with patterns, the guidelines |
| 00:00:19,689 --> 00:00:21,920 | on how to do things. So basically, what the negative |
| 00:00:21,920 --> 00:00:25,170 | design patterns do is, they enable recurring design defects to |
| 00:00:25,170 --> 00:00:28,070 | be avoided. And as we will see in this class extensively, |
| 00:00:28,070 --> 00:00:30,080 | in mini-course four, negative patterns are |
| 00:00:30,080 --> 00:00:33,380 | also called anti-patterns or bad smells, |
| 00:00:33,380 --> 00:00:36,540 | or bad code smells. So in mini-course four we will see several |
| 00:00:36,540 --> 00:00:36,540 | examples of bad smells and what we can do to eliminate them. |