# CS6300 198 - Refining the Class Diagram

| Timestamp | Content |
|-----------|---------|
| 00:00:00,260 --> 00:00:01,720 | Okay, so let me see if |
| 00:00:01,720 --> 00:00:07,930 | anything changed after we did this last modification. |
| 00:00:07,930 --> 00:00:09,530 | Acutally, there is someting that I would like |
| 00:00:09,530 --> 00:00:12,120 | to do here. Because looking at this a little |
| 00:00:12,120 --> 00:00:15,560 | bit more, I noticed that there are two |
| 00:00:15,560 --> 00:00:18,760 | attributes, renewed and due date. That we have in |
| 00:00:18,760 --> 00:00:21,640 | loanable Item, right? But they don't seem to |
| 00:00:21,640 --> 00:00:25,590 | be really, attributes or characteristics of loanable Item. |
| 00:00:25,590 --> 00:00:29,150 | They're more of the characteristics of the association between the |
| 00:00:29,150 --> 00:00:32,470 | Loanable Item and the patron. Wouldn't you agree? |
| 00:00:32,470 --> 00:00:34,230 | >> Well, yeah, it's not like you could |
| 00:00:34,230 --> 00:00:37,644 | only renew a book once in it's entire history. |
| 00:00:37,644 --> 00:00:41,220 | >> Right. Exactly, exactly. So, that's why what l like |
| 00:00:41,220 --> 00:00:43,970 | to do is I would like to move those out of loanable |
| 00:00:43,970 --> 00:00:48,020 | item. And actually there is a construct that we can use |
| 00:00:48,020 --> 00:00:50,710 | to express this. It's called, we haven't seen it yet, but it's |
| 00:00:50,710 --> 00:00:52,780 | a special kind of class. It's called an association |
| 00:00:52,780 --> 00:00:55,480 | class. So, it's a class that is connected to |
| 00:00:55,480 --> 00:00:57,730 | a specific association. So what we can do |
| 00:00:57,730 --> 00:01:00,730 | here, we can create this class, which I'm going to |
| 00:01:00,730 --> 00:01:05,200 | call checked out. I'm going to, associate it with |
| 00:01:05,200 --> 00:01:09,520 | this, association. I'm going to connect it with this association. And |
| 00:01:09,520 --> 00:01:11,620 | then I'm going to move the due date and the |
| 00:01:11,620 --> 00:01:16,300 | renewed attributes From the LoanableItem here in this checked |
| 00:01:16,300 --> 00:01:18,520 | out class. So in this way, seems to me that |
| 00:01:18,520 --> 00:01:20,910 | it makes it very explicit for somebody looking at this |
| 00:01:20,910 --> 00:01:25,530 | class diagram, that these characteristics are characteristics of the loan, |
| 00:01:25,530 --> 00:01:28,200 | and not of the elements involved in the loan. |
| 00:01:28,200 --> 00:01:33,410 | >> Can you do the same thing with Fine, isn't Fine a property of the |
| 00:01:33,410 --> 00:01:36,740 | loan? Yeah, actually is right because |
| 00:01:36,740 --> 00:01:39,120 | a fine is a fine for a specific loan, right? |
| 00:01:39,120 --> 00:01:39,910 | >> That's correct. |
| 00:01:39,910 --> 00:01:41,950 | >> Okay, so yeah. Then we can do that. |
| 00:01:41,950 --> 00:01:45,900 | We don't need to represent fine as a class, we can just transform |
| 00:01:45,900 --> 00:01:49,460 | that into an attribute that we can put into the checked out association class. |
| 00:01:49,460 --> 00:01:50,560 | >> Gotcha. |
| 00:01:50,560 --> 00:01:52,760 | >> Anything else? |
| 00:01:52,760 --> 00:01:57,990 | >> Yeah. It occurred to me that there's another thing that happens in one |
| 00:01:57,990 --> 00:02:00,260 | of my scenarios, I put down |
| 00:02:00,260 --> 00:02:02,770 | about the patron actually returning an item. |
| 00:02:02,770 --> 00:02:07,620 | >> Right. Okay, so we would probably need an additional operation, |
| 00:02:07,620 --> 00:02:08,550 | I guess, for the patron. |
| 00:02:08,550 --> 00:02:08,990 | >> Right. |
| 00:02:08,990 --> 00:02:11,310 | >> So, okay, so what I'm going to do, that's pretty easy |
| 00:02:11,310 --> 00:02:15,350 | to do, I'm just going to add the return operation here in the |
| 00:02:15,350 --> 00:02:19,310 | patron, and when that happens, that will mean that I'll get rid |
| 00:02:19,310 --> 00:02:23,490 | of this association class because the item is returned. Is that right? |
| 00:02:23,490 --> 00:02:27,060 | >> Well, what happens if somebody drops the |
| 00:02:27,060 --> 00:02:29,400 | book in the book drop, but doesn't pay the, |
| 00:02:29,400 --> 00:02:31,050 | if it's overdue and doesn't pay the fine? |
| 00:02:31,050 --> 00:02:32,700 | Will that get rid of the information about what |
| 00:02:32,700 --> 00:02:33,040 | they owe? |
| 00:02:33,040 --> 00:02:37,960 | >> Oh, I see. So you can have the item being available, but you still |
| 00:02:37,960 --> 00:02:42,510 | want to know whether there is any pending fines on the book. |
| 00:02:42,510 --> 00:02:44,390 | >> Uh-huh, and how much those fines are. |
| 00:02:44,390 --> 00:02:47,420 | >> And how do you compute how much it is? |
| 00:02:47,420 --> 00:02:52,710 | >> It's how many days it was, from the time it was |
| 00:02:52,710 --> 00:02:58,170 | due, to when they returned it. I see. OK. |
| 00:02:58,170 --> 00:03:00,380 | So you know what we can do? I think |
| 00:03:00,380 --> 00:03:03,690 | we can put an additional attribute in the checked out |
| 00:03:03,690 --> 00:03:07,190 | class and I'm going to call it when returned and |
| 00:03:07,190 --> 00:03:10,200 | that item will have either a special value or it |
| 00:03:10,200 --> 00:03:12,040 | will contain the date in which the book was |
| 00:03:12,040 --> 00:03:14,520 | returned. So in this way you should be able to |
| 00:03:14,520 --> 00:03:18,040 | keep this in the system until it's paid, and also to compute |
| 00:03:18,040 --> 00:03:19,970 | how much the fine is. Is that working? |
| 00:03:19,970 --> 00:03:23,210 | >> So the special value is for a normal situation when they |
| 00:03:23,210 --> 00:03:25,880 | haven't, they don't owe anything and haven't returned it yet. |
| 00:03:25,880 --> 00:03:28,080 | >> Exactly so that will tell us that, |
| 00:03:28,080 --> 00:03:29,970 | that the loan is still active basically. |
| 00:03:29,970 --> 00:03:30,500 | >> Great. |
| 00:03:30,500 --> 00:03:31,480 | >> Does that work for you? |
| 00:03:31,480 --> 00:03:35,200 | >> Yes. And you know, I like this. I mean, I feel pretty good |
| 00:03:35,200 --> 00:03:38,490 | about it. I think we have a nice class diagram. So what I'd like to |
| 00:03:38,490 --> 00:03:43,280 | do is just go off and clean it up a little bit, and put it |
| 00:03:43,280 --> 00:03:48,640 | in an IDE so I can pretty print it and rearrange things a little bit. |
| 00:03:48,640 --> 00:03:50,080 | And then I'd like to sit down again and |
| 00:03:50,080 --> 00:03:52,730 | just go through it for a last time. And |
| 00:03:52,730 --> 00:03:54,900 | for some final considerations. So if you don't mind |
| 00:03:54,900 --> 00:03:56,880 | we will take a ten minute break and reconvene here. |
| 00:03:56,880 --> 00:03:57,500 | >> That's fine. |
| 00:03:57,500 --> 00:03:57,500 | >> Alright. |