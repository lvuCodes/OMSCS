# CS6300 218 - UML Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:02,350 | And the correct answer, in this case it's only one, |
| 00:00:02,350 --> 00:00:04,720 | is that a use case model is a set of use |
| 00:00:04,720 --> 00:00:07,390 | cases. So a use case model is simply a collection of |
| 00:00:07,390 --> 00:00:07,390 | use cases that represent different pieces of functionality for the system. |