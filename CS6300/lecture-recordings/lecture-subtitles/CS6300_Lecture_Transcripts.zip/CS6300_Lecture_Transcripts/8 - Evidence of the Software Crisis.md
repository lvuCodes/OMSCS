# CS6300 8 - Evidence of the Software Crisis

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:03,220 | After recapping the three major issues that characterize a software crisis |
| 00:00:03,220 --> 00:00:05,626 | let's see what was the evidence that there was indeed a |
| 00:00:05,626 --> 00:00:07,900 | crisis. So what I want to discuss now is the result |
| 00:00:07,900 --> 00:00:11,060 | of a study performed by Davis in 1990s. So in even |
| 00:00:11,060 --> 00:00:13,670 | more recent times than the 60s and the 70s. And the |
| 00:00:13,670 --> 00:00:17,280 | study was performed on nine software projects that were totaling a |
| 00:00:17,280 --> 00:00:20,990 | cost around $7 million and I'm going to show you how this |
| 00:00:20,990 --> 00:00:25,190 | projects went using this representation, this pi representation, in which I'm |
| 00:00:25,190 --> 00:00:27,520 | going to discuss what each of the segment of the |
| 00:00:27,520 --> 00:00:30,010 | pi represent. So let's start looking at the first one. |
| 00:00:30,010 --> 00:00:32,920 | This is a software that was usable as delivered. Other |
| 00:00:32,920 --> 00:00:36,590 | software was delivered, and usable, either after some changes or |
| 00:00:36,590 --> 00:00:41,080 | after some major modifications, so within additional costs involved. |
| 00:00:41,080 --> 00:00:43,530 | But the striking piece of information here is that the |
| 00:00:43,530 --> 00:00:46,890 | vast majority of the software, so these two slices, were |
| 00:00:46,890 --> 00:00:50,250 | software that was either delivered but never successfully used or |
| 00:00:50,250 --> 00:00:53,730 | software that was not even delivered. And this corresponded |
| 00:00:53,730 --> 00:00:57,500 | to five over the seven total million dollars for |
| 00:00:57,500 --> 00:01:00,050 | all the projects. So clearly, this shows a pretty |
| 00:01:00,050 --> 00:01:03,910 | grim picture for software development and its success. In short, |
| 00:01:03,910 --> 00:01:06,410 | there was clear evidence the software was becoming to |
| 00:01:06,410 --> 00:01:08,990 | difficult too build and that the software industry was facing |
| 00:01:08,990 --> 00:01:11,190 | a crisis. And this is what led to the |
| 00:01:11,190 --> 00:01:15,130 | NATO Software Engineering Conference that was held in January 1969, |
| 00:01:15,130 --> 00:01:19,100 | which is what we can consider the birth of software engineering. And what |
| 00:01:19,100 --> 00:01:23,080 | I'm showing here is a drawing of the proceedings for that conference. And if |
| 00:01:23,080 --> 00:01:26,020 | you look at the class notes you can see a link to the actual |
| 00:01:26,020 --> 00:01:27,640 | proceedings, in case you are interested in |
| 00:01:27,640 --> 00:01:27,640 | looking at the issues that were discussed. |