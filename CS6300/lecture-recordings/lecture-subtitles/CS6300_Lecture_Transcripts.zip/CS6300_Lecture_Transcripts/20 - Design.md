# CS6300 20 - Design

| Timestamp | Content |
|-----------|---------|
| 00:00:00,290 --> 00:00:02,900 | Now let's discuss the next phase of software development, |
| 00:00:02,900 --> 00:00:06,080 | which is software design. Software design is the phase |
| 00:00:06,080 --> 00:00:09,030 | where software requirements are analyzed in order to produce |
| 00:00:09,030 --> 00:00:11,500 | a description of the internal structure and organization of |
| 00:00:11,500 --> 00:00:13,900 | the system. And this description will serve as the |
| 00:00:13,900 --> 00:00:17,550 | basis for the construction of the actual system. Traditionally, |
| 00:00:17,550 --> 00:00:20,020 | the software design phase consists of a series of |
| 00:00:20,020 --> 00:00:25,360 | design activities. Which normally consists of the architectural design phase, |
| 00:00:25,360 --> 00:00:27,880 | the abstract specification, interface design, |
| 00:00:27,880 --> 00:00:30,010 | component design, data structure and |
| 00:00:30,010 --> 00:00:33,230 | algorithm design. And notice that this is just a possible list |
| 00:00:33,230 --> 00:00:35,820 | of activities. But you can also characterize design activities in |
| 00:00:35,820 --> 00:00:38,550 | many different ways. And if you're looking at different books, and |
| 00:00:38,550 --> 00:00:41,800 | different sources, you might find different activities described. But the |
| 00:00:41,800 --> 00:00:44,500 | core idea, the important point is that we go from sort |
| 00:00:44,500 --> 00:00:46,940 | of a high-level view of the system, which is the |
| 00:00:46,940 --> 00:00:50,770 | architectural design, to a low-level view, which is the algorithm design. |
| 00:00:50,770 --> 00:00:53,100 | And these activities result in a set of design |
| 00:00:53,100 --> 00:00:56,810 | products, which describe various characteristics of the system. For |
| 00:00:56,810 --> 00:00:59,770 | example, they describe the architecture of the system, so |
| 00:00:59,770 --> 00:01:02,890 | how the system is decomposed and organized into components, the |
| 00:01:02,890 --> 00:01:06,630 | interfaces between these components. They also describe these components |
| 00:01:06,630 --> 00:01:09,030 | into a level of details that is suitable for |
| 00:01:09,030 --> 00:01:12,470 | allowing their construction. We will discuss the details of |
| 00:01:12,470 --> 00:01:16,130 | software design and talk extensively about these different actives and |
| 00:01:16,130 --> 00:01:16,130 | these different products in the third mini course of this class. |