# CS6300 110 - Requirements Engineering Process

| Timestamp | Content |
|-----------|---------|
| 00:00:00,180 --> 00:00:02,580 | Let's now put together all that we have discussed |
| 00:00:02,580 --> 00:00:06,340 | and see how a requirements engineering process actually works. |
| 00:00:06,340 --> 00:00:08,450 | So, first of all, we saw that requirements engineering |
| 00:00:08,450 --> 00:00:12,080 | consists of three main steps. Elicitation of the requirements, |
| 00:00:12,080 --> 00:00:15,450 | in which we extract requirements from various sources. Modeling |
| 00:00:15,450 --> 00:00:17,880 | in which we represent the requirements using one or |
| 00:00:17,880 --> 00:00:21,650 | more notations or formal reasons and analysis, in which |
| 00:00:21,650 --> 00:00:25,230 | we identify possible issues with our requirements and there is |
| 00:00:25,230 --> 00:00:27,870 | actually a 4th step that we kind of mention |
| 00:00:27,870 --> 00:00:30,670 | but not explicitly. And this is the negotiation that can |
| 00:00:30,670 --> 00:00:34,320 | happen between the stakeholders and the developers, during which |
| 00:00:34,320 --> 00:00:38,400 | requirements are discussed and modified until an agreement is reached. |
| 00:00:38,400 --> 00:00:40,000 | So if you want to think of this as a |
| 00:00:40,000 --> 00:00:43,030 | process, so as a sequence of steps, we can see |
| 00:00:43,030 --> 00:00:46,000 | that we start from elicitation. So we start by eliciting |
| 00:00:46,000 --> 00:00:50,450 | an initial setup requirements. We negotiate and refine this set, |
| 00:00:50,450 --> 00:00:53,820 | then we model the resulting requirements. And finally, we |
| 00:00:53,820 --> 00:00:58,190 | analyze such requirements. However, the process doesn't really stop here. |
| 00:00:58,190 --> 00:01:00,620 | Why? Well, because as a result of the analysis, |
| 00:01:00,620 --> 00:01:03,230 | we might have to perform further elicitation. And so this |
| 00:01:03,230 --> 00:01:05,850 | process is not really a sequential one, but rather |
| 00:01:05,850 --> 00:01:09,340 | an iterative process. So, in practice, we continue to iterate |
| 00:01:09,340 --> 00:01:12,700 | over these four steps gathering a better and better understanding |
| 00:01:12,700 --> 00:01:15,560 | of the requirements at every iteration until we are happy |
| 00:01:15,560 --> 00:01:15,560 | with the settle requirement that we gather and stop the process. |