# CS6300 137 - Use Case Diagram_ Actors

| Timestamp                     | Content                                                                       |
| ----------------------------- | ----------------------------------------------------------------------------- |
| 00:00:00,110 --> 00:00:02,320 | Now, let's look at use cases in a little more detail.                         |
| 00:00:02,320 --> 00:00:05,480 | And start by defining exactly what an actor is. An **actor**                  |
| 00:00:05,480 --> 00:00:08,710 | **represents an entity, which can be a human or a device,**                   |
| 00:00:08,710 --> 00:00:12,750 | **that plays a role within my system, so that interacts with my**             |
| 00:00:12,750 --> 00:00:15,660 | **system. It's some entity from the outside world, with respect to**          |
| 00:00:15,660 --> 00:00:18,510 | **my system, that interacts with my system**. It is important to              |
| 00:00:18,510 --> 00:00:21,750 | clarify that **an entity can play more than one role**. For                   |
| 00:00:21,750 --> 00:00:25,240 | example, you might have somebody working in a bank that can be                |
| 00:00:25,240 --> 00:00:28,400 | both an employee of the bank, or a customer of                                |
| 00:00:28,400 --> 00:00:31,280 | the bank, depending on how it interacts with the banking                      |
| 00:00:31,280 --> 00:00:34,360 | **system. And, obviously, more than one entity can play the**                 |
| 00:00:34,360 --> 00:00:37,570 | **same role**. Using the same example, we can have both an                    |
| 00:00:37,570 --> 00:00:40,350 | employee of the bank and just a regular customer, playing                     |
| 00:00:40,350 --> 00:00:43,280 | the role of the customer. So again, it all depends on                         |
| 00:00:43,280 --> 00:00:46,120 | what the entity does, how the entity interacts with the                       |
| 00:00:46,120 --> 00:00:50,150 | system, what kind of functionality of the system the entity uses.             |
| 00:00:50,150 --> 00:00:53,270 | **And finally, actors may appear in more than one use case.**                 |
| 00:00:53,270 --> 00:00:55,930 | So it's fairly normal for the same actor to interact with                     |
| 00:00:55,930 --> 00:00:58,540 | the system in different ways. And therefore, to appear in more                |
| 00:00:58,540 --> 00:01:00,710 | than one use case. Just think about the use cases in                          |
| 00:01:00,710 --> 00:01:04,230 | scenarios of usage. If the same actor can interact with the                   |
| 00:01:04,230 --> 00:01:07,440 | system in different ways, that actor will appear in multiple use              |
| 00:01:07,440 --> 00:01:11,210 | cases. Now let's go back to the description of our course                     |
| 00:01:11,210 --> 00:01:15,140 | management system, and see how we can identify actors in the system.          |
| 00:01:15,140 --> 00:01:17,500 | And as we did for the class diagram before, I encourage                       |
| 00:01:17,500 --> 00:01:20,160 | you to stop the video and try to identify the actors                          |
| 00:01:20,160 --> 00:01:23,475 | in the system yourself, before I do it.                                       |
| 00:01:23,475 --> 00:01:27,250 | If we look at the description, we can see that, for example, the Registration |
| 00:01:27,250 --> 00:01:30,890 | Manager is clearly an actor for the system. Students are actors               |
| 00:01:30,890 --> 00:01:34,400 | for the system. Professors are actors for the system. And notice              |
| 00:01:34,400 --> 00:01:36,060 | that we're not doing the same thing that we were doing                        |
| 00:01:36,060 --> 00:01:38,360 | when identifying classes. Here we're identifying                              |
| 00:01:38,360 --> 00:01:40,460 | **entities that are from the outside**                                        |
| 00:01:40,460 --> 00:01:43,090 | **world, and have an active role in interacting with my**                     |
| 00:01:43,090 --> 00:01:46,830 | **system**. Again, Registration Manager, that we will just call registrar for |
| 00:01:46,830 --> 00:01:50,660 | simplicity, students, and professors. So once we have identified the          |
| 00:01:50,660 --> 00:01:53,760 | actors for our example, we can simply draw them, using the                    |
| 00:01:53,760 --> 00:01:56,550 | notation that we just introduced. So we have the registrar,                   |
| 00:01:56,550 --> 00:01:59,830 | and notice how for every actor we clarify the role that                       |
| 00:01:59,830 --> 00:02:02,450 | the actor plays. We have the professor, and we have                           |
| 00:02:02,450 --> 00:02:05,480 | the student. So here, these are the three actors that we                      |
| 00:02:05,480 --> 00:02:05,480 | identified for our system.                                                    |