# CS6300 25 - Software Phases Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,190 --> 00:00:04,000 | And the answer is the third one. The traditional software phases which are the |
| 00:00:04,000 --> 00:00:05,960 | ones that we just discussed are requirements |
| 00:00:05,960 --> 00:00:08,820 | engineering, design, implementation, verification |
| 00:00:08,820 --> 00:00:08,820 | and validation, and maintenance. |