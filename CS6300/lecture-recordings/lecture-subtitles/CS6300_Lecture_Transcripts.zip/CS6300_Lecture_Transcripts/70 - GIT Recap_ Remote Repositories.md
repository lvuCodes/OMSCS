# CS6300 70 - GIT Recap_ Remote Repositories

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:02,960 | SImilarly, let's go through some commands that you can run on |
| 00:00:02,960 --> 00:00:07,150 | remote repositories. First command is the command to copy a repository, |
| 00:00:07,150 --> 00:00:10,840 | which is git clone in which you get a remote repository and you make a lot of |
| 00:00:10,840 --> 00:00:14,850 | copy in your working directory. The repository can be specified as a URL. |
| 00:00:14,850 --> 00:00:18,230 | It can be a local file, it can be specified using the HTTP or |
| 00:00:18,230 --> 00:00:21,070 | the SSH protocol, and there's also other ways to do it. |
| 00:00:21,070 --> 00:00:25,300 | This creates a complete local copy of the repository, as it says, and links it |
| 00:00:25,300 --> 00:00:29,030 | to the remote repository, which is what is called the origin. And if you want, |
| 00:00:29,030 --> 00:00:33,400 | you could also actually link to the repository, later. Then the normal way of |
| 00:00:33,400 --> 00:00:37,800 | receiving changes from a repository is to perform a git pull command. And we saw |
| 00:00:37,800 --> 00:00:42,345 | that you can also perform the same operation through two commands, get fetch and |
| 00:00:42,345 --> 00:00:47,210 | git merge. In case you want to inspect the changes before actually merging them, |
| 00:00:47,210 --> 00:00:49,550 | before actually getting them in your local copy. And |
| 00:00:49,550 --> 00:00:52,940 | if you want to send changes that you have in your local repository to |
| 00:00:52,940 --> 00:00:52,940 | a remote repository, you will use the git push command. |