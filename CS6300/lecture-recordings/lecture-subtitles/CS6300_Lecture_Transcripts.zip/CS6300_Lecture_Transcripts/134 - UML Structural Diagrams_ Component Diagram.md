# CS6300 134 - UML Structural Diagrams_ Component Diagram

| Timestamp                     | Content                                                                                             |
| ----------------------------- | --------------------------------------------------------------------------------------------------- |
| 00:00:00,100 --> 00:00:02,160 | There's two more structural diagrams that I want to                                                 |
| 00:00:02,160 --> 00:00:04,670 | mention before we move to the behavioral ones. The                                                  |
| 00:00:04,670 --> 00:00:07,420 | first one's the **component diagram**. A component diagram is                                       |
| 00:00:07,420 --> 00:00:09,690 | **a static view of components in a system and of**                                                  |
| 00:00:09,690 --> 00:00:13,010 | **their relationships. More precisely, a node in a component**                                      |
| 00:00:13,010 --> 00:00:16,700 | **diagram represents a component where a component consists of one**                                |
| 00:00:16,700 --> 00:00:21,090 | **or more classes with a well-defined interface. Edges conversely**                                 |
| 00:00:21,090 --> 00:00:25,290 | **indicate relationships between the components.** You can read this relationship                   |
| 00:00:25,290 --> 00:00:29,600 | as component A uses services of component B. And notice that the                                    |
| 00:00:29,600 --> 00:00:32,990 | component diagrams can be used to represent an architecture, which is                               |
| 00:00:32,990 --> 00:00:36,110 | a topic that we will cover extensively in the next mini-course.                                     |
| 00:00:36,110 --> 00:00:39,540 | So let's illustrate this with an example. So, what I'm representing                                 |
| 00:00:39,540 --> 00:00:43,160 | here is a component diagram for our example system, the course                                      |
| 00:00:43,160 --> 00:00:46,220 | management system. And as you can see, it's slightly more complex![[lvu 2026-02-15 at 03.39PM.png]] |
| 00:00:46,220 --> 00:00:48,390 | than the other diagrams that we saw. But there's really no                                          |
| 00:00:48,390 --> 00:00:50,700 | need to go through all the steps and all the details.                                               |
| 00:00:50,700 --> 00:00:53,470 | Important thing is to point out some key aspects of                                                 |
| 00:00:53,470 --> 00:00:56,370 | this diagram. So the first one is that these rectangular                                            |
| 00:00:56,370 --> 00:00:58,560 | nodes are the nodes in the system, so are my                                                        |
| 00:00:58,560 --> 00:01:02,960 | components. For example, student is a component, schedule is a component,                           |
| 00:01:02,960 --> 00:01:05,069 | and so on. And as far as edges are concerned,                                                       |
| 00:01:05,069 --> 00:01:08,580 | I'm representing two kinds of edges. The first kind of dashed                                       |
| 00:01:08,580 --> 00:01:12,060 | edges which were part of the original UML definition and                                            |
| 00:01:12,060 --> 00:01:16,120 | indicate use. So an edge, for example, between this compnent and                                    |
| 00:01:16,120 --> 00:01:19,570 | this compnent indicated that the seminar management uses the                                        |
| 00:01:19,570 --> 00:01:23,890 | facilities component. More recently, in UML two, a richer representation                            |
| 00:01:23,890 --> 00:01:26,240 | was introduced, which is the one that I'm also showing                                              |
| 00:01:26,240 --> 00:01:27,860 | here. So if we look at this part of the                                                             |
| 00:01:27,860 --> 00:01:29,540 | diagram, you can see this sort of you now,                                                          |
| 00:01:29,540 --> 00:01:34,080 | **lollipop socket** representation. And in this case, what this represents,                         |
| 00:01:34,080 --> 00:01:37,920 | is that a **lollipop indicates a provided interface**. So an                                        |
| 00:01:37,920 --> 00:01:41,500 | interface that is provided by the component. So, for example,                                       |
| 00:01:41,500 --> 00:01:45,940 | this security component provides encryption capabilities. The **socket**,                           |
| 00:01:45,940 --> 00:01:49,190 | conversely, indicates a **required interface**. So, for example, in                                 |
| 00:01:49,190 --> 00:01:52,270 | this case, it's saying that the facilities component                                                |
| 00:01:52,270 --> 00:01:55,920 | is needing access control capabilities, which, by the way,                                          |
| 00:01:55,920 --> 00:01:58,660 | is provided by the security component. So in                                                        |
| 00:01:58,660 --> 00:02:02,240 | a sense these sockets and lollipop indicate interfaces between                                      |
| 00:02:02,240 --> 00:02:04,770 | a provider of some of functionality, and the client                                                 |
| 00:02:04,770 --> 00:02:06,630 | of that functionality and you can look at those                                                     |
| 00:02:06,630 --> 00:02:09,740 | **as basically APIs. So sets of methods that**                                                      |
| 00:02:09,740 --> 00:02:12,160 | **provide a given functionality.** To give you another                                              |
| 00:02:12,160 --> 00:02:14,760 | example, if we look at the persistence components                                                   |
| 00:02:14,760 --> 00:02:19,110 | the persistence component provides, unsurprisingly, persistent services. And                        |
| 00:02:19,110 --> 00:02:21,650 | those persistent services are required by several other                                             |
| 00:02:21,650 --> 00:02:24,520 | components in the system. And in turn, the persistent                                               |
| 00:02:24,520 --> 00:02:28,320 | components relies on the University database component to                                           |
| 00:02:28,320 --> 00:02:31,740 | provide such services. So, there's the University DB components                                     |
| 00:02:31,740 --> 00:02:34,700 | provide these sort of low-level database services that are used                                     |
| 00:02:34,700 --> 00:02:38,150 | by the persistence component To in turn provided services. Last thing                               |
| 00:02:38,150 --> 00:02:41,080 | I want to note is that components or relationships can be                                           |
| 00:02:41,080 --> 00:02:44,450 | **annotated**, so, for example if we look at the seminar management                                 |
| 00:02:44,450 --> 00:02:47,090 | and the student administration components you can see that they                                     |
| 00:02:47,090 --> 00:02:51,360 | are annotated here to indicate that they are user inferfaces. So                                    |
| 00:02:51,360 --> 00:02:53,600 | that's all I wanted to say on the component diagrams, but                                           |
| 00:02:53,600 --> 00:02:56,750 | again the key piece of information is that they represent components                                |
| 00:02:56,750 --> 00:03:00,250 | in the system where a component consists of one or more classes indicate the                        |
| 00:03:00,250 --> 00:03:03,540 | interfaces that these components provide or require.                                                |
| 00:03:03,540 --> 00:03:03,540 | and describe the interactions between these components.                                             |