# CS6300 12 - Preliminary Questions Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:01,620 | We're going to go back to these two questions |
| 00:00:01,620 --> 00:00:03,260 | and to your answers later. But I wanted to |
| 00:00:03,260 --> 00:00:05,810 | gather this information beforehand, so that your answers are |
| 00:00:05,810 --> 00:00:05,810 | not biased, they're not influenced by this subsequent discussion. |