# CS6300 253 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,320 --> 00:00:02,620 | In the previous lesson, we discussed the fundamental |
| 00:00:02,620 --> 00:00:06,380 | concepts behind software verification in general, and software testing |
| 00:00:06,380 --> 00:00:09,470 | in particular. In this lesson, we will discuss |
| 00:00:09,470 --> 00:00:12,310 | one of the two main testing approaches. Black box |
| 00:00:12,310 --> 00:00:16,180 | testing, also called functional testing. We will cover |
| 00:00:16,180 --> 00:00:19,180 | the main characteristic of black box testing, its pros |
| 00:00:19,180 --> 00:00:22,260 | and cons, and discuss some commonly used black |
| 00:00:22,260 --> 00:00:25,350 | box testing techniques. We will conclude the lesson with |
| 00:00:25,350 --> 00:00:28,520 | a practical exercise in which we will apply a specific black |
| 00:00:28,520 --> 00:00:32,520 | box testing technique to a real program. We will derive test |
| 00:00:32,520 --> 00:00:34,980 | cases for the program and assess how the use of a |
| 00:00:34,980 --> 00:00:34,980 | systematic approach, in contrast to a brute force approach, can help. |