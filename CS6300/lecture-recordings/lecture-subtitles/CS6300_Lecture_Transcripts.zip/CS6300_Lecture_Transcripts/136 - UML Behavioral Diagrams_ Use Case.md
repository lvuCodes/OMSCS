# CS6300 136 - UML Behavioral Diagrams_ Use Case

| Timestamp                     | Content                                                                     |
| ----------------------------- | --------------------------------------------------------------------------- |
| 00:00:00,110 --> 00:00:04,700 | We now discuss UML's behavioral diagrams. Those diagrams that               |
| 00:00:04,700 --> 00:00:07,490 | have to do with the **behavior, the dynamic aspects**                       |
| 00:00:07,490 --> 00:00:09,940 | **of the system**, rather than the static ones. The                         |
| 00:00:09,940 --> 00:00:12,670 | first behavioral diagram I want to discuss is a very                        |
| 00:00:12,670 --> 00:00:15,590 | fundamental one, the **Use Case Diagram**. So, let's start                  |
| 00:00:15,590 --> 00:00:18,370 | by seeing what a Use Case is. A Use Case                                    |
| 00:00:18,370 --> 00:00:21,800 | represents two main things. **First the sequence of interactions**          |
| 00:00:21,800 --> 00:00:25,250 | **of outside entities which is what we normally call actors**               |
| 00:00:25,250 --> 00:00:27,990 | **with the system that we're modelling and the second thing**               |
| 00:00:27,990 --> 00:00:32,290 | **is the system actions that yield an observable result of values**         |
| 00:00:32,290 --> 00:00:35,380 | **to the actors.** And basically these two things, and nothing else         |
| 00:00:35,380 --> 00:00:38,010 | that the outside view of the system. So the view of                         |
| 00:00:38,010 --> 00:00:41,060 | the system in which we look at the interaction between                      |
| 00:00:41,060 --> 00:00:44,170 | this system, and the outside world. If you want to parallel, think          |
| 00:00:44,170 --> 00:00:48,070 | about designing a house. Considering how you would use the house.           |
| 00:00:48,070 --> 00:00:50,550 | And you might have seen use cases called with different names.              |
| 00:00:50,550 --> 00:00:54,820 | So for example, they're also called **scenarios, scripts or user stories,** |
| 00:00:54,820 --> 00:00:58,220 | but in the context of UML, we'll call the use cases.                        |
| 00:00:58,220 --> 00:01:00,650 | Now let's look at the basic notation for a use case,                        |
| 00:01:00,650 --> 00:01:03,910 | which is fairly simple. We have a use case which is represented             |
| 00:01:03,910 --> 00:01:05,760 | by an **oval**, with a name, which is the name of                           |
| 00:01:05,760 --> 00:01:08,520 | the use case. We have an actor, which is represented by                     |
| 00:01:08,520 --> 00:01:12,330 | this **icon** and is normally identified by a role name. And                |
| 00:01:12,330 --> 00:01:15,820 | finally we have an edge which is a **solid line that connects**             |
| 00:01:15,820 --> 00:01:18,970 | **actors and use cases and indicates that an actor**                        |
| 00:01:18,970 --> 00:01:21,270 | **is the actor of a given use case.** And just                              |
| 00:01:21,270 --> 00:01:24,360 | for completeness let me note there are some additional notational           |
| 00:01:24,360 --> 00:01:24,360 | elements but now for simplicity we'll just use these ones.                  |