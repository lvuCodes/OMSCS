# CS6300 29 - Evolutionary Prototyping Process

| Timestamp | Content |
|-----------|---------|
| 00:00:00,080 --> 00:00:02,430 | The next process model I want to discuss is evolutionary |
| 00:00:02,430 --> 00:00:05,786 | prototyping, which works in four main phases. We start |
| 00:00:05,786 --> 00:00:08,393 | from an initial concept, then we design and implement |
| 00:00:08,393 --> 00:00:11,509 | a prototype based on this initial concept, refine the prototype |
| 00:00:11,509 --> 00:00:14,002 | until it is acceptable, and finally we complete and |
| 00:00:14,002 --> 00:00:17,550 | release the prototype. Therefore, when developing a system using |
| 00:00:17,550 --> 00:00:22,330 | evolutionary prototyping, the system is continually refined and rebuilt. |
| 00:00:22,330 --> 00:00:25,340 | So it is an ideal process when not all requirements |
| 00:00:25,340 --> 00:00:28,330 | are well understood. Which is a very common situation. So, looking |
| 00:00:28,330 --> 00:00:30,370 | at this in a little more details, what happens is that |
| 00:00:30,370 --> 00:00:33,760 | developers start by developing the parts of the system that they |
| 00:00:33,760 --> 00:00:37,690 | understand, instead of working on developing a whole system, including parts |
| 00:00:37,690 --> 00:00:40,520 | that might not be very clear at that stage. The partial |
| 00:00:40,520 --> 00:00:43,900 | system is then shown to the customer and the customer feedback |
| 00:00:43,900 --> 00:00:47,480 | is used to drive the next iteration, in which either changes |
| 00:00:47,480 --> 00:00:50,340 | are made to the current features or new features are added. |
| 00:00:50,340 --> 00:00:53,060 | So, either the current prototype is improved or the |
| 00:00:53,060 --> 00:00:56,270 | prototype is extended. And finally, when the customer agrees that |
| 00:00:56,270 --> 00:00:58,980 | the prototype is good enough, the developers will complete all |
| 00:00:58,980 --> 00:01:01,410 | the remaining work on the system and release the prototype |
| 00:01:01,410 --> 00:01:03,930 | as the final product. So let's discuss as we did |
| 00:01:03,930 --> 00:01:06,780 | for the previous process models, what are the main advantages |
| 00:01:06,780 --> 00:01:10,580 | and disadvantages of evolutionary prototyping. In this case, the main |
| 00:01:10,580 --> 00:01:15,440 | advantage is the immediate feedback. Developers get feedback immediately as |
| 00:01:15,440 --> 00:01:17,560 | soon as they produce a prototype and they show it to |
| 00:01:17,560 --> 00:01:21,050 | the customer and therefore, the risk of implementing the wrong system is |
| 00:01:21,050 --> 00:01:25,150 | minimized. The main negative is the fact that it's difficult to plan. |
| 00:01:25,150 --> 00:01:29,070 | When using evolutionary prototype it is difficult to plan in advance how |
| 00:01:29,070 --> 00:01:31,240 | long the development is going to take, because we don't know how |
| 00:01:31,240 --> 00:01:34,550 | many iterations will be needed. And another drawback is that it can |
| 00:01:34,550 --> 00:01:37,120 | easily become an excuse to do kind of do cut and fix |
| 00:01:37,120 --> 00:01:40,530 | kind of approaches in which we hack something together, fix the main |
| 00:01:40,530 --> 00:01:43,640 | issues when the customer gives us feedback, and then continue this |
| 00:01:43,640 --> 00:01:46,780 | way, until the final product is something that is kind of |
| 00:01:46,780 --> 00:01:49,830 | working, but it's not really a product of high quality. Something |
| 00:01:49,830 --> 00:01:51,910 | else I want to point out before we move to the next |
| 00:01:51,910 --> 00:01:54,490 | software process model is that there are many different kinds of |
| 00:01:54,490 --> 00:01:56,700 | prototyping, so evolutionary prototyping is just |
| 00:01:56,700 --> 00:01:58,010 | one of them. For example, throwaway |
| 00:01:58,010 --> 00:02:02,100 | prototyping is another kind of prototyping in which the prototype is |
| 00:02:02,100 --> 00:02:05,580 | just used to gather requirements, but is thrown away at the end |
| 00:02:05,580 --> 00:02:05,580 | of the requirements gathering, instead of being evolved as it happens here. |