# CS6300 47 - Plug-Ins

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:03,134 | In fact most IDEs are extensible through the use of |
| 00:00:03,134 --> 00:00:06,158 | plug-ins. And by the way, note that plug-ins might be |
| 00:00:06,158 --> 00:00:09,326 | called differently on different platforms. For example, if you're using |
| 00:00:09,326 --> 00:00:12,970 | a Microsoft Visual Studio, plug-ins are normally called add-ins, but |
| 00:00:12,970 --> 00:00:15,598 | the concept is more or less the same. So, what |
| 00:00:15,598 --> 00:00:18,555 | is a plug-in? Well, let's imagine our IDE to be |
| 00:00:18,555 --> 00:00:22,320 | this box. A plug-in is additional functionality that you can |
| 00:00:22,320 --> 00:00:25,430 | actually plug into this box so that this box starts |
| 00:00:25,430 --> 00:00:28,830 | offering more features to the user. For example, you |
| 00:00:28,830 --> 00:00:32,850 | can add to Eclipse the Checkstyle plug-in. Which, paraphrasing the |
| 00:00:32,850 --> 00:00:35,950 | Checkstyle website, helps you ensure that your Java code |
| 00:00:35,950 --> 00:00:38,890 | complies with a set of coding standards by inspecting the |
| 00:00:38,890 --> 00:00:41,690 | code and pointing out items that deviate from a |
| 00:00:41,690 --> 00:00:44,870 | defined set of coding rules. Again, this is a functionality |
| 00:00:44,870 --> 00:00:47,330 | the core of Eclipse doesn't have. You can add |
| 00:00:47,330 --> 00:00:50,600 | the Checkstyle plug-in, and this functionality will become available in |
| 00:00:50,600 --> 00:00:54,840 | the IDE. Another example of plug-in is the EGit plug-in which |
| 00:00:54,840 --> 00:00:58,660 | adds support for the Git version control system in Eclipse. And |
| 00:00:58,660 --> 00:01:01,290 | actually this is something that we'll cover in detail, we'll have |
| 00:01:01,290 --> 00:01:04,150 | a demo, and we will actually use it throughout the class, so |
| 00:01:04,150 --> 00:01:07,018 | I'm not going to say anything more about the EGit plug-in for |
| 00:01:07,018 --> 00:01:09,300 | now. But again, what the plug-in will do is to add |
| 00:01:09,300 --> 00:01:13,220 | the Git functionality to Eclipse. A functionality that is not in |
| 00:01:13,220 --> 00:01:16,110 | the core of Eclipse and that is available to the user after |
| 00:01:16,110 --> 00:01:16,110 | you add the plug-in. |