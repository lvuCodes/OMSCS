# CS6300 315 - XPs Values -  Principles -  and Practices

| Timestamp | Content |
|-----------|---------|
| 00:00:00,218 --> 00:00:03,030 | Next I'm going to go over some of the XP's values |
| 00:00:03,030 --> 00:00:05,870 | and principles that I just hinted on earlier in the lesson. |
| 00:00:05,870 --> 00:00:08,820 | The first one, the first important value is communication. There |
| 00:00:08,820 --> 00:00:12,350 | is no good project without good communication. And XP tries to |
| 00:00:12,350 --> 00:00:15,470 | keep the right communication flowing and it uses several practices |
| 00:00:15,470 --> 00:00:18,890 | to do that. It's got practices based on and require information |
| 00:00:18,890 --> 00:00:21,950 | and in general share the information. For example, pair programming. |
| 00:00:21,950 --> 00:00:25,140 | And we're going to say more about that. User stories, customer involvement, |
| 00:00:25,140 --> 00:00:28,240 | all activities that help communication, |
| 00:00:28,240 --> 00:00:30,440 | that faster communication. Another important |
| 00:00:30,440 --> 00:00:33,420 | principle that we already saw, is simplicity. And the motto here |
| 00:00:33,420 --> 00:00:35,680 | is live for today without worrying too much about the |
| 00:00:35,680 --> 00:00:38,230 | future. When you have to do something, look for the simplest |
| 00:00:38,230 --> 00:00:40,580 | thing that works. And the emphasis here is on, that |
| 00:00:40,580 --> 00:00:43,520 | works. We want to build something simple, but not something stupid. |
| 00:00:43,520 --> 00:00:47,090 | Feedback. That's extremely important in XP, and it occurs at |
| 00:00:47,090 --> 00:00:50,560 | different levels, and it is used to drive changes. For example, |
| 00:00:50,560 --> 00:00:53,910 | developers write test cases. And that's immediate feedback. If your test cases |
| 00:00:53,910 --> 00:00:56,140 | fail, there's something wrong with the code. Or there's something that you |
| 00:00:56,140 --> 00:00:59,690 | still haven't developed. Developers also estimate new stories right away as soon |
| 00:00:59,690 --> 00:01:02,060 | as they get them from the customers and that's immediate feedback to |
| 00:01:02,060 --> 00:01:05,515 | the customer. And finally, on a slightly longer time frame, customers and |
| 00:01:05,515 --> 00:01:07,820 | tester develop together functional system test |
| 00:01:07,820 --> 00:01:09,600 | cases to assess the overall system. |
| 00:01:09,600 --> 00:01:12,100 | And also in this case, that's a great way to provide feedback |
| 00:01:12,100 --> 00:01:15,850 | and by the way, also to help communication. And finally, courage, the courage |
| 00:01:15,850 --> 00:01:18,860 | to throw away code if it doesn't work. To change it if you |
| 00:01:18,860 --> 00:01:21,710 | find a way to improve it. To fix it if you find a problem. |
| 00:01:21,710 --> 00:01:24,300 | To try out new things if you think that they might work better |
| 00:01:24,300 --> 00:01:27,410 | than what you have right now. Now, that we can build and test systems |
| 00:01:27,410 --> 00:01:30,150 | very quickly, we can be much braver than what we were before. So |
| 00:01:30,150 --> 00:01:33,790 | how do we accomplish all that? And what are XP's practices that are going to |
| 00:01:33,790 --> 00:01:37,750 | help us follow these principles and adhere to those values? These are some |
| 00:01:37,750 --> 00:01:40,900 | of XP practices. There are more, but those are the ones that I'd like |
| 00:01:40,900 --> 00:01:44,240 | to discuss in a little more depth, individually. Incremental planning, |
| 00:01:44,240 --> 00:01:48,230 | small releases, simple design, test first, refactoring. We will actually |
| 00:01:48,230 --> 00:01:51,680 | have a whole lesson next on refactoring. Pair programming, continuous |
| 00:01:51,680 --> 00:01:51,680 | integration, and on-site customer. So let's start with incremental planning. |