# CS6300 133 - Class Diagram_ Creation Tips

| Timestamp                     | Content                                                                         |
| ----------------------------- | ------------------------------------------------------------------------------- |
| 00:00:00,140 --> 00:00:02,320 | The last thing that I want to mention about class diagrams is                   |
| 00:00:02,320 --> 00:00:05,830 | some creation tips. So something I know based on my experience and the          |
| 00:00:05,830 --> 00:00:09,300 | experience of others, I can recommend to do when creating a class               |
| 00:00:09,300 --> 00:00:12,780 | diagram. So the first tip is to **understand the problem**. So take the         |
| 00:00:12,780 --> 00:00:15,070 | time to look at the description of the system that you have                     |
| 00:00:15,070 --> 00:00:18,500 | to build, to make sure that you understand the domain. That you understand      |
| 00:00:18,500 --> 00:00:21,230 | what you are supposed to build. Because that is going to save you               |
| 00:00:21,230 --> 00:00:25,550 | time later. It's going to help you identify from the beginning, a more relevant |
| 00:00:25,550 --> 00:00:28,370 | set of entities in the description of the system. This                          |
| 00:00:28,370 --> 00:00:30,730 | one might seem trivial but is very important to **choose**                      |
| 00:00:30,730 --> 00:00:34,910 | **good class names.** Why? Because class names communicate the intent           |
| 00:00:34,910 --> 00:00:37,770 | of the class, and clarify what the class refers to. So                          |
| 00:00:37,770 --> 00:00:40,510 | having a good class name allows you, makes it easier, to                        |
| 00:00:40,510 --> 00:00:44,390 | create the mapping between the real-world object and the entities in            |
| 00:00:44,390 --> 00:00:46,610 | your model. And of course, it also makes it easier                              |
| 00:00:46,610 --> 00:00:50,100 | to understand the system, after the system is built. Third tip,                 |
| 00:00:50,100 --> 00:00:53,480 | **concentrate on the what**. So here, in the class diagram,                     |
| 00:00:53,480 --> 00:00:57,390 | we're just representing the structure of the system. We're representing         |
| 00:00:57,390 --> 00:01:00,150 | **what is in the system**. What are the entities? What                          |
| 00:01:00,150 --> 00:01:03,140 | are the characteristics of the entities? We are not focusing                    |
| 00:01:03,140 --> 00:01:06,850 | at all, on how things are done. So, be careful.                                 |
| 00:01:06,850 --> 00:01:09,430 | Don't think about the how, just think about the what.                           |
| 00:01:09,430 --> 00:01:12,150 | Proceed in an iterative way. So, **start with a simple**                        |
| 00:01:12,150 --> 00:01:14,910 | **diagram and refine it**. There is no need to identify,                        |
| 00:01:14,910 --> 00:01:17,650 | right away, all of the details of the system you need to                        |
| 00:01:17,650 --> 00:01:21,570 | build. It is much easier to look at the description, identify an initial        |
| 00:01:21,570 --> 00:01:24,670 | rough class diagram and then refine it, because in this way, you'll             |
| 00:01:24,670 --> 00:01:27,650 | also gather more understanding of the system as you build it, and you'll        |
| 00:01:27,650 --> 00:01:30,670 | most likely end up with a better product at the end. And                        |
| 00:01:30,670 --> 00:01:33,360 | if you proceed in this way, then make sure to **refine until you**              |
| 00:01:33,360 --> 00:01:36,920 | **feel the class diagram is complete**, until you feel that you represent       |
| 00:01:36,920 --> 00:01:39,960 | the system that you're supposed to build. So your final goal should be          |
| 00:01:39,960 --> 00:01:41,820 | to have a class diagram that is complete.                                       |
| 00:01:41,820 --> 00:01:43,870 | So it represents all of the relevant entities                                   |
| 00:01:43,870 --> 00:01:45,870 | in the system and their characteristics, and it's                               |
| 00:01:45,870 --> 00:01:45,870 | correct so it represents them in the right way                                  |
