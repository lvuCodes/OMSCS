# CS6300 146 - Recap Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,095 --> 00:00:03,320 | A UML state transition diagram does not specify a set |
| 00:00:03,320 --> 00:00:05,960 | of object that work together to perform some action, because |
| 00:00:05,960 --> 00:00:09,270 | this is what a sequence diagram does instead. Conversely, the |
| 00:00:09,270 --> 00:00:12,530 | second one is correct. As we said, a state transition diagram |
| 00:00:12,530 --> 00:00:15,790 | describes the events that cause a transition from one state |
| 00:00:15,790 --> 00:00:19,300 | to another. Again, a UML state transition diagram does not |
| 00:00:19,300 --> 00:00:22,270 | specify the set of components in a system, because this |
| 00:00:22,270 --> 00:00:25,700 | is what a component diagram does, not a state transition diagram. |
| 00:00:25,700 --> 00:00:27,620 | As for the last one, this is correct, |
| 00:00:27,620 --> 00:00:30,510 | because, as we also discussed, a state transition diagram |
| 00:00:30,510 --> 00:00:33,000 | describes the actions that result from a state |
| 00:00:33,000 --> 00:00:33,000 | change, that is, the effects of such state change. |