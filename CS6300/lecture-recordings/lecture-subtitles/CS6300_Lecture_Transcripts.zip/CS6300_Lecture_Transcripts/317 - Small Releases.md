# CS6300 317 - Small Releases

| Timestamp | Content |
|-----------|---------|
| 00:00:00,210 --> 00:00:02,790 | The first practice that we just saw goes together with |
| 00:00:02,790 --> 00:00:06,320 | small releases practice. This idea that instead of having a big |
| 00:00:06,320 --> 00:00:09,390 | release at the end of a long development cycle, we try |
| 00:00:09,390 --> 00:00:12,610 | to release very often. And there are many advantages to small |
| 00:00:12,610 --> 00:00:15,260 | releases and to releasing often. The first one is that |
| 00:00:15,260 --> 00:00:18,980 | we deliver real business value on a very short cycle. And |
| 00:00:18,980 --> 00:00:22,070 | what that means is that we get business value sooner, and |
| 00:00:22,070 --> 00:00:25,550 | that in turn increase our customer confidence and makes the customer |
| 00:00:25,550 --> 00:00:29,040 | more happy. So more releases also mean rapid feedback. We |
| 00:00:29,040 --> 00:00:32,420 | release the software soon, we get feedback from the customer soon, |
| 00:00:32,420 --> 00:00:34,710 | and we can in this way do exactly what we |
| 00:00:34,710 --> 00:00:38,510 | were saying before, steer instead of driving, adapt weekly to possible |
| 00:00:38,510 --> 00:00:41,680 | changes in the requirements. We avoid working for six months |
| 00:00:41,680 --> 00:00:43,970 | on a project and find out six months later that the |
| 00:00:43,970 --> 00:00:46,950 | customer wanted something else and we got the wrong requirements. In |
| 00:00:46,950 --> 00:00:50,610 | addition having small releases, so seeing your product deployed and released |
| 00:00:50,610 --> 00:00:54,040 | soon produces a sense of accomplishment for the developers. |
| 00:00:54,040 --> 00:00:57,000 | And in addition, it also reduces risk because again, |
| 00:00:57,000 --> 00:00:58,640 | if we're going down the wrong path, we will |
| 00:00:58,640 --> 00:01:00,730 | know right away. If we're late, we will know right |
| 00:01:00,730 --> 00:01:03,370 | away. So these are just additional advantages of having |
| 00:01:03,370 --> 00:01:06,140 | this quick cycle and more releases. And finally, as we |
| 00:01:06,140 --> 00:01:09,130 | also said before, we can quickly adapt in the |
| 00:01:09,130 --> 00:01:09,130 | case our requirements change our code to the new requirements. |