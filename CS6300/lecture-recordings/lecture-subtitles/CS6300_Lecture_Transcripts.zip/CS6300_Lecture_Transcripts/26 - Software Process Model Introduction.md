# CS6300 26 - Software Process Model Introduction

| Timestamp | Content |
|-----------|---------|
| 00:00:00,240 --> 00:00:02,600 | At this point, you know the possible activities, the |
| 00:00:02,600 --> 00:00:06,520 | possible phases performed during the software development process. But there |
| 00:00:06,520 --> 00:00:08,710 | this something that we still haven't discussed, which is |
| 00:00:08,710 --> 00:00:11,910 | very important. And that is how should we put these |
| 00:00:11,910 --> 00:00:14,990 | activities together to develop software? And this all comes |
| 00:00:14,990 --> 00:00:18,360 | down to the concept of software process model. Also called |
| 00:00:18,360 --> 00:00:21,520 | software lifecycle model. And what this is, is a |
| 00:00:21,520 --> 00:00:25,470 | prescriptive model of what should happen from the very beginning |
| 00:00:25,470 --> 00:00:28,960 | to the very end. Of a software development process. The |
| 00:00:28,960 --> 00:00:31,360 | main function of the life cycle model is to determine |
| 00:00:31,360 --> 00:00:34,290 | the order of the different activities so that we know |
| 00:00:34,290 --> 00:00:37,920 | which activities should come first and which ones should follow. Another |
| 00:00:37,920 --> 00:00:40,910 | important function of the life cycle model is to determine |
| 00:00:40,910 --> 00:00:45,290 | the transition criteria between activities. So, when we can go from |
| 00:00:45,290 --> 00:00:48,000 | one phase to the subsequent one. In other words, what |
| 00:00:48,000 --> 00:00:50,840 | the model should describe is what should we do next and |
| 00:00:50,840 --> 00:00:53,450 | how long should we continue to do it for each activity |
| 00:00:53,450 --> 00:00:56,290 | in the model. Now let's see a few traditional software process |
| 00:00:56,290 --> 00:00:58,920 | models. I will discuss them here at the high level and |
| 00:00:58,920 --> 00:00:58,920 | then revisit some of these models in the different mini courses. |