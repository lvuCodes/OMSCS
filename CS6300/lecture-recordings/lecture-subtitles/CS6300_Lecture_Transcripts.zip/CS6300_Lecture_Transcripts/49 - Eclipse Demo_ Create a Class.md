# CS6300 49 - Eclipse Demo_ Create a Class

| Timestamp | Content |
|-----------|---------|
| 00:00:00,130 --> 00:00:02,420 | So now that we know, we saw what happens under |
| 00:00:02,420 --> 00:00:04,570 | the hood, and as I said, don't worry about it if |
| 00:00:04,570 --> 00:00:06,689 | you don't care about that part. Now we can go back |
| 00:00:06,689 --> 00:00:09,850 | to Eclipse, and we can start creating a package. A package |
| 00:00:09,850 --> 00:00:13,125 | is basically a way of organizing your classes into a |
| 00:00:13,125 --> 00:00:17,015 | hierarchy. In this case, I'm going to specify the package name as |
| 00:00:17,015 --> 00:00:21,350 | edu.gatech, which means that I'm creating really two packages, a package |
| 00:00:21,350 --> 00:00:25,480 | gatech inside package edu. And I can start creating classes inside |
| 00:00:25,480 --> 00:00:28,770 | my packages. So here, I can use the contextual menu, select |
| 00:00:28,770 --> 00:00:32,055 | New>Class, and I'll get another wizard that will allow me to |
| 00:00:32,055 --> 00:00:35,160 | specify the name of the class. I'm not very creative here, |
| 00:00:35,160 --> 00:00:38,250 | so I'm just going to call it Hello World. There's many other parameters |
| 00:00:38,250 --> 00:00:41,710 | you can set, and in particular, you can define whether you |
| 00:00:41,710 --> 00:00:45,450 | want a main method in your class. Where having a main |
| 00:00:45,450 --> 00:00:48,460 | method means that your class can be the main class in |
| 00:00:48,460 --> 00:00:50,850 | your project, can be the one that is run when you run |
| 00:00:50,850 --> 00:00:54,340 | your project. After we click the button, the Finish button, we, |
| 00:00:54,340 --> 00:00:56,859 | we get the class. So we also get template code for the |
| 00:00:56,859 --> 00:00:59,604 | class, as you can see here, so we go to the editor |
| 00:00:59,604 --> 00:01:02,120 | function, you can see that there is a to do. Where you |
| 00:01:02,120 --> 00:01:05,019 | have to put your code, and here we are simply, basically printing, |
| 00:01:05,019 --> 00:01:08,370 | you know, the typical first program. We just going to print Hello World |
| 00:01:08,370 --> 00:01:11,180 | in Java. And something you can note is that as we are |
| 00:01:11,180 --> 00:01:16,370 | typing, Eclipse gives us a auto complete suggestions, which is very helpful. |
| 00:01:16,370 --> 00:01:19,650 | For example, in case you don't remember the exact syntax, |
| 00:01:19,650 --> 00:01:22,190 | or the method, or you don't remember the parameters of the |
| 00:01:22,190 --> 00:01:24,470 | method. Which is, you know, often the case especially where you |
| 00:01:24,470 --> 00:01:27,590 | work with large libraries. So having that feature can really, really |
| 00:01:27,590 --> 00:01:30,050 | help you. So now if we want to run our code |
| 00:01:30,050 --> 00:01:33,380 | we can either click on the button up here, or we |
| 00:01:33,380 --> 00:01:37,960 | can right-click in the Call window and select Run As Java |
| 00:01:37,960 --> 00:01:41,370 | Application. And if we do that, Eclipse will run our tool, |
| 00:01:41,370 --> 00:01:45,650 | and it will create, as you can see here, a console view that basically contains |
| 00:01:45,650 --> 00:01:45,650 | the textual output of my program. And as expected, the output is Hello World. |