# CS6300 129 - Class Diagram Relationships Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,130 --> 00:00:02,130 | So, I'm going to start by marking the |
| 00:00:02,130 --> 00:00:04,920 | relationships that actually hold in the system. |
| 00:00:04,920 --> 00:00:08,860 | Which are these ones. And then what I'm going to do, I'm going to explain this |
| 00:00:08,860 --> 00:00:12,480 | answers. Not here but in the next part of this lesson. By looking at the |
| 00:00:12,480 --> 00:00:14,860 | different relationships in the context of our |
| 00:00:14,860 --> 00:00:14,860 | example. Which will make the explanation much clearer. |
![[lvu 2026-02-15 at 03.18PM.png]]