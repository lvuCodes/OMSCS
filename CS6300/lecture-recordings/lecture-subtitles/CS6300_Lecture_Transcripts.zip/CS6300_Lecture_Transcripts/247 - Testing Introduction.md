# CS6300 247 - Testing Introduction

| Timestamp | Content |
|-----------|---------|
| 00:00:00,340 --> 00:00:02,290 | So let's talk more about testing, as we said a |
| 00:00:02,290 --> 00:00:06,500 | little earlier in the lesson, testing means executing the program on |
| 00:00:06,500 --> 00:00:09,400 | a sample of the input domain, that is of all |
| 00:00:09,400 --> 00:00:12,210 | the possible input data and I really want to stress that |
| 00:00:12,210 --> 00:00:16,190 | this sample is tiny sample of the input domain. There |
| 00:00:16,190 --> 00:00:19,154 | are two important aspects of testing that I'm want to mention here, |
| 00:00:19,154 --> 00:00:22,360 | there first one is that testing is a dynamic technique. And |
| 00:00:22,360 --> 00:00:25,370 | what that means is that the program must be executed in |
| 00:00:25,370 --> 00:00:28,130 | order to perform testing. The second important point is that |
| 00:00:28,130 --> 00:00:32,040 | testing is an optimistic approximation. And what does it mean |
| 00:00:32,040 --> 00:00:35,590 | to be optimistic? Well, it means that the program under |
| 00:00:35,590 --> 00:00:38,820 | test is exercised with a very small subset of all the |
| 00:00:38,820 --> 00:00:41,260 | possible inputs as we just said. And this is done |
| 00:00:41,260 --> 00:00:45,150 | under the assumption that the behavior with any other input |
| 00:00:45,150 --> 00:00:47,770 | is consistent with the behavior shown for the selected subset |
| 00:00:47,770 --> 00:00:51,140 | of input data, that is why it is an optimistic approach. |
| 00:00:51,140 --> 00:00:54,620 | Another concept that I want to mention explicitly, is the |
| 00:00:54,620 --> 00:00:57,930 | concept of successful test. And I'm going to do that, |
| 00:00:57,930 --> 00:01:01,260 | using another quote. This one from Goodenough and Gerhart |
| 00:01:01,260 --> 00:01:03,850 | in their paper Towards a Theory of Test Data Selection, |
| 00:01:03,850 --> 00:01:06,420 | and what the quote says is that a test |
| 00:01:06,420 --> 00:01:10,000 | is successful if the program fails. And this might sound |
| 00:01:10,000 --> 00:01:13,650 | counterintuitive, but the point here is that testing cannot |
| 00:01:13,650 --> 00:01:16,490 | prove the absence of errors, but only reveal their presence. |
| 00:01:16,490 --> 00:01:21,550 | If a set of tests does not produce any failure, we are either in the extremely |
| 00:01:21,550 --> 00:01:24,050 | unlikely case of a correct program, or in |
| 00:01:24,050 --> 00:01:26,650 | the very likely situation of a bad set of |
| 00:01:26,650 --> 00:01:30,932 | tests that are not able to reveal failures of the program. And that is why we |
| 00:01:30,932 --> 00:01:32,730 | say that the test is successful if you |
| 00:01:32,730 --> 00:01:32,730 | can show that there are problems in the program. |