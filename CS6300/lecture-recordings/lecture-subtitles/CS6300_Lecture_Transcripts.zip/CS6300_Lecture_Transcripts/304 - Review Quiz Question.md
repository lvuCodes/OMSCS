# CS6300 304 - Review Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:04,260 | White box testing, in general, and coverage criteria in particular, involve some |
| 00:00:04,260 --> 00:00:07,550 | subtle concepts, so before I conclude this lesson, I want to have a |
| 00:00:07,550 --> 00:00:10,960 | few more quizzes to make sure that we all understand these concepts. |
| 00:00:10,960 --> 00:00:13,610 | The first one involves a very simple piece of code, a straight line |
| 00:00:13,610 --> 00:00:16,540 | of code, three statements, in which we simply read an integer and |
| 00:00:16,540 --> 00:00:20,180 | then prints 10 divided by the value of that integer minus 3. Now, |
| 00:00:20,180 --> 00:00:22,250 | let's imagine that we have a test where there consists of three |
| 00:00:22,250 --> 00:00:25,250 | test cases for this code, and what I'm showing in the test cases |
| 00:00:25,250 --> 00:00:28,580 | is the input and the expected output. So for the first one, |
| 00:00:28,580 --> 00:00:31,280 | the input is 1, and I expect the output to be minus 5. |
| 00:00:31,280 --> 00:00:34,480 | For the second one, the input is minus 1, I'm expecting to |
| 00:00:34,480 --> 00:00:37,120 | have 2.5. And for the third one, the input is 0, and I'm |
| 00:00:37,120 --> 00:00:42,440 | expecting to have minus 3.3333 as the result. Now the first question |
| 00:00:42,440 --> 00:00:45,180 | I want to ask, is if we considered this test suite, and we |
| 00:00:45,180 --> 00:00:48,050 | run it on the code, does it achieve path coverage? And remember |
| 00:00:48,050 --> 00:00:48,050 | that path coverage is one of the strongest coverage criteria that we saw. |