# CS6300 80 - Interview with Jane Cleland-Huang

| Timestamp | Content |
|-----------|---------|
| 00:00:00,270 --> 00:00:02,800 | As we did for other lessons, before starting this |
| 00:00:02,800 --> 00:00:06,150 | lesson on requirements engineering, I want to ask a world |
| 00:00:06,150 --> 00:00:10,210 | expert on this topic a few questions. I'm here with |
| 00:00:10,210 --> 00:00:14,150 | Jane Cleland-Huang, a professor at the DePaul University. And Jane |
| 00:00:14,150 --> 00:00:16,500 | is a world expert in the area of requirements |
| 00:00:16,500 --> 00:00:19,830 | engineering, which is the theme of this lesson. So I'm |
| 00:00:19,830 --> 00:00:22,220 | talking to Jane who is currently in Chicago and I |
| 00:00:22,220 --> 00:00:25,380 | want to. Ask her a few questions about requirements engineering. |
| 00:00:25,380 --> 00:00:26,530 | So hi Jane how are you? |
| 00:00:26,530 --> 00:00:27,990 | >> Fine. Thank you Alex. |
| 00:00:27,990 --> 00:00:29,480 | >> And thank you so much for agreeing to |
| 00:00:29,480 --> 00:00:31,960 | be interviewed for our course, I'm sure the students |
| 00:00:31,960 --> 00:00:34,080 | will really benefit from this. And let me start |
| 00:00:34,080 --> 00:00:37,240 | with the first question which is what are software requirements? |
| 00:00:37,240 --> 00:00:40,900 | >> That's an interesting question. And software requirements |
| 00:00:40,900 --> 00:00:44,220 | basically provide us a description of what a |
| 00:00:44,220 --> 00:00:47,520 | system has to do. So, typically they describe |
| 00:00:47,520 --> 00:00:50,550 | the functionality of the features. That the system has |
| 00:00:50,550 --> 00:00:54,420 | to deliver in order to satisfy its stakeholders. |
| 00:00:54,420 --> 00:00:59,010 | And we usually talk about the requirement specification |
| 00:00:59,010 --> 00:01:01,050 | in terms of what the system's going to |
| 00:01:01,050 --> 00:01:04,010 | do. And we describe it sometimes formally in |
| 00:01:04,010 --> 00:01:07,300 | terms of set of shall statements, that the |
| 00:01:07,300 --> 00:01:09,110 | system shall do this or shall do that. |
| 00:01:09,110 --> 00:01:12,330 | Or we can use various templates to specify |
| 00:01:12,330 --> 00:01:16,120 | both textural requirements. But requirements can also be represented |
| 00:01:16,120 --> 00:01:20,790 | informally in, in the form of user stories, or use cases, or more |
| 00:01:20,790 --> 00:01:26,180 | formally in the form of state transition diagrams and even in kind of |
| 00:01:26,180 --> 00:01:32,260 | formal specifications. Especially for critical parts of safety critical systems. |
| 00:01:32,260 --> 00:01:34,180 | >> And another should discuss what the |
| 00:01:34,180 --> 00:01:37,230 | requirements are. What is the requirements engineering? |
| 00:01:37,230 --> 00:01:41,180 | >> So, that's also an interesting question because if you notice |
| 00:01:41,180 --> 00:01:45,330 | it's it's engineering and I'm sure in the |
| 00:01:45,330 --> 00:01:47,750 | other parts of the software engineering process that |
| 00:01:47,750 --> 00:01:51,130 | you're discussing in your course. Parts such as |
| 00:01:51,130 --> 00:01:55,200 | testing or coding. They don't have the word engineering |
| 00:01:55,200 --> 00:01:56,930 | there and I think one of the reasons |
| 00:01:56,930 --> 00:02:00,310 | requirements engineering has that term is because it covers |
| 00:02:00,310 --> 00:02:03,570 | a number of different activities. So it includes |
| 00:02:03,570 --> 00:02:07,390 | things such as working with stakeholders to elicit or |
| 00:02:07,390 --> 00:02:10,620 | to proactively discover what their requirements of the |
| 00:02:10,620 --> 00:02:14,440 | system are. Analyzing those requirements so that we |
| 00:02:14,440 --> 00:02:17,380 | understand the tradeoffs. So you might have different |
| 00:02:17,380 --> 00:02:21,170 | stakeholders that care about different things, and it |
| 00:02:21,170 --> 00:02:26,086 | might not be possible to deliver all of those things, so we have to analyze the |
| 00:02:26,086 --> 00:02:29,140 | feasibility of the requirements, explore the tradeoffs, emerge |
| 00:02:29,140 --> 00:02:32,550 | conflicts. And then of course the specification part, |
| 00:02:32,550 --> 00:02:34,930 | which we talked about a little bit already, |
| 00:02:34,930 --> 00:02:37,340 | and the validation, so did we in fact get |
| 00:02:37,340 --> 00:02:40,480 | the requirements right? Did we build a system |
| 00:02:40,480 --> 00:02:43,490 | that actually matches our, our requirements. And then on |
| 00:02:43,490 --> 00:02:46,960 | into the requirements management process. And the requirements |
| 00:02:46,960 --> 00:02:50,860 | management process. Kind of like goes through things like |
| 00:02:50,860 --> 00:02:55,010 | change management. So what if customer or stakeholders |
| 00:02:55,010 --> 00:02:57,630 | need the system to change? How do we manage |
| 00:02:57,630 --> 00:03:00,180 | changing requirements? And I think this is one of |
| 00:03:00,180 --> 00:03:03,230 | the reasons that we've coined the term engineering because |
| 00:03:03,230 --> 00:03:06,490 | that it's, has to be a systematic process which |
| 00:03:06,490 --> 00:03:09,550 | extends across. The whole of this is life cycle. |
| 00:03:09,550 --> 00:03:12,890 | >> And I guess my last question here is |
| 00:03:12,890 --> 00:03:15,100 | so now that we heard about software requirements and |
| 00:03:15,100 --> 00:03:18,790 | about software requirements engineering, why is requirements engineering so |
| 00:03:18,790 --> 00:03:20,770 | important? So what happens if we don't do it right? |
| 00:03:20,770 --> 00:03:22,620 | >> Well, I'm sure that, you know, |
| 00:03:22,620 --> 00:03:24,880 | many people have probably read the kind of |
| 00:03:24,880 --> 00:03:28,560 | report like Spanish report, and other reports of failed |
| 00:03:28,560 --> 00:03:31,900 | project, and things like that, and are aware that |
| 00:03:31,900 --> 00:03:35,280 | one of the major reasons for projects failing |
| 00:03:35,280 --> 00:03:37,360 | is because we didn't get the requirements right |
| 00:03:37,360 --> 00:03:40,110 | in the first place. So if we don't understand |
| 00:03:40,110 --> 00:03:42,970 | the requirements then we're simply going to build the |
| 00:03:42,970 --> 00:03:47,960 | wrong system. Getting requirements right includes all sorts of |
| 00:03:47,960 --> 00:03:52,900 | things such as finding the right group of stakeholders so we don't exclude major |
| 00:03:52,900 --> 00:03:56,940 | groups of stakeholders. Understanding the requirements correctly. |
| 00:03:56,940 --> 00:03:59,910 | There will be many, many different examples of |
| 00:03:59,910 --> 00:04:02,310 | projects that have failed. For example, in |
| 00:04:02,310 --> 00:04:06,500 | America the healthcare.gov failure, and while we cannot |
| 00:04:06,500 --> 00:04:09,540 | put the blame squarely in the area |
| 00:04:09,540 --> 00:04:13,040 | of requirements, because obviously the project was challenged |
| 00:04:13,040 --> 00:04:15,650 | for a number of different reasons. But |
| 00:04:15,650 --> 00:04:21,070 | clearly it underperformed in many respects related to |
| 00:04:21,070 --> 00:04:25,740 | security, performance, and reliability and these are all |
| 00:04:25,740 --> 00:04:28,300 | parts of the requirements process. Things that should |
| 00:04:28,300 --> 00:04:30,000 | have been discovered and the system should have |
| 00:04:30,000 --> 00:04:32,914 | been built in order to meet those requirements, |
| 00:04:32,914 --> 00:04:36,240 | getting the requirements right in the first place. |
| 00:04:36,240 --> 00:04:38,110 | Puts us, a project on the right foot. |
| 00:04:38,110 --> 00:04:41,430 | And so that gives us a much better chance |
| 00:04:41,430 --> 00:04:44,940 | of delivering to the customer what they need. And |
| 00:04:44,940 --> 00:04:49,130 | designing a solution that really meets those requirements. So, |
| 00:04:49,130 --> 00:04:52,800 | it's a critical part of the overall software engineering success. |
| 00:04:52,800 --> 00:04:56,441 | >> Okay. So that's critical. I mean, we better get our requirements right. |
| 00:04:56,441 --> 00:04:56,987 | >> Yeah. |
| 00:04:56,987 --> 00:04:57,733 | >> That's, that's the message. |
| 00:04:57,733 --> 00:04:57,743 | >> Yeah. |
| 00:04:57,743 --> 00:05:00,822 | >> Okay. Well, thank you so much Jane, for taking |
| 00:05:00,822 --> 00:05:03,435 | the time off your busy schedule to speak with us. |
| 00:05:03,435 --> 00:05:07,150 | I'm sure. The students really appreciate this, and we'll talk to you soon. |
| 00:05:07,150 --> 00:05:08,480 | >> Bye Alex, thank you. |
| 00:05:08,480 --> 00:05:10,890 | >> Bye, Jane, bye bye. Jane gave |
| 00:05:10,890 --> 00:05:13,410 | us an interesting perspective on requirements engineering |
| 00:05:13,410 --> 00:05:15,410 | and its importance. Let's now start our |
| 00:05:15,410 --> 00:05:15,410 | lesson with a general definition of requirements engineering. |