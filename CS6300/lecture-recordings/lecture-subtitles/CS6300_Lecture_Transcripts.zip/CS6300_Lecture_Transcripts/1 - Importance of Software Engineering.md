# CS6300 1 - Importance of Software Engineering

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:02,106 | First, let me start by asking a couple of very |
| 00:00:02,106 --> 00:00:04,820 | natural questions that you might have when considering whether to take |
| 00:00:04,820 --> 00:00:07,800 | this course. The first one is what is software engineering. |
| 00:00:07,800 --> 00:00:10,050 | And the second, very related one, is why do we need |
| 00:00:10,050 --> 00:00:12,430 | it? So what I did was actually to go out |
| 00:00:12,430 --> 00:00:15,430 | and ask some of the main experts in the field, both |
| 00:00:15,430 --> 00:00:18,290 | in academia and industry, these very questions and let's see what |
| 00:00:18,290 --> 00:00:23,170 | they said. What is software engineering and why is it important? |
| 00:00:23,170 --> 00:00:25,150 | >> Okay, can I start with another question? |
| 00:00:25,150 --> 00:00:26,020 | >> Of course. |
| 00:00:26,020 --> 00:00:31,290 | >> Okay, first what is a computer? It's a programmable device. So the essence |
| 00:00:31,290 --> 00:00:34,730 | of computing is programming. So program development |
| 00:00:34,730 --> 00:00:37,240 | is basically the most essential use of the |
| 00:00:37,240 --> 00:00:41,010 | computer. So software engineering is the discipline |
| 00:00:41,010 --> 00:00:44,850 | that investigates program development. So, how can it |
| 00:00:44,850 --> 00:00:47,390 | been done more efficiently? What's the best |
| 00:00:47,390 --> 00:00:50,170 | way of doing program development? And how can |
| 00:00:50,170 --> 00:00:53,140 | you develop reliable programs? So that's how I would define |
| 00:00:53,140 --> 00:00:55,060 | it. But I consider any |
| 00:00:55,060 --> 00:00:58,825 | software development activity software engineering activity |
| 00:00:58,825 --> 00:01:04,239 | >> Software engineering is the systematic application of methods to build |
| 00:01:04,239 --> 00:01:07,884 | software in a rigorous way. And I think one of the |
| 00:01:07,884 --> 00:01:11,196 | aspects that I like to bring into the notion of software |
| 00:01:11,196 --> 00:01:15,228 | engineering is that it's something that involves not only kind of |
| 00:01:15,228 --> 00:01:18,612 | technically building the system but understanding the |
| 00:01:18,612 --> 00:01:22,317 | requirements, working with stake holders. Trying to |
| 00:01:22,317 --> 00:01:28,232 | find a solution that balances all of the stakeholder needs in order to deliver |
| 00:01:28,232 --> 00:01:34,338 | the software thats tested and its rigorous to meet the needs of a stakeholder. |
| 00:01:34,338 --> 00:01:37,656 | Well, software engineering is the whole process |
| 00:01:37,656 --> 00:01:41,460 | of creation of software using engineering principles. |
| 00:01:41,460 --> 00:01:42,886 | >> My view is kind of a holistic |
| 00:01:42,886 --> 00:01:45,490 | view and I think about it from the perspective |
| 00:01:45,490 --> 00:01:49,440 | of how is software engineering different from programming. |
| 00:01:49,440 --> 00:01:52,940 | So, I think that research about programming is all |
| 00:01:52,940 --> 00:01:57,550 | about the create part of software. And that |
| 00:01:57,550 --> 00:02:00,270 | software engineering is about the entire life cycle. So, |
| 00:02:00,270 --> 00:02:03,070 | that's one aspect. And the other aspect of the |
| 00:02:03,070 --> 00:02:07,350 | definition is it's about quality, the quality of software. |
| 00:02:07,350 --> 00:02:12,330 | Software engineering even considers things long after you ship which we all know |
| 00:02:12,330 --> 00:02:18,310 | is one of the, it is the largest economic piece of software development. |
| 00:02:18,310 --> 00:02:22,990 | >> So, improve, software engineering process |
| 00:02:22,990 --> 00:02:26,440 | for better software productivity and quality. |
| 00:02:26,440 --> 00:02:32,472 | >> The set of activities that one engages in when building software |
| 00:02:32,472 --> 00:02:39,634 | systems or software products. It's fundamentally a venue-creating |
| 00:02:39,634 --> 00:02:45,492 | activity. It involves social processes. |
| 00:02:45,492 --> 00:02:47,247 | >> Software engineering is the act |
| 00:02:47,247 --> 00:02:49,652 | of many people working together and putting |
| 00:02:49,652 --> 00:02:52,057 | together many versions of large and complex |
| 00:02:52,057 --> 00:02:57,110 | systems. And our world depends on software, |
| 00:02:57,110 --> 00:02:58,910 | software is immensely complex and we need |
| 00:02:58,910 --> 00:03:01,700 | many, many smart people to build these things. |
| 00:03:01,700 --> 00:03:05,610 | >> Well, engineering I think is the activity of envisioning and |
| 00:03:05,610 --> 00:03:10,180 | realizing valuable new functions with sufficient |
| 00:03:10,180 --> 00:03:13,500 | and justifiable confidence that the resulting |
| 00:03:13,500 --> 00:03:18,190 | system will have all of the critical quality attributes that are necessary |
| 00:03:18,190 --> 00:03:22,140 | for the system to be a success. And software engineering is the |
| 00:03:22,140 --> 00:03:24,790 | activity of doing this not only for |
| 00:03:24,790 --> 00:03:28,830 | the software components of engineering systems but |
| 00:03:28,830 --> 00:03:31,740 | for the system overall, given that it's |
| 00:03:31,740 --> 00:03:35,500 | so heavily reliant on it's underlying software technologies. |
| 00:03:35,500 --> 00:03:40,440 | >> So, I would say software engineering is the |
| 00:03:40,440 --> 00:03:44,070 | kind of art and practice of building software systems. |
| 00:03:44,070 --> 00:03:47,610 | >> Software engineering, in a nutshell, is a set of |
| 00:03:47,610 --> 00:03:53,220 | methods and principles and techniques that we have developed to enable us to |
| 00:03:53,220 --> 00:03:59,090 | engineer, or build, large software systems that |
| 00:03:59,090 --> 00:04:03,960 | outstrip or outpace one engineer's or even a small |
| 00:04:03,960 --> 00:04:08,900 | team of engineer's ability or abilities to understand |
| 00:04:08,900 --> 00:04:13,330 | and construct and maintain |
| 00:04:13,330 --> 00:04:17,339 | over time. So it requires a lot of people, it requires a long, |
| 00:04:17,339 --> 00:04:21,820 | term investment by an organization or a number of organizations, and often times |
| 00:04:21,820 --> 00:04:28,040 | it requires support for systems that that are intended for one purpose but end |
| 00:04:28,040 --> 00:04:33,930 | up getting used for many additional purposes in addition to the original one. |
| 00:04:33,930 --> 00:04:38,656 | >> Software engineering is about building and constructing very large-scale |
| 00:04:38,656 --> 00:04:42,800 | high-quality systems, so the high quality is the big issue. |
| 00:04:42,800 --> 00:04:46,268 | >> Software engineering is engineering discipline of developing |
| 00:04:46,268 --> 00:04:52,800 | software-based systems, usually embedded into larger systems composed of |
| 00:04:52,800 --> 00:04:58,544 | hardware and and humans [LAUGH] and business |
| 00:04:58,544 --> 00:05:04,943 | processes and processes in general. And why is that important? |
| 00:05:04,943 --> 00:05:06,971 | Well, because software is pervasive in all industry sectors |
| 00:05:06,971 --> 00:05:09,001 | and therefore systems must be reliable, safe and secure. |
| 00:05:09,001 --> 00:05:13,232 | >> Why can't we just get that by sitting down and writing software? |
| 00:05:13,232 --> 00:05:16,697 | >> Well, you could if software was small and |
| 00:05:16,697 --> 00:05:20,162 | simple enough to be developed by one or two |
| 00:05:20,162 --> 00:05:25,360 | people together in a room. But software development now |
| 00:05:25,360 --> 00:05:31,550 | is distributed, involves teams of people with different backgrounds |
| 00:05:31,550 --> 00:05:37,450 | who have to communicate with each other. It also involves customers, |
| 00:05:37,450 --> 00:05:42,512 | clients, users. Software engineers have to work with |
| 00:05:42,512 --> 00:05:47,462 | hardware engineers, with domain experts and therefore, |
| 00:05:47,462 --> 00:05:52,233 | well, no, we can't simply sit down and start coding. |
| 00:05:52,233 --> 00:05:57,380 | >> Software engineering is mostly being able |
| 00:05:57,380 --> 00:06:02,775 | to program. And you need to be able to put big |
| 00:06:02,775 --> 00:06:06,920 | systems together so that they actually work. That's my simple definition. |
| 00:06:06,920 --> 00:06:09,210 | >> And if you don't use software engineering practices, |
| 00:06:09,210 --> 00:06:10,670 | you're not going to be able to put them together? |
| 00:06:10,670 --> 00:06:13,290 | >> Well, you're not going to be able to reliably |
| 00:06:13,290 --> 00:06:16,160 | put them together. So basically, you could maybe hack something up, |
| 00:06:16,160 --> 00:06:18,750 | but it's not going to necessarily stand the test of time. |
| 00:06:18,750 --> 00:06:21,221 | If somebody wants to change it it's probably going to break. |
| 00:06:21,221 --> 00:06:24,140 | >> It's important |
| 00:06:24,140 --> 00:06:29,700 | because if you don't think about how you're building this system and |
| 00:06:29,700 --> 00:06:31,600 | how you're trading off different aspects, |
| 00:06:31,600 --> 00:06:35,580 | like performance and scalability and reliability, then |
| 00:06:35,580 --> 00:06:39,900 | it's going to end up breaking or not lasting very long or not, |
| 00:06:39,900 --> 00:06:43,960 | not doing everything that you want it to do, or being really expensive. |
| 00:06:43,960 --> 00:06:45,800 | >> If it's not done in a principled way it will |
| 00:06:45,800 --> 00:06:49,220 | be bad and every user will suffer. That's why we need |
| 00:06:49,220 --> 00:06:49,970 | software engineering. |
| 00:06:49,970 --> 00:06:56,252 | >> Why is it important? Because, I mean these two goal, productivity, faster, |
| 00:06:56,252 --> 00:06:59,480 | in developing software. And higher quality |
| 00:06:59,480 --> 00:07:03,551 | would be apparently important. Software is everywhere. |
| 00:07:03,551 --> 00:07:08,260 | >> It's important because we use software in everyday life. Everything's |
| 00:07:08,260 --> 00:07:14,120 | built on software systems. And these are ubiquitous across our society. |
| 00:07:14,120 --> 00:07:14,300 | >> It's |
| 00:07:14,300 --> 00:07:20,820 | important because software is everywhere around us and the way we build it, |
| 00:07:20,820 --> 00:07:26,910 | and the way we maintain it, is something that determines almost a basic |
| 00:07:26,910 --> 00:07:33,940 | quality of life nowadays. And getting that software right can make a difference, |
| 00:07:33,940 --> 00:07:40,640 | oftentimes, between a really fun product and one that you won't like to use |
| 00:07:40,640 --> 00:07:45,750 | a reasonably successful company, or one that fails. And in |
| 00:07:45,750 --> 00:07:49,690 | more extreme cases even the difference between life and death, |
| 00:07:49,690 --> 00:07:51,510 | if you think about the software that runs in the |
| 00:07:51,510 --> 00:07:56,380 | airplane on which many of you fly on a regular basis. |
| 00:07:56,380 --> 00:08:00,790 | >> There are programs out there that if they screw up we are all screwed. |
| 00:08:00,790 --> 00:08:02,440 | >> Software engineering is crucially |
| 00:08:02,440 --> 00:08:06,460 | important because it's the engineering discipline |
| 00:08:06,460 --> 00:08:10,250 | that is uniquely capable of carrying out |
| 00:08:10,250 --> 00:08:13,848 | the engineering mission for software reliant systems. |
| 00:08:13,848 --> 00:08:17,620 | >> In the U.S we've all seen an unfortunate example with |
| 00:08:17,620 --> 00:08:23,032 | a system that went badly wrong in healthcare.gov and that system wasn't |
| 00:08:23,032 --> 00:08:26,740 | engineered correctly. And I think if we look at the reasons for |
| 00:08:26,740 --> 00:08:32,350 | that, they stem back to somewhere at the intersection between requirements and |
| 00:08:32,350 --> 00:08:37,470 | architecture and politics and project management, and all of these things are |
| 00:08:37,470 --> 00:08:43,270 | important concepts that have to go into the software engineering mix. |
| 00:08:43,270 --> 00:08:45,570 | >> It would end up in lots and lots of chaos because people |
| 00:08:45,570 --> 00:08:47,220 | wouldn't know how to organize themselves and |
| 00:08:47,220 --> 00:08:49,400 | wouldn't know how to organize software. Many |
| 00:08:49,400 --> 00:08:53,830 | of software engineering has very simple rules that you need to apply properly in |
| 00:08:53,830 --> 00:08:57,280 | order to get things done. And people who look at these rules and think, |
| 00:08:57,280 --> 00:09:01,050 | these rules are so super simple. This is totally obvious. But once |
| 00:09:01,050 --> 00:09:05,495 | you try to apply them, you'll find out they're not obvious at all. |
| 00:09:05,495 --> 00:09:07,670 | >> Now that we've heard these experts, let me show you an |
| 00:09:07,670 --> 00:09:10,080 | example that illustrates what can happen |
| 00:09:10,080 --> 00:09:15,310 | when software engineering practices are not suitably |
| 00:09:15,310 --> 00:09:15,310 | applied. [NOISE]. |