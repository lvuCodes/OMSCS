# CS6300 252 - White Box Testing Example

| Timestamp | Content |
|-----------|---------|
| 00:00:00,080 --> 00:00:03,086 | In this case we focus on white box testing. So consider now this |
| 00:00:03,086 --> 00:00:06,556 | other function, called fun. And let's assume that we want to test this function |
| 00:00:06,556 --> 00:00:09,777 | without having a specification. So without knowing exactly what it needs to do. |
| 00:00:09,777 --> 00:00:12,996 | But just by looking at the code. So we will try to do the |
| 00:00:12,996 --> 00:00:16,030 | problem in this case is to try to just execute all the statements. |
| 00:00:16,030 --> 00:00:18,995 | In the function. And notice I will talk extensively of what does it |
| 00:00:18,995 --> 00:00:22,560 | means to do white box testing later on in the next, two classes. |
| 00:00:22,560 --> 00:00:25,560 | So if that's our goal, if our goal is to cover all the statements, |
| 00:00:25,560 --> 00:00:27,670 | any input will really do. So any test case |
| 00:00:27,670 --> 00:00:30,250 | will excecute all statements in the code. And we'll a |
| 00:00:30,250 --> 00:00:33,801 | complete, you know, white-box testing coverage for the program. |
| 00:00:33,801 --> 00:00:35,865 | Imagine that I now give you a specification for this |
| 00:00:35,865 --> 00:00:39,071 | function. And what the specification says is that this |
| 00:00:39,071 --> 00:00:43,232 | function inputs an integer parameter, param, and returns half of |
| 00:00:43,232 --> 00:00:45,860 | its value, if param is even, and its value |
| 00:00:45,860 --> 00:00:50,740 | unchanged otherwise. That means if param is odd. So looking |
| 00:00:50,740 --> 00:00:54,320 | at this specification, we can clearly see that the function fun |
| 00:00:54,320 --> 00:00:57,740 | works correctly only for even integers, and it doesn't work for |
| 00:00:57,740 --> 00:01:00,570 | odd integers. Because it computes. Half of the value of the |
| 00:01:00,570 --> 00:01:04,410 | parameter and returns it every time, no matter what param is. So |
| 00:01:04,410 --> 00:01:07,320 | this is a case in which white box testing could easily |
| 00:01:07,320 --> 00:01:10,620 | miss the problem, because as we said any input will exercise |
| 00:01:10,620 --> 00:01:12,900 | the code. It's just by chance that we could reveal one |
| 00:01:12,900 --> 00:01:15,750 | that revealed the problem in the code. Conversely if we were to |
| 00:01:15,750 --> 00:01:19,520 | work, in a black box manner. Typically looking at the specification, we |
| 00:01:19,520 --> 00:01:22,390 | will select at least one odd, and one even input number to |
| 00:01:22,390 --> 00:01:25,010 | exercise all of the specified behavior. And we will find the problem |
| 00:01:25,010 --> 00:01:28,110 | right away. So these two examples are just very small examples, and |
| 00:01:28,110 --> 00:01:30,910 | they're kind of, you know, stretched. But these kind of issues occur |
| 00:01:30,910 --> 00:01:33,680 | on a much bigger scale and in much more subtle ways in |
| 00:01:33,680 --> 00:01:36,970 | real world software. And so what this examples do is to show |
| 00:01:36,970 --> 00:01:41,270 | you, how black box and white box tests are really complimentary techniques. |
| 00:01:41,270 --> 00:01:43,130 | So in the next two lessions we will explore |
| 00:01:43,130 --> 00:01:45,130 | these two types of techniques in detail. We will |
| 00:01:45,130 --> 00:01:48,020 | see different kinds of white box and black box |
| 00:01:48,020 --> 00:01:48,020 | testing. And we'll talk about their strengths and the mutations |