# CS6300 185 - Architectural Styles Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,090 --> 00:00:02,630 | Consider now the following architectural styles |
| 00:00:02,630 --> 00:00:04,356 | that we just saw: pipes and filters, |
| 00:00:04,356 --> 00:00:09,310 | event-driven, publish-subscribe, client-server, peer-to-peer, and rest. |
| 00:00:09,310 --> 00:00:11,150 | I'm showing you here, a list of |
| 00:00:11,150 --> 00:00:15,220 | four different systems, and I would like for you to mark here which |
| 00:00:15,220 --> 00:00:18,750 | architectural style, or styles, characterize Each of |
| 00:00:18,750 --> 00:00:18,750 | these systems. Again, mark all that apply. |