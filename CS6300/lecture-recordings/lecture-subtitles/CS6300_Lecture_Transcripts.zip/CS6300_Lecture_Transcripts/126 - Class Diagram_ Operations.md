# CS6300 126 - Class Diagram_ Operations

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:02,920 | At this point we have our classes, our attributes, |
| 00:00:02,920 --> 00:00:05,740 | what we're missing is the operations for the class. |
| 00:00:05,740 --> 00:00:08,340 | Let me remind you that operations represent the behavior |
| 00:00:08,340 --> 00:00:10,370 | of a class, and that they may be found by |
| 00:00:10,370 --> 00:00:14,310 | examining interactions among entities in the description of my |
| 00:00:14,310 --> 00:00:18,480 | system. So once more, let's bring back our description, and |
| 00:00:18,480 --> 00:00:22,090 | let's in this case focus on this specific item. |
| 00:00:22,090 --> 00:00:25,330 | That says that the students may use the system to |
| 00:00:25,330 --> 00:00:29,800 | add courses. So this is clearly indicating an action |
| 00:00:29,800 --> 00:00:32,320 | that the students should be able to perform. But notice |
| 00:00:32,320 --> 00:00:35,100 | that this doesn't mean that this is an operation that |
| 00:00:35,100 --> 00:00:38,370 | should be provided by the student's class. It rather means |
| 00:00:38,370 --> 00:00:41,860 | that there should be, somewhere in the system, the possibility |
| 00:00:41,860 --> 00:00:45,080 | of performing this operation. So let's see what this means |
| 00:00:45,080 --> 00:00:47,920 | for our example. This might mean, for example, if we |
| 00:00:47,920 --> 00:00:50,400 | focus on the RegistrationManager, so that there should be an |
| 00:00:50,400 --> 00:00:53,520 | operation in the RegistrationManager that allows me to add |
| 00:00:53,520 --> 00:00:56,300 | a student to a course. And this, in turn, means |
| 00:00:56,300 --> 00:01:00,270 | that both Course and CourseOffering should provide a way to |
| 00:01:00,270 --> 00:01:04,140 | add a student. And therefore, I add this corresponding operation |
| 00:01:04,140 --> 00:01:07,790 | to the RegistrationManager, to the Course, and to the CourseOffering. |
| 00:01:07,790 --> 00:01:10,020 | So after doing that we will continue and populate in |
| 00:01:10,020 --> 00:01:13,080 | a similar way, the other classes in the system. So |
| 00:01:13,080 --> 00:01:16,040 | let me recap. Now we saw how to identify classes. |
| 00:01:16,040 --> 00:01:18,300 | How to identify members of the classes, and |
| 00:01:18,300 --> 00:01:21,910 | particular attributes, and operations. There is one thing that |
| 00:01:21,910 --> 00:01:24,060 | we're missing, a very important aspect of the |
| 00:01:24,060 --> 00:01:24,060 | class diagram which is the relationships between these classes. |