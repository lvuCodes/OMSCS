# CS6300 301 - B&C Coverage Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,190 --> 00:00:03,010 | Obviously there are many possible tests that we can use to |
| 00:00:03,010 --> 00:00:05,910 | reach 100% branch and condition coverage. So I'm just going to show a |
| 00:00:05,910 --> 00:00:08,740 | possible one, which is x equal to 3 and y is |
| 00:00:08,740 --> 00:00:11,410 | equal to negative 2. If we specify this as case, you can |
| 00:00:11,410 --> 00:00:14,900 | see that the overall condition is false, because neither x is |
| 00:00:14,900 --> 00:00:17,990 | equal to 0 nor y is greater than 0. Therefore we will |
| 00:00:17,990 --> 00:00:22,420 | follow the false, false branch, and achieve 100% branch and condition coverage |
| 00:00:22,420 --> 00:00:25,400 | for this code. And we might require to be even more thorough, |
| 00:00:25,400 --> 00:00:28,690 | that all the combinations of our conditions inside each |
| 00:00:28,690 --> 00:00:31,790 | decision, inside each predicate, are tested. Which is what is |
| 00:00:31,790 --> 00:00:36,010 | called, multiple condition coverage. But because of the way |
| 00:00:36,010 --> 00:00:39,050 | this criterion is defined, it is combinatorial, becuse you have |
| 00:00:39,050 --> 00:00:42,220 | to consider all the possible combinations of conditions. And |
| 00:00:42,220 --> 00:00:45,210 | therefore it's extremely expensive, to the point of being impractical. |
| 00:00:45,210 --> 00:00:47,610 | So instead of defining that criterion, we're going to find |
| 00:00:47,610 --> 00:00:51,000 | another one which finds a good trade off between thoroughness |
| 00:00:51,000 --> 00:00:51,000 | of the tests and their cost. |