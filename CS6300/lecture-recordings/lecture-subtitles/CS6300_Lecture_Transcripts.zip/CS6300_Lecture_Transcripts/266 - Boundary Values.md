# CS6300 266 - Boundary Values

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:02,590 | So let's go back again to our domain, with |
| 00:00:02,590 --> 00:00:06,580 | all the sub-domains identified. And the basic idea, or the |
| 00:00:06,580 --> 00:00:09,750 | intuitive idea I was talking about, is that errors tend |
| 00:00:09,750 --> 00:00:12,425 | to occur at the boundary of a domain, or a |
| 00:00:12,425 --> 00:00:15,510 | sub-domain. Like in this case. And why? Because these |
| 00:00:15,510 --> 00:00:19,360 | are the cases that are less understood by the developers. |
| 00:00:19,360 --> 00:00:22,155 | Like for example, the last iteration of a loop, or |
| 00:00:22,155 --> 00:00:25,150 | a special value like zero for integers. So if this |
| 00:00:25,150 --> 00:00:29,590 | is true, what we want to do is to select inputs at these |
| 00:00:29,590 --> 00:00:32,189 | boundaries. And this is complementary to partition |
| 00:00:32,189 --> 00:00:34,270 | testing, in the sense that partition testing |
| 00:00:34,270 --> 00:00:38,160 | will identify the partitions in which we want to select inputs, and boundary |
| 00:00:38,160 --> 00:00:40,570 | testing. So the selection of boundary values |
| 00:00:40,570 --> 00:00:40,570 | will help select inputs in these partitions. |