# CS6300 217 - UML Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:03,440 | Before doing that though, let's have a quiz to check whether you remember |
| 00:00:03,440 --> 00:00:07,160 | the basics of UML. Since we're going to talk about use cases, I want |
| 00:00:07,160 --> 00:00:10,040 | to ask you, what is the difference between a use case and a |
| 00:00:10,040 --> 00:00:13,330 | use case model. So here are the possible answers, and you can mark |
| 00:00:13,330 --> 00:00:16,710 | more than one. First one is that only use case models include actors. |
| 00:00:16,710 --> 00:00:19,150 | The second is that they are the same thing. The third one is |
| 00:00:19,150 --> 00:00:22,000 | that a use case model is a set of use cases. The fourth |
| 00:00:22,000 --> 00:00:24,950 | one says that a use case is a set of use case models. |
| 00:00:24,950 --> 00:00:26,520 | Finally, the last one says that use cases |
| 00:00:26,520 --> 00:00:29,650 | are a dynamic representation, whereas use case models |
| 00:00:29,650 --> 00:00:31,880 | are a static representation of a system. So |
| 00:00:31,880 --> 00:00:31,880 | mark all the answers that you think are correct. |