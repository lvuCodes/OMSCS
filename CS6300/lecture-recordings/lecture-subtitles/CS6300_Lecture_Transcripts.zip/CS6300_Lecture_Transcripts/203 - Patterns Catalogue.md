# CS6300 203 - Patterns Catalogue

| Timestamp | Content |
|-----------|---------|
| 00:00:00,230 --> 00:00:03,380 | This book contains a patterns catalog which is |
| 00:00:03,380 --> 00:00:06,725 | a number of design patterns classified by purpose. And |
| 00:00:06,725 --> 00:00:09,122 | there are five main classes of patterns. There are |
| 00:00:09,122 --> 00:00:11,890 | fundamental patterns which are the basic patterns. There are |
| 00:00:11,890 --> 00:00:15,170 | creational patterns which are the patterns that support object |
| 00:00:15,170 --> 00:00:18,290 | creation. Then there are structural patterns and these are |
| 00:00:18,290 --> 00:00:22,090 | patterns that help compose objects, put objects together. The |
| 00:00:22,090 --> 00:00:25,280 | next class of patterns are behavioral patterns and these |
| 00:00:25,280 --> 00:00:28,840 | are patterns that are mostly focused on realizing interactions |
| 00:00:28,840 --> 00:00:32,820 | among different objects. Finally, there are concurrency patterns and these |
| 00:00:32,820 --> 00:00:36,400 | are patterns that support, as the name says, concurrency, so |
| 00:00:36,400 --> 00:00:39,700 | they're more related to concurrency aspects. And for each of |
| 00:00:39,700 --> 00:00:43,560 | these classes there are a number of specific patterns, and |
| 00:00:43,560 --> 00:00:46,130 | here I'm just listing some of them. Clearly we cannot |
| 00:00:46,130 --> 00:00:48,740 | cover in one lesson all of these patterns, but what |
| 00:00:48,740 --> 00:00:50,440 | I want to do is to cover at least a few |
| 00:00:50,440 --> 00:00:52,670 | of those to give an idea of what patterns are and |
| 00:00:52,670 --> 00:00:55,430 | how they can be used. In particular, we will see in |
| 00:00:55,430 --> 00:00:59,200 | detail the Factory Method Pattern and the Strategy Pattern. And we |
| 00:00:59,200 --> 00:00:59,200 | will also discuss a few more patterns at a higher level. |