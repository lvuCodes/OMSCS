# CS6300 18 - Traditional Software Phases

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:02,650 | As we just heard from Professor Bohem, software |
| 00:00:02,650 --> 00:00:05,970 | engineering is an important and critical discipline, concerned |
| 00:00:05,970 --> 00:00:09,100 | with cost effective software development. We also heard |
| 00:00:09,100 --> 00:00:11,170 | that this is based on a systematic approach |
| 00:00:11,170 --> 00:00:14,580 | that uses appropriate tools and techniques, operates under |
| 00:00:14,580 --> 00:00:18,130 | specific development constraints. And most importantly, follows a |
| 00:00:18,130 --> 00:00:20,890 | process. As we discussed in the previous lesson, |
| 00:00:20,890 --> 00:00:25,770 | the software development process contains fundamental activities, or phases. |
| 00:00:25,770 --> 00:00:28,480 | Since we will discuss several processes, I'm going to remind |
| 00:00:28,480 --> 00:00:31,150 | you what these phases are. We start with requirements |
| 00:00:31,150 --> 00:00:33,630 | engineering, followed by design, |
| 00:00:33,630 --> 00:00:36,980 | implementation, verification and validation, and |
| 00:00:36,980 --> 00:00:40,950 | finally maintenance. Note that we will revisit each of |
| 00:00:40,950 --> 00:00:43,940 | these phases and devote an entire lesson or more |
| 00:00:43,940 --> 00:00:46,160 | to each phase. So what I want to do next |
| 00:00:46,160 --> 00:00:48,210 | is simply to give you a quick overview of |
| 00:00:48,210 --> 00:00:51,020 | what these phases are. Note also that for now |
| 00:00:51,020 --> 00:00:54,330 | I will follow a very traditional take on these topics. Later on in the |
| 00:00:54,330 --> 00:00:54,330 | class we will see how things can change and did change over the years. |