# CS6300 27 - Waterfall Process

| Timestamp | Content |
|-----------|---------|
| 00:00:00,070 --> 00:00:02,830 | The first model we want to discuss is the grandfather of |
| 00:00:02,830 --> 00:00:05,900 | all life cycle models. And it is the waterfall model. In |
| 00:00:05,900 --> 00:00:08,890 | the waterfall model the project progresses to an orderly sequence of |
| 00:00:08,890 --> 00:00:13,040 | steps. From the initial software concept, down until the final phase. |
| 00:00:13,040 --> 00:00:16,110 | Which is system testing. And at the end of each phase |
| 00:00:16,110 --> 00:00:18,510 | there will be a review to determine whether the project is |
| 00:00:18,510 --> 00:00:22,120 | ready to advance to the next phase. The pure waterfall model |
| 00:00:22,120 --> 00:00:25,340 | performs well for softer products in which there is a stable |
| 00:00:25,340 --> 00:00:28,400 | product definition. The domain is well known and the technologies |
| 00:00:28,400 --> 00:00:31,220 | involved are well understood. In these kind of domains, the |
| 00:00:31,220 --> 00:00:34,350 | waterfall model helps you to find errors in the early, |
| 00:00:34,350 --> 00:00:37,180 | local stages of the projects. If you remember what we discussed, |
| 00:00:37,180 --> 00:00:39,950 | this is the place where we want to find errors, |
| 00:00:39,950 --> 00:00:43,440 | not down here because finding them here will reduce the cost |
| 00:00:43,440 --> 00:00:47,160 | of our overall software development. The main advantage of the |
| 00:00:47,160 --> 00:00:50,930 | waterfall model is that it allows you to find errors early. |
| 00:00:50,930 --> 00:00:53,910 | However, the main disadvantages of the waterfall model arise |
| 00:00:53,910 --> 00:00:56,550 | from the fact that it is not flexible. Normally, |
| 00:00:56,550 --> 00:00:59,520 | it is difficult to fully specify requirements at the |
| 00:00:59,520 --> 00:01:02,470 | beginning of a project. And this lack of flexibility is |
| 00:01:02,470 --> 00:01:04,800 | far from ideal when dealing with project in which |
| 00:01:04,800 --> 00:01:07,310 | requirements change, the developers are not domain experts or |
| 00:01:07,310 --> 00:01:11,130 | the technology used are new and evolving, that is |
| 00:01:11,130 --> 00:01:11,130 | it is less than ideal for most real world projects. |