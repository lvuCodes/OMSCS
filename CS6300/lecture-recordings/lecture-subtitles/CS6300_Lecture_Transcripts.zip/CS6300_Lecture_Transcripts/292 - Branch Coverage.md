# CS6300 292 - Branch Coverage

| Timestamp | Content |
|-----------|---------|
| 00:00:00,400 --> 00:00:03,780 | So now that we know what the CFG is, let's see how we can get into a count, |
| 00:00:03,780 --> 00:00:07,860 | that else part, that is missing in our example code by introducing a new |
| 00:00:07,860 --> 00:00:10,480 | kind of coverage. Branch coverage. As usual, |
| 00:00:10,480 --> 00:00:13,550 | I'm going to describe branch coverage in terms of test requirements and |
| 00:00:13,550 --> 00:00:17,100 | coverage measure. So starting from test requirements. The test requirement for |
| 00:00:17,100 --> 00:00:21,080 | branch coverage are the branches in the program. In other words, |
| 00:00:21,080 --> 00:00:25,240 | the goal of branch coverage is to execute all of the branches in the program. |
| 00:00:25,240 --> 00:00:28,370 | The coverage measure is defined accordingly as the number of branches |
| 00:00:28,370 --> 00:00:33,150 | executed by my test cases over the total number of branches in the program. And |
| 00:00:33,150 --> 00:00:37,020 | let me remind you that branches are the outgoing edges from a decision point. |
| 00:00:37,020 --> 00:00:40,410 | Therefore, an if statement, a switch statement, a while statement. |
| 00:00:40,410 --> 00:00:44,400 | Any note in the c of g that has got more than one outgoing edge. |
| 00:00:44,400 --> 00:00:48,170 | Those edges are called branches. So let's look at that using our example. So |
| 00:00:48,170 --> 00:00:51,690 | now we're looking back at our printSum example. And in addition to the code, |
| 00:00:51,690 --> 00:00:54,440 | I also want to represent the CFG for the program. So |
| 00:00:54,440 --> 00:00:58,590 | let's start by looking at how many branches we have in our code. Which means how |
| 00:00:58,590 --> 00:01:02,070 | many test requirements we have. And in this case there are two decision points. |
| 00:01:02,070 --> 00:01:04,940 | The first one that corresponds to the first if, and the second one that |
| 00:01:04,940 --> 00:01:10,100 | corresponds to the second if. So we have one, two, three, and four branches. So |
| 00:01:10,100 --> 00:01:13,880 | now, let's bring back our current set of test cases. We had two test cases. |
| 00:01:13,880 --> 00:01:17,440 | The one's that, with which we achieved a 100% statement coverage. And |
| 00:01:17,440 --> 00:01:21,140 | let's see what happens in terms of branch coverage when we run these test cases. |
| 00:01:21,140 --> 00:01:24,110 | I start from the first one, when we execute it, we follow the code, |
| 00:01:24,110 --> 00:01:27,890 | we get to this decision point because the predicate in the if statement is true. |
| 00:01:27,890 --> 00:01:30,770 | We follow the true branch, therefore we get here and then, |
| 00:01:30,770 --> 00:01:34,970 | we exit from the program. So, in this case, we covered one of the branches, |
| 00:01:34,970 --> 00:01:40,710 | which means that we got to 25% coverage. Now when we run the second test case, |
| 00:01:40,710 --> 00:01:44,160 | again we follow this path. We get to this, the first if and |
| 00:01:44,160 --> 00:01:47,730 | in this case the predicate of the if is false. Therefore, we go this way. |
| 00:01:47,730 --> 00:01:51,160 | We reach the second predicate, the second if. The result is true, so |
| 00:01:51,160 --> 00:01:55,490 | we follow the true branch and therefore, we cover these additional two branches. |
| 00:01:55,490 --> 00:01:59,900 | So at this point, we are at 75% branch coverage. So what |
| 00:01:59,900 --> 00:02:04,070 | happens is that we're missing this branch. For now, the inputs that we consider, |
| 00:02:04,070 --> 00:02:07,740 | this branch is executed. Therefore, we need to add an additional test case. And |
| 00:02:07,740 --> 00:02:11,600 | that this case that we need, is one for which this predicate is false and this |
| 00:02:11,600 --> 00:02:15,680 | predicate is false. The simplest possibility in this case is the test case for |
| 00:02:15,680 --> 00:02:20,170 | which A is equal to 0 and B is equal to 0. If we execute this test case, |
| 00:02:20,170 --> 00:02:24,250 | our execution again followed this path, follows the fourth branch here. |
| 00:02:24,250 --> 00:02:28,090 | And in this case, because result is not less than zero either, will follow |
| 00:02:28,090 --> 00:02:33,090 | this branch as well. And therefore, we will reach our 100% branch coverage. And |
| 00:02:33,090 --> 00:02:35,820 | this covered the problem. Something that I would like to clarify before we |
| 00:02:35,820 --> 00:02:40,920 | move to the next topic, is that 100% coverage does not provide any guarantee of |
| 00:02:40,920 --> 00:02:44,530 | finding the problems in the code. All we saw so far is the fact that by |
| 00:02:44,530 --> 00:02:48,580 | testing more thoroughly we have more chances of finding a problem in the code. |
| 00:02:48,580 --> 00:02:51,680 | But it doesn't matter which kind of coverage we utilize, and how much |
| 00:02:51,680 --> 00:02:55,440 | coverage we achieve. There's always a chance that we might miss something. And |
| 00:02:55,440 --> 00:02:59,760 | I will get back to this later on in the lesson. I just mentioned the fact that |
| 00:02:59,760 --> 00:03:03,910 | we tested more fully when we went from statement coverage to branch coverage. |
| 00:03:03,910 --> 00:03:06,900 | What does that mean exactly? To explain that, I'm going to introduce the concept |
| 00:03:06,900 --> 00:03:11,420 | of test criteria subsumption. One test criteria subsumes another criteria when |
| 00:03:11,420 --> 00:03:16,760 | all the tests widths that satisfy that criteria will also satisfy the other one. |
| 00:03:16,760 --> 00:03:18,740 | So let me show you that with statement and |
| 00:03:18,740 --> 00:03:23,220 | branch coverage. If we identify a test width that achieves 100% branch coverage, |
| 00:03:23,220 --> 00:03:27,780 | the same test width will also achieve, necessarily, 100% statement coverage. |
| 00:03:27,780 --> 00:03:31,290 | That's what happened for our example, and also what happens in general, |
| 00:03:31,290 --> 00:03:35,660 | because branch coverage is a stronger criteria than statement coverage. |
| 00:03:35,660 --> 00:03:39,670 | There is no way to cover all the branches without covering all the statements. |
| 00:03:39,670 --> 00:03:43,480 | It is not true that any test results satisfies statement coverage will also |
| 00:03:43,480 --> 00:03:47,040 | satisfy branch coverage. And, in fact, we just saw a counter example. |
| 00:03:47,040 --> 00:03:50,569 | When we look at the printSum code. We had a test where there was achieving 100% |
| 00:03:50,569 --> 00:03:53,910 | statement coverage and was not achieving 100% branch coverage. Therefore, |
| 00:03:53,910 --> 00:03:58,301 | in this case we have a substantial relation in this direction. Branch coverage, |
| 00:03:58,301 --> 00:04:02,860 | subsumes statement coverage. What it also means is that normally, or in general, |
| 00:04:02,860 --> 00:04:06,910 | it is more expensive to achieve branch coverage than achieve statement coverage, |
| 00:04:06,910 --> 00:04:09,490 | because achieving branch coverage requires the generation of |
| 00:04:09,490 --> 00:04:13,770 | a larger number of test cases. So what this relation means is that |
| 00:04:13,770 --> 00:04:13,770 | branch coverage is stronger than statement coverage but also more expensive. |