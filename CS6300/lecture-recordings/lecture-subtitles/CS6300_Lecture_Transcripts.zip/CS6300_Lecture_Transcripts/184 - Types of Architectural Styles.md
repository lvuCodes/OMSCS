# CS6300 184 - Types of Architectural Styles

| Timestamp | Content |
|-----------|---------|
| 00:00:00,130 --> 00:00:02,410 | So what does it mean to know architectural styles? There |
| 00:00:02,410 --> 00:00:06,390 | are many many, many architectural styles. So we cannot cover them |
| 00:00:06,390 --> 00:00:08,730 | all here. What I want to do instead is, I want to |
| 00:00:08,730 --> 00:00:10,960 | mention a few of those. And then I want to go in |
| 00:00:10,960 --> 00:00:13,300 | more depth, on one of them. So the first item I |
| 00:00:13,300 --> 00:00:17,420 | want to mention is pipes and filters. And pipes and filters indicate |
| 00:00:17,420 --> 00:00:21,110 | an architectural style in which a chain of processing elements, which |
| 00:00:21,110 --> 00:00:25,410 | can be processes, threads, co-routines, is arranged so that the output |
| 00:00:25,410 --> 00:00:28,420 | of each element is the input of the next one |
| 00:00:28,420 --> 00:00:31,840 | and usually with some buffering in between consecutive elements. A |
| 00:00:31,840 --> 00:00:34,120 | typical example of this, if you're familiar with Unix are |
| 00:00:34,120 --> 00:00:37,900 | Unix pipes, that you can use to concatenate Unix commands. |
| 00:00:37,900 --> 00:00:40,310 | Another style I want to mention is the event driven |
| 00:00:40,310 --> 00:00:43,540 | one. An event driven system typically consists of event |
| 00:00:43,540 --> 00:00:46,590 | emittors, like the alarm over here, and event consumers, like |
| 00:00:46,590 --> 00:00:50,720 | the fire truck, down here, and consumers are notified when events |
| 00:00:50,720 --> 00:00:53,810 | of interest occurr and have the responsibility of reacting |
| 00:00:53,810 --> 00:00:56,676 | to those events. A typical example will be a GUI, |
| 00:00:56,676 --> 00:00:59,950 | in which widgets generate events and listeners listen to those |
| 00:00:59,950 --> 00:01:02,550 | events and react to them. For example, they react to |
| 00:01:02,550 --> 00:01:05,060 | the push of a button. A very commonly used |
| 00:01:05,060 --> 00:01:09,250 | architectural style is Publish-subscribe, represented by the paper boy. Over |
| 00:01:09,250 --> 00:01:12,420 | here. And this is an architectural style in which senders |
| 00:01:12,420 --> 00:01:15,870 | of messages, they're called publishers, do not send messages directly |
| 00:01:15,870 --> 00:01:19,330 | to specific recievers. Instead, they publish messages with one |
| 00:01:19,330 --> 00:01:22,530 | or more associated texts without knowledge of who will |
| 00:01:22,530 --> 00:01:26,810 | receive such messages. Similarly subscribers will express interest in |
| 00:01:26,810 --> 00:01:29,340 | one or more tags. And will only receive messages of |
| 00:01:29,340 --> 00:01:32,095 | interest according to such tags. A typical example of |
| 00:01:32,095 --> 00:01:35,240 | a publish-subscribe system, will be Twitter. And I'm pretty |
| 00:01:35,240 --> 00:01:36,835 | sure that most of you are familiar with the |
| 00:01:36,835 --> 00:01:41,170 | client-server architecture. In which computers in a network, assume one |
| 00:01:41,170 --> 00:01:43,930 | of two roles. The server provides the resources and |
| 00:01:43,930 --> 00:01:47,630 | functionality. And the client initiates contact with the server, |
| 00:01:47,630 --> 00:01:50,920 | and requests the use of those resources and functionality. |
| 00:01:50,920 --> 00:01:53,340 | Also in this case, a typical example would be |
| 00:01:53,340 --> 00:01:56,470 | email, in which an email server provides email storage |
| 00:01:56,470 --> 00:01:59,390 | and management capabilities, and an email client will use |
| 00:01:59,390 --> 00:02:02,580 | those capabilities. You may also be familiar with peer-to-peer, |
| 00:02:02,580 --> 00:02:06,530 | or P2P, systems. A P2P system is a type |
| 00:02:06,530 --> 00:02:10,850 | of decentralized and distributed network system in which individual nodes |
| 00:02:10,850 --> 00:02:14,220 | in the network, that are called peers, act as independent |
| 00:02:14,220 --> 00:02:17,940 | agents that are both suppliers and consumers of resources. This |
| 00:02:17,940 --> 00:02:20,700 | is in contrast to the centralized client-server model, where client |
| 00:02:20,700 --> 00:02:23,660 | nodes interact with the central authority. And I'm not going to |
| 00:02:23,660 --> 00:02:26,030 | say anything more about peer-to-peer, because I'm going to show you |
| 00:02:26,030 --> 00:02:28,940 | two examples, of peer-to-peer systems in the rest of the |
| 00:02:28,940 --> 00:02:32,040 | lesson. And you probably have at least heard of rest. |
| 00:02:32,040 --> 00:02:33,990 | Which in this case is not an invitation to |
| 00:02:33,990 --> 00:02:36,970 | relax as the graphic might indicate. But rather stands for |
| 00:02:36,970 --> 00:02:41,400 | Representational State Transfer. REST is a hybrid architectural style |
| 00:02:41,400 --> 00:02:45,150 | for distributed hypermedia systems, that is derived from several other |
| 00:02:45,150 --> 00:02:48,210 | network based architectural styles. And that is characterized by |
| 00:02:48,210 --> 00:02:51,970 | uniform connector interface, and even if I'm not going to say |
| 00:02:51,970 --> 00:02:54,230 | anything else about the rest, I wanted to mention |
| 00:02:54,230 --> 00:02:57,440 | it, because it is an extremely well known architectural style. |
| 00:02:57,440 --> 00:02:59,300 | And the reason for this is that REST is |
| 00:02:59,300 --> 00:03:03,310 | very widely used, because it is basically the architectural style |
| 00:03:03,310 --> 00:03:06,050 | that governs the world wide web. So we use it |
| 00:03:06,050 --> 00:03:06,050 | all the time when we browse the internet, for instance. |