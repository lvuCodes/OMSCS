# CS6300 207 - Strategy Pattern

| Timestamp | Content |
|-----------|---------|
| 00:00:00,230 --> 00:00:02,110 | The second pattern I want to discuss is the |
| 00:00:02,110 --> 00:00:05,050 | strategy pattern, which provides a way to configure a |
| 00:00:05,050 --> 00:00:07,900 | class with one of many behaviors. What does that |
| 00:00:07,900 --> 00:00:11,040 | mean? Well, more precisely, this pattern allows for defining |
| 00:00:11,040 --> 00:00:15,330 | a family of algorithms, encapsulating them into separate classes, |
| 00:00:15,330 --> 00:00:17,900 | so each algorithm in one class, and making these |
| 00:00:17,900 --> 00:00:21,490 | classes interchangeable, but providing a common interface for all |
| 00:00:21,490 --> 00:00:25,350 | the encapsulated algorithms. So in essence, the intent of |
| 00:00:25,350 --> 00:00:29,250 | a strategy pattern is to allow for switching between |
| 00:00:29,250 --> 00:00:33,490 | different algorithms for accomplishing a given task. For example, imagine |
| 00:00:33,490 --> 00:00:36,610 | having different sorting algorithms with different space or time |
| 00:00:36,610 --> 00:00:38,800 | tradeoffs. You might want to be able to have them |
| 00:00:38,800 --> 00:00:42,670 | all available and use different ones in different situations. |
| 00:00:42,670 --> 00:00:44,820 | And this pattern is applicable not only when we have |
| 00:00:44,820 --> 00:00:47,260 | different variants of an algorithm, but also when we |
| 00:00:47,260 --> 00:00:51,690 | have many related classes that differ only in their behavior. |
| 00:00:51,690 --> 00:00:53,640 | So let's get more concrete and see how this is |
| 00:00:53,640 --> 00:00:55,960 | done. And I'm going to do it as before, by |
| 00:00:55,960 --> 00:00:59,700 | discussing the structure and the participants for this strategy pattern. |
| 00:00:59,700 --> 00:01:02,540 | In this case, we have 3 types of participants for this |
| 00:01:02,540 --> 00:01:07,210 | pattern, the context, the algorithm, and the concrete strategies. There |
| 00:01:07,210 --> 00:01:09,580 | can be as many as the number of behaviors that |
| 00:01:09,580 --> 00:01:12,300 | I need to implement. So, let's see what those are. |
| 00:01:12,300 --> 00:01:16,690 | The context is the interface to the outside world. It maintains |
| 00:01:16,690 --> 00:01:19,180 | a reference to the current algorithm and allows for |
| 00:01:19,180 --> 00:01:22,860 | updating this reference at run time. So, basically the outside |
| 00:01:22,860 --> 00:01:26,370 | world will invoke the functionality provided by the different algorithms, |
| 00:01:26,370 --> 00:01:29,170 | by using this interface. And depending on which algorithm is |
| 00:01:29,170 --> 00:01:31,640 | currently selected, that's the one that will be executed when |
| 00:01:31,640 --> 00:01:35,920 | the functionality is involved. The algorithm, also called the strategy, |
| 00:01:35,920 --> 00:01:37,970 | so that's where the pattern gets its name, Is the |
| 00:01:37,970 --> 00:01:42,130 | common interface for the different algorithims. So all the algorithms |
| 00:01:42,130 --> 00:01:46,690 | implement this interface. Finally, the concrete strategies are the |
| 00:01:46,690 --> 00:01:49,920 | actual implementations of the algorithms. So if I have 10 |
| 00:01:49,920 --> 00:01:53,030 | different variants of my algorithm, I will implement 10 different |
| 00:01:53,030 --> 00:01:53,030 | concrete strategies. They will all be implementations of this interface. |