# CS6300 103 - Traditional Techniques

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,930 | To cover the intrinsic problem of eliciting requirements, |
| 00:00:02,930 --> 00:00:05,670 | many different techniques have been proposed. So here |
| 00:00:05,670 --> 00:00:08,260 | I list some of most traditional techniques for |
| 00:00:08,260 --> 00:00:11,290 | requirement elicitation and as I present those, please keep |
| 00:00:11,290 --> 00:00:13,140 | in mind that these techniques can be used |
| 00:00:13,140 --> 00:00:17,230 | separately or combined. A first technique is called background |
| 00:00:17,230 --> 00:00:20,740 | reading. And, this technique involves collecting information by |
| 00:00:20,740 --> 00:00:24,840 | reading existing documents such as company reports, organizational charts, |
| 00:00:24,840 --> 00:00:29,280 | policy manuals, job descriptions, documentation of existing systems and so |
| 00:00:29,280 --> 00:00:32,400 | on. And, this technique is especially appropriate when one Is |
| 00:00:32,400 --> 00:00:35,370 | not familiar with your organization for which the requirements are |
| 00:00:35,370 --> 00:00:38,950 | being collected. So you want to get some background before interviewing |
| 00:00:38,950 --> 00:00:41,240 | actual people. And one of the main imitations of these |
| 00:00:41,240 --> 00:00:43,930 | kinds of approaches is that written documents might be out |
| 00:00:43,930 --> 00:00:46,320 | of sync and they often are out of sync with |
| 00:00:46,320 --> 00:00:49,970 | reality. Tend to be long winded. It may contain many irrelevant |
| 00:00:49,970 --> 00:00:51,850 | details, so you may have to look at a lot |
| 00:00:51,850 --> 00:00:54,810 | of materials to extract enough information. The hard data and |
| 00:00:54,810 --> 00:00:58,650 | samples techniques consist in deciding which hard data we want |
| 00:00:58,650 --> 00:01:01,680 | to collect and choosing the sample of the population for which |
| 00:01:01,680 --> 00:01:04,750 | to collect such data and hard data includes facts and |
| 00:01:04,750 --> 00:01:09,790 | figures such as forms, invoices, financial information, survey results, marketing |
| 00:01:09,790 --> 00:01:12,300 | data, and so on. And the sampling of this data |
| 00:01:12,300 --> 00:01:15,170 | can be done in different ways. For example, the typical ways |
| 00:01:15,170 --> 00:01:19,200 | to do random selection. Interviews are another typical approach for |
| 00:01:19,200 --> 00:01:21,870 | requirement solicitation, and this is the approach that we use for |
| 00:01:21,870 --> 00:01:24,910 | the first project in this course, for instance. Interviews can be |
| 00:01:24,910 --> 00:01:27,720 | structured in which case there is an agenda of fairly open |
| 00:01:27,720 --> 00:01:30,450 | questions or they can be open ended in which case there |
| 00:01:30,450 --> 00:01:32,770 | is no preset agenda and the interview is more of a |
| 00:01:32,770 --> 00:01:36,500 | conversation. On the positive side, interviews can collect a rich set |
| 00:01:36,500 --> 00:01:40,260 | of information because they allow for uncovering opinions as well as |
| 00:01:40,260 --> 00:01:43,230 | hard facts. Moreover, they can probe in depth through follow |
| 00:01:43,230 --> 00:01:46,790 | up questions. On the more negative side, interviewing requires special |
| 00:01:46,790 --> 00:01:50,400 | skills that are difficult to master and require experience. And |
| 00:01:50,400 --> 00:01:52,890 | it is not enough to collect a lot of information. If |
| 00:01:52,890 --> 00:01:55,520 | this information is hard to analyze or even irrelevant, it |
| 00:01:55,520 --> 00:01:58,250 | might become useless. So you need to know how to conduct |
| 00:01:58,250 --> 00:02:01,180 | an interview in order to take advantage of these techniques. |
| 00:02:01,180 --> 00:02:05,440 | Surveys can also be extremely useful for gathering new requirements because |
| 00:02:05,440 --> 00:02:08,550 | they can quickly collect information from a large number |
| 00:02:08,550 --> 00:02:11,520 | of people. Moreover, they can be administered remotely. For |
| 00:02:11,520 --> 00:02:13,610 | example, by email, through the web. On the other |
| 00:02:13,610 --> 00:02:16,750 | hand, surveys tend to severely constrain the information that |
| 00:02:16,750 --> 00:02:19,430 | the user can provide and might miss opportunities to |
| 00:02:19,430 --> 00:02:24,460 | collect unforeseen, relevant information. Finally, meetings are generally used |
| 00:02:24,460 --> 00:02:27,690 | for summarization of findings and collection of feedback, so as |
| 00:02:27,690 --> 00:02:30,500 | to confirm or refute what has been learned. So the |
| 00:02:30,500 --> 00:02:32,660 | only additional thing I want to mention about meetings |
| 00:02:32,660 --> 00:02:34,920 | is the fact that it is fundamental that have clearly |
| 00:02:34,920 --> 00:02:37,970 | stated objectives and are planned carefully. This is something that |
| 00:02:37,970 --> 00:02:37,970 | should be quite obvious, but doesn't always happen in practice. |