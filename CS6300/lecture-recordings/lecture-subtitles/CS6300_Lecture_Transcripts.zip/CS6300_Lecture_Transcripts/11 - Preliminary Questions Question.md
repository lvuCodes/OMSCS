# CS6300 11 - Preliminary Questions Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,110 --> 00:00:01,450 | So, now before we actually jump to the |
| 00:00:01,450 --> 00:00:03,410 | discussion of software processes I want to ask you |
| 00:00:03,410 --> 00:00:05,770 | a couple of preliminary questions. The first one is, |
| 00:00:05,770 --> 00:00:08,140 | what is the largest software system on which you |
| 00:00:08,140 --> 00:00:10,860 | had worked? And you should enter here the size. |
| 00:00:10,860 --> 00:00:12,850 | And the second question I'm going to ask is how |
| 00:00:12,850 --> 00:00:15,070 | many LOC or how many lines of code per |
| 00:00:15,070 --> 00:00:15,070 | day you were producing when working on this system? |