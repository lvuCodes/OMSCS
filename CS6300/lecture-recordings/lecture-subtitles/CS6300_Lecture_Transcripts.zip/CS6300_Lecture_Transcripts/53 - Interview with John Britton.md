# CS6300 53 - Interview with John Britton

| Timestamp | Content |
|-----------|---------|
| 00:00:00,170 --> 00:00:02,630 | >> And I thought that the best way to break the ice on version |
| 00:00:02,630 --> 00:00:04,970 | control systems and Git and some other |
| 00:00:04,970 --> 00:00:07,939 | related concepts was to interview John Britton who |
| 00:00:07,939 --> 00:00:11,840 | works with GitHub. So let's go and see what John has to say about |
| 00:00:11,840 --> 00:00:14,120 | Git, about version control systems in general, |
| 00:00:14,120 --> 00:00:17,809 | and about GitHub. John is in Tapei, if I'm not wrong. |
| 00:00:17,809 --> 00:00:18,610 | >> That's correct. |
| 00:00:18,610 --> 00:00:20,320 | >> Okay so we're, you know we couldn't |
| 00:00:20,320 --> 00:00:22,570 | go there so we're interviewing him remotely. And I |
| 00:00:22,570 --> 00:00:25,490 | want, I just want to thank you so much and John for agreeing to talk to us. |
| 00:00:25,490 --> 00:00:27,940 | >> Thank you very much for having me it was my pleasure. |
| 00:00:27,940 --> 00:00:30,560 | >> And, I'm just going to ask, a few |
| 00:00:30,560 --> 00:00:32,938 | general questions because John is an expert on, |
| 00:00:32,938 --> 00:00:36,270 | Git and GitHub. John is a developer and |
| 00:00:36,270 --> 00:00:38,550 | a community builder is active in both the |
| 00:00:38,550 --> 00:00:42,200 | open source and the open education areas. And |
| 00:00:42,200 --> 00:00:44,860 | as an educational liaison we have, is working |
| 00:00:44,860 --> 00:00:47,580 | to improve Computer Science education by bringing the |
| 00:00:47,580 --> 00:00:51,460 | principles of open source into the classroom. And |
| 00:00:51,460 --> 00:00:53,160 | I'm going to start with an general question, |
| 00:00:53,160 --> 00:00:55,320 | which is what is a version control system? |
| 00:00:55,320 --> 00:00:57,960 | >> So, a version control system is |
| 00:00:57,960 --> 00:01:00,360 | a tool that software developers use. Anybody |
| 00:01:00,360 --> 00:01:02,560 | who's doing you know, working with digital |
| 00:01:02,560 --> 00:01:06,540 | assets, digital projects can also use for |
| 00:01:06,540 --> 00:01:11,320 | keeping track of, you know, revisions of your project, and when I say revisions, I |
| 00:01:11,320 --> 00:01:16,850 | mean essentially snapshots of your project over time. So you can imagine doing |
| 00:01:16,850 --> 00:01:19,720 | some work and then every so often, be it, every couple of |
| 00:01:19,720 --> 00:01:24,880 | hours, every couple of days, saving a permanent snapshot of your project. |
| 00:01:24,880 --> 00:01:26,650 | >> Why is this useful? I understand that |
| 00:01:26,650 --> 00:01:28,720 | it is nice to take a snapshot of your |
| 00:01:28,720 --> 00:01:30,070 | project, but what did you do with the |
| 00:01:30,070 --> 00:01:33,420 | snapshot afterwards? I think the most immediately obvious benefit |
| 00:01:33,420 --> 00:01:36,340 | to having snapshots of your project to keeping |
| 00:01:36,340 --> 00:01:38,280 | revisions is that you can go back. If you |
| 00:01:38,280 --> 00:01:40,190 | have ever worked on a project and got to |
| 00:01:40,190 --> 00:01:41,940 | a point where you solved a bunch of your |
| 00:01:41,940 --> 00:01:45,330 | problems, and there is just one more step to do. And |
| 00:01:45,330 --> 00:01:47,640 | you start working on trying to solve that last step, and |
| 00:01:47,640 --> 00:01:51,350 | you break things, you make it worse then it was an |
| 00:01:51,350 --> 00:01:54,420 | hour ago. At that point its easier to just go back |
| 00:01:54,420 --> 00:01:56,780 | to what you had then trying to figure out what you |
| 00:01:56,780 --> 00:01:59,320 | broke. So you can always go back in time, and the |
| 00:01:59,320 --> 00:02:02,660 | other big one is being able to collaborate with multiple people, |
| 00:02:02,660 --> 00:02:07,450 | so its pretty seldom these days that you. Work on a production |
| 00:02:07,450 --> 00:02:09,860 | totally on your own. It's most common to work in, you |
| 00:02:09,860 --> 00:02:12,993 | know, in teams and small groups. And so, using a revision |
| 00:02:12,993 --> 00:02:16,340 | control system allows you to collaborate with other people. And make |
| 00:02:16,340 --> 00:02:19,060 | sure that you don't step on each other's toes as you're working. |
| 00:02:19,060 --> 00:02:21,310 | >> Alright, that's great, because those are exactly some of the |
| 00:02:21,310 --> 00:02:25,250 | topics that we're going to cover in the lesson. And so since we're |
| 00:02:25,250 --> 00:02:28,470 | going to talk about the specifics of version control system which is |
| 00:02:28,470 --> 00:02:32,660 | Git and you're definitely an expert in, in Git. So what would |
| 00:02:32,660 --> 00:02:36,510 | you say is specifically special about Git? What characterizes it |
| 00:02:36,510 --> 00:02:39,940 | and how does it compare to other version control systems. |
| 00:02:39,940 --> 00:02:43,140 | >> So if any of you have used version control systems before, you |
| 00:02:43,140 --> 00:02:47,850 | may have heard of something like subversion, CVS, or maybe a commercial solution |
| 00:02:47,850 --> 00:02:53,550 | like ProForce. I think the main important characteristics of Git are first that |
| 00:02:53,550 --> 00:02:56,050 | it's open source. And the second, |
| 00:02:56,050 --> 00:02:59,030 | that it's a distributed version control system. |
| 00:02:59,030 --> 00:03:00,430 | So what that means, the distributed version |
| 00:03:00,430 --> 00:03:04,260 | control system is essentially a system for tracking |
| 00:03:04,260 --> 00:03:07,700 | revisions of your software that doesn't have any |
| 00:03:07,700 --> 00:03:11,730 | central repository. So the biggest characteristic is that |
| 00:03:11,730 --> 00:03:14,520 | I can do my work and you can also work on the same project at |
| 00:03:14,520 --> 00:03:16,900 | the same time without communicating with each other |
| 00:03:16,900 --> 00:03:19,650 | and without communicating to a central system. |
| 00:03:19,650 --> 00:03:24,190 | >> Okay, great. And so now that we saw what Git is, what is |
| 00:03:24,190 --> 00:03:26,050 | GitHub and how does it fit into |
| 00:03:26,050 --> 00:03:29,320 | this picture of the distributed, revision control system? |
| 00:03:29,320 --> 00:03:34,800 | >> So GitHub is, the world's largest code host, and we essentially have a |
| 00:03:34,800 --> 00:03:36,940 | website where you can collaborate with people |
| 00:03:36,940 --> 00:03:39,950 | when you're writing code. There's two ways you |
| 00:03:39,950 --> 00:03:43,650 | can use GitHub. You can use it publicly for open source and you can use |
| 00:03:43,650 --> 00:03:49,660 | it in private within your team, or your company, or within your class. And, Git |
| 00:03:49,660 --> 00:03:53,960 | Hub started out just as a way to host your Git repositories. But it's |
| 00:03:53,960 --> 00:03:56,000 | actually grown into quite a bit more. It's |
| 00:03:56,000 --> 00:03:59,820 | an entire collaboration system around your code. |
| 00:03:59,820 --> 00:04:00,580 | >> How many users do you have? |
| 00:04:00,580 --> 00:04:03,620 | >> I would say that we're approaching five million. |
| 00:04:03,620 --> 00:04:05,570 | I don't know the exact number. We're definitely more |
| 00:04:05,570 --> 00:04:08,080 | than four million right now. But yeah, I'd say |
| 00:04:08,080 --> 00:04:10,330 | somewhere, somewhere close to between four and five million. |
| 00:04:10,330 --> 00:04:14,750 | >> So that's a lot space I'd guess. Terabytes of disk |
| 00:04:14,750 --> 00:04:15,840 | space, I would imagine. |
| 00:04:15,840 --> 00:04:19,170 | >> There are a lot of GIT repositories on, on our servers. |
| 00:04:19,170 --> 00:04:21,180 | >> Something else you want to say? I |
| 00:04:21,180 --> 00:04:23,920 | guess that the when taking about GitHub there's one |
| 00:04:23,920 --> 00:04:26,110 | thing that you kind of can't leave out and |
| 00:04:26,110 --> 00:04:28,670 | that's that's a feature that's called a pull request. |
| 00:04:28,670 --> 00:04:31,090 | So when you're using GitHub, you can share |
| 00:04:31,090 --> 00:04:34,940 | your Git repository, do some work, and actually do |
| 00:04:34,940 --> 00:04:37,880 | do a code review. Of proposed changes which |
| 00:04:37,880 --> 00:04:39,770 | is what we call a pull request on github.com. |
| 00:04:39,770 --> 00:04:42,790 | Essentially what it let's you do is have a discussion |
| 00:04:42,790 --> 00:04:46,320 | about a set of proposed changes and leave feedback in |
| 00:04:46,320 --> 00:04:48,870 | line with the code. You could say for example, this |
| 00:04:48,870 --> 00:04:51,670 | method needs to be re-factored or I think I found if |
| 00:04:51,670 --> 00:04:54,830 | off by one error here, just different kinds of feedback |
| 00:04:54,830 --> 00:04:59,120 | so that before you totally integrate some proposed changes. You have, |
| 00:04:59,120 --> 00:05:01,180 | kind of a conversation about what your code. And I |
| 00:05:01,180 --> 00:05:03,050 | think that's really valuable when you are working in a team. |
| 00:05:03,050 --> 00:05:05,510 | >> Thank you, John, that was very informative and |
| 00:05:05,510 --> 00:05:07,440 | thanks again for taking the time to talk to us. |
| 00:05:07,440 --> 00:05:10,160 | >> No problem, thanks for having me. I'll talk to you soon. |
| 00:05:10,160 --> 00:05:13,990 | >> Let's thank again John for enlightening us |
| 00:05:13,990 --> 00:05:17,350 | on some aspects of version control systems, Git and |
| 00:05:17,350 --> 00:05:19,410 | GitHub. And now, let's go over some of the |
| 00:05:19,410 --> 00:05:19,410 | topics that we discussed with John to recap them. |