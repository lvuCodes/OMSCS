# CS6300 124 - Class Diagram_ Class

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:02,370 | So how do we represent a class in a class |
| 00:00:02,370 --> 00:00:06,140 | diagram? Class is represented as a rectangle with three parts. The |
| 00:00:06,140 --> 00:00:09,290 | first part is the class name. Classes should be named using |
| 00:00:09,290 --> 00:00:12,160 | the vocabulary of the domain, so we should pick names that |
| 00:00:12,160 --> 00:00:16,059 | make sense. And the normal naming standard requires that the classes |
| 00:00:16,059 --> 00:00:19,720 | are singular nouns starting with a capital letter. The second part |
| 00:00:19,720 --> 00:00:22,840 | of the class are the attributes of the class, where the |
| 00:00:22,840 --> 00:00:25,310 | set of attribute for the class, we find the state for |
| 00:00:25,310 --> 00:00:27,940 | the class. And, we can list an attribute simply by |
| 00:00:27,940 --> 00:00:31,060 | name, or we can provide the additional information. For example, |
| 00:00:31,060 --> 00:00:33,520 | we might define the title of the attribute, and we |
| 00:00:33,520 --> 00:00:37,450 | might also define the initial. Value for the attribute. Finally, the |
| 00:00:37,450 --> 00:00:40,850 | third part of the class consist of the operations of |
| 00:00:40,850 --> 00:00:44,050 | the class. And normally, the operations of the class are represented |
| 00:00:44,050 --> 00:00:47,090 | by name, with a list of arguments. That the operation |
| 00:00:47,090 --> 00:00:50,340 | will take as input, and with a result type. So the |
| 00:00:50,340 --> 00:00:53,750 | type of the result produced by the operation. Something |
| 00:00:53,750 --> 00:00:55,940 | else you can notice in this representation is the |
| 00:00:55,940 --> 00:00:58,450 | fact that there is a minus before these attributes |
| 00:00:58,450 --> 00:01:01,810 | and a plus before this operation. This indicates what is |
| 00:01:01,810 --> 00:01:04,739 | called the visibility of these class members. So the |
| 00:01:04,739 --> 00:01:08,950 | minus indicates that the attributes are private to the class. |
| 00:01:08,950 --> 00:01:12,600 | So only instances of this class, roughly speaking, can |
| 00:01:12,600 --> 00:01:15,340 | access these attributes. And notice that this is what allows |
| 00:01:15,340 --> 00:01:19,030 | to enforce the information hiding principle, because clients of |
| 00:01:19,030 --> 00:01:22,000 | the class cannot see what's inside this box, what are |
| 00:01:22,000 --> 00:01:25,360 | these attributes. The plus conversely indicates that this is a |
| 00:01:25,360 --> 00:01:28,850 | public operation. So something that is visible outside the class. |
| 00:01:28,850 --> 00:01:30,790 | And, in fact, normally, this is what we use to |
| 00:01:30,790 --> 00:01:35,110 | define the interface for my class. So we encapsulate the |
| 00:01:35,110 --> 00:01:37,730 | state of the class and we make it accessible to |
| 00:01:37,730 --> 00:01:40,370 | the extent that we want and that is needed through |
| 00:01:40,370 --> 00:01:43,850 | a set of public operations. Last thing I want to |
| 00:01:43,850 --> 00:01:46,730 | note is the use of these ellipses that we can |
| 00:01:46,730 --> 00:01:49,520 | utilize if we want to indicate that there are more |
| 00:01:49,520 --> 00:01:52,400 | attributes for example, or more operations. But we just don't |
| 00:01:52,400 --> 00:01:55,160 | want to list them now. Okay now that we know what |
| 00:01:55,160 --> 00:01:58,020 | a class is, and how it is represented, let's start |
| 00:01:58,020 --> 00:02:02,150 | our analysis of our course management system. By identifying the |
| 00:02:02,150 --> 00:02:05,530 | relevant classes in the system, we need to bring back the |
| 00:02:05,530 --> 00:02:08,270 | description of our system. And what we want to |
| 00:02:08,270 --> 00:02:10,389 | do, is that we want to go through the description |
| 00:02:10,389 --> 00:02:14,840 | and underline the relevant nouns in the description. And here |
| 00:02:14,840 --> 00:02:17,020 | I encourage you to stop the video and to do |
| 00:02:17,020 --> 00:02:20,450 | the exercise of underlying such nouns yourself before listening to |
| 00:02:20,450 --> 00:02:23,910 | my explanation into how I do it. For example in |
| 00:02:23,910 --> 00:02:28,030 | this case I might want to underlined the registration manager which |
| 00:02:28,030 --> 00:02:30,820 | is a noun and probably a relevant one. The scheduling |
| 00:02:30,820 --> 00:02:33,800 | algorithm, also seems like a relevant concept, so |
| 00:02:33,800 --> 00:02:37,890 | is the course. The course offerings, again, course offerings |
| 00:02:37,890 --> 00:02:40,930 | over here. Definitely, the students seem to be a |
| 00:02:40,930 --> 00:02:44,750 | relevant noun and so is probably the registration form |
| 00:02:44,750 --> 00:02:47,140 | and the professors. Okay, so, at this point, I |
| 00:02:47,140 --> 00:02:50,630 | identified seven possible classes for my system. So, what |
| 00:02:50,630 --> 00:02:53,340 | I'm going to do is simply to create classes for |
| 00:02:53,340 --> 00:02:55,980 | each one of these nouns. So my initial class |
| 00:02:55,980 --> 00:03:00,100 | diagram looks exactly like this, with the seven classes where |
| 00:03:00,100 --> 00:03:03,140 | for each class, I picked the name that is representative of |
| 00:03:03,140 --> 00:03:05,680 | the domain. So, in this case, it's pretty straightforward. The |
| 00:03:05,680 --> 00:03:08,950 | registration form is called registration form, the student is called student |
| 00:03:08,950 --> 00:03:10,780 | and so on and so forth. But you can already |
| 00:03:10,780 --> 00:03:14,490 | see how this analysis method is starting from a description of |
| 00:03:14,490 --> 00:03:17,950 | the real world and it's just identifying objects or classes |
| 00:03:17,950 --> 00:03:21,240 | in the real world and transforming them into entities in my |
| 00:03:21,240 --> 00:03:21,240 | analysis document. |