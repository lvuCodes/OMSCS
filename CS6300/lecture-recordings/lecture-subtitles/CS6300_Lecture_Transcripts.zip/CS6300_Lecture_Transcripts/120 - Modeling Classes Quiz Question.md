# CS6300 120 - Modeling Classes Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,190 --> 00:00:02,890 | Now let's see how object oriented analysis might work |
| 00:00:02,890 --> 00:00:06,640 | in practice by considering the following requirement for an online |
| 00:00:06,640 --> 00:00:10,230 | shopping website. The requirement says that users can add |
| 00:00:10,230 --> 00:00:12,890 | more than one item on sale at a time to |
| 00:00:12,890 --> 00:00:15,590 | a shopping cart. So, looking at this requirement I |
| 00:00:15,590 --> 00:00:18,180 | would like you to tell me which of the following |
| 00:00:18,180 --> 00:00:21,285 | elements should be modeled as classes. And the elements |
| 00:00:21,285 --> 00:00:25,650 | are: item, sale, shopping cart, time and user. So mark |
| 00:00:25,650 --> 00:00:25,650 | all that apply. |