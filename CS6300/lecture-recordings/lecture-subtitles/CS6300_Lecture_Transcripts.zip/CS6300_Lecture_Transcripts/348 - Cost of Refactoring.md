# CS6300 348 - Cost of Refactoring

| Timestamp | Content |
|-----------|---------|
| 00:00:00,080 --> 00:00:03,800 | Let's also talk about the cost of refactoring. Refactoring might be |
| 00:00:03,800 --> 00:00:06,750 | free or almost free if you're using a tool to do refactoring |
| 00:00:06,750 --> 00:00:08,570 | as we did in our demo. But that's not always the |
| 00:00:08,570 --> 00:00:12,530 | case. In many cases, refactoring involves quite a bit of manual work |
| 00:00:12,530 --> 00:00:16,309 | if you're doing some manual refactoring. And how much that costs |
| 00:00:16,309 --> 00:00:19,460 | depends on how well the operations on the source code are supported. |
| 00:00:19,460 --> 00:00:22,379 | You might have partial support from an ID. You might have complete |
| 00:00:22,379 --> 00:00:25,017 | support, in which case it's greater. Or you might have no support, |
| 00:00:25,017 --> 00:00:26,879 | in which case you have to be very careful about |
| 00:00:26,879 --> 00:00:28,888 | how you change your code and how you check that you |
| 00:00:28,888 --> 00:00:32,030 | didn't change the behavior of the code. There's also an additional |
| 00:00:32,030 --> 00:00:34,460 | cost associated with refactoring. Remember |
| 00:00:34,460 --> 00:00:36,990 | that refactoring relies heavily on testing |
| 00:00:36,990 --> 00:00:39,808 | after each small step of refactoring. So you might have |
| 00:00:39,808 --> 00:00:43,451 | to develop test cases, specifically to check your refactoring. And even |
| 00:00:43,451 --> 00:00:47,163 | if you have an existing test because, for example, you're working |
| 00:00:47,163 --> 00:00:50,235 | some agile context and therefore you develop a lot of UNIX |
| 00:00:50,235 --> 00:00:53,550 | test cases before writing your code. And therefore you have a good |
| 00:00:53,550 --> 00:00:56,635 | regression test with it you can use every time you modify your code. |
| 00:00:56,635 --> 00:00:59,550 | Nevertheless, when you refactor and you change your code, you might need |
| 00:00:59,550 --> 00:01:03,255 | to update your test so it's not only the development of the test |
| 00:01:03,255 --> 00:01:05,379 | cases but also it's maintaining the test cases. And if you have |
| 00:01:05,379 --> 00:01:07,970 | a lot of test cases, you have to maintain more test cases. So |
| 00:01:07,970 --> 00:01:12,460 | that's a cost that is not directly visible but can affect quite |
| 00:01:12,460 --> 00:01:15,800 | a bit the overall cost of refactoring and the overall cost of system |
| 00:01:15,800 --> 00:01:18,342 | development therefore. And finally, you should not |
| 00:01:18,342 --> 00:01:21,191 | under estimate the cost of documentation maintenance. |
| 00:01:21,191 --> 00:01:24,241 | Applying refactoring may involve changes in interfaces, |
| 00:01:24,241 --> 00:01:26,528 | names, for example, names of classes. And |
| 00:01:26,528 --> 00:01:29,384 | when you make this kind of changes, you might need to update the documentation, |
| 00:01:29,384 --> 00:01:30,890 | and that's also cost. It's something that |
| 00:01:30,890 --> 00:01:30,890 | takes effort and therefore should be considered. |