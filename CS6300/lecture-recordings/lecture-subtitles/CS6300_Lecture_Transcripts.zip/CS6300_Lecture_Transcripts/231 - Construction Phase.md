# CS6300 231 - Construction Phase

| Timestamp | Content |
|-----------|---------|
| 00:00:00,230 --> 00:00:03,170 | So if the elaboration phase is successful, we then move |
| 00:00:03,170 --> 00:00:06,560 | to the construction phase, which is our third phase. And |
| 00:00:06,560 --> 00:00:09,550 | the construction phase is basically the phase in which most |
| 00:00:09,550 --> 00:00:13,860 | of the actual development occurs. In short, all the features considered |
| 00:00:13,860 --> 00:00:17,360 | are developed. So we'll continue with our car metaphor that |
| 00:00:17,360 --> 00:00:19,310 | we used for the prototype. And in this case we |
| 00:00:19,310 --> 00:00:22,390 | will have our complete car ready. Not only the features |
| 00:00:22,390 --> 00:00:25,940 | are developed but they're also thoroughly tested. So we have performed |
| 00:00:25,940 --> 00:00:29,490 | quality assurance. We have verified and validated the software, |
| 00:00:29,490 --> 00:00:32,580 | the system and we know that it works correctly. Or |
| 00:00:32,580 --> 00:00:34,620 | at least that it works correctly as far as |
| 00:00:34,620 --> 00:00:37,850 | we can tell. So, in general, the construction phase is |
| 00:00:37,850 --> 00:00:39,760 | the phase in which there is a shift in |
| 00:00:39,760 --> 00:00:42,640 | emphasis from intellectual property development |
| 00:00:42,640 --> 00:00:45,460 | to product development. From ideas |
| 00:00:45,460 --> 00:00:47,650 | to products. So, what is the outcome of the |
| 00:00:47,650 --> 00:00:51,250 | construction phase? Well, basically the construction phrase produces a product |
| 00:00:51,250 --> 00:00:54,520 | that is ready to be deployed to the users. Specifically, |
| 00:00:54,520 --> 00:00:57,570 | the phase generates the following outcomes. First of all, at the |
| 00:00:57,570 --> 00:01:00,150 | end of this phase, all the use cases have been |
| 00:01:00,150 --> 00:01:03,220 | realized with traceability information. What does that mean? It means that |
| 00:01:03,220 --> 00:01:06,640 | not only all the functionality expressed by the use cases |
| 00:01:06,640 --> 00:01:10,240 | have been implemented, but also that we have traceability information from |
| 00:01:10,240 --> 00:01:13,530 | the use cases, to the different artifacts. So for example, |
| 00:01:13,530 --> 00:01:16,780 | we know which part of the design realizes which use case. |
| 00:01:16,780 --> 00:01:19,230 | We know which part of the implementation is related to a |
| 00:01:19,230 --> 00:01:22,150 | given use case. Which use cases were derived from a use |
| 00:01:22,150 --> 00:01:24,390 | case, and so on and so forth. And in this way |
| 00:01:24,390 --> 00:01:28,310 | we can trace our requirements throughout the system. Throughout the different |
| 00:01:28,310 --> 00:01:32,162 | artifacts that were developed during the software process. As we were |
| 00:01:32,162 --> 00:01:35,790 | saying, we also have complete software product here, which is integrated |
| 00:01:35,790 --> 00:01:39,240 | on all the needed platforms. Since the system, the software product, |
| 00:01:39,240 --> 00:01:42,200 | has to be thoroughly tested, we will also have a complete |
| 00:01:42,200 --> 00:01:44,900 | set of results for our tests. As part of this |
| 00:01:44,900 --> 00:01:47,980 | phase, we will also finalize the user manual, so you'll have |
| 00:01:47,980 --> 00:01:51,050 | a user manual ready to be provided to the users, and |
| 00:01:51,050 --> 00:01:53,700 | ready to be used. And finally, we will have a complete |
| 00:01:53,700 --> 00:01:58,370 | set of artifacts that include design documents, code, test cases, and |
| 00:01:58,370 --> 00:02:00,440 | so on and so forth, so basically all of the artifacts |
| 00:02:00,440 --> 00:02:04,240 | that have been produced during the development process. So roughly speaking, |
| 00:02:04,240 --> 00:02:07,280 | we can consider the product that is produced at the end |
| 00:02:07,280 --> 00:02:10,570 | of this phase as a typical beta release. So in case |
| 00:02:10,570 --> 00:02:12,920 | you're not familiar with that, a beta release is an initial |
| 00:02:12,920 --> 00:02:16,050 | release normally meant for a selected subset of users. So it |
| 00:02:16,050 --> 00:02:19,250 | is something that is not quite yet ready for primetime, but |
| 00:02:19,250 --> 00:02:22,540 | almost. So let's see also in this case, what are the evaluation |
| 00:02:22,540 --> 00:02:25,740 | criteria for the construction phase. So how do we assess, that |
| 00:02:25,740 --> 00:02:29,620 | this third milestone has been accomplished, successfully? We pretty much have |
| 00:02:29,620 --> 00:02:32,510 | a complete product ready to be shipped right? So the first question |
| 00:02:32,510 --> 00:02:35,260 | we want to ask is, whether the product is stable and mature |
| 00:02:35,260 --> 00:02:37,910 | enough to be deployed to users. At the end of this |
| 00:02:37,910 --> 00:02:40,510 | phase it has to be. Are the stakeholders ready for the |
| 00:02:40,510 --> 00:02:44,160 | transition into the user community? Are we ready to go from development |
| 00:02:44,160 --> 00:02:45,450 | to production? Are the actual |
| 00:02:45,450 --> 00:02:48,060 | resource expenditures versus the planned expenditures |
| 00:02:48,060 --> 00:02:50,890 | still acceptable? So what this means is that at this point we |
| 00:02:50,890 --> 00:02:54,660 | can really assess whether our estimates were accurate enough with respect |
| 00:02:54,660 --> 00:02:57,740 | to what we actually spent for the project up to this point. |
| 00:02:57,740 --> 00:03:00,390 | So unless we can answer in a positive way to |
| 00:03:00,390 --> 00:03:03,790 | all these questions, the transition might be postponed by one release. |
| 00:03:03,790 --> 00:03:05,930 | Because that means that we're still not ready to go |
| 00:03:05,930 --> 00:03:05,930 | to the market. We're still not ready to deploy our product. |