# CS6300 170 - Architectural Degradation

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:02,790 | And there are two important and related concepts that |
| 00:00:02,790 --> 00:00:04,790 | have to do with the way software architecture |
| 00:00:04,790 --> 00:00:08,109 | evolves. The first one is Architectural Drift, which is |
| 00:00:08,109 --> 00:00:12,140 | the introduction of architectural design decisions that are orthogonal to |
| 00:00:12,140 --> 00:00:15,870 | a system's prescriptive architecture. That is, they're not included |
| 00:00:15,870 --> 00:00:20,080 | in, encompassed by, or implied by the prescriptive architecture. |
| 00:00:20,080 --> 00:00:22,300 | And the result of Architectural Drift is that you |
| 00:00:22,300 --> 00:00:25,220 | start from a clean architecture, like the one that I'm |
| 00:00:25,220 --> 00:00:28,830 | showing here, and then you start adding pieces without following a clear plan. |
| 00:00:28,830 --> 00:00:32,229 | Like, for example, here, we add an additional room here, but we don't really |
| 00:00:32,229 --> 00:00:34,380 | do it in the right way so we need to add something else |
| 00:00:34,380 --> 00:00:37,090 | to keep it stable. And then maybe we want some more room so we |
| 00:00:37,090 --> 00:00:40,310 | add a tent. And then another side of the house, it doesn't really |
| 00:00:40,310 --> 00:00:43,540 | follow the same architecture but it doesn't matter, we just put it there because |
| 00:00:43,540 --> 00:00:46,690 | we want to expand. And maybe then we want to put something classic |
| 00:00:46,690 --> 00:00:48,210 | there, even though it doesn't really fit |
| 00:00:48,210 --> 00:00:50,520 | the overall design and the overall architecture. |
| 00:00:50,520 --> 00:00:52,160 | So I think you get my point, the fact |
| 00:00:52,160 --> 00:00:56,210 | that the architecture then becomes unnecessarily complex, hard to understand |
| 00:00:56,210 --> 00:00:58,410 | and ultimately awkward, just like the one that I'm |
| 00:00:58,410 --> 00:01:00,880 | showing here, that goes from the original building into this |
| 00:01:00,880 --> 00:01:04,870 | final monstrosity. The second concept is Architectural Erosion, which |
| 00:01:04,870 --> 00:01:08,560 | is the introduction of architectural design decisions that violate a |
| 00:01:08,560 --> 00:01:12,070 | system prescriptive architecture. So in this case, that we were |
| 00:01:12,070 --> 00:01:14,070 | introducing decisions that were orthogonal, |
| 00:01:14,070 --> 00:01:15,580 | here, were introducing this decisions |
| 00:01:15,580 --> 00:01:17,410 | that don't comply with the prescriptive |
| 00:01:17,410 --> 00:01:20,140 | architecture. And the result of Architectural Erosion |
| 00:01:20,140 --> 00:01:22,590 | is typically a poor architecture an |
| 00:01:22,590 --> 00:01:24,550 | architecture that is going to have problems in |
| 00:01:24,550 --> 00:01:27,040 | the future. So both Architectural Drift |
| 00:01:27,040 --> 00:01:29,640 | and Architectural Erosion take you away in |
| 00:01:29,640 --> 00:01:29,640 | different ways from what you think your software architecture is or should be. |