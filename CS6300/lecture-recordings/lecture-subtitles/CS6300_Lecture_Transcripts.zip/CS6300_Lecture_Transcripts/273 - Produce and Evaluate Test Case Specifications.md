# CS6300 273 - Produce and Evaluate Test Case Specifications

| Timestamp | Content |
|-----------|---------|
| 00:00:00,130 --> 00:00:03,200 | Before getting to our demo, we still have two steps to consider. |
| 00:00:03,200 --> 00:00:06,570 | The first step corresponds to the identification of the test case specifications |
| 00:00:06,570 --> 00:00:09,890 | in our general systematic approach. And in fact, it's called produce and |
| 00:00:09,890 --> 00:00:13,410 | evaluate test case specifications. This is a step than can be completely |
| 00:00:13,410 --> 00:00:16,590 | automated given the results of the previous steps. And the final result |
| 00:00:16,590 --> 00:00:19,860 | of this step is the production of a set of test frames. |
| 00:00:19,860 --> 00:00:22,820 | Where a test frame is the specification of a test. Let me |
| 00:00:22,820 --> 00:00:25,330 | show you an example of this. What we are looking at here |
| 00:00:25,330 --> 00:00:28,380 | is a test frame for the program split. Test frames are normally |
| 00:00:28,380 --> 00:00:31,460 | identified by a sequence number. But in this case we are looking at |
| 00:00:31,460 --> 00:00:34,290 | the 30th six test frame. And what they do is simply to |
| 00:00:34,290 --> 00:00:38,280 | specify the characteristic of the inputs for that test. In this case, since |
| 00:00:38,280 --> 00:00:40,920 | we have two inputs, we have two entries, the first one for |
| 00:00:40,920 --> 00:00:44,010 | string str tells us that the length of the string has to be |
| 00:00:44,010 --> 00:00:47,840 | size minus 1, and that the string has to contain special characters. And |
| 00:00:47,840 --> 00:00:50,380 | for size, it tells us that the value of size has to be |
| 00:00:50,380 --> 00:00:53,340 | greater than zero. As the title says, this step is meant |
| 00:00:53,340 --> 00:00:56,790 | to produce but also evaluate the case specification. What does it mean |
| 00:00:56,790 --> 00:01:00,070 | to evaluate? One of the advantages of this approach is that we |
| 00:01:00,070 --> 00:01:03,420 | can easily use it to assess how many test frames and therefore |
| 00:01:03,420 --> 00:01:06,120 | how many test cases we will generate with the current least |
| 00:01:06,120 --> 00:01:09,340 | of categories, choices and constraints. And the beauty of this is that |
| 00:01:09,340 --> 00:01:12,320 | if the number is too large we can just add additional constraints |
| 00:01:12,320 --> 00:01:15,840 | and reduce it. And given then the step is automated we just |
| 00:01:15,840 --> 00:01:19,030 | add constraints push a button and we get our new set of |
| 00:01:19,030 --> 00:01:21,580 | test frames. And again we can have a wait it either go |
| 00:01:21,580 --> 00:01:24,560 | hat or add more constraints if we need to further reduce it |
| 00:01:24,560 --> 00:01:24,560 | and this is something else that we will see in our demo. |