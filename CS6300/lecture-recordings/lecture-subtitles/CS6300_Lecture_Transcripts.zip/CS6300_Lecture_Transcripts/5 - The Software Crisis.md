# CS6300 5 - The Software Crisis

| Timestamp | Content |
|-----------|---------|
| 00:00:00,072 --> 00:00:02,190 | To do that we'll have to go back in time to |
| 00:00:02,190 --> 00:00:05,280 | the late 60s. So what was happening in the 60s? Well for |
| 00:00:05,280 --> 00:00:08,410 | example the first man landed on the moon. That was also |
| 00:00:08,410 --> 00:00:11,720 | time when Woodstock took place and also the time when the first |
| 00:00:11,720 --> 00:00:16,149 | 60 second picture from Polaroid was created. Concurrently to these events, |
| 00:00:16,149 --> 00:00:18,910 | which you probably didn't witness in first person, that was also the |
| 00:00:18,910 --> 00:00:22,280 | time when people started to realize that they were not able |
| 00:00:22,280 --> 00:00:25,610 | to build the software they needed. This happened for several reasons and |
| 00:00:25,610 --> 00:00:29,220 | resulted in what we call the software crisis. So let's |
| 00:00:29,220 --> 00:00:31,820 | look at some of the most important reasons behind this |
| 00:00:31,820 --> 00:00:35,760 | crisis. The first cause was the rising demand for software. |
| 00:00:35,760 --> 00:00:38,500 | Now you're used to see software everywhere: in your phone, |
| 00:00:38,500 --> 00:00:41,530 | in your car, even your washing machine. Before the 60s, |
| 00:00:41,530 --> 00:00:44,590 | however, the size and complexity of software was very limited |
| 00:00:44,590 --> 00:00:47,580 | and hardware components were really dominating the scene. Then things |
| 00:00:47,580 --> 00:00:51,490 | started to change and software started to be increasingly prevalent. |
| 00:00:51,490 --> 00:00:53,940 | So we move from a situation where everything was mostly |
| 00:00:53,940 --> 00:00:57,380 | hardware to a situation in which software became more and more |
| 00:00:57,380 --> 00:01:00,660 | important. To give an example, I'm going to show you the growth |
| 00:01:00,660 --> 00:01:04,080 | in the software demand at NASA along those years. And in |
| 00:01:04,080 --> 00:01:07,610 | particular, from the 1950s to more or less 2000. And this |
| 00:01:07,610 --> 00:01:10,350 | is just a qualitative plot but that's more or less the |
| 00:01:10,350 --> 00:01:13,880 | ways things went. So the demand for software in NASA grow |
| 00:01:13,880 --> 00:01:16,930 | exponentially. And the same happened in a lot of other companies. |
| 00:01:16,930 --> 00:01:19,020 | For example, just to cite one, for Boeing. So the |
| 00:01:19,020 --> 00:01:22,350 | amount of software on airplanes became larger and larger. The |
| 00:01:22,350 --> 00:01:26,170 | second cause for the software crisis was the increasing amount |
| 00:01:26,170 --> 00:01:30,210 | of development effort needed due to the increase of product complexity. |
| 00:01:30,210 --> 00:01:34,260 | Unfortunately, software complexity does not increase linearly with size. It |
| 00:01:34,260 --> 00:01:36,170 | is not the same thing to write software for a |
| 00:01:36,170 --> 00:01:39,410 | class exercise or a small project, or a temp project, |
| 00:01:39,410 --> 00:01:41,970 | than it is to build a software for a word processor, |
| 00:01:41,970 --> 00:01:45,950 | an operating system, a distributed system, or even more complex and larger |
| 00:01:45,950 --> 00:01:49,390 | system. And what I'm giving here is just an indicative size for |
| 00:01:49,390 --> 00:01:52,643 | the software so the class exercise might be 100 lines of code, |
| 00:01:52,643 --> 00:01:55,600 | the small project might be 1000 lines of code, in the other thousand |
| 00:01:55,600 --> 00:01:58,328 | lines of code, and so on and so forth. For the former, |
| 00:01:58,328 --> 00:02:01,510 | the heroic effort of an individual developer can get the job done. |
| 00:02:01,510 --> 00:02:03,850 | So that's what we call a programming effort. If you're a good |
| 00:02:03,850 --> 00:02:07,340 | programmer, you can go sit down and do it, right. For the latter, |
| 00:02:07,340 --> 00:02:09,330 | this is not possible. This is what we called the |
| 00:02:09,330 --> 00:02:13,810 | software engineering effort. In fact, no matter how much programming languages, |
| 00:02:13,810 --> 00:02:17,280 | development environments, and software tools improve, developers could not keep |
| 00:02:17,280 --> 00:02:20,220 | up with increasing software size and complexity. Which leads us to |
| 00:02:20,220 --> 00:02:22,280 | the third problem that I want to mention and the |
| 00:02:22,280 --> 00:02:25,020 | third reason for the software crisis. And this cause is the |
| 00:02:25,020 --> 00:02:28,790 | slow developer's productivity growth. So let me show this again |
| 00:02:28,790 --> 00:02:32,243 | with a qualitative diagram. And this is taken from the IEEE |
| 00:02:32,243 --> 00:02:35,550 | Software Magazine. And what I'm showing here is the growth in |
| 00:02:35,550 --> 00:02:39,930 | software size and complexity over time, and how the developers' productivity |
| 00:02:39,930 --> 00:02:43,800 | really couldn't keep up with this additional software complexity, which resulted |
| 00:02:43,800 --> 00:02:43,800 | in this gap between what was needed and what was actually available. |