# CS6300 343 - Extract Method

| Timestamp | Content |
|-----------|---------|
| 00:00:00,060 --> 00:00:02,406 | The next re-factoring which is also the last one that we'll |
| 00:00:02,406 --> 00:00:05,640 | see, extract method is one of the most commonly used re-factoring. As |
| 00:00:05,640 --> 00:00:09,080 | it is applicable in many, many situations. The starting point is |
| 00:00:09,080 --> 00:00:12,720 | a method that is too long and contains cohesive code fragments, that |
| 00:00:12,720 --> 00:00:16,180 | really serve a single very specific purpose. So we start from |
| 00:00:16,180 --> 00:00:19,270 | a cohesive code fragment in a large method. What we can do |
| 00:00:19,270 --> 00:00:22,370 | in this case, is to create a method using that code fragment. |
| 00:00:22,370 --> 00:00:25,620 | And then replacing the code fragment with a call to that method. |
| 00:00:25,620 --> 00:00:28,390 | Let's look at this with an example. Here over this method called |
| 00:00:28,390 --> 00:00:31,070 | print owing, and what it does, imagine that it does a lot |
| 00:00:31,070 --> 00:00:33,850 | of operations here that I'm just not listing, and then it's got |
| 00:00:33,850 --> 00:00:37,620 | a set of print statements. That are just printing a lot of details |
| 00:00:37,620 --> 00:00:41,280 | about the owing information. And then again, a lot of code after |
| 00:00:41,280 --> 00:00:44,270 | that. So what I could do in this case to simplify. The |
| 00:00:44,270 --> 00:00:47,940 | method is to transform this set of statements. They are cohesive in |
| 00:00:47,940 --> 00:00:51,120 | the sense that they do just one thing, they just print these details |
| 00:00:51,120 --> 00:00:53,890 | into a method, and then I had, replace the statements with a |
| 00:00:53,890 --> 00:00:56,740 | call to that method. Which is actually something similar to what we did |
| 00:00:56,740 --> 00:00:59,900 | as part of some the previous re-factoring's. Here I'm showing the result. |
| 00:00:59,900 --> 00:01:02,770 | So here is the method that I extracted. As you can see. It |
| 00:01:02,770 --> 00:01:05,790 | contains the code that was previously here. I give you the meaningful |
| 00:01:05,790 --> 00:01:09,080 | name, I called it printDetails so it's clear what it does. And now |
| 00:01:09,080 --> 00:01:12,820 | the print owning method is simpler. Because I still have the remaining code |
| 00:01:12,820 --> 00:01:17,200 | the one I didn't touch. But now this potentially long list of details. |
| 00:01:17,200 --> 00:01:20,560 | Of prints, of details is not replaced by a single method code. |
| 00:01:20,560 --> 00:01:23,550 | So a gain similar to the previous refactorings that we saw. If |
| 00:01:23,550 --> 00:01:26,370 | we just look at the printing method, it's very easy to figure |
| 00:01:26,370 --> 00:01:29,490 | out what this part does. Oh, print some details. And once more I |
| 00:01:29,490 --> 00:01:33,060 | really want to stress this. If you don't care about how, this |
| 00:01:33,060 --> 00:01:36,350 | is implemented and knowing that this print some details is enough. Then |
| 00:01:36,350 --> 00:01:38,980 | you're done. You don't need to understand anything more. It's clear, it's |
| 00:01:38,980 --> 00:01:42,430 | self explanatory. And if you'll need to look at what print details does, |
| 00:01:42,430 --> 00:01:44,390 | you just go and look at print details. And you look at |
| 00:01:44,390 --> 00:01:47,280 | it in isolation. So it's easier to understand what this does without having |
| 00:01:47,280 --> 00:01:49,640 | to think the rest of the code. So once more the color we |
| 00:01:49,640 --> 00:01:52,740 | factor in is just to improve your design, made the code more readable |
| 00:01:52,740 --> 00:01:56,020 | Make the code more maintainable. And also keep in mind all of these, |
| 00:01:56,020 --> 00:01:59,080 | are kind of small examples. You also always have to think about the |
| 00:01:59,080 --> 00:02:02,560 | effect that this can have on larger codebases. It can really improve a |
| 00:02:02,560 --> 00:02:05,280 | lot. The understandabililty, and maintainability of |
| 00:02:05,280 --> 00:02:05,280 | your code. So in general, it's design. |