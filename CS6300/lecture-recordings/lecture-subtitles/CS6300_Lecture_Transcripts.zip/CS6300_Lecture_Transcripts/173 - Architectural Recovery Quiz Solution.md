# CS6300 173 - Architectural Recovery Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:03,210 | The first sentence is definitely false. Prescriptive architecture |
| 00:00:03,210 --> 00:00:06,530 | and descriptive architecture tend to diverge as systems evolve, |
| 00:00:06,530 --> 00:00:08,960 | and sometimes, even when the system is first developed, |
| 00:00:08,960 --> 00:00:10,680 | as we will see in some of the upcoming |
| 00:00:10,680 --> 00:00:14,340 | examples. Conversely, the second sentence is true. By |
| 00:00:14,340 --> 00:00:18,150 | adding unnecessary elements to the architecture, architectural drift can |
| 00:00:18,150 --> 00:00:22,470 | transform an otherwise clean architecture into a complex sub-optimal, |
| 00:00:22,470 --> 00:00:25,960 | and often ugly, architecture. The third sentence is false. |
| 00:00:25,960 --> 00:00:30,540 | Architectural erosion and architectural drift are, indeed, different phenomena. |
| 00:00:30,540 --> 00:00:32,940 | But they both result in a less than ideal, and |
| 00:00:32,940 --> 00:00:36,160 | in some cases, highly degraded architecture. And the fourth |
| 00:00:36,160 --> 00:00:39,600 | sentence is also false, as we discussed a minute ago. |
| 00:00:39,600 --> 00:00:42,050 | Just tweaking at the code is very unlikely to |
| 00:00:42,050 --> 00:00:44,930 | improve the code. Quite the opposite, actually. The best way |
| 00:00:44,930 --> 00:00:48,420 | to repair a degraded architectural design is to first, understand |
| 00:00:48,420 --> 00:00:51,110 | the current architecture, and then, try to fix it in |
| 00:00:51,110 --> 00:00:51,110 | a more principled way. |