# CS6300 96 - Defining Requirements Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,200 --> 00:00:03,460 | So let's look at each one of these items individually, starting from |
| 00:00:03,460 --> 00:00:06,260 | the first one. And here this item has to do with how |
| 00:00:06,260 --> 00:00:08,250 | the machine stores the information and |
| 00:00:08,250 --> 00:00:10,240 | how the corresponding algorithm is written. |
| 00:00:10,240 --> 00:00:12,920 | But it has no bearing in the real world. That is, in |
| 00:00:12,920 --> 00:00:15,720 | the application domain. Therefore this. Definitely |
| 00:00:15,720 --> 00:00:17,200 | belongs to the machine domain, and |
| 00:00:17,200 --> 00:00:19,610 | we're going to put a one here. What about a notification of |
| 00:00:19,610 --> 00:00:21,980 | the arrival of a message on a smart watch? This is an |
| 00:00:21,980 --> 00:00:25,170 | event that is generated within the machine, but it has an effect, |
| 00:00:25,170 --> 00:00:28,480 | an observable effect, in this case, in the real world as well. |
| 00:00:28,480 --> 00:00:31,780 | Therefore, we're going to mark this as three. So this is an |
| 00:00:31,780 --> 00:00:33,460 | event. This is something that belongs |
| 00:00:33,460 --> 00:00:35,160 | to the intersection between the application |
| 00:00:35,160 --> 00:00:37,480 | domain and the machine domain. So it's something that could be in |
| 00:00:37,480 --> 00:00:40,730 | the specification. Now what about an employee that wants to organize a |
| 00:00:40,730 --> 00:00:43,850 | meeting with a set of colleagues? This is an event that belongs |
| 00:00:43,850 --> 00:00:46,460 | to the application domain because it is a fact that it's true |
| 00:00:46,460 --> 00:00:50,290 | that exists. In the real world independently from the existence of a machine. |
| 00:00:50,290 --> 00:00:52,380 | Therefore, we're going to mark this as two. |
| 00:00:52,380 --> 00:00:54,890 | Finally, the event of a user clicking on a |
| 00:00:54,890 --> 00:00:58,950 | link on a web page is an event that occurs in the real world but that has an |
| 00:00:58,950 --> 00:01:01,932 | effect also within the machine and, therefore, we're |
| 00:01:01,932 --> 00:01:04,920 | going to mark this as three, something that happens |
| 00:01:04,920 --> 00:01:07,730 | at the intersection. between these two domains, and once |
| 00:01:07,730 --> 00:01:07,730 | more, something that could be in a specification. |