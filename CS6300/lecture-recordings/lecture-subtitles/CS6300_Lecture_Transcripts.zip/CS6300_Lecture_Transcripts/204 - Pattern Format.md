# CS6300 204 - Pattern Format

| Timestamp | Content |
|-----------|---------|
| 00:00:00,180 --> 00:00:02,711 | So let's start by seeing how patterns are defined. So |
| 00:00:02,711 --> 00:00:05,620 | what is the format of the pattern definitions. If we look |
| 00:00:05,620 --> 00:00:08,000 | at the Gang of Four's book we can see that these |
| 00:00:08,000 --> 00:00:11,630 | definitions contain a lot of information. In fact, what I'm listing |
| 00:00:11,630 --> 00:00:14,980 | here is just a subset of this information. In this lesson, |
| 00:00:14,980 --> 00:00:17,510 | what I want to do is to focus on four essential |
| 00:00:17,510 --> 00:00:21,480 | elements of a design pattern. It's name, the intent which is |
| 00:00:21,480 --> 00:00:25,270 | the goal of the pattern. The pattern's applicability which is the |
| 00:00:25,270 --> 00:00:28,040 | list of situations or context in which the |
| 00:00:28,040 --> 00:00:31,560 | pattern is applicable. I also want to cover the structure |
| 00:00:31,560 --> 00:00:34,700 | and participants. Which is the static model that describes |
| 00:00:34,700 --> 00:00:37,870 | the elements, so normally the classes or the object |
| 00:00:37,870 --> 00:00:39,900 | involved in the pattern. In addition to that |
| 00:00:39,900 --> 00:00:41,400 | the structure also describes |
| 00:00:41,400 --> 00:00:44,420 | the relationships, responsibilities and collaborations |
| 00:00:44,420 --> 00:00:47,264 | among these classes or objects. Finally what I want |
| 00:00:47,264 --> 00:00:50,560 | to cover is sample code. So examples that illustrate |
| 00:00:50,560 --> 00:00:50,560 | the use of patterns. |