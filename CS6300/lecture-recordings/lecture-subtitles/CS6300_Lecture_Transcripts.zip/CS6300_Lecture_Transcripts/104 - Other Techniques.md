# CS6300 104 - Other Techniques

| Timestamp | Content |
|-----------|---------|
| 00:00:00,070 --> 00:00:02,370 | So just for completeness, I want to mention some other |
| 00:00:02,370 --> 00:00:05,340 | techniques besides the traditional ones that we just saw that |
| 00:00:05,340 --> 00:00:07,880 | can be used for requirements solicitation. And these other |
| 00:00:07,880 --> 00:00:10,740 | techniques can be divided in three main groups. There are |
| 00:00:10,740 --> 00:00:14,820 | collaborative techniques that were created to support incremental development |
| 00:00:14,820 --> 00:00:18,850 | of complex systems with large diverse user populations. An example |
| 00:00:18,850 --> 00:00:21,130 | of such techniques which is widely used and you |
| 00:00:21,130 --> 00:00:25,120 | might know is brainstorming. There are also social approaches and |
| 00:00:25,120 --> 00:00:28,140 | these are approaches, techniques that exploit the social |
| 00:00:28,140 --> 00:00:31,520 | sciences to better collect information from the stakeholders and |
| 00:00:31,520 --> 00:00:34,310 | the environment. And among those I just want to mention |
| 00:00:34,310 --> 00:00:36,730 | ethnographic techniques which are based on the idea of |
| 00:00:36,730 --> 00:00:40,100 | collecting information on the participants by observing them |
| 00:00:40,100 --> 00:00:44,660 | in their original environment. Finally cognitive techniques, leverage cognitive |
| 00:00:44,660 --> 00:00:48,490 | science approaches to discover expert knowledge for example they |
| 00:00:48,490 --> 00:00:51,260 | can be used to understand the problem solving methods. |
| 00:00:51,260 --> 00:00:54,000 | And in case you're interested in finding out more about this and |
| 00:00:54,000 --> 00:00:54,000 | other techniques, I'm providing some references in the notes for the lesson. |