# CS6300 182 - Deployment Architectural Perspective

| Timestamp | Content |
|-----------|---------|
| 00:00:00,180 --> 00:00:03,100 | A system cannot fulfill its purpose until it is |
| 00:00:03,100 --> 00:00:06,727 | deployed. And deploying a system involves physically placing the |
| 00:00:06,727 --> 00:00:09,960 | system's executable modules on the hardware devices on which |
| 00:00:09,960 --> 00:00:12,490 | they are supposed to run. So when you do that, |
| 00:00:12,490 --> 00:00:16,132 | you're basically mapping your components and connectors to specific |
| 00:00:16,132 --> 00:00:19,810 | hardware elements. Here in this diagram, for instance, I'm |
| 00:00:19,810 --> 00:00:22,160 | showing the same components that we saw in the |
| 00:00:22,160 --> 00:00:25,400 | previous diagram, but we see them deployed on a laptop, |
| 00:00:25,400 --> 00:00:28,620 | which is depicted here in this way, and on two |
| 00:00:28,620 --> 00:00:32,820 | smartphones that are represented here, or PDAs, if you wish. |
| 00:00:32,820 --> 00:00:34,730 | So why do we this, why do we create |
| 00:00:34,730 --> 00:00:38,540 | a deployment perspective for our architecture? Well, because the deployment |
| 00:00:38,540 --> 00:00:41,710 | view of an architecture can be critical in assessing whether |
| 00:00:41,710 --> 00:00:44,920 | the system will be able to satisfy its requirement. Because |
| 00:00:44,920 --> 00:00:47,860 | doing this mapping allows you to discover and assess other |
| 00:00:47,860 --> 00:00:50,840 | characteristics of your system that you might not have considered |
| 00:00:50,840 --> 00:00:53,440 | up to now. For instance, using a deployment view like this |
| 00:00:53,440 --> 00:00:57,030 | one and knowing the characteristics of the hardware devices, one might |
| 00:00:57,030 --> 00:01:00,056 | be able to assess the system in terms of available memory. |
| 00:01:00,056 --> 00:01:02,610 | Is there going to be enough memory available to run the system, |
| 00:01:02,610 --> 00:01:06,140 | for example, on this device? Power consumption. Is the power consumption |
| 00:01:06,140 --> 00:01:09,270 | profile going to be larger than what the device can handle? |
| 00:01:09,270 --> 00:01:12,580 | Or again the required network bandwidth. Does the system have enough |
| 00:01:12,580 --> 00:01:16,170 | network bandwidth to enable the required interactions? And so on. So all |
| 00:01:16,170 --> 00:01:19,140 | of these characteristics, all of these qualities, you can assess when |
| 00:01:19,140 --> 00:01:19,140 | you do this final mapping of the components to the hardware elements. |