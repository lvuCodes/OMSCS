# CS6300 330 - Lesson Overview

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,220 | In the previous lesson, we discussed agile |
| 00:00:02,220 --> 00:00:05,689 | software development. Its principles and practices. And two |
| 00:00:05,689 --> 00:00:10,060 | specific agile processes. XP and Scrub. In |
| 00:00:10,060 --> 00:00:12,230 | this lesson, we will introduce a practice that |
| 00:00:12,230 --> 00:00:15,020 | is of fundamental importance in the context |
| 00:00:15,020 --> 00:00:20,120 | of agile software development. Software refactoring. Software refactoring |
| 00:00:20,120 --> 00:00:22,030 | is the process of taking a program and |
| 00:00:22,030 --> 00:00:25,040 | transforming it to make it better. That is, |
| 00:00:25,040 --> 00:00:27,240 | to make it easier to understand, make it |
| 00:00:27,240 --> 00:00:29,880 | more maintainable, and in general to improve its |
| 00:00:29,880 --> 00:00:34,300 | design. Specifically, we will discuss what the refactoring |
| 00:00:34,300 --> 00:00:37,680 | is and why it is important? When to perform |
| 00:00:37,680 --> 00:00:40,980 | refactoring, and when not to perform refactoring? And |
| 00:00:40,980 --> 00:00:44,520 | how to perform refactoring in a fully automated way, |
| 00:00:44,520 --> 00:00:47,293 | using tools. We will also introduce the concept |
| 00:00:47,293 --> 00:00:50,040 | of bad smells, where a bad smell, in software, |
| 00:00:50,040 --> 00:00:53,323 | is the indication that there might be something wrong with |
| 00:00:53,323 --> 00:00:53,323 | the code that might call for the application of refactoring. |