# CS6300 195 - Identifying Operations

| Timestamp | Content |
|-----------|---------|
| 00:00:00,460 --> 00:00:03,276 | >> And before we get started actually, I'd like to mention that there's |
| 00:00:03,276 --> 00:00:05,124 | just, you know, FYI, there's different kinds |
| 00:00:05,124 --> 00:00:06,708 | of verbs because what I'm looking for |
| 00:00:06,708 --> 00:00:10,099 | is really action verbs. So verb, verbs that clearly express an action that |
| 00:00:10,099 --> 00:00:13,580 | can tell me that, you know, what, for example, an item could do, 'kay? |
| 00:00:13,580 --> 00:00:13,820 | >> Okay? |
| 00:00:13,820 --> 00:00:16,620 | >> Not the verbs that represent, for example, relationships, 'kay? |
| 00:00:16,620 --> 00:00:17,076 | >> Okay. |
| 00:00:17,076 --> 00:00:19,080 | >> So, and the, there, and the ones |
| 00:00:19,080 --> 00:00:22,020 | that I've identified und, underlined here actually, I, |
| 00:00:22,020 --> 00:00:26,158 | I underlined complete sentences so that you kind of we can look at the verbs in |
| 00:00:26,158 --> 00:00:29,150 | in context. And the first one is this |
| 00:00:29,150 --> 00:00:30,850 | sentence that says that the library may need |
| 00:00:30,850 --> 00:00:33,190 | to know or to calculate the items a |
| 00:00:33,190 --> 00:00:35,790 | patron has checked out, when they are due, and |
| 00:00:35,790 --> 00:00:38,860 | any outstanding overdue fines. So I, I will |
| 00:00:38,860 --> 00:00:41,430 | imagine that this is representing a situation in |
| 00:00:41,430 --> 00:00:44,224 | which you bring up a patron's record and |
| 00:00:44,224 --> 00:00:46,131 | you start looking up this information. Is that [CROSSTALK] |
| 00:00:46,131 --> 00:00:50,970 | >> The, the patron often wants to know what they have currently checked out. |
| 00:00:50,970 --> 00:00:51,044 | >> Oh, |
| 00:00:51,044 --> 00:00:51,282 | alright. |
| 00:00:51,282 --> 00:00:53,260 | >> Or when are their due or how much they're owed or. |
| 00:00:53,260 --> 00:00:55,100 | >> Oh, in fact, and then now that you mentioned it, |
| 00:00:55,100 --> 00:00:57,500 | I think you sent me. One of the scenarios you sent |
| 00:00:57,500 --> 00:00:59,400 | me had to do with that, right, with the patron coming |
| 00:00:59,400 --> 00:01:01,930 | in and asking for this information. So yeah, and it makes |
| 00:01:01,930 --> 00:01:05,025 | a lot of sense. So what I'm going to do, I'm going to |
| 00:01:05,025 --> 00:01:10,520 | model this by adding this three operations to the patron method. |
| 00:01:10,520 --> 00:01:13,410 | The first one, I'm going to call, itemsCheckedOut and, basically, it's an |
| 00:01:13,410 --> 00:01:16,520 | operation, but you don't need to, you know, understand the implementation |
| 00:01:16,520 --> 00:01:18,820 | details, but when you call this operation, it will |
| 00:01:18,820 --> 00:01:21,770 | give you back exactly this information, so the items |
| 00:01:21,770 --> 00:01:23,864 | that are checked out by that patron. The second |
| 00:01:23,864 --> 00:01:25,965 | one, I'm going to call it whenDue. That will tell you |
| 00:01:25,965 --> 00:01:29,080 | basically when a, when an item is due. And |
| 00:01:29,080 --> 00:01:32,550 | the third one is going to be called the outstandingOverdueFines and, |
| 00:01:32,550 --> 00:01:34,510 | you know, as the name says, it's going to tell |
| 00:01:34,510 --> 00:01:36,860 | you what are the outstanding overdue fines for that patron. |
| 00:01:36,860 --> 00:01:37,300 | >> Okay. |
| 00:01:37,300 --> 00:01:39,306 | >> And as you might notice I mean, |
| 00:01:39,306 --> 00:01:41,843 | I, I'm going to separate the, the, the attributes |
| 00:01:41,843 --> 00:01:44,085 | from the operations by having a separate kind |
| 00:01:44,085 --> 00:01:46,386 | of subrectangle so, in this way, it's clear |
| 00:01:46,386 --> 00:01:48,274 | what is attribute and what is, what is |
| 00:01:48,274 --> 00:01:51,000 | an attribute and what's an, what's an operation. |
| 00:01:51,000 --> 00:01:51,420 | >> Gotcha. |
| 00:01:51,420 --> 00:01:57,540 | >> And let me see then. Okay, for the |
| 00:01:57,540 --> 00:02:00,040 | second one you can see that that patron can check |
| 00:02:00,040 --> 00:02:02,990 | out books and audio visual materials. So I guess, |
| 00:02:02,990 --> 00:02:06,880 | similarly you, you build kind of the record for a patron. |
| 00:02:06,880 --> 00:02:09,150 | The patron will give you an item and you will record |
| 00:02:09,150 --> 00:02:11,020 | the fact that the patron is kind of checking it out. |
| 00:02:11,020 --> 00:02:15,730 | >> Right. And is that operation related to this, |
| 00:02:15,730 --> 00:02:18,150 | the checked out attribute that we did a minute ago? |
| 00:02:18,150 --> 00:02:21,495 | >> It is actually because what will happen then again, you know, if we jump |
| 00:02:21,495 --> 00:02:24,975 | ahead a little bit would be that every time you invoke this operation. So I'm |
| 00:02:24,975 --> 00:02:26,810 | going to represent this as a checkOut operation |
| 00:02:26,810 --> 00:02:28,896 | for the patron. Every time you invoke this, |
| 00:02:28,896 --> 00:02:31,920 | you will also have to say something about the item and so we will also |
| 00:02:31,920 --> 00:02:35,700 | flip kind of that that, that build information in the, in the, in the item. |
| 00:02:35,700 --> 00:02:36,904 | >> Okay. |
| 00:02:36,904 --> 00:02:39,680 | >> Mm, 'kay? And, and finally, here, I can see that |
| 00:02:39,680 --> 00:02:42,660 | a patron can request a book or an audio video item Is |
| 00:02:42,660 --> 00:02:46,240 | not currently in. So I guess this is referring to items that |
| 00:02:46,240 --> 00:02:48,980 | are already checked out but for which there is interest. Is that? |
| 00:02:48,980 --> 00:02:54,770 | >> Right. So, particularly, the popular items the patrons want to get on |
| 00:02:54,770 --> 00:02:57,140 | the list so that they get notified when it comes back in and. |
| 00:02:57,140 --> 00:02:57,204 | >> Oh. |
| 00:02:57,204 --> 00:02:57,730 | >> And check it out. |
| 00:02:57,730 --> 00:03:00,570 | >> I see. I see. Okay. Then I'm going to do |
| 00:03:00,570 --> 00:03:04,400 | the same thing here. I'm, I'm going to add this method, |
| 00:03:04,400 --> 00:03:08,510 | which I'm going to call request and I'm going to put it |
| 00:03:08,510 --> 00:03:11,340 | here in the list of the methods in the list. |
| 00:03:11,340 --> 00:03:11,450 | >> Okay. |
| 00:03:11,450 --> 00:03:11,450 | >> Of operations for the, for the patron, okay? |