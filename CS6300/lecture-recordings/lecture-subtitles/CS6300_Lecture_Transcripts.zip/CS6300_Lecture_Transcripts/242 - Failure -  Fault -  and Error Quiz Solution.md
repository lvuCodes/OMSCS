# CS6300 242 - Failure -  Fault -  and Error Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,350 --> 00:00:02,740 | And I apologize, but this was a tricky question that |
| 00:00:02,740 --> 00:00:06,770 | we cannot really answer. We really have no way to |
| 00:00:06,770 --> 00:00:08,860 | know what the error was. It could have been a |
| 00:00:08,860 --> 00:00:13,240 | typo, an erroneous copy and paste operation, or even worse |
| 00:00:13,240 --> 00:00:16,079 | a conceptual error. In case a developer did not know |
| 00:00:16,079 --> 00:00:19,910 | what it means to double a number. Unfortunately though, the |
| 00:00:19,910 --> 00:00:22,200 | developer is the only one who could actually answer this |
| 00:00:22,200 --> 00:00:25,610 | question. So even though we cannot really answer this question, |
| 00:00:25,610 --> 00:00:28,000 | having it help us think about how the |
| 00:00:28,000 --> 00:00:28,000 | error is in fact related to human behavior. |