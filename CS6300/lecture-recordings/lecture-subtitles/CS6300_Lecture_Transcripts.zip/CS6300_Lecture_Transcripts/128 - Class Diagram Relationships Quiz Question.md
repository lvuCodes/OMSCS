# CS6300 128 - Class Diagram Relationships Quiz Question

| Timestamp | Content |
|-----------|---------|
| 00:00:00,200 --> 00:00:02,840 | Before doing that, though, now that we discuss the different kinds |
| 00:00:02,840 --> 00:00:05,510 | of relationships among classes in the class diagram. I would like |
| 00:00:05,510 --> 00:00:08,230 | to ask you to look at a list of relationships that |
| 00:00:08,230 --> 00:00:11,920 | I'm providing here and mark the relationships that you think actually |
| 00:00:11,920 --> 00:00:15,120 | hold for the classes in the system that we are modeling. |
| 00:00:15,120 --> 00:00:18,260 | So here I have a list of possible relationships for each |
| 00:00:18,260 --> 00:00:22,070 | relationship. I'm first defining what the relationship is and then what |
| 00:00:22,070 --> 00:00:25,270 | kind of relationship that is, for example, for the first one I'm |
| 00:00:25,270 --> 00:00:27,500 | saying that the registration manager uses |
| 00:00:27,500 --> 00:00:30,090 | the scheduling algorithm, which is a dependency |
| 00:00:30,090 --> 00:00:33,860 | relationship. And similarly for the other ones. So like for you to go back |
| 00:00:33,860 --> 00:00:37,070 | to the example, look at the classes that we defined, think about the |
| 00:00:37,070 --> 00:00:40,360 | requirements, and identify which ones of this |
| 00:00:40,360 --> 00:00:40,360 | relationships you think hold in the system. |
![[lvu 2026-02-15 at 03.15PM.png]]