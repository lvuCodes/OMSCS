# CS6300 223 - Iterative and Incremental

| Timestamp | Content |
|-----------|---------|
| 00:00:00,190 --> 00:00:03,100 | We just saw two of the three distinguishing aspects of |
| 00:00:03,100 --> 00:00:05,800 | the rational unified process. The fact that it is used |
| 00:00:05,800 --> 00:00:08,810 | case driven and the fact that it is architecture centric. |
| 00:00:08,810 --> 00:00:11,950 | The third and final distinguished aspect of R.U.P. is that |
| 00:00:11,950 --> 00:00:15,210 | it is iterative and incremental. So let's see what that |
| 00:00:15,210 --> 00:00:18,870 | means by considering the lifetime of a software project. Basically, |
| 00:00:18,870 --> 00:00:22,120 | the lifetime of a rational unified process consists of a |
| 00:00:22,120 --> 00:00:24,920 | series of cycles, such as the ones that are represented here. |
| 00:00:24,920 --> 00:00:28,070 | Cycle one, cycle two, through cycle n. And as |
| 00:00:28,070 --> 00:00:30,990 | you can see, these cycles can also be called increments. |
| 00:00:30,990 --> 00:00:33,280 | And each one of the cycles involves all of |
| 00:00:33,280 --> 00:00:36,700 | the main phases of software development. In addition, each cycle |
| 00:00:36,700 --> 00:00:39,700 | results in a product release which can be internal |
| 00:00:39,700 --> 00:00:43,210 | or external. More precisely, each cycle terminates with a product |
| 00:00:43,210 --> 00:00:46,340 | release that includes a complete set of artifacts for |
| 00:00:46,340 --> 00:00:50,150 | the project. That means code, manuals, use cases, non-functional |
| 00:00:50,150 --> 00:00:52,840 | specification, test cases, and so on. So, I've just |
| 00:00:52,840 --> 00:00:55,760 | said, that each cycle involves all of the main phases |
| 00:00:55,760 --> 00:00:59,440 | of software development. Specifically, each cycle is further divided |
| 00:00:59,440 --> 00:01:04,040 | in four phases. Inception, elaboration, construction and transition. In a |
| 00:01:04,040 --> 00:01:06,290 | minute, we will look at each one of these |
| 00:01:06,290 --> 00:01:08,840 | phases in detail and see how they relate to the |
| 00:01:08,840 --> 00:01:12,150 | traditional activities of software development. Before that, I want |
| 00:01:12,150 --> 00:01:15,760 | to mention the last level of these iterations, which happens |
| 00:01:15,760 --> 00:01:20,330 | within these individual phases More precisely, inside each of these |
| 00:01:20,330 --> 00:01:24,230 | phases, there might be multiple iterations. So what are these |
| 00:01:24,230 --> 00:01:28,070 | iterations? Well, basically, each iteration corresponds to a group of |
| 00:01:28,070 --> 00:01:30,550 | use cases that are selected so as to deal with |
| 00:01:30,550 --> 00:01:33,200 | the most important risks first. So if you have a |
| 00:01:33,200 --> 00:01:35,510 | set of use cases that you're considering, which means that |
| 00:01:35,510 --> 00:01:37,450 | you have a set of features that you need to |
| 00:01:37,450 --> 00:01:41,260 | implement, you will select for each iteration the most risky |
| 00:01:41,260 --> 00:01:44,720 | ones that you still haven't realized, and realize them in that |
| 00:01:44,720 --> 00:01:47,720 | iteration. And then continue in the following iterations with less and |
| 00:01:47,720 --> 00:01:50,980 | less risky ones. So basically what happens in the end is |
| 00:01:50,980 --> 00:01:52,960 | that essentially each iteration extends |
| 00:01:52,960 --> 00:01:52,960 | the functionality beyond the previous iteration. |