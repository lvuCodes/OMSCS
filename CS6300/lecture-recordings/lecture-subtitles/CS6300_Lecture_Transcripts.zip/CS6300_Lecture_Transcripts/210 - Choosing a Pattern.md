# CS6300 210 - Choosing a Pattern

| Timestamp | Content |
|-----------|---------|
| 00:00:00,150 --> 00:00:03,200 | But with so many patterns, how do we choose a pattern? So |
| 00:00:03,200 --> 00:00:05,970 | this is a possible approach that you can follow. First of all, you |
| 00:00:05,970 --> 00:00:09,140 | want to make sure that you understand your design context. You understand |
| 00:00:09,140 --> 00:00:12,800 | what you're designing and what are the issues involved with this design. What |
| 00:00:12,800 --> 00:00:15,200 | are the problems that you need to solve. At this point, you |
| 00:00:15,200 --> 00:00:17,160 | can examine the patterns catalog, or,if |
| 00:00:17,160 --> 00:00:18,750 | you're already familiar with the catalog, just |
| 00:00:18,750 --> 00:00:22,430 | think about the possible patterns that you could use. Once you identify |
| 00:00:22,430 --> 00:00:25,440 | the patterns that you can use, you also want to study them and |
| 00:00:25,440 --> 00:00:29,090 | study the related patterns. So normally if you look at any pattern catalog, |
| 00:00:29,090 --> 00:00:32,229 | for each pattern there will also be a list of related patterns. So |
| 00:00:32,229 --> 00:00:35,010 | you can also look at those to see whether maybe some of those |
| 00:00:35,010 --> 00:00:38,370 | might be more applicable. And finally, once you identify the pattern that you |
| 00:00:38,370 --> 00:00:41,360 | think is appropriate, you will apply that pattern. When you do that, just |
| 00:00:41,360 --> 00:00:44,850 | be mindful that there are pitfalls in the use of patterns. One obvious |
| 00:00:44,850 --> 00:00:47,490 | one is the fact that you might select the wrong pattern and make |
| 00:00:47,490 --> 00:00:50,460 | your design worse instead of better. The second one is that if you |
| 00:00:50,460 --> 00:00:52,560 | get too excited about patterns, then you |
| 00:00:52,560 --> 00:00:54,850 | might be abusing patterns, so just using too |
| 00:00:54,850 --> 00:00:56,370 | many patterns, and end up with a design |
| 00:00:56,370 --> 00:00:58,980 | that is more complicated rather than less complicated. |
| 00:00:58,980 --> 00:01:01,890 | So always be careful, spend the time to figure out which one is the right |
| 00:01:01,890 --> 00:01:03,577 | pattern to apply, and make sure that you |
| 00:01:03,577 --> 00:01:03,577 | don't use patterns that you don't actually need. |