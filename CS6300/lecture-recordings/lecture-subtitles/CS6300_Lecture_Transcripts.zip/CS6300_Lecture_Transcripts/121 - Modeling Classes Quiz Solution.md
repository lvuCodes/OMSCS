# CS6300 121 - Modeling Classes Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,120 --> 00:00:03,110 | Looking at the requirements, item is definitely a relevant element |
| 00:00:03,110 --> 00:00:07,060 | for my system, so it is appropriate to model item as |
| 00:00:07,060 --> 00:00:09,300 | a class. Sale, on the other hand, is more of |
| 00:00:09,300 --> 00:00:12,610 | a characteristic of an item, an attribute of an item, rather |
| 00:00:12,610 --> 00:00:14,960 | than a class in itself. So, we're not going to mark |
| 00:00:14,960 --> 00:00:18,460 | this one. Shopping cart sounds, as well, as an important element |
| 00:00:18,460 --> 00:00:21,550 | for my system. Time can be an important system in some |
| 00:00:21,550 --> 00:00:25,420 | contexts, but in this case we're measuring time just because more |
| 00:00:25,420 --> 00:00:28,430 | than one item at a time can be added to the shopping cart. |
| 00:00:28,430 --> 00:00:32,770 | So, time really doesn't have any reason for being modeled as a class. |
| 00:00:32,770 --> 00:00:36,550 | And finally, user also seems to also have an important role to play |
| 00:00:36,550 --> 00:00:36,550 | in the system, and therefore we will model user as a class as well. |