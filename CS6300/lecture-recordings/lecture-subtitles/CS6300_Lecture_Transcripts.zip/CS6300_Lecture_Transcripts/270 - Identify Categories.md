# CS6300 270 - Identify Categories

| Timestamp | Content |
|-----------|---------|
| 00:00:00,140 --> 00:00:02,980 | In the second step of the category partition technique, the goal is |
| 00:00:02,980 --> 00:00:05,630 | to Identify Categories. Where categories are |
| 00:00:05,630 --> 00:00:08,650 | characteristics of each input element. So |
| 00:00:08,650 --> 00:00:11,490 | let me illustrate what that means using an example. And to do |
| 00:00:11,490 --> 00:00:14,440 | that I'm going to use again the example of the split program, as |
| 00:00:14,440 --> 00:00:16,830 | we are already familiar with it and we kind of already played |
| 00:00:16,830 --> 00:00:20,110 | with it. When we were talking about the generic black box approach. |
| 00:00:20,110 --> 00:00:22,293 | So let me bring back the program, and let me remind you |
| 00:00:22,293 --> 00:00:25,440 | that what the program does is to take two inputs, a string and |
| 00:00:25,440 --> 00:00:28,560 | the size, and it breaks down the string into chunks, |
| 00:00:28,560 --> 00:00:31,300 | whose length is size. If we look at the split program |
| 00:00:31,300 --> 00:00:34,330 | there are two input elements, str and size so we going to |
| 00:00:34,330 --> 00:00:37,930 | identify categories for these two. So starting from str, what are |
| 00:00:37,930 --> 00:00:41,228 | the interesting characteristics of the string? In, in this step |
| 00:00:41,228 --> 00:00:44,948 | you're going to use your domain knowledge, your understanding of what a |
| 00:00:44,948 --> 00:00:47,986 | string is, and for example we might identify the length of |
| 00:00:47,986 --> 00:00:50,528 | the string and the content of the string as the two |
| 00:00:50,528 --> 00:00:53,840 | main characteristics that we want to focus on. If we now |
| 00:00:53,840 --> 00:00:57,540 | move our focus to size, the only characteristic I can really |
| 00:00:57,540 --> 00:01:00,340 | think of for an integer is its value. So that's what |
| 00:01:00,340 --> 00:01:02,470 | I'm going to mark here. So at the end of the step |
| 00:01:02,470 --> 00:01:05,030 | what we have is that we have two categories. So two |
| 00:01:05,030 --> 00:01:08,930 | interesting characteristics for the string input str, which are the length |
| 00:01:08,930 --> 00:01:12,940 | and the content. And one category for the integer input size |
| 00:01:12,940 --> 00:01:16,480 | which is its value. And notice that there's not only one solution. |
| 00:01:16,480 --> 00:01:18,200 | So there's not only one possibility. |
| 00:01:18,200 --> 00:01:20,384 | So that the specific characteristics that you |
| 00:01:20,384 --> 00:01:22,800 | will identify are somehow subjective. But the |
| 00:01:22,800 --> 00:01:25,630 | important point is that you identify characteristics |
| 00:01:25,630 --> 00:01:29,259 | that are meaningful and they sort of cover the main aspects of the |
| 00:01:29,259 --> 00:01:31,200 | inputs, which is the case for the |
| 00:01:31,200 --> 00:01:31,200 | categories that we've identified in this example. |