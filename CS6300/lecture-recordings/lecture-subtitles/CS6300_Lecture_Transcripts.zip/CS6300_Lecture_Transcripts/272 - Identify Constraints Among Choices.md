# CS6300 272 - Identify Constraints Among Choices

| Timestamp | Content |
|-----------|---------|
| 00:00:00,160 --> 00:00:02,080 | Something that we saw when we were looking at the split |
| 00:00:02,080 --> 00:00:05,760 | program before is that if we just combine the interesting values that |
| 00:00:05,760 --> 00:00:08,490 | we identify, we might end up with a lot of cases. |
| 00:00:08,490 --> 00:00:11,030 | And I mentioned that we, we're going to look at some way of |
| 00:00:11,030 --> 00:00:13,720 | addressing that problem. And this is exactly what happens in the |
| 00:00:13,720 --> 00:00:17,420 | next step of the category partition method, in which we identify constraints |
| 00:00:17,420 --> 00:00:20,510 | among choices. And why do we identify these constraints? We do |
| 00:00:20,510 --> 00:00:23,440 | that to eliminate meaningless combinations of |
| 00:00:23,440 --> 00:00:25,460 | inputs. If you remember, for example, |
| 00:00:25,460 --> 00:00:27,260 | we had the case in which we were trying to |
| 00:00:27,260 --> 00:00:30,110 | create a string with a size less than 0, which |
| 00:00:30,110 --> 00:00:32,930 | doesn't make any sense. And very importantly, we also do |
| 00:00:32,930 --> 00:00:37,070 | that to reduce the number of test cases. Because every time |
| 00:00:37,070 --> 00:00:40,930 | we constrain one of the possible choices, we eliminate possible |
| 00:00:40,930 --> 00:00:43,250 | test cases, so we can use it to keep under |
| 00:00:43,250 --> 00:00:45,960 | control the number of tests that we generate. There are |
| 00:00:45,960 --> 00:00:47,571 | three types of properties. The |
| 00:00:47,571 --> 00:00:50,610 | pair property...if, error properties, and properties |
| 00:00:50,610 --> 00:00:52,610 | of type single. So we're going to look at what these |
| 00:00:52,610 --> 00:00:56,230 | properties mean, using, once more, our example of the split program. |
| 00:00:56,230 --> 00:00:58,750 | In particular, we're going to use some of the choices that we |
| 00:00:58,750 --> 00:01:02,080 | identified earlier. So let's look, for example, at choice 0, for |
| 00:01:02,080 --> 00:01:04,599 | category length of the string. All we can say is that, |
| 00:01:04,599 --> 00:01:07,860 | if the length is 0, this define a special property of |
| 00:01:07,860 --> 00:01:11,160 | the string. And that was specified in this way by saying |
| 00:01:11,160 --> 00:01:15,610 | that this identifies property zerovalue. So every time that we use |
| 00:01:15,610 --> 00:01:19,080 | this choice, zerovalue is defined. At this point, we can use |
| 00:01:19,080 --> 00:01:20,550 | this to exclude some meaningless |
| 00:01:20,550 --> 00:01:23,170 | combinations. For instance, consider special characters. |
| 00:01:23,170 --> 00:01:25,130 | If we have a string of length 0, which means a |
| 00:01:25,130 --> 00:01:26,850 | string with no characters. Obviously, there |
| 00:01:26,850 --> 00:01:28,760 | cannot be special characters. So, considering |
| 00:01:28,760 --> 00:01:31,020 | this combination will just be a waste of time. So what |
| 00:01:31,020 --> 00:01:33,770 | we do is that we specify next to this choice, that we |
| 00:01:33,770 --> 00:01:36,360 | will only consider this if length is not 0. And we |
| 00:01:36,360 --> 00:01:41,110 | do this by saying that we consider this only if not zerovalue. |
| 00:01:41,110 --> 00:01:43,970 | So, if zerovalue is not defined. So this pair is an |
| 00:01:43,970 --> 00:01:47,640 | example of a property...if case. Define a property and use that |
| 00:01:47,640 --> 00:01:49,770 | property. Now let's look at a case in which we might |
| 00:01:49,770 --> 00:01:52,580 | want to use an error property. For instance, when we look at |
| 00:01:52,580 --> 00:01:56,480 | the category value for the input size, the choice value less |
| 00:01:56,480 --> 00:01:59,510 | than 0 is an erroneous choice. So it's a choice that |
| 00:01:59,510 --> 00:02:02,630 | we selected to test a possibly erroneous situation, so we can |
| 00:02:02,630 --> 00:02:06,160 | mark this as an error property. And what that means is that |
| 00:02:06,160 --> 00:02:09,949 | when generating a combination of choices, we will consider this only |
| 00:02:09,949 --> 00:02:12,990 | once because we assume that we just want to test this error condition |
| 00:02:12,990 --> 00:02:16,260 | once. Finally, the single property is a property that we use |
| 00:02:16,260 --> 00:02:19,050 | when we want to limit the number of test cases. And it's |
| 00:02:19,050 --> 00:02:21,900 | similar as an effect to error. It just has a different |
| 00:02:21,900 --> 00:02:24,410 | meaning. So what we do when we use the single property is |
| 00:02:24,410 --> 00:02:27,420 | that we're saying that this choice, we want to use in only |
| 00:02:27,420 --> 00:02:31,120 | one combination. So don't combine it multiple times. And that, of course, |
| 00:02:31,120 --> 00:02:34,260 | given the combinatorial nature of the problem, cuts down dramatically |
| 00:02:34,260 --> 00:02:36,370 | the number of test cases. And we might use, for |
| 00:02:36,370 --> 00:02:39,500 | instance, the single property for maxint, which means that we |
| 00:02:39,500 --> 00:02:41,890 | will only have one test case in which the size is |
| 00:02:41,890 --> 00:02:44,300 | equal to maxint. We're actually going to see a demo |
| 00:02:44,300 --> 00:02:46,880 | on this topic so we'll have more chances of seeing how |
| 00:02:46,880 --> 00:02:49,370 | properties work in practice and how good they are at |
| 00:02:49,370 --> 00:02:49,370 | eliminating meaningless combinations and at reducing the number of test cases. |