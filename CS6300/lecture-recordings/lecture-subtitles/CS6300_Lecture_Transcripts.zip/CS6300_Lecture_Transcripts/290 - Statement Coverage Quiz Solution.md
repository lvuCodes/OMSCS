# CS6300 290 - Statement Coverage Quiz Solution

| Timestamp | Content |
|-----------|---------|
| 00:00:00,210 --> 00:00:01,900 | To get the answer to this question, I'm |
| 00:00:01,900 --> 00:00:03,540 | going to ask you to be a little patient, and |
| 00:00:03,540 --> 00:00:05,120 | to wait until the end of the lesson. |
| 00:00:05,120 --> 00:00:06,792 | Because there are a couple of more topics that |
| 00:00:06,792 --> 00:00:08,244 | I want to cover, before I actually get in |
| 00:00:08,244 --> 00:00:10,210 | to this. Nevertheless, I wanted to ask you right |
| 00:00:10,210 --> 00:00:11,880 | away, because I wanted you to think about |
| 00:00:11,880 --> 00:00:11,880 | this, before you see the rest of the lesson. |